/**
 * A catalog built from what an npm registry actually holds.
 *
 * Every other catalog source in this market is a document somebody wrote:
 * the curated list, a catalog package, a file on the operator's machine. All
 * three have the same weakness in an intranet deployment — the catalog is a
 * second thing to keep in step with the registry, and it goes stale the
 * moment someone publishes a plugin without also editing it. The user then
 * sees a market that lists a plugin the registry no longer has, or does not
 * list one it just received.
 *
 * An intranet registry is already the authoritative list: it is where the
 * packages were uploaded. So this reads the registry itself. Two steps:
 *
 * 1. Ask the registry which packages it has. `/ -/v1/search` and `/-/all` are
 *    the npm-standard endpoints; a read-only snapshot that implements
 *    neither can still answer `/-/ping` with its selection, which is the
 *    convention our own offline bundle uses.
 * 2. Read each package's own manifest and keep the ones that are DSH
 *    plugins. This is the step that makes the result usable: an intranet
 *    registry carries the plugins' DEPENDENCIES too — pnpm itself, the
 *    @babel/* tree, every transitive library — and listing those as
 *    installable plugins would bury thirteen entries under several hundred.
 *
 * The discriminator is the `dsh` field in package.json, which every plugin
 * carries and no ordinary library does (verified against all thirteen
 * packages in the Windows offline bundle: the field is present on each, and
 * on none of their dependencies). `keywords` alone is not enough — several
 * plugins ship `keywords: []`, so a keyword rule would silently hide them.
 *
 * Nothing here caches. The registry is asked on every load for the same
 * reason the file source is re-read: a plugin uploaded this morning is
 * exactly the case this source exists to show, and a cached listing would
 * report it as absent.
 */
import type { Registry } from './registry.ts';
/**
 * The catalog, read out of a registry.
 *
 * `names` short-circuits discovery: an operator who states the plugin list
 * gets exactly that list, in that order, and nothing is filtered out — the
 * statement is theirs. Without it, the registry is asked and the `dsh` field
 * decides.
 *
 * @throws when the registry cannot be asked, when it names no packages, or
 * when none of the packages it names is a plugin — three different
 * situations with three different things for the operator to fix, so the
 * message says which one happened.
 */
export declare function catalogFromRegistry(registry: string, names?: readonly string[] | null): Promise<Registry>;
