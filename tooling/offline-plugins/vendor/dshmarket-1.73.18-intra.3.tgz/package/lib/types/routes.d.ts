/**
 * HTTP routes bridging the browser market UI to the host. This layer only
 * parses requests, calls the service modules, and serializes responses —
 * process spawning lives in dsh-cli.ts, filesystem reads in profile.ts,
 * orchestration in install.ts / themes.ts / updates.ts.
 *
 * Security: the install route executes a shell command, so it accepts only
 * same-origin POSTs and only sources present in the curated registry.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import { type PluginCommandRuntime } from './dsh-cli.ts';
import { type AgentsLookup } from './agents.ts';
import { type Channel } from './channels.ts';
import { type CatalogSource, type Region } from './regions.ts';
import { type LoaderEntry } from './themes.ts';
export type { LoaderEntry } from './themes.ts';
export type { UpdateStatus } from './updates.ts';
/**
 * Why an install cannot happen on this network, or null when it can.
 *
 * Intranet mode does not narrow the catalog: the operator's own listing is
 * the catalog, and it may legitimately include a plugin whose only published
 * artifact is a GitHub release. What it narrows is the transport — a registry
 * name is installed from `npmRegistry`, a tarball URL from wherever the
 * catalog points, and nothing else has a host this network can reach.
 *
 * Judged by the target pnpm would be given, not by the entry's `url`: an
 * entry whose `npm` field is set installs from the registry even though its
 * catalog URL is a GitHub repository, and refusing that would take away the
 * exact plugins an operator took the trouble to republish.
 */
export declare function offlineInstallRefusal(target: string): string | null;
export interface WebServerService {
    register(route: {
        kind: 'exact' | 'prefix';
        path: string;
        handler: (request: IncomingMessage, response: ServerResponse) => void | Promise<void>;
    }): () => void;
}
export interface MarketHost {
    webServer: WebServerService;
    loader: {
        entries(): Iterable<LoaderEntry>;
    };
    plugin(plugin: unknown, config: unknown): {
        await(): Promise<unknown>;
        dispose(): Promise<unknown> | void;
    };
    on?(event: string, callback: (payload: unknown) => void): () => void;
    logger?: {
        info?(message: string): void;
        warn(message: string): void;
    };
}
/**
 * A host that owns activation for the whole composition.
 *
 * Some hosts watch the profile and replay it the moment the manifest lands
 * (measured against a bun-hmr watcher), which makes the market's own hot
 * mount a SECOND loader entry for an id the live composition already serves:
 * duplicate prefix routes, and a "restart required" verdict for a plugin that
 * is already up. Where the host publishes this bridge, the market asks it to
 * replay and reports what it answers, instead of mounting on its own.
 *
 * Optional by construction: absent on every host without the capability, and
 * named with `pluginActivation?` so a host that only knows `current` keeps
 * working unchanged.
 */
export interface HostPluginActivation {
    activate(): Promise<{
        ok: true;
    } | {
        ok: false;
        error: string;
    }>;
}
export interface MarketConfig {
    /** Profile the market installs into; matches the profile serving this UI. */
    profile: string;
    /** Host-authoritative profile directory; ordinary DSH derives it from DSH_HOME. */
    profileDirectory?: string;
    /** Installation-owned bundles live beside this host, outside the Desktop profile. */
    dshInstallDir?: string;
    /**
     * Whether a DSH Desktop shell serves this process — the shell owns the
     * window and the process lifecycle, which is what the capability bits mean
     * by "desktop".
     *
     * Kept separate from `profileDirectory` on purpose: since #639 the dsh
     * launcher hands every profile its own directory, so an explicit directory
     * no longer tells a desktop shell apart from an ordinary `dsh` run.
     */
    desktopHost?: boolean;
    /**
     * How long to wait for the host's own replay of a fresh install before
     * hot-mounting it (#814). A desktop shell that watches the profile replays
     * the composition itself, about two seconds after the manifest lands; one
     * that does not publish `pluginActivation` gives the market no way to ask,
     * and mounting first made the host's replay fail as a duplicate. Unset,
     * the wait follows the host's own profile watcher instead (#827).
     */
    hostReplayWaitMs?: number;
    /** Detached self-restart is unsafe under systemd/launchd/pm2; operators can disable it (#14). */
    allowRestart?: boolean;
    /** Which release channel the market offers ITSELF from; other plugins never follow it. */
    channel?: Channel;
    /** Which mirrors every outbound request uses; undefined until decided. */
    region?: Region;
    /**
     * An npm registry the operator's own network serves — an internal mirror,
     * Verdaccio, Nexus — or undefined to use the region's own table.
     *
     * The region table's two entries are npm itself and a public mirror, and an
     * internal network reaches neither. This is how that network says "packages
     * come from here", and it moves every registry request with it: catalog,
     * latest/version lookups, tarball downloads, the self-update spec, and the
     * registry a spawned pnpm is given. Ignored when it is not a plain http(s)
     * base URL; `DSHM_NPM_MIRROR` outranks it.
     */
    npmRegistry?: string;
    /**
     * Intranet deployment: this network serves its own packages and reaches
     * nothing else.
     *
     * Everything the market does that needs the public internet — the catalog
     * origin, README and screenshot images, release manifests, giscus
     * comments, Gist backups — becomes unreachable, and the difference this
     * flag makes is whether that shows up as a fifteen-second timeout per
     * request or as one immediate, explanatory failure. Off, nothing changes.
     *
     * It does NOT stop installs: those go to `npmRegistry`, which on this
     * deployment is the point. It does refuse a plugin whose only source is
     * GitHub, because no configuration can make that install succeed here and
     * a pnpm that hangs for fifteen minutes is the worst way to find out.
     */
    offline?: boolean;
    /**
     * Where the catalog is, when it is not the public one — an intranet URL or
     * a path to a `plugins.json` on this machine (`file://` also accepted).
     *
     * This is the single most important setting in an air-gapped deployment:
     * with it, the market lists what the operator published; without it, the
     * market only knows the public catalog it cannot reach. Defaults to the
     * registry's own `dsh-plugin-catalog` package when that is enough.
     */
    catalog?: string;
    /**
     * The packages that are plugins, when the market should not decide.
     *
     * Only read when the catalog is the registry itself (`offline` with no
     * `catalog`): every other catalog source states what it holds. Without
     * this the registry is filtered by the `dsh` field in each package's
     * manifest — the marker every plugin carries and no library does. Name the
     * list here for a deployment whose plugins predate that marker, or to fix
     * the order they appear in. Stating it also disables the filter: the
     * operator's list is a statement, not a hint.
     */
    plugins?: string[];
    /** Snapshots retained per profile (issue #98); defaults to DEFAULT_MAX_SNAPSHOTS. */
    maxSnapshots?: number;
    /**
     * Environment variables pinned for plugin build/install commands (issue
     * #336): the compiler (CC/CXX) or anything else a native build reads, for
     * hosts whose dsh process cannot inherit a shell environment. These may
     * override values the parent process inherited, but never the PATH or CI
     * the market computes for its children.
     */
    buildEnv?: Record<string, string>;
    /**
     * Where `profile` came from, for the exported log (#744). Not used for any
     * decision: it exists because "why did the market think this was the web
     * profile" stalled an investigation for want of exactly this line.
     */
    origin?: {
        /** Which source named the profile. */
        profileSource: string;
        /** The launcher's `profileContext` as the market saw it at start. */
        launcherAtStart: string;
        /**
         * The same, read again now. Absent at start but present later means the
         * service arrived after the market mounted (timing); absent both times
         * means the market cannot see it at all (scope) — the two causes need
         * different fixes, and only a live read tells them apart.
         */
        launcherNow: () => string;
    };
}
/**
 * A catalog location as a human reads it — for the boot log and the status
 * payload, never for routing.
 *
 * The distinction matters in a bug report from an intranet deployment: "the
 * catalog is /opt/dsh/plugins.json" and "the catalog is a package on
 * http://npm.corp" fail for entirely different reasons, and the operator
 * cannot tell which one this process is using from a page that just says
 * "catalog unavailable".
 */
export declare function describeCatalogSource(source: CatalogSource): string;
export declare function marketVersion(): string;
/**
 * Register the market's HTTP routes.
 * @param host - Acquired webServer + shell services.
 * @param config - Validated market configuration.
 * @returns Disposer removing every registered route.
 */
export declare function mountMarketRoutes(host: MarketHost, config: MarketConfig, commandRuntime?: PluginCommandRuntime, agentsLookup?: AgentsLookup, hostActivation?: HostPluginActivation): () => void;
