window.__ModuleLoader__.load({ id: "dshmarket", factory: (require) => {


		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		//#region \0rolldown/runtime.js
		var __create = Object.create;
		var __defProp = Object.defineProperty;
		var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
		var __getOwnPropNames = Object.getOwnPropertyNames;
		var __getProtoOf = Object.getPrototypeOf;
		var __hasOwnProp = Object.prototype.hasOwnProperty;
		var __copyProps = (to, from, except, desc) => {
			if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
				key = keys[i];
				if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
					get: ((k) => from[k]).bind(null, key),
					enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
				});
			}
			return to;
		};
		var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
			value: mod,
			enumerable: true
		}) : target, mod));
		//#endregion
		let react = require("react");
		let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
		_deepseek_ai_dsh_client_ui_primitives = __toESM(_deepseek_ai_dsh_client_ui_primitives, 1);
		let react_jsx_runtime = require("react/jsx-runtime");
		let react_dom = require("react-dom");
		//#region src/client/icons.ts
		/**
		* Each entry: the name this package imports, then the 0.1.7+ Regular export,
		* then the pre-0.1.7 size-suffixed export.
		*/
		const ICON_ALIASES = [
			[
				"IconCheckOutline16",
				"IconCheckOutlineRegular",
				"IconCheckOutline16"
			],
			[
				"IconChevronDownOutline14",
				"IconChevronDownOutlineRegular",
				"IconChevronDownOutline14"
			],
			[
				"IconChevronLeftOutline14",
				"IconChevronLeftOutlineRegular",
				"IconChevronLeftOutline14"
			],
			[
				"IconChevronRightOutline14",
				"IconChevronRightOutlineRegular",
				"IconChevronRightOutline14"
			],
			[
				"IconChevronUpOutline14",
				"IconChevronUpOutlineRegular",
				"IconChevronUpOutline14"
			],
			[
				"IconCodeOutline16",
				"IconCodeOutlineRegular",
				"IconCodeOutline16"
			],
			[
				"IconCopyOutline16",
				"IconCopyOutlineRegular",
				"IconCopyOutline16"
			],
			[
				"IconCordisPluginOutline14",
				"IconCordisPluginOutlineRegular",
				"IconCordisPluginOutline14"
			],
			[
				"IconDownloadOutline16",
				"IconDownloadOutlineRegular",
				"IconDownloadOutline16"
			],
			[
				"IconFolderOpen16",
				"IconFolderOpenRegular",
				"IconFolderOpen16"
			],
			[
				"IconFullscreenOutline16",
				"IconFullscreenOutlineRegular",
				"IconFullscreenOutline16"
			],
			[
				"IconLinkOutline14",
				"IconLinkOutlineRegular",
				"IconLinkOutline14"
			],
			[
				"IconLoadingOutline16",
				"IconLoadingOutlineRegular",
				"IconLoadingOutline16"
			],
			[
				"IconQuestionOutline14",
				"IconQuestionOutlineRegular",
				"IconQuestionOutline14"
			],
			[
				"IconRefreshOutline14",
				"IconRefreshOutlineRegular",
				"IconRefreshOutline14"
			],
			[
				"IconSearchOutline16",
				"IconSearchOutlineRegular",
				"IconSearchOutline16"
			],
			[
				"IconSparkle16",
				"IconSparkleRegular",
				"IconSparkle16"
			],
			[
				"IconWarningOutline16",
				"IconWarningOutlineRegular",
				"IconWarningOutline16"
			]
		];
		/**
		* True for a value React will accept as an element type. Plain functions are
		* the common case today; memo / forwardRef wrappers are objects tagged with
		* $$typeof and must not be treated as "missing".
		*/
		function isIconComponent(value) {
			if (typeof value === "function") return true;
			if (typeof value !== "object" || value === null) return false;
			return typeof value.$$typeof === "symbol";
		}
		/**
		* Read one name out of a primitives-shaped table. A strict namespace proxy may
		* throw on unknown keys; that must not be what blanks the market.
		*/
		function fromHost(mod, name) {
			try {
				return mod[name];
			} catch {
				return;
			}
		}
		/** Resolve one icon from a primitives-shaped module; null when both names are absent. */
		function resolveIcon(mod, newer, older) {
			const candidate = fromHost(mod, newer) ?? fromHost(mod, older);
			return isIconComponent(candidate) ? candidate : null;
		}
		/**
		* Names for which neither the 0.1.7 nor the pre-0.1.7 export exists.
		* Informational — apply() does not disable the market for these; pickIcon
		* renders nothing instead so a rename costs one glyph, not the page.
		*/
		function missingIcons(mod) {
			const gaps = [];
			for (const [stable, newer, older] of ICON_ALIASES) if (resolveIcon(mod, newer, older) === null) gaps.push(stable);
			return gaps;
		}
		/** Rendered when a host exports neither spelling — see the module comment. */
		function renderNothing() {
			return null;
		}
		function pickIcon(newer, older) {
			const resolved = resolveIcon(_deepseek_ai_dsh_client_ui_primitives, newer, older);
			if (resolved === null) {
				console.warn(`[dsh-market] host ui-primitives missing ${newer} / ${older} — icon skipped`);
				return renderNothing;
			}
			return resolved;
		}
		const IconCheckOutline16 = pickIcon("IconCheckOutlineRegular", "IconCheckOutline16");
		const IconChevronDownOutline14 = pickIcon("IconChevronDownOutlineRegular", "IconChevronDownOutline14");
		const IconChevronLeftOutline14 = pickIcon("IconChevronLeftOutlineRegular", "IconChevronLeftOutline14");
		const IconChevronRightOutline14 = pickIcon("IconChevronRightOutlineRegular", "IconChevronRightOutline14");
		const IconChevronUpOutline14 = pickIcon("IconChevronUpOutlineRegular", "IconChevronUpOutline14");
		const IconCodeOutline16 = pickIcon("IconCodeOutlineRegular", "IconCodeOutline16");
		const IconCopyOutline16 = pickIcon("IconCopyOutlineRegular", "IconCopyOutline16");
		const IconCordisPluginOutline14 = pickIcon("IconCordisPluginOutlineRegular", "IconCordisPluginOutline14");
		const IconDownloadOutline16 = pickIcon("IconDownloadOutlineRegular", "IconDownloadOutline16");
		const IconFolderOpen16 = pickIcon("IconFolderOpenRegular", "IconFolderOpen16");
		const IconFullscreenOutline16 = pickIcon("IconFullscreenOutlineRegular", "IconFullscreenOutline16");
		const IconLinkOutline14 = pickIcon("IconLinkOutlineRegular", "IconLinkOutline14");
		const IconLoadingOutline16 = pickIcon("IconLoadingOutlineRegular", "IconLoadingOutline16");
		const IconQuestionOutline14 = pickIcon("IconQuestionOutlineRegular", "IconQuestionOutline14");
		const IconRefreshOutline14 = pickIcon("IconRefreshOutlineRegular", "IconRefreshOutline14");
		const IconSearchOutline16 = pickIcon("IconSearchOutlineRegular", "IconSearchOutline16");
		const IconSparkle16 = pickIcon("IconSparkleRegular", "IconSparkle16");
		const IconWarningOutline16 = pickIcon("IconWarningOutlineRegular", "IconWarningOutline16");
		//#endregion
		//#region src/client/locales.ts
		/** zh/en/ja dictionaries for the Market settings section and install toast. */
		const zh = {
			nav: "插件市场",
			setCardDesc: "查看插件市场版本与设置。",
			setSelfUpToDate: "已是最新版本",
			setSelfUpdateReady: "有新版本",
			setSelfUpdateHint: "更新会下载新版本，重启后生效。",
			setSelfUpToDateHint: "",
			setSelfHostManagedHint: "这份市场由桌面端安装，新版本请在桌面端更新。",
			setSelfUpdate: "更新",
			setSelfUpdatedHint: "已下载完成。重启 DeepSeek Harness 后新版本才会生效——页面会先显示新版本号。",
			setSidebar: "侧栏入口",
			setSidebarHint: "在侧栏「插件」下方显示市场。",
			setSidebarOnlyDoorHint: "这个宿主没有市场设置页，这一行是唯一的入口，不能关闭。",
			setAdvanced: "高级",
			setAdvancedHint: "控制市场在界面中的入口。至少保留一个。",
			setEntrySection: "设置页入口",
			setEntrySectionHint: "在设置中显示插件市场分区。",
			setEntryPluginsTab: "插件页入口",
			setEntryPluginsTabHint: "在插件页「已安装」旁显示插件市场页签。",
			setEntryLastDoorHint: "至少保留一个入口；这是当前唯一可用的入口。",
			setEntryShow: "显示",
			setEntryHide: "不显示",
			setIndexSource: "官方 Discover 索引",
			setIndexSourceHint: "dsh 0.2.1 起，官方的「插件 → 发现 → 索引源」可以添加 https://cdn.jsdelivr.net/npm/dsh-plugin-catalog/index.json —— 官方发现页和 plugin_market 智能体工具会搜索同一份目录。",
			setSidebarOn: "显示",
			setSidebarOff: "不显示",
			sidebarTip: "想更快打开？可在侧栏显示。",
			sidebarTipDismiss: "不再提示",
			setRegion: "下载区域",
			setRegionGlobal: "全球",
			setRegionChina: "中国大陆",
			setRegionGlobalHint: "从 npm 和 GitHub 官方源下载。",
			setRegionChinaHint: "中国大陆访问更快。仅改变下载线路，插件来源不变。",
			setRegionAuto: "已根据网络状况自动选择，可随时切换。",
			setGithubProxy: "GitHub 加速",
			setGithubProxyAutoHint: "自动选择可用线路，失败时才切换。",
			setGithubProxyCustom: "自定义",
			setGithubProxyCustomHint: "优先使用自定义线路，失败后仍会尝试直连。",
			setGithubProxyManagedHint: "由环境变量 DSHM_GITHUB_PROXY 管理，界面中不可修改。",
			setGithubProxyEdit: "编辑",
			setGithubProxyAuto: "恢复自动",
			setGithubProxyInput: "HTTPS 加速前缀",
			setGithubProxySave: "保存",
			setBuildEnv: "构建环境变量",
			setBuildEnvHint: "作用于市场启动的每个进程（安装、编译、git 等），不只是编译器。每行一个 KEY=value，例如 CC=/usr/bin/gcc-11；PATH 和 CI 由市场管理。留空保存即恢复原有配置。",
			setBuildEnvSave: "保存环境变量",
			setChannel: "更新通道",
			setChannelStable: "稳定版",
			setChannelBeta: "Beta",
			setChannelStableHint: "仅接收正式发布版本。",
			setChannelBetaHint: "提前获取待验证版本，可能不稳定。仅影响插件市场自身。",
			setChannelDev: "开发版",
			setChannelDevHint: "开发分支构建，未经验证，不建议普通用户使用。",
			setChannelSwitch: "切换至",
			setChannelSwitchHint: "该版本低于当前已安装版本。",
			setSelfRemove: "卸载插件市场",
			setSelfRemoveHint: "从这个 profile 卸载市场。已装的其它插件不受影响。",
			setSelfRemoveRemote: "这个页面不是从本机打开的，市场没法从这里卸载自己。请到运行 DSH 的那台机器上移除：桌面端用「设置 → 插件」，其它环境用命令行。",
			setSelfConfirm: "确定要卸载插件市场吗？卸载后需使用命令行重新安装。",
			setSelfPurge: "同时清除市场自己的数据",
			setSelfPurgeOn: "将删除：市场的停用清单与自定义分组，以及它写进配置文件的停用记录——被停用的插件将恢复运行。不涉及密码或密钥，市场从不把它们存在磁盘上。",
			setSelfPurgeOff: "保留市场数据。注意：被市场停用的插件会保持停用，且移除后将没有界面可将其重新启用。",
			setSelfRemoveConfirm: "确认卸载",
			setSelfCancel: "取消",
			setSelfWorking: "正在卸载…",
			setSelfRemoved: "已卸载",
			setSelfRemovedHint: "重启 DeepSeek Harness 后完全清理。",
			setSelfFailed: "操作失败",
			versionHint: "插件市场版本 — 反馈问题时请附上",
			offlineBadge: "内网离线",
			offlineHint: "内网离线模式：只从内部 npm 源安装插件，目录由运维提供。评论、截图与 GitHub 链接不可用。",
			subtitle: "发现社区为 DeepSeek Harness 开发的插件",
			submitPlugin: "申请收录插件 ↗",
			descExpand: "展开",
			descCollapse: "收起",
			descMore: "展开全部",
			searchPh: "搜索插件，例如：通知、终端、记忆…",
			searchFavoritesPh: "搜索收藏…",
			clearSearch: "清除搜索",
			capabilityTitle: "它会做什么",
			capabilityAhead: "安装后它可以",
			capabilityCount: "{0} 项",
			capabilityCountUncommon: "{0} 项，{1} 项在已扫描插件里较少出现",
			capabilityUncommonLegend: "实心的项在已扫描的插件里较少出现",
			capGroupFiles: "文件与环境",
			capGroupNetwork: "网络",
			capGroupRun: "执行",
			capGroupKeys: "密钥",
			capGroupHost: "DSH 内部",
			capGroupOther: "其他",
			capShell: "能运行命令",
			capFsRead: "会读取本机文件",
			capFsWrite: "会写入本机文件",
			capNetwork: "会联网",
			capCredentials: "会用你的密钥",
			capEnv: "会读你的环境变量",
			capLlm: "会调用 AI 模型",
			capSubagent: "会自己开任务干活",
			capDynamicCode: "会在运行时执行拼出来的代码",
			capHostRuntime: "用到 DSH 宿主内部的包",
			capInstallScript: "安装时就会运行代码",
			capabilityNone: "没有扫描到。这不等于安全。",
			capabilityUnchecked: "还没有扫描结果",
			capabilityNote: "静态扫描只能证明「有」，不能证明「没有」。这不代表它安全。",
			capabilityScannedAt: "扫描于 {0}",
			capRedCredentialsNetwork: "会联网，并用到你的密钥",
			capRedPlaintextHttp: "有连接没有加密（{0}）",
			/** The families the scanner can emit (#401): one translation per rule. */
			capRedLiteralIp: "会直接连接固定 IP 地址（{0}）",
			capRedInstallScript: "安装时会立刻运行它自带的脚本，不需要你打开插件",
			capRedInstallScriptScripts: "安装时会立刻运行 {0}，不需要你打开插件",
			capRedCoreTamper: "会改动 DSH 自带的组件",
			capRedCoreTamperDetail: "会改动 DSH 自带的组件（{0}）",
			capRedCoreOverride: "会覆盖 DSH 自带的组件（{0}）",
			capRedCoreDisable: "会禁用 DSH 自带的组件（{0}）",
			favoriteAdd: "加入收藏",
			favoriteRemove: "取消收藏",
			favoritesEmpty: "还没有收藏。在「发现」或「主题」里点书签图标，或在「已安装」的「···」里加入收藏。",
			favoritesResultCount: "共 {0} 个收藏",
			favoritesPluginsSection: "插件（{0}）",
			favoritesThemesSection: "主题（{0}）",
			favoritesStaleEmpty: "收藏的条目已不在目录中。",
			favoritesStaleNote: "{0} 个收藏已不在目录中",
			favoritesClearStale: "清除失效收藏",
			favoritesClearingStale: "清除中…",
			blockAdd: "屏蔽",
			blockRemove: "取消屏蔽",
			blockMoved: "已从发现页移出。在「已安装」后面的「已屏蔽」里可以取消。",
			blockedTabHint: "这些插件不在发现页显示，全部更新也会跳过。",
			blockedFilteredEmpty: "匹配的插件在「已屏蔽」标签里。",
			blockedEmpty: "还没有屏蔽任何插件。",
			blockFailed: "无法更新屏蔽列表，请重试。",
			tabDiscover: "发现",
			tabFavorites: "收藏",
			tabInstalled: "已安装",
			tabBlocked: "已屏蔽",
			tabAdvanced: "高级",
			all: "全部",
			install: "安装",
			installing: "安装中…",
			installedBadge: "✓ 已安装",
			alreadyInstalled: "✓ 已安装",
			restartBanner: "项变更需重启 DeepSeek Harness 后生效",
			uninstall: "卸载",
			confirmRemove: "确认卸载？",
			uninstalling: "卸载中…",
			uninstallConfirmDesc: "将从当前 profile 中移除该插件。",
			uninstallLibraryConfirmDesc: "删除这个依赖库后，使用它的插件可能无法启动。",
			restartHint: "重启方式：关闭当前 dsh 进程后重新运行（例如 dsh web）",
			restartHintSupervised: "本进程是 {0} 服务的主进程，重启交给它负责——市场自己重启会连带杀掉 cgroup 里的接管进程，服务将起不来。请执行 systemctl restart <你的 unit>。确认你的配置能承受市场自行重启（如 KillMode=process），可在本插件配置里手动打开「允许重启」。",
			restartHintDebugged: "当前 dsh 进程正被调试器连接。请从 IDE 或终端停止该进程后重新启动，市场不能从界面里结束正在调试的 dsh。",
			restartHintViaProxy: "你是通过代理或网关访问的，出于安全，重启只接受本机直连。请在运行 dsh 的机器上重启它，例如 docker restart 或 kubectl rollout restart。",
			confirmTitle: "安装",
			confirmWarn: "社区第三方插件，构建脚本默认不运行。",
			installCaution: "安装前请注意",
			terminalCautionTitle: "可能不适用于网页版",
			terminalCautionBody: "这是终端插件，网页版里可能用不了。",
			terminalCautionStartup: "也可能让 DeepSeek Harness 起不来。",
			terminalCautionLink: "先看使用说明 ↗",
			cancel: "取消",
			empty: "没有匹配的插件",
			clearFilters: "清除筛选",
			installedEmpty: "尚未安装社区插件，可前往「发现」页浏览",
			marketGoneTitle: "插件市场已停止运行",
			marketGoneBody: "DSH 重新加载插件时把市场一起卸载了。重启 DSH 即可恢复；刚才的操作可能已经完成。",
			marketGoneRecord: "市场被 DSH 卸载了，这次操作没有等到结果。市场恢复后，到「已安装」里确认。",
			marketGoneReconnecting: "正在重新连接…",
			marketGoneReconnect: "重新连接",
			loadFail: "插件目录加载失败，请稍后重试",
			loadRetry: "重试",
			installFail: "安装失败",
			viewSource: "源码",
			refreshBanner: "项变更，刷新后生效",
			refresh: "刷新页面",
			update: "更新",
			updating: "更新中…",
			updated: "✓ 已更新，重启后生效",
			cancelOp: "取消",
			cancelled: "已取消",
			busyWait: "另一个安装、更新或卸载还在进行，请等它完成后再试",
			agentBusyUpdate: "有 Agent 正在运行，请等它完成或先取消，再更新——更新会直接替换插件文件，运行中的 Agent 可能中途报错或新旧版本混用。",
			agentBusyInstall: "有 Agent 正在运行，请等它完成或先取消，再安装——安装会改动插件文件，运行中的 Agent 可能中途报错。",
			agentBusyQueued: "Agent 正忙，已排队，空闲后自动安装（可在右上角「任务」里取消）。",
			agentBusyUpdateQueued: "Agent 正忙，已排队，空闲后自动更新（可在右上角「任务」里取消）。",
			agentBusyUninstallQueued: "Agent 正忙，已排队，空闲后自动卸载（可在右上角「任务」里取消）。",
			queuedRunBlocked: "有 {0} 个会话正在运行，现在还不能执行：这类操作会直接替换插件文件，运行中的 Agent 可能中途报错。它们空闲后会自动开始（也可以先在「任务」里取消这一条）。",
			queuedRunBusy: "另一个安装、更新或卸载还在进行，现在还不能开始：这一条留在队列里，等它完成后会自动开始，不需要再点一次。",
			queuedInstallGone: "这一条要装的插件在当前目录里找不到了（目录刷新过或换了页），已从队列移除。请在目录里重新找到它再装一次。",
			agentQueueStaleGone: "排队时它还在已安装列表里，现在已不在，因此跳过（没有卸载）。",
			agentQueueStaleNoUpdate: "排队时它有可用更新，现在没有了，已跳过。",
			queuedBadge: "排队中",
			agentDrainBadge: "等待 Agent",
			agentDrainWaiting: "等待 {0} 个 Agent 到达安全点…",
			agentDrainShowAgents: "查看正在运行的会话",
			agentDrainVerifying: "正在验证结果…",
			agentDrainCancelled: "已取消。",
			agentDrainRestarted: "宿主在这次操作完成前重启了，它已取消。需要的话请重新发起。",
			agentDrainHistoryDone: "上次排队的操作已完成。",
			agentDrainHistoryFailed: "上次排队的操作失败了（{0}）。请检查「已安装」或导出的日志。",
			agentDrainHistoryFailedShort: "上次排队的操作失败了。请检查「已安装」或导出的日志。",
			agentDrainHistoryCancelled: "上次排队的操作已取消。",
			favoriteFailed: "收藏失败，请稍后重试",
			favoriteUnavailable: "收藏功能暂不可用。请刷新页面或重启 dsh web。",
			favoriteBusy: "插件操作未结束，收藏未保存，请稍后重试",
			compatRiskBanner: "检测到兼容性风险，建议重启前到诊断页处理，或回滚本次操作。",
			compatRiskBannerNoRollback: "检测到兼容性风险，建议重启前到诊断页处理。",
			shadowNameBanner: "此操作后，同一个插件名出现在两处（仅供参考，不算冲突）：",
			brokenBundleBanner: "下列插件的界面文件已损坏，刷新后页面可能空白，建议回滚：",
			goDiagnose: "查看诊断",
			rollbackNow: "回滚",
			rollingBack: "回滚中…",
			rollbackUnavailable: "无法确认更新前的准确来源，自动回滚不可用。",
			approveBuilds: "允许构建脚本并重试",
			buildsSkipped: "该插件需要运行构建脚本才能工作，出于安全考虑已默认阻止。确认来源可信后，可放行并重新安装：",
			restartNow: "立即重启",
			dismiss: "关闭提示",
			dismissNotice: "关闭此提示",
			restarting: "正在重启…",
			restartFail: "重启失败",
			restartTimeout: "等待 DeepSeek Harness 启动超时",
			updateNow: "立即更新",
			updateFail: "更新失败",
			upToDate: "已是最新",
			updateHeldTag: "新版等待中",
			updateHeldTarget: "最新版 {0} 刚发布，还要约 {1} 小时。先更新到 {2}。",
			updateHeldTargetUnknown: "最新版 {0} 的发布时间暂不确定，还需等待。先更新到 {2}。",
			updateHeldHint: "这个 profile 要求新版本发布满一段时间才允许安装，大约还要 {1} 小时。",
			updateHeldEstimatedHint: "新版本已经出现在 /latest，但镜像的完整信息还没同步，所以先不提供更新；大约 {1} 分钟后会重新检查。",
			newerPrereleaseAvailable: "预发布版 {0} 已发布",
			newerPrereleaseHint: "npm 上的 latest 没有更新；你在跟的这条预发布线发布了更新的版本。",
			unreleasedCommits: "有新提交（未发版）{0}",
			unreleasedCommitsHint: "所选分支上有比你已装版本更新的提交，但没有发布新版本号；市场只安装正式版本，不会自动装这些提交。",
			linkedDev: "本地开发",
			hostUpdateReady: "有新版本 {0}",
			hostUpdateHint: "本市场由桌面端安装和更新，新版本请在桌面端更新",
			notesLink: "更新内容",
			notesRelease: "版本说明",
			notesCommits: "提交记录",
			notesCommitsRecent: "最近提交（无法对应你当前安装的版本，仅供参考）",
			notesNpm: "版本发布时间",
			notesNone: "该插件未提供更新说明。",
			notesSource: "市场还没收录这个插件的更新说明。",
			notesSourceUnreadable: "这个插件不是从 GitHub 装的，市场读不到它的改动记录。",
			notesSourceLink: "去仓库看改了什么",
			notesSourceNoLink: "可以问问插件作者改了什么。",
			notesLoadFail: "暂时读不到更新说明，稍后再试。",
			migrateNpm: "换用 npm 版本",
			migrateTitle: "换用 npm 版本？",
			migrateDescription: "这会更改插件的安装来源，而不是普通版本更新。",
			migrateCurrentSource: "当前来源",
			migrateTargetSource: "新的 npm 来源",
			migrateWarning: "该 npm 包可能由其他人发布，并非同一插件；确认可信后再继续。",
			migrateContinue: "确认换用",
			migrateFail: "换用来源失败",
			renameRowAction: "迁移到新名字",
			renameTitle: "迁移到新名字并更新？",
			renameDescription: "这个插件换了 npm 包名，旧名字不再发新版本。迁移会把安装换成新名字，开关、分组和备注都保留。",
			renameCurrentPackage: "现在的包",
			renameTargetPackage: "新的包",
			renameWarning: "插件自己保存的数据（人格、习惯、绑定）不归市场管，迁移不会动它们。",
			renameContinue: "迁移并更新",
			restoreOnline: "换用线上版本",
			restoreHint: "将卸载本地版本并安装线上版本，之后照常检查更新。此操作无法撤销。",
			hostIncompatibleTitle: "这个新版本要求更新的 DSH",
			hostIncompatibleBody: "{plugin} 声明需要 DSH {requirement}，而你现在运行的是 {host}。装上去很可能用不了，只能手动装回旧版。\n已停止，插件仍是原来的版本。\n如果你确定这个版本号不准（例如桌面端自带的 DSH 不报告版本），仍可继续更新。",
			hostIncompatibleUnknown: "未知版本",
			hostIncompatibleSearching: "正在查找还兼容当前 DSH 的版本…",
			hostIncompatibleFoundInstall: "可以装 {version}：它声明兼容当前 DSH。",
			hostIncompatibleFoundUpdate: "可以更新到 {version}：它声明兼容当前 DSH。",
			hostIncompatibleHeldTarget: "可以选 {version}：它声明兼容当前 DSH，但还在发布等待期——新版本发布后要等 {window} 小时才算稳定，还差约 {hours} 小时。",
			hostIncompatibleHeldTargetUnknown: "可以选 {version}：它声明兼容当前 DSH，但还在发布等待期，暂时算不出还要等多久。",
			hostIncompatibleHeldButton: "还在等待期（约 {hours} 小时）",
			hostIncompatibleHeldButtonUnknown: "还在等待期",
			hostIncompatibleNoCompat: "没有找到声明兼容当前 DSH 的版本。",
			hostIncompatibleSearchFailed: "暂时查不到兼容版本。",
			hostIncompatibleInstallCompat: "安装 {version}",
			hostIncompatibleUpdateCompat: "更新到 {version}",
			hostIncompatibleRetry: "重试",
			hostIncompatibleKeep: "保持现在的版本",
			hostIncompatibleAnyway: "仍然更新",
			hostStatusCompatible: "符合宿主要求（依据声明）",
			hostStatusIncompatible: "确证与当前 DSH 不兼容",
			hostIncompatibleBodyInstall: "{plugin} 声明需要 DSH {requirement}，而你现在运行的是 {host}。装上去很可能用不了。\n已停止，没有安装任何东西。\n如果你确定这个版本号不准（例如桌面端自带的 DSH 不报告版本），仍可继续安装。",
			hostIncompatibleCancel: "取消安装",
			hostIncompatibleInstallAnyway: "仍然安装",
			restoreNameOnlyHint: "本地副本未注明来源仓库，市场只能按包名在精选目录中匹配。下方插件可能是其他作者的同名插件，并非你本地副本的来源。确认前请核对作者和仓库地址。此操作会卸载本地版本并安装该插件，无法撤销。",
			restoreContinue: "继续更新",
			restoreProceed: "确认恢复",
			restoreNoCatalogTitle: "无法恢复",
			restoreNoCatalog: "精选目录里没有这个插件，无法恢复到线上版本。可以卸载本地版，或继续用本地开发。",
			restoreNoMatch: "精选目录里有同名插件，但与你本地仓库不一致，无法安全恢复。可以卸载本地版，或继续用本地开发。",
			restoreFail: "恢复失败",
			exportLog: "导出日志",
			crashTitle: "插件市场无法显示",
			crashHint: "市场界面未能正常显示，你的插件不受影响，也没有任何改动。\n点击「重新加载」通常即可恢复。如反复出现，请导出日志并提交 issue，日志会记录出错位置。\n如果开启了浏览器网页翻译，请关闭后重试，这是已知原因之一。",
			crashReload: "重新加载",
			crashDetails: "错误详情",
			exportingLog: "导出中…",
			exportedLog: "日志已导出：dsh-market-log.txt，请将其附在 issue 中",
			exportLogFail: "日志导出失败",
			readme: "使用说明",
			comments: "评论",
			commentsTitle: "评论",
			commentsNote: "评论来自 GitHub Discussions。打开后会连接 giscus.app 与 GitHub；发表评论需要 GitHub 账号。",
			commentsLoginHint: "在这里登录会离开本页，返回时需重新打开 dsh web——这不是故障。发表评论请到 GitHub，本页只用于阅读。",
			commentsLoading: "正在加载评论…",
			commentsError: "评论加载失败。请检查网络连接后重试。",
			commentsRetry: "重试",
			commentsOnGitHub: "在 GitHub 登录并参与讨论",
			conflictTitle: "无法安装：与已安装的插件冲突",
			conflictBody: "和已安装的插件冲突，只能留一个：",
			conflictReverted: "已自动撤销，未改动任何插件",
			conflictKeep: "保留现有插件",
			conflictKeepNote: "",
			conflictSwap: "改为安装这个",
			conflictSwapNote: "被卸载的插件配置会保留，可以再装回来",
			conflictDetails: "详情",
			conflictOutcomeInstall: "安装",
			conflictOutcomeSkip: "不安装",
			conflictOutcomeKeep: "保留",
			conflictOutcomeRemove: "卸载",
			conflictWhy: "cordis 不接受重复的条目 id，保留它会让 DeepSeek Harness 下次启动失败。",
			opTitle: "任务",
			opInstalling: "正在安装",
			opNeedsYou: "项需处理",
			opQueued: "排队中",
			opQueuedAhead: "前面还有",
			opQueuedWaitingAgents: "等待 {0} 个会话空闲",
			opWaitingAgents: "{0} 个任务等待 agent 空闲",
			opRunning: "正在处理",
			opNeedsChoice: "无法安装 · 已自动撤销，未改动任何插件",
			opDone: "已完成",
			opDoneRefresh: "已安装 · 刷新页面后生效",
			opLeaveHint: "可离开本页面，完成后将通知你",
			opLeaveHintAgents: "Agent 空闲后自动开始",
			opEmpty: "暂无进行中的操作",
			opEmptyHint: "安装、更新与卸载的进度将显示在这里",
			opClose: "收起",
			opClear: "清空已完成",
			opDequeue: "移出队列",
			opRunNow: "立即执行",
			opUpdateNow: "现在更新",
			opUninstallNow: "现在卸载",
			agentsRunningConfirm: "仍要继续？",
			agentsRunningRisk: "有会话正在运行。此操作会替换或删除插件文件。运行中的会话可能中途报错。不想冒险可取消，等会话结束再试。",
			opRetry: "重试",
			opKind_install: "安装",
			opKind_update: "更新",
			opKind_uninstall: "卸载",
			opBlockedCard: "无法安装 · 查看详情",
			conflictDeclined: "已选择保留现有插件，未安装",
			conflictReplacing: "正在替换…",
			conflictReplaceFailed: "替换未完成。下列插件已卸载且未恢复，请重新安装：",
			lightboxClose: "关闭预览",
			lightboxPrev: "上一张",
			lightboxNext: "下一张",
			envMissing: "安装插件前需要先配置 pnpm 环境",
			envFix: "自动配置",
			envFixing: "正在配置…",
			envFixFail: "自动配置失败。请导出日志并附在 issue 中。",
			loading: "正在加载插件目录…",
			backTop: "回到顶部",
			confirm: "确认",
			confirmInstall: "确认安装",
			cmdDetails: "安装命令",
			cmdCopy: "复制安装命令",
			cmdDesktopUnavailable: "桌面端的插件由应用自己安装（用上面的「安装」按钮）；`dsh plugin` 不接受桌面端这个 profile。",
			cmdCopied: "已复制",
			catsMore: "更多分类",
			catsLess: "收起",
			filter: "筛选",
			filterSort: "排序字段",
			filterDir: "排序方向",
			filterTime: "发布时间范围",
			filterHost: "宿主版本",
			hostAll: "显示全部",
			hostCompatible: "兼容当前 DSH {0}",
			hostDetecting: "正在识别宿主版本…",
			hostUnknown: "宿主版本未知",
			hostFilterLoading: "正在检查宿主要求 {0}/{1}；未声明或无法确认的插件仍会显示",
			hostFilterActive: "已隐藏 {1} 个与 DSH {0} 不兼容的插件；未声明版本的仍在列表里",
			hostRequirement: "DSH {0}",
			hostRequirementLoading: "正在读取宿主要求…",
			hostRequirementUndeclared: "未声明宿主要求",
			hostRequirementUnavailable: "宿主要求未知",
			sortDownloads: "npm 下载量（近 30 天）",
			downloadsPeriod: "近30天",
			downloadsMeaning: "近 30 天 npm 下载：{0}",
			githubReleaseDownloadsMeaning: "GitHub 发行附件累计下载：{0}（包括安装包、校验和配套文件）",
			starsMeaning: "GitHub Star：{0}",
			statisticCheckedAt: "；采集于 {0}",
			downloadsWindow: "（{0} 至 {1}）",
			/** Discover/theme card byline tooltip for catalog `version`. */
			catalogNpmLatest: "npm 当前 latest",
			catalogVersionDated: "目录（{0} 更新）记录的安装版本；新发行需等待目录更新",
			catalogVersionUndated: "目录记录的安装版本；可能滞后于项目的新发行",
			sortStars: "Star 数",
			sortAdded: "收录时间",
			recentlyAdded: "最近收录",
			recentHide: "隐藏这一块",
			recentShow: "显示最近收录",
			sortDesc: "降序",
			sortAsc: "升序",
			sortNewest: "最新",
			sortOldest: "最旧",
			timeAll: "全部时间",
			timeDay: "最近 1 天",
			timeWeek: "最近 7 天",
			timeMonth: "最近 30 天",
			timeQuarter: "最近 90 天",
			timeYear: "最近 1 年",
			published: "收录时间",
			prevPage: "上一页",
			nextPage: "下一页",
			loadMore: "加载更多",
			pageInfo: "第 {0} / {1} 页",
			perPage: "每页",
			marketUpdate: "更新插件市场",
			updateAll: "全部更新",
			heldReleaseNotice: "已安装，但不是最新版：这个 profile 的 minimumReleaseAge 挡住了 {0}，安装的是 {1}。",
			versionUnverifiedNote: "已安装，但版本没能确认：registry 两次都查不到，这次装的是 {0}。插件页会显示实际版本，可以在那里核对。",
			versionUnverifiedNoteUnknown: "已安装，但版本没能确认：registry 两次都查不到。插件页会显示实际版本，可以在那里核对。",
			installedDependencyNote: "另有 {0} 个包是插件带进来的依赖，不是插件，未列在上方。",
			heldReleaseAction: "仍安装 {0}",
			ignoreUpdateNotice: "重启前不再提醒",
			openInHostPage: "在插件页查看",
			ignoreAllUpdateNotices: "重启前都不再提醒",
			updateNoticeIgnored: "重启前不再提醒",
			updateExemptAdd: "一直不提醒更新",
			updateExemptRemove: "恢复更新提醒",
			updateExemptMark: "提醒已关闭",
			updateExemptRestore: "恢复提醒",
			updateExemptHint: "新版本仍会列出，只是不再提醒。",
			updateExemptOn: "更新提醒已关闭。新版本仍会列出。",
			updateExemptOff: "已恢复更新提醒。",
			updateExemptFailed: "无法保存，请重试。",
			updateAvailableShort: "有新版本",
			copyPath: "复制路径",
			pathCopied: "已复制",
			tabThemes: "主题",
			tabBackup: "备份与恢复",
			backupLocal: "本地文件",
			backupExportFailed: "导出备份失败",
			backupDownload: "导出备份",
			backupImport: "导入并预览",
			backupHint: "仅包含插件清单和 profile 配置，不含插件文件；恢复时按清单重新安装。",
			webdav: "WebDAV",
			webdavPreset: "服务商预设",
			webdavUrl: "备份文件 URL",
			webdavUser: "用户名（可选）",
			webdavPassword: "密码（可选）",
			webdavUpload: "上传备份",
			webdavRestore: "从 WebDAV 恢复",
			autoBackup: "每天自动备份（打开市场时）",
			webdavNote: "WebDAV 地址与用户名仅保存在当前浏览器；密码只留在当前页面，刷新或重启后需要重新输入。",
			webdavAutoBackupPaused: "每天自动备份没能完成：这个服务需要密码认证，而密码不会保存到磁盘，刷新或重启后要重新输入。填好后点「上传备份」即可。",
			webdavPathHint: "填完整的文件地址（含文件名）：备份写进这个文件，恢复也从它读。开启自动备份后每天最多上传一次。",
			localOnly: "WebDAV 地址和用户名只保存在此浏览器。",
			credsWarning: "请注意：备份包含 profile 配置，以及可能含密钥的文件（config.toml、.env 等）。本地导出的文件会原样包含这些内容，上传 WebDAV 前请确认目标可信。",
			gist: "GitHub Gist",
			gistToken: "GitHub token（仅本次会话内存，刷新后需重新输入；留空则使用服务端 DSH_GITHUB_TOKEN 或已登录的 gh CLI）",
			gistId: "Gist ID 或链接（导出留空则新建私有 Gist）",
			gistVerify: "验证连接",
			gistExport: "导出到 Gist…",
			gistImport: "从 Gist 导入",
			gistExportDone: "已导出到 Gist",
			gistVerifySource: "验证通过（Token 来源：{0}）",
			gistSrcToken: "手动输入",
			gistSrcEnv: "环境变量 DSH_GITHUB_TOKEN",
			gistSrcGh: "gh CLI",
			gistExportSelect: "选择要导出的插件",
			gistExportHint: "全选 = 完整备份（含配置文件）；否则只导出勾选的插件，可另勾「包含配置文件」。",
			gistSelectAll: "全选",
			gistSelectNone: "全不选",
			gistIncludeConfig: "包含配置文件（可能含密钥）",
			gistNoPlugins: "当前 profile 没有可导出的插件",
			gistSpecLocal: "本地",
			gistExportGo: "导出",
			gistCreated: "已导出：",
			gistErrTimeout: "GitHub 请求超时，请检查网络后重试",
			gistErrNetwork: "无法连接 GitHub，请检查网络或代理设置",
			gistErrAuth: "GitHub 认证失败：Token 无效、已过期，或 gh CLI 未登录",
			gistErrNotFound: "未找到该 Gist，请检查 ID 或链接",
			gistErrRateLimit: "GitHub 限流或 Token 权限不足",
			gistErrInvalid: "Gist 内容无效或备份格式不受支持",
			gistModeUpdate: "更新到输入框中的 Gist",
			gistModeCreate: "新建一个私有 Gist",
			gistErrNoId: "更新模式需要 Gist ID：请填写，或切换为「新建」",
			gistNote: "与本地导出（本机存档）不同，Gist 用于跨机器同步：导出到私有 Gist 后，可在其他电脑用同一账号导入复用。Token 仅保存在本次会话内存中，绝不写入浏览器存储；已登录 gh CLI 或设置 DSH_GITHUB_TOKEN 则无需输入。Gist 为私有，单文件上限 1 MB。",
			backupWorking: "处理中…",
			backupDone: "备份已上传",
			restoreDone: "恢复完成，请重启 DeepSeek Harness",
			restorePartial: "恢复已完成，但下列插件安装失败：",
			restoreUnportable: "安装来源是另一台电脑上的本地路径，本机找不到。请重新安装该插件，或改为本机路径",
			restoreSelfPinned: "市场自身的版本不会随恢复改变（否则会在恢复途中替换掉正在运行的自己）。需要时请用「更新」单独升级",
			restoreBootError: "恢复后仍无法启动：",
			orphanBundle: "⚠️ 下次启动会失败：profile 声明了这些插件，但它们没有安装。请重新安装，或从 profile 的 package.json 的 dsh.profile.bundles 中删除：",
			restoreConfirm: "恢复将覆盖当前 profile 配置并重新安装插件，确定继续吗？",
			restorePreviewDone: "备份已导入，请在「已安装」中确认后开始恢复",
			restoreMissing: "备份中有 {0} 个插件尚未安装",
			restoreStart: "开始恢复",
			notInstalled: "未安装",
			themeApply: "使用",
			themeActive: "使用中",
			themeDeactivate: "停用",
			themeEmpty: "目录中暂无主题",
			themePreview: "预览",
			themePreviewLoading: "正在查找预览…",
			themePreviewMissing: "暂无预览",
			themePreviewCount: "{0} 张预览",
			themeResultCount: "{0} 款主题",
			themeFullscreen: "全屏浏览",
			themeExitFullscreen: "退出全屏",
			progressHint: "首次安装需下载插件的依赖包，大型插件可能需 1-3 分钟",
			progressSlow: "比平常久。有依赖在下载或编译时，要等几分钟；等不及可以取消，换个网络再试",
			toastReady: "已安装并已生效",
			toastTheme: "已启用。可在「设置 → 插件市场 → 主题」中随时切换",
			toastToggledOn: "已启用",
			toastToggledOff: "已停用，功能立即失效",
			gotIt: "关闭",
			stateLive: "已生效",
			stateRestart: "已安装，重启后生效",
			stateIncompatible: "已安装，与当前 dsh 不兼容",
			stateInert: "已安装，未生效",
			stateLibrary: "依赖库",
			libraryUseHint: "供其他插件使用，无需启用。",
			stateDependencyLibrary: "{0} 的依赖库",
			stateLoadedByProfile: "由你的配置加载",
			stateBroken: "已安装，校验未通过",
			stateFailed: "启动时没能加载",
			stateDisabled: "已停用",
			phaseResolving: "准备依赖",
			phaseDownloading: "下载中",
			phaseLinking: "链接依赖",
			phaseBuilding: "运行构建脚本",
			cancelling: "正在取消…",
			packagesDone: "已处理 {0} 个包",
			updatedLive: "✓ 已更新，已生效",
			updatedLibrary: "✓ 已更新",
			partialNote: "已取消，部分更改已应用",
			reconciledNote: "已卸载，但 pnpm 在收尾阶段报错（通常是文件被占用）；配置已同步，无需重试",
			actWhy: "为什么未生效？",
			tabList: "列表",
			tabGroups: "分组",
			repoLink: "在 GitHub 上查看仓库",
			viewSourceRepo: "查看仓库↗",
			disabledState: "已停用",
			noteAdd: "添加备注",
			noteEdit: "编辑备注",
			noteTheirs: "原文",
			noteMine: "我的备注",
			noteSave: "保存",
			notePlaceholder: "用你自己的话描述这个插件，将代替作者简介显示",
			noteSeeTheirs: "查看作者简介",
			noteSeeMine: "返回我的备注",
			switchOnLabel: "启用中",
			enable: "启用",
			disable: "停用",
			toggleFail: "切换失败",
			deprecatedBadge: "已废弃",
			deprecatedWarn: "该插件已被目录标记为废弃，不建议新用户安装。",
			configNamespaceNotice: "{0} 的设置面板读不到配置：它按「{1}」读取，而这个环境里没有这个名字的条目 id。它自己的条目是「{2}」，插件客户端应该改成读那个——这是插件自身的问题，市场无法代改。",
			brokenPluginTitle: "{0} 更新失败后被移除了",
			brokenPluginBody: "DSH 正在运行时无法更新，而更新前的版本也已经损坏。为避免下次启动卡住，市场把它从 profile 里移除。插件目录还在原处，退出 DSH 后重新安装即可。",
			brokenPluginTitleCancelled: "{0} 取消更新后被移除了",
			brokenPluginBodyCancelled: "取消时，旧版本已被清掉一部分。为避免下次启动卡住，市场把它从 profile 里移除。插件目录还在原处，重新安装即可；若再次失败，先退出 DSH 再装。",
			brokenPluginAction: "查找这个插件",
			brokenPluginDismiss: "不再显示这条",
			viewReplacement: "查看替代品",
			installReplacement: "安装替代品",
			replacementHint: "目录建议改用",
			groupNew: "新建分组",
			groupNamePh: "分组名称",
			groupRename: "重命名",
			groupDelete: "删除分组",
			groupConfirmDelete: "删除分组？",
			groupExpand: "展开 {0}",
			groupFold: "收起 {0}",
			groupThemeTaken: "已有主题",
			groupSearchEmpty: "没有匹配的插件",
			groupStateInert: "未生效",
			groupStateRestart: "重启后生效",
			groupStateBroken: "校验未通过",
			ungrouped: "未分组",
			groupAssign: "分配到",
			groupRemove: "移出",
			groupEmpty: "该组暂无成员",
			groupMixed: "部分启用",
			noGroups: "尚无分组，请先新建",
			groupCreate: "创建",
			groupAdd: "添加成员",
			groupAddEmpty: "没有未分组的插件可加入",
			groupAddPick: "加入",
			groupAddSearchPh: "搜索插件…",
			groupAddTitle: "添加到「{0}」",
			groupAddSelected: "已选择 {0} 项",
			groupAddConfirm: "添加 {0} 项",
			groupAddHint: "加入分组不会自动启用插件",
			groupPickTheme: "选择主题",
			groupChangeTheme: "更换主题",
			groupThemeTitle: "为「{0}」选择主题",
			groupThemeUse: "使用",
			groupThemeEmpty: "没有未分组的主题",
			groupThemeHint: "一组只有一个主题。选择不会启用它，更换会把原来的主题移出该组。",
			groupThemeCurrent: "当前",
			groupThemeRemove: "移出主题",
			groupThemeBadge: "主题",
			groupOrgHint: "分组仅用于整理，不会改变插件启用状态",
			groupMembersMeta: "{0} 个 · {1} 个已启用",
			groupMore: "更多",
			groupRenameSave: "保存",
			groupRenameTitle: "重命名分组",
			groupRenameHint: "只改分组名称，组内插件与启用状态不受影响",
			tabDiagnostics: "诊断",
			checkIssues: "发现问题",
			checkErrors: "错误",
			checkWarnings: "警告",
			checkLoading: "正在分析 profile…",
			checkLoadFail: "诊断加载失败：",
			checkProfile: "profile",
			checkErrorsEmpty: "没有错误",
			checkWarningsEmpty: "没有警告",
			checkBundles: "插件加载顺序（bundle）",
			checkBundlesEmpty: "未配置任何插件包",
			checkOfficial: "官方",
			checkCommunity: "社区",
			checkSource: "来源",
			checkEntries: "加载条目（loader id）",
			checkPatch: "patch 文件",
			checkDir: "目录",
			checkDuplicates: "重复的插件条目",
			checkDuplicatesEmpty: "没有重复的插件条目",
			checkHoisted: "顶层",
			checkPeerMismatches: "依赖版本不匹配",
			checkPeerEmpty: "没有依赖版本不匹配",
			checkPeerInfo: "另有 {0} 条待确认信息",
			checkPeerOverview: "{0} 不匹配 · {1} 条信息",
			checkRange: "要求版本",
			checkResolved: "实际版本",
			checkSatisfied: "满足",
			checkUnsatisfied: "不满足",
			checkUnknown: "未知",
			checkPeerRisk: "依赖风险",
			checkPeerRiskEmpty: "没有依赖风险",
			checkPeerWarning: "依赖警告",
			checkPeerWarningEmpty: "没有依赖警告",
			checkPeerInfoTier: "依赖信息",
			checkPeerInfoTierEmpty: "没有依赖信息",
			checkPeerSatisfied: "已满足的依赖",
			checkPeerSatisfiedEmpty: "没有已满足的依赖条目",
			peerRiskBelowMin: "低于声明下限",
			peerRiskAboveMax: "高于显式上限",
			peerWarnOptional: "可选依赖",
			peerWarnAboveMax: "超出声明上限",
			peerInfoUnverified: "未确认",
			checkMultiVersion: "核心包多版本",
			checkMultiEmpty: "没有多版本核心包",
			checkOverrides: "覆盖关系",
			checkOverridesEmpty: "没有覆盖关系",
			checkOverridden: "覆盖了",
			checkResiduals: "残留目录",
			checkResidualsEmpty: "没有发现残留目录。",
			checkResidualsHint: "这些目录不被任何插件使用，也不影响启动，是更新中断后留下的。退出 DSH 后可以删除，或重新安装对应的插件。",
			checkResidualTmp: "pnpm 临时目录",
			checkResidualIncomplete: "残缺的包目录（缺少 package.json）",
			checkConfigNamespaces: "设置面板读不到配置的插件",
			checkConfigNamespacesEmpty: "没有发现这类插件。",
			checkConfigNamespacesHint: "插件面板按「条目 id」读自己的配置，写错名字不会报错，只会静默读不到值：面板空白、存不进去，插件会退回它写死的默认值（画布类插件因此白屏）。这是插件客户端里的名字写错了，市场改不了它，需要插件作者改一行代码。",
			checkConfigNamespaceRow: "它按「{0}」读配置，但这不是任何条目 id",
			checkConfigNamespaceOwn: "它自己的条目 id",
			checkConfigNamespaceNone: "它自己没有声明任何条目 id",
			checkOrphans: "无效的配置条目",
			checkOrphansEmpty: "没有无效配置条目",
			orphanInsertNotArray: "格式错误",
			orphanInsertTargetMissing: "目标不存在",
			orphanInsertTargetNotGroup: "目标不是分组",
			orphanIdRequired: "缺少标识",
			orphanPatchTargetMissing: "目标不存在",
			orphanNameMismatch: "名称不匹配",
			orphanReasonOther: "其他",
			diagExplain: "术语说明",
			diagExplainText: "本页检查插件冲突、依赖版本不匹配与加载顺序问题。常用术语：",
			diagTermBundle: "bundle = 一个插件包，会按顺序叠加加载",
			diagTermEntry: "加载条目 = 插件在运行组合里注册的每一项",
			diagTermPeer: "对等依赖 = 插件要求宿主环境提供的另一个包",
			diagTermShadow: "遮蔽 = 插件自带的旧版包盖住了宿主的新版",
			diagTermOrphan: "无效条目 = 配置里引用了不存在的东西",
			diagTermOrder: "加载顺序 = 插件被激活的先后，后加载者可能覆盖先加载者",
			orderSection: "排序",
			orderUp: "↑",
			orderDown: "↓",
			orderApply: "应用顺序",
			orderDrag: "拖拽排序",
			orderDragHint: "拖动 ⠿ 调整顺序，选择「应用顺序」后才会保存",
			orderConflicts: "当前顺序的 before/after 冲突",
			orderApplied: "✓ 已应用，重启后生效",
			orderSuggestApply: "采用建议顺序",
			orderSuggestHint: "建议顺序（按 before/after 规则自动排序）：",
			orderAutoSort: "自动排序",
			orderAlreadyOptimal: "当前顺序已满足全部规则与插件依赖，无需调整",
			orderTrialFail: "顺序检查未通过：{0}",
			orderDiffHint: "该顺序会改变组合：{0} 处覆盖、{1} 个无效条目、{2} 个重复条目",
			duplicateNames: "同名插件（仅供参考，不算冲突）",
			orderReset: "重置草稿",
			checkRefresh: "重新检查",
			aiFix: "AI 修复",
			aiFixHint: "将诊断问题交由新对话中的 Agent 修复（内容已复制到剪贴板，由你决定是否发送）",
			aiFixIntro: "请帮我修复 DeepSeek Harness 的插件问题（profile：{0}）。诊断发现如下：",
			aiFixDetect: "【第一步·先判断身份】开始前先判断：当前 Agent 所运行的进程，是否就是这个 profile 对应的 DeepSeek Harness 本机进程（即：诊断出的这套组合，就是你现在运行中的组合）？判断依据：当前工作目录 / $DSH_HOME / 进程命令行是否指向该 profile，或你是否运行在 deepseek-harness 进程内。若无法确定，一律按【是你】处理（更安全）。",
			aiFixIfSelf: "【是 → 你就是这个 harness】严禁原地改动组合、harness 或核心包：不修改 cordis.patch.yml、不调整 bundle 顺序或启停、不安装/卸载/升级插件、不重新安装依赖、不升级或重启 dsh。三步：① 先只读分析，不改任何东西；② 给出 apply.sh/.bat（本次修复的改动）与 rollback.sh/.bat（完整撤销 apply）；两者都可重复执行——apply 只在没有快照时创建快照（不覆盖；已有快照说明 apply 跑过，先回滚或确认再重跑），rollback 从快照恢复，因此 apply 跑到一半失败也能回滚、重复回滚也安全；③ 由我在外部终端执行 apply，并将 stdout/stderr 回贴给你判断。每步先说明理由、等我确认；绝不自行执行。",
			aiFixScope: "【否 → 保守执行】你要是判定自己并非运行在目标 harness 内（独立进程），才可考虑：修改 dsh.profile.bundles 顺序、停用/启用插件、调整 cordis.patch.yml。注意：官方 bundle 不可移动；动手前先说明计划。",
			aiFixConservative: "请保持保守：只修复上面列出的明确错误（启动失败/重复条目/风险级依赖不匹配）。警告和信息级问题（如可选依赖、未确认的依赖范围）仅在它们与明确错误相关时处理。不要做不必要的升级或重新排序；每项改动前说明理由并等待确认。",
			aiFixCopied: "已复制修复说明，请粘贴到新对话中发送",
			aiFixFail: "无法访问剪贴板，请手动复制下面的诊断内容",
			catConflict: "冲突",
			catDeps: "依赖",
			catRisk: "风险",
			catWarn: "警告",
			catInfo: "信息",
			catOrder: "顺序",
			/** Summary-strip tooltip for the order count (before/after rule conflicts). */
			checkOrderTip: "社区 bundle 加载顺序与插件声明的 before/after 规则冲突",
			diagOkAll: "未发现冲突、依赖或加载顺序问题",
			presetSection: "插件组合",
			presetHint: "把当前的插件顺序和已停用的插件保存为组合，随时切换；应用前会先试启动一次并自动创建快照。",
			presetName: "组合名称",
			presetSave: "保存当前状态",
			presetSaving: "保存中…",
			presetSaved: "组合已保存",
			presetApply: "应用",
			presetApplied: "已应用，重启后生效",
			presetDelete: "删除",
			presetDeleted: "组合已删除",
			presetEmpty: "还没有保存过组合",
			presetNameEmpty: "请输入组合名称",
			presetFail: "组合操作失败：",
			presetListFail: "组合列表加载失败：",
			presetBundleCount: "{0} 个插件",
			presetPreview: "预览",
			presetPreviewTitle: "应用此组合将：",
			presetReorder: "重排 {0} 个插件的位置",
			presetEnable: "启用 {0} 个插件",
			presetDisable: "停用 {0} 个插件",
			presetNoop: "无变更",
			presetPreviewFail: "预览失败：",
			snapSection: "快照与回滚",
			snapHint: "应用变更前会自动创建快照；也可手动创建，随时回滚到任意状态。",
			snapCreate: "创建快照",
			snapCreating: "创建中…",
			snapCreated: "快照已创建",
			snapEmpty: "还没有快照",
			snapListFail: "快照列表加载失败：",
			snapCreateFail: "创建快照失败：",
			snapRestore: "回滚",
			snapRestoring: "回滚中…",
			snapRestored: "已回滚，重启后生效",
			snapRestoreFail: "回滚失败：",
			snapRestoreConfirm: "确认回滚",
			snapRestoreConfirmText: "回滚会用快照覆盖当前的插件与配置，且不可撤销（可先创建新快照再回滚）。",
			snapFiles: "包含文件",
			snapDelete: "删除",
			snapDeleting: "删除中…",
			snapDeleted: "快照已删除",
			snapDeleteFail: "删除快照失败：",
			snapDeleteConfirm: "确认删除",
			snapDeleteConfirmText: "删除后该快照将无法恢复。",
			marketNoToggle: "市场自身不能停用",
			hostDependencyWarning: "插件把 DSH 自带的公共包列进了依赖，可能和 DSH 自己的版本互相干扰（仅依据声明，未确认）：",
			hostDependencyMore: "另有 {0} 项已省略",
			recoveryTitle: "启动失败——调整插件",
			recoveryLead: "本次重启没有成功，dsh 已经退出。勾选你希望下次启动时启用的插件；本次启动报错的插件已标红并取消勾选。",
			recoveryOption: "调整插件",
			recoveryBanner: "启动失败：",
			recoveryOpening: "正在读取失败详情…",
			recoveryNoSummary: "日志里没有说明具体原因",
			recoveryRawLog: "dsh 的原始输出（结尾部分）",
			recoveryBlamedHint: "下面标红的插件在本次启动时报了错，取消勾选后下次启动不再启用它们。",
			recoveryNoBlameHint: "日志没有指出具体插件，下面按启用状态列出可调整的插件。",
			recoveryCarrier: "停用其他",
			recoveryNotToggleable: "本页无法开关",
			recoveryUnmatched: "DSH 指出但本页无法开关的插件：",
			recoveryLogPath: "完整日志：",
			recoveryApply: "保存并重启",
			recoveryApplying: "正在保存并重启…",
			recoveryStandalone: "打开独立恢复页",
			recoveryRestarting: "正在重启：dsh 启动后本页会刷新；若又失败，会带着新的报错回到这里。",
			recoveryApplyFailed: "保存失败：",
			recoveryWriteFailed: "上次的选择没有全部保存，因此没有重启：",
			recoveryTimeout: "等待 DeepSeek Harness 启动超时。可点「调整插件」，检查是否某个插件导致无法启动。",
			hostRecoveryTitle: "配置被换成了空壳",
			hostRecoveryBody: "上次启动失败后，DSH 的恢复流程把配置换成了默认的。原来的 {0} 条还在备份里。",
			hostRecoverySource: "备份：{0}，{1}",
			hostRecoveryRestore: "恢复配置",
			hostRecoveryRestored: "已恢复 {0} 条设置。刷新页面就能看到。",
			hostRecoveryFail: "恢复失败：",
			hostRecoveryNote: "恢复前会自动存快照，随时能退回。"
		};
		const en = {
			nav: "Plugin Market",
			setCardDesc: "View the plugin market version and settings.",
			setSelfUpToDate: "Up to date",
			setSelfUpdateReady: "New version available:",
			setSelfUpdateHint: "Updating downloads the new version; it takes effect after a restart.",
			setSelfUpToDateHint: "",
			setSelfHostManagedHint: "This copy was installed by the desktop app; update it from there.",
			setSelfUpdate: "Update",
			setSelfUpdatedHint: "Downloaded. Restart DeepSeek Harness for it to take effect — the page will already show the new version.",
			setSidebar: "Sidebar shortcut",
			setSidebarHint: "Shows the market below Plugins in the sidebar.",
			setSidebarOnlyDoorHint: "This host has no market page in Settings, so this row is the only way in and stays on.",
			setAdvanced: "Advanced",
			setAdvancedHint: "Where the market appears. Keep at least one entry.",
			setEntrySection: "Settings entry",
			setEntrySectionHint: "Shows the market section in Settings.",
			setEntryPluginsTab: "Plugins page entry",
			setEntryPluginsTabHint: "Shows the market tab beside Installed on the Plugins page.",
			setEntryLastDoorHint: "Keep at least one entry; this is the only one left.",
			setEntryShow: "Show",
			setEntryHide: "Hide",
			setIndexSource: "Discover index",
			setIndexSourceHint: "On dsh 0.2.1 and newer, add https://cdn.jsdelivr.net/npm/dsh-plugin-catalog/index.json under Plugins → Discover → Index sources — the official Discover tab and the plugin_market agent tool then search the same catalog.",
			setSidebarOn: "Show",
			setSidebarOff: "Hide",
			sidebarTip: "Want a quicker open? Show it in the sidebar.",
			sidebarTipDismiss: "Don't show again",
			setRegion: "Download region",
			setRegionGlobal: "Global",
			setRegionChina: "China mainland",
			setRegionGlobalHint: "Downloads directly from npm and GitHub.",
			setRegionChinaHint: "Faster in mainland China. Changes the download route, not the source.",
			setRegionAuto: "Selected from a network check. Change it anytime.",
			setGithubProxy: "GitHub acceleration",
			setGithubProxyAutoHint: "Chooses a working route automatically and switches only after a failure.",
			setGithubProxyCustom: "Custom",
			setGithubProxyCustomHint: "Tries your custom route first, then falls back to GitHub directly.",
			setGithubProxyManagedHint: "Managed by DSHM_GITHUB_PROXY and cannot be changed here.",
			setGithubProxyEdit: "Edit",
			setGithubProxyAuto: "Restore automatic",
			setGithubProxyInput: "HTTPS acceleration prefix",
			setGithubProxySave: "Save",
			setBuildEnv: "Build environment",
			setBuildEnvHint: "Reaches every process the market runs — installs, builds, git — not just the compiler. One KEY=value per line, e.g. CC=/usr/bin/gcc-11. PATH and CI are managed by the market. Saving an empty list restores the original config.",
			setBuildEnvSave: "Save variables",
			setChannel: "Update channel",
			setChannelStable: "Stable",
			setChannelBeta: "Beta",
			setChannelStableHint: "Released versions only.",
			setChannelBetaHint: "Early access to unverified versions. Affects the plugin market only.",
			setChannelDev: "Dev",
			setChannelDevHint: "Unverified builds from a development branch. Not recommended for general use.",
			setChannelSwitch: "Switch to",
			setChannelSwitchHint: "This version is lower than the one installed.",
			setSelfRemove: "Uninstall the plugin market",
			setSelfRemoveHint: "Uninstall the market from this profile. Your other plugins are untouched.",
			setSelfRemoveRemote: "This page was not opened on the machine running DSH, so the market cannot remove itself from here. Remove it there: Settings → Plugins on the desktop app, or the command line elsewhere.",
			setSelfConfirm: "Uninstall the plugin market? Reinstalling it requires the command line.",
			setSelfPurge: "Also clear the market's own data",
			setSelfPurgeOn: "Will delete: the market's disable list and custom groups, plus the disable entries it wrote into your config file — plugins it switched off will run again. No passwords or tokens are involved; the market never stores those on disk.",
			setSelfPurgeOff: "Keeps the market's data. Note: plugins the market switched off stay off, and once it is removed there is no UI left to switch them back on.",
			setSelfRemoveConfirm: "Uninstall",
			setSelfCancel: "Cancel",
			setSelfWorking: "Uninstalling…",
			setSelfRemoved: "Uninstalled",
			setSelfRemovedHint: "Restart DeepSeek Harness to finish cleaning up.",
			setSelfFailed: "The operation failed",
			versionHint: "Plugin market version — include it when reporting an issue",
			offlineBadge: "Intranet",
			offlineHint: "Intranet mode: plugins install from the internal npm registry and the catalog is the one your operators publish. Comments, screenshots and GitHub links are unavailable here.",
			subtitle: "Discover community plugins for DeepSeek Harness",
			submitPlugin: "Submit a plugin ↗",
			descExpand: "Show more",
			descCollapse: "Show less",
			descMore: "Show all",
			searchPh: "Search plugins: notify, terminal, memory…",
			searchFavoritesPh: "Search favorites…",
			clearSearch: "Clear search",
			capabilityTitle: "What it does",
			capabilityAhead: "After you install, it can",
			capabilityCount: "{0} found",
			capabilityCountUncommon: "{0} found, {1} less common among scanned plugins",
			capabilityUncommonLegend: "Filled items are less common among scanned plugins",
			capGroupFiles: "Files & env",
			capGroupNetwork: "Network",
			capGroupRun: "Runs code",
			capGroupKeys: "Keys",
			capGroupHost: "DSH internals",
			capGroupOther: "Other",
			capShell: "runs commands",
			capFsRead: "reads files on this machine",
			capFsWrite: "writes files on this machine",
			capNetwork: "connects to servers",
			capCredentials: "uses your API keys",
			capEnv: "reads your environment variables",
			capLlm: "calls an AI model",
			capSubagent: "runs its own subagents",
			capDynamicCode: "runs code it assembles at runtime",
			capHostRuntime: "uses DSH host-internal packages",
			capInstallScript: "runs code when you install",
			capabilityNone: "Nothing found — which is not the same as safe.",
			capabilityUnchecked: "Not scanned yet",
			capabilityNote: "A static scan only shows what it found. “Nothing found” is not “safe”.",
			capabilityScannedAt: "Scanned {0}",
			capRedCredentialsNetwork: "connects to servers and uses your API keys",
			capRedPlaintextHttp: "makes an unencrypted connection to {0}",
			capRedLiteralIp: "connects to the fixed IP address {0}",
			capRedInstallScript: "runs its own script the moment you install — you do not have to open the plugin",
			capRedInstallScriptScripts: "runs {0} the moment you install — you do not have to open the plugin",
			capRedCoreTamper: "replaces parts of DSH itself",
			capRedCoreTamperDetail: "replaces parts of DSH itself ({0})",
			capRedCoreOverride: "overrides a part of DSH itself ({0})",
			capRedCoreDisable: "disables a part of DSH itself ({0})",
			favoriteAdd: "Add to favorites",
			favoriteRemove: "Remove from favorites",
			favoritesEmpty: "No favorites yet. Use the bookmark icon in Discover or Themes, or “Add to favorites” in an installed row’s “···” menu.",
			favoritesResultCount: "{0} favorites",
			favoritesPluginsSection: "Plugins ({0})",
			favoritesThemesSection: "Themes ({0})",
			favoritesStaleEmpty: "Bookmarked entries are no longer in the catalog.",
			favoritesStaleNote: "{0} favorites are no longer in the catalog",
			favoritesClearStale: "Remove stale favorites",
			favoritesClearingStale: "Removing…",
			blockAdd: "Hide",
			blockRemove: "Show again",
			blockMoved: "Removed from Discover. Undo it in Hidden, the tab after Installed.",
			blockedTabHint: "These stay off Discover, and Update all skips them.",
			blockedFilteredEmpty: "Matching plugins are on the Hidden tab.",
			blockedEmpty: "No hidden plugins yet.",
			blockFailed: "Could not update the hidden list. Try again.",
			tabDiscover: "Discover",
			tabFavorites: "Favorites",
			tabInstalled: "Installed",
			tabBlocked: "Hidden",
			tabAdvanced: "Advanced",
			all: "All",
			install: "Install",
			installing: "Installing…",
			installedBadge: "✓ Installed",
			alreadyInstalled: "✓ Installed",
			restartBanner: "change(s) pending restart — restart DeepSeek Harness to apply",
			uninstall: "Uninstall",
			confirmRemove: "Uninstall?",
			uninstalling: "Uninstalling…",
			uninstallConfirmDesc: "This removes the plugin from the current profile.",
			uninstallLibraryConfirmDesc: "Removing this library may stop plugins that use it from starting.",
			restartHint: "To restart: stop the current dsh process and run it again (e.g. dsh web)",
			restartHintSupervised: "This process is {0}'s own service process, so restarts belong to it — restarting from here would kill the takeover process along with the cgroup and the service would not come back. Use systemctl restart &lt;your unit&gt;. If your unit can survive a self-restart (KillMode=process), turn Allow restart on in this plugin's configuration.",
			restartHintDebugged: "This dsh process is under a debugger. Stop it from your IDE or terminal and start it again — the market cannot stop the debugged process from the UI.",
			restartHintViaProxy: "You are reaching dsh through a proxy or gateway, and for safety restart only accepts a direct local connection. Restart it on the machine running dsh, for example with docker restart or kubectl rollout restart.",
			confirmTitle: "Install",
			confirmWarn: "Community third-party plugin. Build scripts do not run by default.",
			installCaution: "Before you install",
			terminalCautionTitle: "May not work in the web app",
			terminalCautionBody: "This is a terminal plugin. It may not work in the web version.",
			terminalCautionStartup: "It can stop DeepSeek Harness from starting.",
			terminalCautionLink: "Read its instructions first ↗",
			cancel: "Cancel",
			empty: "No plugins match",
			clearFilters: "Clear filters",
			installedEmpty: "No community plugins yet — browse the Discover tab",
			marketGoneTitle: "The plugin market stopped running",
			marketGoneBody: "DSH unloaded the market while reloading plugins. Restart DSH to bring it back. The last operation may already have finished.",
			marketGoneRecord: "DSH unloaded the market, so this operation got no result. Once the market is back, check Installed.",
			marketGoneReconnecting: "Reconnecting…",
			marketGoneReconnect: "Reconnect",
			loadFail: "The plugin catalog failed to load. Try again later.",
			loadRetry: "Retry",
			installFail: "Install failed",
			viewSource: "Source",
			refreshBanner: "change(s) applied — refresh the page to see them",
			refresh: "Refresh",
			update: "Update",
			updating: "Updating…",
			updated: "✓ Updated — restart to apply",
			cancelOp: "Cancel",
			cancelled: "Cancelled",
			busyWait: "Another install, update or uninstall is still running — wait for it to finish, then try again.",
			agentBusyUpdate: "An agent is currently working — wait for it to finish (or cancel it) before updating. Updates replace plugin files in place, so a working agent can fail or mix versions mid-turn.",
			agentBusyInstall: "An agent is currently working — wait for it to finish (or cancel it) before installing. Installing changes plugin files, so a working agent can fail mid-turn.",
			agentBusyQueued: "Agent is busy — queued and will install automatically when idle (cancel it in Tasks, top right).",
			agentBusyUpdateQueued: "Agent is busy — queued and will update automatically when idle (cancel it in Tasks, top right).",
			agentBusyUninstallQueued: "Agent is busy — queued and will uninstall automatically when idle (cancel it in Tasks, top right).",
			queuedRunBlocked: "{0} session(s) are running, so this cannot start yet: these operations replace plugin files in place, and a working agent can fail mid-turn. It will begin on its own once they go idle (or cancel this entry in Tasks).",
			queuedRunBusy: "Another install, update or uninstall is still running, so this cannot start yet: it stays queued and begins on its own when that one finishes — no need to press again.",
			queuedInstallGone: "The plugin this entry was going to install is no longer in the catalog (it was refreshed or you changed pages), so the entry was removed. Find it in the catalog and install it again.",
			agentQueueStaleGone: "It was installed when you queued this, and is not now — skipped, nothing was uninstalled.",
			agentQueueStaleNoUpdate: "It had an update available when you queued this, and does not now — skipped.",
			queuedBadge: "Queued",
			agentDrainBadge: "Waiting for Agents",
			agentDrainWaiting: "Waiting for {0} Agent(s) to reach a safe point…",
			agentDrainShowAgents: "Show running sessions",
			agentDrainVerifying: "Verifying the result…",
			agentDrainCancelled: "Cancelled.",
			agentDrainRestarted: "The host restarted before this finished, so the task was cancelled. Start it again if you still need it.",
			agentDrainHistoryDone: "The last deferred operation completed.",
			agentDrainHistoryFailed: "The last deferred operation failed ({0}). Check Installed or the exported log.",
			agentDrainHistoryFailedShort: "The last deferred operation failed. Check Installed or the exported log.",
			agentDrainHistoryCancelled: "The last deferred operation was cancelled.",
			favoriteFailed: "Could not update favorites. Try again.",
			favoriteUnavailable: "Favorites are unavailable. Refresh the page or restart dsh web.",
			favoriteBusy: "A plugin operation is still running. Favorites were not saved — try again shortly.",
			compatRiskBanner: "Compatibility risk detected — open Diagnostics before restarting, or roll this operation back.",
			compatRiskBannerNoRollback: "Compatibility risk detected — open Diagnostics before restarting.",
			shadowNameBanner: "One plugin name is now defined in two places (informational only, not a conflict):",
			brokenBundleBanner: "These plugins have damaged UI files. The page may be blank after a refresh; rolling back is recommended:",
			goDiagnose: "Open Diagnostics",
			rollbackNow: "Roll back",
			rollingBack: "Rolling back…",
			rollbackUnavailable: "Automatic rollback is unavailable because the previous exact source could not be verified.",
			approveBuilds: "Allow build scripts and retry",
			buildsSkipped: "This plugin needs its build scripts to run; they are blocked by default for safety. If you trust the source, allow them and reinstall:",
			restartNow: "Restart now",
			dismiss: "Dismiss",
			dismissNotice: "Dismiss this notice",
			restarting: "Restarting…",
			restartFail: "Restart failed",
			restartTimeout: "Timed out waiting for DeepSeek Harness to start",
			updateNow: "Update now",
			updateFail: "Update failed",
			upToDate: "Up to date",
			updateHeldTag: "new version waiting",
			updateHeldTarget: "Latest {0} was just released; about {1} hours to wait. Update to {2} for now.",
			updateHeldTargetUnknown: "The release time of latest {0} is unknown, so it still needs to wait. Update to {2} for now.",
			updateHeldHint: "This profile waits a while before it installs a fresh release; about {1} hour(s) left.",
			updateHeldEstimatedHint: "The new version is listed, but the registry mirror has not caught up with its metadata, so the update is held; the market checks again in about {1} minute(s).",
			newerPrereleaseAvailable: "prerelease {0} published",
			newerPrereleaseHint: "The package's latest tag has no update; the prerelease line you are on published a newer build.",
			unreleasedCommits: "New commits (unreleased) {0}",
			unreleasedCommitsHint: "The selected branch has commits newer than your install, but no new version was published; the market installs releases only and will not apply them automatically.",
			linkedDev: "local",
			hostUpdateReady: "New version {0}",
			hostUpdateHint: "Installed and updated by the desktop app; update it there.",
			notesLink: "What changed",
			notesRelease: "Release notes",
			notesCommits: "Commits",
			notesCommitsRecent: "Recent commits (do not match your installed version — for reference only)",
			notesNpm: "Version publish times",
			notesNone: "This plugin does not publish update notes.",
			notesSource: "The market doesn't have update notes for this plugin yet.",
			notesSourceUnreadable: "This plugin was not installed from GitHub, so the market cannot read its change history.",
			notesSourceLink: "See what changed in the repository",
			notesSourceNoLink: "You can ask the plugin author what changed.",
			notesLoadFail: "Update notes are unavailable right now — try again later.",
			migrateNpm: "Use npm version",
			migrateTitle: "Use npm version?",
			migrateDescription: "This changes the plugin's install source rather than its version.",
			migrateCurrentSource: "Current source",
			migrateTargetSource: "New npm source",
			migrateWarning: "The npm package may be published by someone else and not be the same plugin. Continue only if you trust it.",
			migrateContinue: "Confirm switch",
			migrateFail: "Source switch failed",
			renameRowAction: "Migrate to new name",
			renameTitle: "Migrate to the new name and update?",
			renameDescription: "This plugin has a new npm package name, and the old one no longer gets new versions. Migrating moves the install to the new name; switches, groups and notes stay.",
			renameCurrentPackage: "Current package",
			renameTargetPackage: "New package",
			renameWarning: "Data the plugin saved itself (personas, habits, bindings) is not part of the market; migrating leaves it alone.",
			renameContinue: "Migrate and update",
			restoreOnline: "Use online version",
			restoreHint: "This uninstalls the local version and installs the online version. Update checks continue as usual. This cannot be undone.",
			hostIncompatibleTitle: "This release needs a newer DSH",
			hostIncompatibleBody: "{plugin} declares that it needs DSH {requirement}, and you are running {host}. Installing it would most likely break the plugin, leaving a manual downgrade as the only way back.\nNothing was changed — the plugin is still on its current version.\nIf you know the version number is wrong (a bundled DSH that does not report one, for example), you can update anyway.",
			hostIncompatibleUnknown: "an unknown version",
			hostIncompatibleSearching: "Looking for a version that still supports this DSH…",
			hostIncompatibleFoundInstall: "You can install {version} — it declares support for this DSH.",
			hostIncompatibleFoundUpdate: "You can update to {version} — it declares support for this DSH.",
			hostIncompatibleHeldTarget: "{version} does declare support for this DSH, but it is still inside the release-age wait — a new release has to settle for {window} hours, so about {hours} more to go.",
			hostIncompatibleHeldTargetUnknown: "{version} does declare support for this DSH, but it is still inside the release-age wait, and this host cannot work out how long is left.",
			hostIncompatibleHeldButton: "Still waiting ({hours}h)",
			hostIncompatibleHeldButtonUnknown: "Still waiting",
			hostIncompatibleNoCompat: "No version declares support for this DSH.",
			hostIncompatibleSearchFailed: "Could not look up compatible versions.",
			hostIncompatibleInstallCompat: "Install {version}",
			hostIncompatibleUpdateCompat: "Update to {version}",
			hostIncompatibleRetry: "Retry",
			hostIncompatibleKeep: "Keep the current version",
			hostIncompatibleAnyway: "Update anyway",
			hostStatusCompatible: "Host requirement satisfied (declared)",
			hostStatusIncompatible: "Confirmed incompatible with this DSH",
			hostIncompatibleBodyInstall: "{plugin} declares that it needs DSH {requirement}, and you are running {host}. Installing it would most likely break the plugin.\nNothing was installed.\nIf you know the version number is wrong (a bundled DSH that does not report one, for example), you can install anyway.",
			hostIncompatibleCancel: "Cancel install",
			hostIncompatibleInstallAnyway: "Install anyway",
			restoreNameOnlyHint: "Your local copy does not name its source repository, so the market could only match it by package name. The plugin below may be another author's plugin with the same name, not the source of your copy. Check the owner and repository before confirming. This uninstalls the local version, installs that plugin, and cannot be undone.",
			restoreContinue: "Continue update",
			restoreProceed: "Confirm restore",
			restoreNoCatalogTitle: "Cannot restore",
			restoreNoCatalog: "This plugin is not in the curated catalog, so it cannot be restored. Uninstall the local copy, or keep developing it locally.",
			restoreNoMatch: "A same-named plugin exists in the catalog, but it does not match your local repository, so restore is not safe. Uninstall the local copy, or keep developing it locally.",
			restoreFail: "Restore failed",
			exportLog: "Export log",
			crashTitle: "The plugin market could not be displayed",
			crashHint: "'The market could not be displayed. Your plugins are unaffected and nothing was changed.\nReload usually fixes this. If it keeps happening, export the log and attach it to an issue — the log records where the error occurred.\nIf your browser is translating this page, turn translation off and reload. This is a known cause.'",
			crashReload: "Reload",
			crashDetails: "Error details",
			exportingLog: "Exporting…",
			exportedLog: "Log exported: dsh-market-log.txt — please attach it to your issue",
			exportLogFail: "Log export failed",
			readme: "README",
			comments: "Comments",
			commentsTitle: "Comments",
			commentsNote: "Comments come from GitHub Discussions. Opening this connects to giscus.app and GitHub; posting needs a GitHub account.",
			commentsLoginHint: "Signing in here leaves this page; you will need to reopen dsh web — nothing is broken. Post on GitHub; this page is for reading only.",
			commentsLoading: "Loading comments…",
			commentsError: "Comments could not be loaded. Check your connection and try again.",
			commentsRetry: "Try again",
			commentsOnGitHub: "Sign in and join on GitHub",
			conflictTitle: "Cannot install: conflicts with an installed plugin",
			conflictBody: "It conflicts with an installed plugin — only one can stay:",
			conflictReverted: "Reverted automatically; nothing was changed",
			conflictKeep: "Keep existing plugins",
			conflictKeepNote: "",
			conflictSwap: "Switch to this one",
			conflictSwapNote: "Settings of the uninstalled plugins are kept, so you can reinstall later",
			conflictDetails: "Details",
			conflictOutcomeInstall: "install",
			conflictOutcomeSkip: "skip",
			conflictOutcomeKeep: "keep",
			conflictOutcomeRemove: "uninstall",
			conflictWhy: "cordis rejects duplicate entry ids; keeping this plugin would stop DeepSeek Harness from starting.",
			opTitle: "Tasks",
			opInstalling: "Installing",
			opNeedsYou: "need attention",
			opQueued: "Queued",
			opQueuedAhead: "ahead:",
			opQueuedWaitingAgents: "waiting for {0} running session(s)",
			opWaitingAgents: "{0} task(s) waiting for agents to go idle",
			opRunning: "In progress",
			opNeedsChoice: "Cannot install · reverted automatically, nothing changed",
			opDone: "Done",
			opDoneRefresh: "Installed · refresh the page to apply",
			opLeaveHint: "You can leave this page; you will be notified when it finishes",
			opLeaveHintAgents: "Starts on its own once the agents go idle",
			opEmpty: "No operations in progress",
			opEmptyHint: "Install, update and uninstall progress appears here",
			opClose: "Collapse",
			opClear: "Clear finished",
			opDequeue: "Remove from queue",
			opRunNow: "Run now",
			opUpdateNow: "Update now",
			opUninstallNow: "Uninstall now",
			agentsRunningConfirm: "Continue anyway?",
			agentsRunningRisk: "Sessions are running. This operation replaces or removes plugin files, so running sessions may fail mid-turn. Cancel and wait for them to finish if you do not want to take this risk.",
			opRetry: "Retry",
			opKind_install: "Install",
			opKind_update: "Update",
			opKind_uninstall: "Uninstall",
			opBlockedCard: "Cannot install · details",
			conflictDeclined: "You kept the installed plugins; this one was not installed",
			conflictReplacing: "Replacing…",
			conflictReplaceFailed: "Replace did not finish. These plugins were uninstalled and not restored — reinstall them:",
			lightboxClose: "Close preview",
			lightboxPrev: "Previous",
			lightboxNext: "Next",
			envMissing: "pnpm needs to be set up before installing plugins",
			envFix: "Set up automatically",
			envFixing: "Setting up…",
			envFixFail: "Automatic setup failed. Export the log and attach it to your issue.",
			loading: "Loading the catalog…",
			backTop: "Back to top",
			confirm: "Confirm",
			confirmInstall: "Confirm install",
			cmdDetails: "Install command",
			cmdCopy: "Copy install command",
			cmdDesktopUnavailable: "The desktop app installs plugins itself — use the Install button above; `dsh plugin` refuses this profile.",
			cmdCopied: "Copied",
			catsMore: "More categories",
			catsLess: "Fewer categories",
			filter: "Filter",
			filterSort: "Sort field",
			filterDir: "Order",
			filterTime: "Released within",
			filterHost: "Host version",
			hostAll: "Show all",
			hostCompatible: "Compatible with current DSH {0}",
			hostDetecting: "Detecting host version…",
			hostUnknown: "Host version unknown",
			hostFilterLoading: "Checking host requirements {0}/{1}; undeclared or unavailable plugins remain visible",
			hostFilterActive: "Hid {1} plugins incompatible with DSH {0}; those declaring no version stay listed",
			hostRequirement: "DSH {0}",
			hostRequirementLoading: "Reading host requirement…",
			hostRequirementUndeclared: "Host requirement undeclared",
			hostRequirementUnavailable: "Host requirement unknown",
			sortDownloads: "npm downloads (30d)",
			downloadsPeriod: "30d",
			downloadsMeaning: "Last 30 days on npm: {0}",
			githubReleaseDownloadsMeaning: "GitHub Release asset downloads, all time: {0} (packages, checksums and companion files)",
			starsMeaning: "GitHub stars: {0}",
			statisticCheckedAt: "; checked {0}",
			downloadsWindow: " ({0} – {1})",
			/** Discover/theme card byline tooltip for catalog `version`. */
			catalogNpmLatest: "npm latest",
			catalogVersionDated: "the installable version as of the catalog's last refresh ({0}); a release published since then appears after the next refresh",
			catalogVersionUndated: "the installable version as of the catalog's last refresh — the catalog updates daily, so newer project releases may not appear yet",
			sortStars: "Stars",
			sortAdded: "Date added",
			recentlyAdded: "Recently added",
			recentHide: "Hide this block",
			recentShow: "Show recently added",
			sortDesc: "Descending",
			sortAsc: "Ascending",
			sortNewest: "Newest",
			sortOldest: "Oldest",
			timeAll: "Any time",
			timeDay: "Last day",
			timeWeek: "Last 7 days",
			timeMonth: "Last 30 days",
			timeQuarter: "Last 90 days",
			timeYear: "Last year",
			published: "Date added",
			prevPage: "Previous",
			nextPage: "Next",
			loadMore: "Load more",
			pageInfo: "Page {0} of {1}",
			perPage: "Per page",
			marketUpdate: "Update the plugin market",
			updateAll: "Update all",
			heldReleaseNotice: "Installed, but not the newest: this profile's minimumReleaseAge held {0} back, so {1} was installed.",
			versionUnverifiedNote: "Installed, but the version could not be confirmed: both registry lookups failed, so {0} is what pnpm chose. The plugin page shows the version actually on disk.",
			versionUnverifiedNoteUnknown: "Installed, but the version could not be confirmed: both registry lookups failed. The plugin page shows the version actually on disk.",
			installedDependencyNote: "{0} more packages came in as dependencies of plugins — they are not plugins, so they are not listed above.",
			heldReleaseAction: "Install {0} anyway",
			ignoreUpdateNotice: "Don't remind until restart",
			openInHostPage: "View in Plugins",
			ignoreAllUpdateNotices: "Don't remind any until restart",
			updateNoticeIgnored: "No reminders until restart",
			updateExemptAdd: "Never remind about updates",
			updateExemptRemove: "Resume update reminders",
			updateExemptMark: "Reminders off",
			updateExemptRestore: "Remind again",
			updateExemptHint: "New versions stay listed. Only the reminder stops.",
			updateExemptOn: "Update reminders are off. New versions stay listed.",
			updateExemptOff: "Update reminders are back on.",
			updateExemptFailed: "Couldn't save that. Try again.",
			updateAvailableShort: "New version",
			copyPath: "Copy path",
			pathCopied: "Copied",
			tabThemes: "Themes",
			tabBackup: "Backup & Restore",
			backupLocal: "Local file",
			backupExportFailed: "Backup export failed",
			backupDownload: "Export backup",
			backupImport: "Import and preview",
			backupHint: "Includes the plugin list and profile configuration, not the plugin files. Restore reinstalls them from the list.",
			webdav: "WebDAV",
			webdavPreset: "Provider preset",
			webdavUrl: "Backup file URL",
			webdavUser: "Username (optional)",
			webdavPassword: "Password (optional)",
			webdavUpload: "Upload backup",
			webdavRestore: "Restore from WebDAV",
			autoBackup: "Back up daily (when the market opens)",
			webdavNote: "The WebDAV URL and username stay in this browser only; the password lives in this page and has to be re-entered after a reload.",
			webdavAutoBackupPaused: "Daily backup could not run: this server needs a password, and the password is never stored, so it has to be entered again after a reload. Enter it and press Upload backup.",
			webdavPathHint: "Give the whole file path, name included: the backup writes that file and restore reads it back. With automatic backup on it uploads at most once a day.",
			localOnly: "The WebDAV URL and username stay in this browser only.",
			credsWarning: "Note: backups include profile configuration and files that may hold secrets (config.toml, .env, …). Local exports are unmodified, so upload only to a WebDAV target you trust.",
			gist: "GitHub Gist",
			gistToken: "GitHub token (session memory only — re-enter after refresh; leave empty to use server-side DSH_GITHUB_TOKEN or a logged-in gh CLI)",
			gistId: "Gist ID or URL (leave empty on export to create a new private Gist)",
			gistVerify: "Verify connection",
			gistExport: "Export to Gist…",
			gistImport: "Import from Gist",
			gistExportDone: "Exported to Gist",
			gistVerifySource: "Verified — token source: {0}",
			gistSrcToken: "manually entered",
			gistSrcEnv: "DSH_GITHUB_TOKEN env var",
			gistSrcGh: "gh CLI",
			gistExportSelect: "Select plugins to export",
			gistExportHint: "All checked = full backup (config included); otherwise only the checked plugins are exported, plus “include config” if ticked.",
			gistSelectAll: "Select all",
			gistSelectNone: "Select none",
			gistIncludeConfig: "Include config files (may contain secrets)",
			gistNoPlugins: "This profile has no plugins to export",
			gistSpecLocal: "local",
			gistExportGo: "Export",
			gistCreated: "Exported:",
			gistErrTimeout: "GitHub request timed out — check your network and retry",
			gistErrNetwork: "Cannot reach GitHub — check your network or proxy",
			gistErrAuth: "GitHub authentication failed: invalid/expired token, or gh CLI not logged in",
			gistErrNotFound: "Gist not found — check the ID or URL",
			gistErrRateLimit: "GitHub rate limit hit, or the token lacks the gist scope",
			gistErrInvalid: "Gist content is invalid or uses an unsupported backup format",
			gistModeUpdate: "Update the Gist in the field",
			gistModeCreate: "Create a new private Gist",
			gistErrNoId: "Update mode needs a Gist ID — fill it in, or switch to “Create”",
			gistNote: "Unlike local export (this-machine archive), Gist is for cross-machine sync: export to a private Gist, then import it on another computer with the same account to reuse your plugins. The token lives in this session's memory only and is never written to browser storage; a logged-in gh CLI or DSH_GITHUB_TOKEN skips entering it. Gists are private, 1 MB per file.",
			backupWorking: "In progress…",
			backupDone: "Backup uploaded",
			restoreDone: "Restore complete — restart DeepSeek Harness",
			restorePartial: "Restore completed, but these plugins failed to install:",
			restoreUnportable: "installs from a path on another computer that does not exist here — reinstall or point it to a local path",
			restoreSelfPinned: "the market keeps its own version during a restore — swapping it mid-restore would replace the running market. Update it separately when you want the newer one",
			restoreBootError: "Still cannot boot after the restore:",
			orphanBundle: "⚠️ The next start will fail: the profile declares these plugins but they are not installed. Reinstall them, or remove them from dsh.profile.bundles in the profile package.json:",
			restoreConfirm: "Restore will overwrite this profile configuration and reinstall plugins. Continue?",
			restorePreviewDone: "Backup imported. Review Installed, then start restore.",
			restoreMissing: "{0} plugins from this backup are not installed",
			restoreStart: "Start restore",
			notInstalled: "Not installed",
			themeApply: "Use",
			themeActive: "Active",
			themeDeactivate: "Deactivate",
			themeEmpty: "No themes in the catalog yet",
			themePreview: "Preview",
			themePreviewLoading: "Finding preview…",
			themePreviewMissing: "Preview unavailable",
			themePreviewCount: "{0} previews",
			themeResultCount: "{0} themes",
			themeFullscreen: "Browse full screen",
			themeExitFullscreen: "Exit full screen",
			progressHint: "First installs download the plugin and its dependencies — large plugins can take 1-3 minutes",
			progressSlow: "Taking longer than usual. A dependency that downloads or compiles can need a few minutes. Cancel and retry on another network if you cannot wait",
			toastReady: "installed and live",
			toastTheme: "is now active. Switch any time in Settings → Plugin Market → Themes",
			toastToggledOn: "is now on",
			toastToggledOff: "is now off; it stopped working immediately",
			gotIt: "Dismiss",
			stateLive: "Active",
			stateRestart: "Installed — restart to apply",
			stateIncompatible: "Installed — incompatible with this dsh",
			stateInert: "Installed, not active",
			stateLibrary: "Library",
			libraryUseHint: "Shared code for other plugins. No need to enable it.",
			stateDependencyLibrary: "Library for {0}",
			stateLoadedByProfile: "Loaded by your setup",
			stateBroken: "Installed, verification failed",
			stateFailed: "Did not load at start",
			stateDisabled: "Disabled",
			phaseResolving: "Preparing dependencies",
			phaseDownloading: "Downloading",
			phaseLinking: "Linking",
			phaseBuilding: "Running build scripts",
			cancelling: "Cancelling…",
			packagesDone: "{0} packages processed",
			updatedLive: "✓ Updated — live",
			updatedLibrary: "✓ Updated",
			partialNote: "Cancelled — some changes were applied",
			reconciledNote: "Removed, but pnpm reported an error while finishing up (usually a locked file). Your settings are already in sync — no retry needed.",
			actWhy: "Why is it not active?",
			tabList: "List",
			tabGroups: "Groups",
			repoLink: "View the repository on GitHub",
			viewSourceRepo: "View the repository↗",
			disabledState: "Disabled",
			noteAdd: "Add note",
			noteEdit: "Edit note",
			noteTheirs: "Original",
			noteMine: "My note",
			noteSave: "Save",
			notePlaceholder: "Describe it in your own words. This replaces the author description.",
			noteSeeTheirs: "Show the author description",
			noteSeeMine: "Back to my note",
			switchOnLabel: "Enabled",
			enable: "Enable",
			disable: "Disable",
			toggleFail: "Toggle failed",
			deprecatedBadge: "Deprecated",
			deprecatedWarn: "This plugin is marked as deprecated by the catalog; new users are advised against installing it.",
			configNamespaceNotice: "{0}'s settings panel cannot read its config: it asks for \"{1}\", and no entry id in this environment has that name. Its own entry is \"{2}\", which is what the plugin's client should ask for — the mistake is in the plugin, and the market cannot change it.",
			brokenPluginTitle: "{0} was removed after a failed update",
			brokenPluginBody: "The running DSH blocked the update, and the version it was replacing was already damaged. The market removed it from the profile so the next start does not fail. Its directory is untouched — quit DSH and install it again.",
			brokenPluginTitleCancelled: "{0} was removed after an update was cancelled",
			brokenPluginBodyCancelled: "The update was cancelled after the old version had been partly cleared. The market removed it from the profile so the next start does not fail. Its directory is untouched — install it again; if that fails, quit DSH first.",
			brokenPluginAction: "Find this plugin",
			brokenPluginDismiss: "Stop showing this",
			viewReplacement: "View replacement",
			installReplacement: "Install replacement",
			replacementHint: "Catalog suggests",
			groupNew: "New group",
			groupNamePh: "Group name",
			groupRename: "Rename",
			groupDelete: "Delete group",
			groupConfirmDelete: "Delete group?",
			groupExpand: "Expand {0}",
			groupFold: "Collapse {0}",
			groupThemeTaken: "Already has a theme",
			groupSearchEmpty: "No matching plugins",
			groupStateInert: "Not active",
			groupStateRestart: "Restart to apply",
			groupStateBroken: "Verification failed",
			ungrouped: "Ungrouped",
			groupAssign: "Assign to",
			groupRemove: "Remove",
			groupEmpty: "No members yet",
			groupMixed: "Partially enabled",
			noGroups: "No groups yet. Create one to begin.",
			groupCreate: "Create",
			groupAdd: "Add members",
			groupAddEmpty: "No ungrouped plugin available to add",
			groupAddPick: "Add",
			groupAddSearchPh: "Search plugins…",
			groupAddTitle: "Add to “{0}”",
			groupAddSelected: "{0} selected",
			groupAddConfirm: "Add {0}",
			groupAddHint: "Adding to a group does not enable plugins",
			groupPickTheme: "Choose theme",
			groupChangeTheme: "Change theme",
			groupThemeTitle: "Choose a theme for “{0}”",
			groupThemeUse: "Use",
			groupThemeEmpty: "No ungrouped theme",
			groupThemeHint: "A group holds one theme. Choosing one does not enable it. Replacing moves the previous theme out of the group.",
			groupThemeCurrent: "Current",
			groupThemeRemove: "Remove theme",
			groupThemeBadge: "Theme",
			groupOrgHint: "Groups are for organization only and do not change enable state",
			groupMembersMeta: "{0} · {1} enabled",
			groupMore: "More",
			groupRenameSave: "Save",
			groupRenameTitle: "Rename group",
			groupRenameHint: "Only the group name changes — members and enable state stay the same",
			tabDiagnostics: "Diagnostics",
			checkIssues: "Issues found",
			checkErrors: "Errors",
			checkWarnings: "Warnings",
			checkLoading: "Analyzing the profile…",
			checkLoadFail: "Failed to load diagnostics: ",
			checkProfile: "profile",
			checkErrorsEmpty: "No errors",
			checkWarningsEmpty: "No warnings",
			checkBundles: "Plugin load order (bundles)",
			checkBundlesEmpty: "No plugin packages configured",
			checkOfficial: "official",
			checkCommunity: "community",
			checkSource: "source",
			checkEntries: "entries (loader ids)",
			checkPatch: "patch file",
			checkDir: "directory",
			checkDuplicates: "Duplicate plugin entries",
			checkDuplicatesEmpty: "No duplicate plugin entries",
			checkHoisted: "top level",
			checkPeerMismatches: "Dependency version mismatches",
			checkPeerEmpty: "No dependency version mismatches",
			checkPeerInfo: "{0} more unconfirmed entries",
			checkPeerOverview: "{0} mismatch(es) · {1} informational",
			checkRange: "required version",
			checkResolved: "resolved version",
			checkSatisfied: "satisfied",
			checkUnsatisfied: "not satisfied",
			checkUnknown: "unknown",
			checkPeerRisk: "Dependency risks",
			checkPeerRiskEmpty: "No dependency risks",
			checkPeerWarning: "Dependency warnings",
			checkPeerWarningEmpty: "No dependency warnings",
			checkPeerInfoTier: "Dependency info",
			checkPeerInfoTierEmpty: "No dependency info",
			checkPeerSatisfied: "Satisfied dependencies",
			checkPeerSatisfiedEmpty: "No satisfied dependency entries",
			peerRiskBelowMin: "below declared minimum",
			peerRiskAboveMax: "above explicit maximum",
			peerWarnOptional: "optional peer",
			peerWarnAboveMax: "above declared upper bound",
			peerInfoUnverified: "unverified",
			checkMultiVersion: "Multi-version core packages",
			checkMultiEmpty: "No multi-version core packages",
			checkOverrides: "Overrides",
			checkOverridesEmpty: "No overrides",
			checkOverridden: "overrides",
			checkResiduals: "Leftover directories",
			checkResidualsEmpty: "No leftover directories.",
			checkResidualsHint: "No plugin uses these directories and they do not stop DSH from starting: an interrupted update left them behind. Quit DSH, then delete them or reinstall the affected plugin.",
			checkResidualTmp: "pnpm temp directory",
			checkResidualIncomplete: "incomplete package (no package.json)",
			checkConfigNamespaces: "Plugins whose settings read the wrong name",
			checkConfigNamespacesEmpty: "No plugin does this.",
			checkConfigNamespacesHint: "A plugin panel reads its own config by ENTRY ID. A wrong name there reports nothing: the panel is blank and cannot save, and the plugin falls back to whatever default it hardcoded (a canvas panel shows a white screen). The name is wrong inside the plugin's own client bundle — the market cannot fix it, its author has to change one line.",
			checkConfigNamespaceRow: "it reads its config from \"{0}\", which is not an entry id",
			checkConfigNamespaceOwn: "its own entry id",
			checkConfigNamespaceNone: "it declares no entry id of its own",
			checkOrphans: "Invalid config entries",
			checkOrphansEmpty: "No invalid config entries",
			orphanInsertNotArray: "malformed",
			orphanInsertTargetMissing: "target not found",
			orphanInsertTargetNotGroup: "target is not a group",
			orphanIdRequired: "missing id",
			orphanPatchTargetMissing: "target not found",
			orphanNameMismatch: "name mismatch",
			orphanReasonOther: "other",
			diagExplain: "Glossary",
			diagExplainText: "This page checks for plugin conflicts, mismatched dependencies and wrong load order. Terms used:",
			diagTermBundle: "bundle = one plugin package, applied in order",
			diagTermEntry: "entry = one item a plugin registers in the running composition",
			diagTermPeer: "peer dependency = another package a plugin requires from the host",
			diagTermShadow: "shadowing = a plugin’s old copy covers the host’s newer one",
			diagTermOrphan: "invalid entry = config references something that does not exist",
			diagTermOrder: "load order = the order plugins activate; the later one may override the earlier",
			orderSection: "Ordering",
			orderUp: "↑",
			orderDown: "↓",
			orderApply: "Apply order",
			orderDrag: "Drag to reorder",
			orderDragHint: "Drag ⠿ to reorder. Changes are saved when you apply the order.",
			orderConflicts: "before/after conflicts in the current order",
			orderApplied: "✓ Applied — restart to apply",
			orderSuggestApply: "Apply suggested order",
			orderSuggestHint: "Suggested order (auto-sorted by before/after rules):",
			orderAutoSort: "Auto-sort",
			orderAlreadyOptimal: "Current order already satisfies every rule and plugin dependency — nothing to reorder",
			orderTrialFail: "Order check failed: {0}",
			orderDiffHint: "This order would change the composition: {0} override(s), {1} orphan(s), {2} duplicate(s)",
			duplicateNames: "Same-name plugins (informational only, not a conflict)",
			orderReset: "Reset draft",
			checkRefresh: "Re-check",
			aiFix: "AI fix",
			aiFixHint: "Hand the diagnostics to a new Agent session (copied to the clipboard; you decide whether to send)",
			aiFixIntro: "Please help me fix the plugin issues of DeepSeek Harness (profile: {0}). Diagnostics found:",
			aiFixDetect: "Step 1 — identify yourself first. Before touching anything, determine whether the process you are running in IS the DeepSeek Harness process this profile belongs to (i.e. this diagnosed composition is the one you are running in right now). Check whether the cwd / $DSH_HOME / command line points at this profile, or whether you are running inside a deepseek-harness process. If you cannot tell, assume the answer is \"yes\" (the safe choice).",
			aiFixIfSelf: "If YES — you are this harness: never change the live composition, the harness or core packages in place (don't edit cordis.patch.yml, don't reorder/enable/disable bundles, don't install/remove/upgrade a plugin, don't reinstall deps, don't upgrade/restart dsh). Three steps: 1) read-only analysis only, change nothing; 2) produce apply.sh/.bat (this fix's changes) and rollback.sh/.bat (fully reverts it); both are safe to re-run — apply snapshots only when none exists yet and never overwrites an existing snapshot (an existing one means apply already ran, so roll back or confirm before re-running), while rollback restores from that snapshot, so a half-run apply can still be rolled back and repeated rollback is safe; 3) have me run apply in an external terminal and paste the output back to you. State the reason and wait for my confirmation at each step — never run these yourself.",
			aiFixScope: "If NO — you are a process outside the target harness: you may then consider reordering dsh.profile.bundles, disabling / enabling plugins, or adjusting cordis.patch.yml. Note: official bundles are fixed; state your plan before changing anything.",
			aiFixConservative: "Be conservative: only fix the clear errors listed above (boot failures / duplicate entries / risk-level dependency mismatches). Treat warnings and informational entries (e.g. optional or unconfirmed peer ranges) only when they relate to a clear error. Do not perform unnecessary upgrades or reordering; explain each change and wait for confirmation.",
			aiFixCopied: "Fix prompt copied — paste it into a new conversation and send when ready",
			aiFixFail: "Clipboard unavailable — copy the diagnostics below manually",
			catConflict: "Conflicts",
			catDeps: "Dependencies",
			catRisk: "Risk",
			catWarn: "Warning",
			catInfo: "Info",
			catOrder: "Order",
			/** Summary-strip tooltip for the order count (before/after rule conflicts). */
			checkOrderTip: "community bundle load order conflicts with declared before/after rules",
			diagOkAll: "No conflict, dependency or ordering issues found",
			presetSection: "Plugin presets",
			presetHint: "Save the current plugin order and disabled plugins as a preset and switch anytime; applying runs a trial start and creates a snapshot first.",
			presetName: "Preset name",
			presetSave: "Save current state",
			presetSaving: "Saving…",
			presetSaved: "Preset saved",
			presetApply: "Apply",
			presetApplied: "Applied — restart to take effect",
			presetDelete: "Delete",
			presetDeleted: "Preset deleted",
			presetEmpty: "No presets saved yet",
			presetNameEmpty: "Enter a preset name",
			presetFail: "Preset operation failed: ",
			presetListFail: "Failed to load presets: ",
			presetBundleCount: "{0} plugins",
			presetPreview: "Preview",
			presetPreviewTitle: "Applying this preset will:",
			presetReorder: "reorder {0} plugins",
			presetEnable: "enable {0} plugins",
			presetDisable: "disable {0} plugins",
			presetNoop: "no changes",
			presetPreviewFail: "Preview failed: ",
			snapSection: "Snapshots & Rollback",
			snapHint: "Snapshots are taken automatically before applying changes; you can also create one manually and roll back anytime.",
			snapCreate: "Create snapshot",
			snapCreating: "Creating…",
			snapCreated: "Snapshot created",
			snapEmpty: "No snapshots yet",
			snapListFail: "Failed to load snapshots: ",
			snapCreateFail: "Failed to create snapshot: ",
			snapRestore: "Restore",
			snapRestoring: "Restoring…",
			snapRestored: "Restored — restart to apply",
			snapRestoreFail: "Failed to restore: ",
			snapRestoreConfirm: "Confirm restore",
			snapRestoreConfirmText: "Restoring overwrites the current plugins and configuration from the snapshot; this cannot be undone (create a new snapshot first if unsure).",
			snapFiles: "files",
			snapDelete: "Delete",
			snapDeleting: "Deleting…",
			snapDeleted: "Snapshot deleted",
			snapDeleteFail: "Failed to delete snapshot: ",
			snapDeleteConfirm: "Confirm delete",
			snapDeleteConfirmText: "This snapshot cannot be recovered after deletion.",
			marketNoToggle: "The market itself cannot be disabled",
			hostDependencyWarning: "A plugin lists packages that DSH already provides, so two copies may clash (declaration only — not confirmed):",
			hostDependencyMore: "{0} more omitted",
			recoveryTitle: "Boot failed — adjust plugins",
			recoveryLead: "This restart never came up, and dsh has exited. Tick the plugins to enable at the next start; the ones this boot blamed are marked in red and left unticked.",
			recoveryOption: "Adjust plugins",
			recoveryBanner: "Boot failed: ",
			recoveryOpening: "Reading the failure details…",
			recoveryNoSummary: "The log does not say why",
			recoveryRawLog: "The raw dsh output (tail)",
			recoveryBlamedHint: "The plugins marked in red failed during this boot; unticking them disables them on the next start.",
			recoveryNoBlameHint: "The log named no plugin in particular; below is what can be adjusted, as it stands now.",
			recoveryCarrier: "disables others",
			recoveryNotToggleable: "cannot be switched here",
			recoveryUnmatched: "Named by DSH but not switchable here: ",
			recoveryLogPath: "Full log: ",
			recoveryApply: "Save and restart",
			recoveryApplying: "Saving and restarting…",
			recoveryStandalone: "Open the standalone recovery page",
			recoveryRestarting: "Restarting: this page reloads once dsh is up; if it fails again you come back here with the new error.",
			recoveryApplyFailed: "Could not save: ",
			recoveryWriteFailed: "The last choice was not saved in full, so nothing was restarted: ",
			recoveryTimeout: "Timed out waiting for DeepSeek Harness to start. \"Adjust plugins\" can tell you whether one of them is what stops it.",
			hostRecoveryTitle: "Your configuration was replaced",
			hostRecoveryBody: "After the last failed start, DSH's recovery replaced your configuration with a default one. The previous {0} settings are still in the backup.",
			hostRecoverySource: "Backup: {0}, {1}",
			hostRecoveryRestore: "Restore configuration",
			hostRecoveryRestored: "Restored {0} settings. Refresh the page to see them.",
			hostRecoveryFail: "Restore failed: ",
			hostRecoveryNote: "A snapshot is taken first, so you can roll this back."
		};
		const ja = {
			nav: "プラグインマーケット",
			setCardDesc: "プラグインマーケットのバージョンと設定を確認します。",
			setSelfUpToDate: "最新バージョンです",
			setSelfUpdateReady: "新しいバージョンがあります",
			setSelfUpdateHint: "更新すると新しいバージョンをダウンロードし、再起動後に有効になります。",
			setSelfUpToDateHint: "",
			setSelfHostManagedHint: "このマーケットはデスクトップアプリがインストールしたものです。新しいバージョンへの更新はデスクトップアプリで行ってください。",
			setSelfUpdate: "更新",
			setSelfUpdatedHint: "ダウンロードが完了しました。新しいバージョンは DeepSeek Harness を再起動すると有効になります。ページには先に新しいバージョン番号が表示されます。",
			setSidebar: "サイドバーの入口",
			setSidebarHint: "サイドバーの「プラグイン」の下にマーケットを表示します。",
			setSidebarOnlyDoorHint: "このホストには設定内のマーケットページがないため、この行が唯一の入口です。オフにはできません。",
			setAdvanced: "詳細",
			setAdvancedHint: "マーケットの表示場所です。入口は最低 1 つ残してください。",
			setEntrySection: "設定の入口",
			setEntrySectionHint: "設定にマーケットのセクションを表示します。",
			setEntryPluginsTab: "プラグインページの入口",
			setEntryPluginsTabHint: "プラグインページの「インストール済み」の隣にマーケットのタブを表示します。",
			setEntryLastDoorHint: "入口を最低 1 つ残してください。現在はこれが唯一の入口です。",
			setEntryShow: "表示",
			setEntryHide: "表示しない",
			setIndexSource: "公式 Discover インデックス",
			setIndexSourceHint: "dsh 0.2.1 以降では、公式の「プラグイン → 見つける → インデックスソース」に https://cdn.jsdelivr.net/npm/dsh-plugin-catalog/index.json を追加できます。公式の見つけるページと plugin_market エージェントツールが同じカタログを検索するようになります。",
			setSidebarOn: "表示",
			setSidebarOff: "表示しない",
			sidebarTip: "もっと早く開きたいですか？サイドバーに表示できます。",
			sidebarTipDismiss: "今後表示しない",
			setRegion: "ダウンロード地域",
			setRegionGlobal: "グローバル",
			setRegionChina: "中国本土",
			setRegionGlobalHint: "npm と GitHub の公式ソースからダウンロードします。",
			setRegionChinaHint: "中国本土ではより高速です。ダウンロード経路が変わるだけで、プラグインの入手元は変わりません。",
			setRegionAuto: "ネットワーク状況から自動で選択済みです。いつでも切り替えできます。",
			setGithubProxy: "GitHub 高速化",
			setGithubProxyAutoHint: "使える経路を自動で選び、失敗したときだけ切り替えます。",
			setGithubProxyCustom: "カスタム",
			setGithubProxyCustomHint: "カスタム経路を優先し、失敗したら直接接続も試します。",
			setGithubProxyManagedHint: "環境変数 DSHM_GITHUB_PROXY で管理されており、ここでは変更できません。",
			setGithubProxyEdit: "編集",
			setGithubProxyAuto: "自動に戻す",
			setGithubProxyInput: "HTTPS 高速化プレフィックス",
			setGithubProxySave: "保存",
			setBuildEnv: "ビルド環境変数",
			setBuildEnvHint: "マーケットが起動するすべてのプロセス（インストール、コンパイル、git など）に作用します。コンパイラだけではありません。1 行に 1 つの KEY=value を書きます（例：CC=/usr/bin/gcc-11）。PATH と CI はマーケットが管理します。空で保存すると元の設定に戻ります。",
			setBuildEnvSave: "環境変数を保存",
			setChannel: "更新チャネル",
			setChannelStable: "安定版",
			setChannelBeta: "Beta",
			setChannelStableHint: "正式リリース版だけを受け取ります。",
			setChannelBetaHint: "検証前のバージョンを先行して取得します。不安定なことがあります。プラグインマーケット自体にのみ影響します。",
			setChannelDev: "開発版",
			setChannelDevHint: "開発ブランチの未検証ビルドです。一般の利用にはおすすめしません。",
			setChannelSwitch: "切り替え先",
			setChannelSwitchHint: "このバージョンは現在インストールされているものより古いです。",
			setSelfRemove: "プラグインマーケットをアンインストール",
			setSelfRemoveHint: "この profile からマーケットをアンインストールします。インストール済みの他のプラグインには影響しません。",
			setSelfRemoveRemote: "このページはこのマシンから開かれていないため、マーケットはここから自分をアンインストールできません。DSH を実行しているマシンで削除してください。デスクトップアプリなら「設定 → プラグイン」、その他の環境ではコマンドラインを使います。",
			setSelfConfirm: "プラグインマーケットをアンインストールしますか？再インストールにはコマンドラインが必要です。",
			setSelfPurge: "マーケット自身のデータも消去する",
			setSelfPurgeOn: "削除されるもの：マーケットの無効化リストとカスタムグループ、および設定ファイルに書き込まれた無効化の記録です。無効化されていたプラグインは再び動作します。パスワードやキーは関係しません。マーケットがそれらをディスクに保存することは決してありません。",
			setSelfPurgeOff: "マーケットのデータは残ります。注意：マーケットが無効化したプラグインは無効なままで、マーケットを削除すると再び有効化する画面はなくなります。",
			setSelfRemoveConfirm: "アンインストールする",
			setSelfCancel: "キャンセル",
			setSelfWorking: "アンインストール中…",
			setSelfRemoved: "アンインストールしました",
			setSelfRemovedHint: "DeepSeek Harness を再起動すると完全にクリーンアップされます。",
			setSelfFailed: "操作に失敗しました",
			versionHint: "プラグインマーケットのバージョン — 問題を報告するときに添えてください",
			offlineBadge: "イントラネット",
			offlineHint: "イントラネットモード：プラグインは社内 npm レジストリからインストールし、カタログは管理者が配布したものを使用します。コメント、スクリーンショット、GitHub リンクは利用できません。",
			subtitle: "DeepSeek Harness のためにコミュニティが開発したプラグインを見つけましょう",
			submitPlugin: "プラグインの収録を申請 ↗",
			descExpand: "展開",
			descCollapse: "折りたたむ",
			descMore: "すべて展開",
			searchPh: "プラグインを検索（例：通知、ターミナル、メモリ…）",
			searchFavoritesPh: "お気に入りを検索…",
			clearSearch: "検索をクリア",
			capabilityTitle: "このプラグインができること",
			capabilityAhead: "インストールするとできること",
			capabilityCount: "{0} 件",
			capabilityCountUncommon: "{0} 件（うち {1} 件はスキャン済みプラグインの中であまり見られません）",
			capabilityUncommonLegend: "塗りつぶした項目は、スキャン済みプラグインの中であまり見られません",
			capGroupFiles: "ファイルと環境",
			capGroupNetwork: "ネットワーク",
			capGroupRun: "実行",
			capGroupKeys: "キー",
			capGroupHost: "DSH 内部",
			capGroupOther: "その他",
			capShell: "コマンドを実行できます",
			capFsRead: "このマシンのファイルを読み取ります",
			capFsWrite: "このマシンにファイルを書き込みます",
			capNetwork: "ネットワークに接続します",
			capCredentials: "あなたのキーを使います",
			capEnv: "あなたの環境変数を読み取ります",
			capLlm: "AI モデルを呼び出します",
			capSubagent: "自分でタスクを立てて作業します",
			capDynamicCode: "実行時に組み立てたコードを実行します",
			capHostRuntime: "DSH ホスト内部のパッケージを使います",
			capInstallScript: "インストール時にコードを実行します",
			capabilityNone: "何も検出されませんでした。これは安全であることとイコールではありません。",
			capabilityUnchecked: "まだスキャン結果がありません",
			capabilityNote: "静的スキャンは「ある」ことは示せても「ない」ことは示せません。安全であることの証明にはなりません。",
			capabilityScannedAt: "スキャン日時 {0}",
			capRedCredentialsNetwork: "ネットワークに接続し、あなたのキーを使います",
			capRedPlaintextHttp: "暗号化されていない接続があります（{0}）",
			capRedLiteralIp: "固定 IP アドレスに直接接続します（{0}）",
			capRedInstallScript: "インストールした瞬間に同梱のスクリプトを実行します。プラグインを開く必要はありません",
			capRedInstallScriptScripts: "インストールした瞬間に {0} を実行します。プラグインを開く必要はありません",
			capRedCoreTamper: "DSH 本体のコンポーネントを変更します",
			capRedCoreTamperDetail: "DSH 本体のコンポーネントを変更します（{0}）",
			capRedCoreOverride: "DSH 本体のコンポーネントを上書きします（{0}）",
			capRedCoreDisable: "DSH 本体のコンポーネントを無効化します（{0}）",
			favoriteAdd: "お気に入りに追加",
			favoriteRemove: "お気に入りから外す",
			favoritesEmpty: "お気に入りはまだありません。「見つける」や「テーマ」でブックマークのアイコンを押すか、「インストール済み」の「···」からお気に入りに追加できます。",
			favoritesResultCount: "お気に入り {0} 件",
			favoritesPluginsSection: "プラグイン（{0}）",
			favoritesThemesSection: "テーマ（{0}）",
			favoritesStaleEmpty: "お気に入りの項目はカタログにありません。",
			favoritesStaleNote: "{0} 件のお気に入りがカタログにありません",
			favoritesClearStale: "無効なお気に入りを消去",
			favoritesClearingStale: "消去中…",
			blockAdd: "非表示にする",
			blockRemove: "非表示をやめる",
			blockMoved: "見つけるページから移動しました。「インストール済み」の後ろにある「非表示」で元に戻せます。",
			blockedTabHint: "これらのプラグインは見つけるページに表示されず、一括更新でもスキップされます。",
			blockedFilteredEmpty: "一致するプラグインは「非表示」タブにあります。",
			blockedEmpty: "非表示にしたプラグインはまだありません。",
			blockFailed: "非表示リストを更新できませんでした。再試行してください。",
			tabDiscover: "見つける",
			tabFavorites: "お気に入り",
			tabInstalled: "インストール済み",
			tabBlocked: "非表示",
			tabAdvanced: "高度な設定",
			all: "すべて",
			install: "インストール",
			installing: "インストール中…",
			installedBadge: "✓ インストール済み",
			alreadyInstalled: "✓ インストール済み",
			restartBanner: "件の変更は DeepSeek Harness の再起動後に有効になります",
			uninstall: "アンインストール",
			confirmRemove: "アンインストールしますか？",
			uninstalling: "アンインストール中…",
			uninstallConfirmDesc: "現在の profile からこのプラグインを削除します。",
			uninstallLibraryConfirmDesc: "この依存ライブラリを削除すると、それを使うプラグインが起動できなくなることがあります。",
			restartHint: "再起動の方法：現在の dsh プロセスを終了してから再実行してください（例：dsh web）",
			restartHintSupervised: "このプロセスは {0} サービス自体のプロセスなので、再起動はそちらに任せます。ここから再起動すると cgroup 内の takeover プロセスまで一緒に終了してしまい、サービスが起動しなくなります。systemctl restart <あなたの unit> を実行してください。あなたの設定がマーケット自身の再起動に耐えられる場合（KillMode=process など）は、このプラグインの設定で「再起動を許可」を手動でオンにできます。",
			restartHintDebugged: "現在の dsh プロセスにはデバッガが接続されています。IDE またはターミナルからそのプロセスを停止して再起動してください。デバッグ中の dsh を画面から終了することはできません。",
			restartHintViaProxy: "プロキシまたはゲートウェイ経由でアクセスしています。安全のため、再起動はこのマシンからの直接接続でのみ受け付けます。dsh を実行しているマシンで再起動してください（例：docker restart、kubectl rollout restart）。",
			confirmTitle: "インストール",
			confirmWarn: "コミュニティ製のサードパーティプラグインです。ビルドスクリプトは既定では実行されません。",
			installCaution: "インストールする前に",
			terminalCautionTitle: "Web 版では使えないことがあります",
			terminalCautionBody: "これはターミナル用プラグインです。Web 版では使えないことがあります。",
			terminalCautionStartup: "DeepSeek Harness が起動できなくなることもあります。",
			terminalCautionLink: "まず使い方を確認 ↗",
			cancel: "キャンセル",
			empty: "一致するプラグインはありません",
			clearFilters: "絞り込みをクリア",
			installedEmpty: "コミュニティプラグインはまだインストールされていません。「見つける」ページで探せます",
			marketGoneTitle: "プラグインマーケットが停止しました",
			marketGoneBody: "DSH がプラグインを再読み込みした際に、マーケットも一緒にアンロードされました。DSH を再起動すれば復旧します。直前の操作は完了している可能性があります。",
			marketGoneRecord: "マーケットが DSH からアンロードされたため、この操作の結果は届きませんでした。マーケットが戻ったら、「インストール済み」で確認してください。",
			marketGoneReconnecting: "再接続しています…",
			marketGoneReconnect: "再接続",
			loadFail: "プラグインカタログの読み込みに失敗しました。しばらくしてから再試行してください",
			loadRetry: "再試行",
			installFail: "インストールに失敗しました",
			viewSource: "ソース",
			refreshBanner: "件の変更を適用しました。ページを更新すると表示されます",
			refresh: "ページを更新",
			update: "更新",
			updating: "更新中…",
			updated: "✓ 更新しました。再起動後に有効になります",
			cancelOp: "キャンセル",
			cancelled: "キャンセルしました",
			busyWait: "別のインストール、更新、アンインストールが進行中です。完了してから再試行してください",
			agentBusyUpdate: "Agent が動作中です。完了するか先にキャンセルしてから更新してください。更新はプラグインのファイルを直接置き換えるため、動作中の Agent が途中でエラーになったり、新旧バージョンが混ざったりすることがあります。",
			agentBusyInstall: "Agent が動作中です。完了するか先にキャンセルしてからインストールしてください。インストールはプラグインのファイルを変更するため、動作中の Agent が途中でエラーになることがあります。",
			agentBusyQueued: "Agent がビジーなためキューに入れました。空き次第、自動でインストールします（右上の「タスク」でキャンセルできます）。",
			agentBusyUpdateQueued: "Agent がビジーなためキューに入れました。空き次第、自動で更新します（右上の「タスク」でキャンセルできます）。",
			agentBusyUninstallQueued: "Agent がビジーなためキューに入れました。空き次第、自動でアンインストールします（右上の「タスク」でキャンセルできます）。",
			queuedRunBlocked: "{0} 件のセッションが動作中のため、まだ実行できません。この種類の操作はプラグインのファイルを直接置き換えるため、動作中の Agent が途中でエラーになることがあります。セッションが空くと自動で始まります（「タスク」でこの項目をキャンセルすることもできます）。",
			queuedRunBusy: "別のインストール、更新、アンインストールが進行中のため、まだ始められません。この項目はキューに残り、そちらが完了すると自動で始まります。再度押す必要はありません。",
			queuedInstallGone: "この項目がインストールするはずだったプラグインは、現在のカタログに見つからなくなりました（カタログが更新されたか、ページが変わりました）。キューから削除しました。カタログで見つけ直して、もう一度インストールしてください。",
			agentQueueStaleGone: "キューに入れた時点ではインストール済みでしたが、現在は存在しないためスキップしました（アンインストールはしていません）。",
			agentQueueStaleNoUpdate: "キューに入れた時点では利用できる更新がありましたが、現在はないためスキップしました。",
			queuedBadge: "キュー待ち",
			agentDrainBadge: "Agent 待ち",
			agentDrainWaiting: "{0} 件の Agent が安全な地点に到達するのを待っています…",
			agentDrainShowAgents: "実行中のセッションを表示",
			agentDrainVerifying: "結果を確認しています…",
			agentDrainCancelled: "キャンセルしました。",
			agentDrainRestarted: "この操作が終わる前にホストが再起動したため、キャンセルされました。必要ならもう一度実行してください。",
			agentDrainHistoryDone: "前回の保留操作は完了しました。",
			agentDrainHistoryFailed: "前回の保留操作は失敗しました（{0}）。「インストール済み」またはエクスポートしたログを確認してください。",
			agentDrainHistoryFailedShort: "前回の保留操作は失敗しました。「インストール済み」またはエクスポートしたログを確認してください。",
			agentDrainHistoryCancelled: "前回の保留操作はキャンセルされました。",
			favoriteFailed: "お気に入りを更新できませんでした。しばらくしてから再試行してください",
			favoriteUnavailable: "お気に入り機能は現在使えません。ページを更新するか、dsh web を再起動してください。",
			favoriteBusy: "プラグインの操作が終わっていないため、お気に入りは保存されませんでした。しばらくしてから再試行してください",
			compatRiskBanner: "互換性のリスクが検出されました。再起動する前に診断ページで対処するか、この操作をロールバックすることをおすすめします。",
			compatRiskBannerNoRollback: "互換性のリスクが検出されました。再起動する前に診断ページで対処することをおすすめします。",
			shadowNameBanner: "この操作により、同じプラグイン名が 2 か所に現れるようになりました（参考情報であり、競合ではありません）：",
			brokenBundleBanner: "次のプラグインの画面ファイルが破損しています。更新するとページが真っ白になることがあるため、ロールバックをおすすめします：",
			goDiagnose: "診断を見る",
			rollbackNow: "ロールバック",
			rollingBack: "ロールバック中…",
			rollbackUnavailable: "更新前の正確な入手元を確認できないため、自動ロールバックは使えません。",
			approveBuilds: "ビルドスクリプトを許可して再試行",
			buildsSkipped: "このプラグインが動作するにはビルドスクリプトの実行が必要です。安全のため既定ではブロックしています。入手元を信頼できる場合は、許可してインストールし直してください：",
			restartNow: "今すぐ再起動",
			dismiss: "通知を閉じる",
			dismissNotice: "この通知を閉じる",
			restarting: "再起動中…",
			restartFail: "再起動に失敗しました",
			restartTimeout: "DeepSeek Harness の起動を待つ間にタイムアウトしました",
			updateNow: "今すぐ更新",
			updateFail: "更新に失敗しました",
			upToDate: "最新です",
			updateHeldTag: "新しいバージョンは保留中",
			updateHeldTarget: "最新版 {0} は公開されたばかりで、あと約 {1} 時間待つ必要があります。まずは {2} に更新してください。",
			updateHeldTargetUnknown: "最新版 {0} の公開時刻が不明なため、まだ待つ必要があります。まずは {2} に更新してください。",
			updateHeldHint: "この profile では、新しいバージョンが公開されてから一定期間が経つまでインストールできません。あと約 {1} 時間です。",
			updateHeldEstimatedHint: "新しいバージョンは /latest に現れていますが、ミラーの完全な情報がまだ同期されていないため、更新は保留しています。約 {1} 分後に再確認します。",
			newerPrereleaseAvailable: "プレリリース版 {0} が公開されました",
			newerPrereleaseHint: "npm の latest は更新されていません。あなたが追っているプレリリースの系列で、より新しいバージョンが公開されました。",
			unreleasedCommits: "新しいコミットがあります（未リリース）{0}",
			unreleasedCommitsHint: "選択したブランチには、インストール済みバージョンより新しいコミットがありますが、新しいバージョン番号は公開されていません。マーケットは正式版だけをインストールし、これらのコミットを自動で適用することはありません。",
			linkedDev: "ローカル開発",
			hostUpdateReady: "新しいバージョン {0} があります",
			hostUpdateHint: "このマーケットはデスクトップアプリがインストールと更新を行います。新しいバージョンへの更新はデスクトップアプリで行ってください",
			notesLink: "変更内容",
			notesRelease: "リリースノート",
			notesCommits: "コミット履歴",
			notesCommitsRecent: "最近のコミット（現在のインストール済みバージョンには対応しません。参考情報です）",
			notesNpm: "バージョンの公開日時",
			notesNone: "このプラグインは更新内容を公開していません。",
			notesSource: "このプラグインの更新内容は、マーケットにはまだ収録されていません。",
			notesSourceUnreadable: "このプラグインは GitHub からインストールされたものではないため、マーケットはその変更履歴を読めません。",
			notesSourceLink: "リポジトリで変更内容を見る",
			notesSourceNoLink: "プラグインの作者に変更内容を尋ねることができます。",
			notesLoadFail: "更新内容を今は読めません。しばらくしてから再試行してください。",
			migrateNpm: "npm 版に切り替える",
			migrateTitle: "npm 版に切り替えますか？",
			migrateDescription: "これは通常のバージョン更新ではなく、プラグインのインストール元を変更します。",
			migrateCurrentSource: "現在の入手元",
			migrateTargetSource: "新しい npm の入手元",
			migrateWarning: "その npm パッケージは他の人が公開したもので、同じプラグインではない可能性があります。信頼できる場合だけ続行してください。",
			migrateContinue: "切り替えを確認",
			migrateFail: "入手元の切り替えに失敗しました",
			renameRowAction: "新しい名前に移行",
			renameTitle: "新しい名前に移行して更新しますか？",
			renameDescription: "このプラグインは npm のパッケージ名が変わり、古い名前では新しいバージョンが出なくなりました。移行するとインストールが新しい名前になり、スイッチ、グループ、メモは保持されます。",
			renameCurrentPackage: "現在のパッケージ",
			renameTargetPackage: "新しいパッケージ",
			renameWarning: "プラグイン自身が保存したデータ（ペルソナ、習慣、連携など）はマーケットの管理外であり、移行では変更されません。",
			renameContinue: "移行して更新",
			restoreOnline: "オンライン版に切り替える",
			restoreHint: "ローカル版をアンインストールしてオンライン版をインストールします。その後も通常どおり更新を確認します。この操作は取り消せません。",
			hostIncompatibleTitle: "この新しいバージョンには、より新しい DSH が必要です",
			hostIncompatibleBody: "{plugin} は DSH {requirement} が必要だと宣言していますが、現在動作しているのは {host} です。インストールしてもほぼ確実に使えなくなり、手動で古い版に戻すしかなくなります。\n何も変更されていません。プラグインは現在のバージョンのままです。\nバージョン番号が正しくないと分かっている場合（バージョンを報告しない同梱の DSH など）は、そのまま更新できます。",
			hostIncompatibleUnknown: "不明なバージョン",
			hostIncompatibleSearching: "現在の DSH と互換性のあるバージョンを探しています…",
			hostIncompatibleFoundInstall: "{version} をインストールできます。現在の DSH への対応を宣言しています。",
			hostIncompatibleFoundUpdate: "{version} に更新できます。現在の DSH への対応を宣言しています。",
			hostIncompatibleHeldTarget: "{version} は現在の DSH への対応を宣言していますが、まだ公開直後の待機期間中です — 新しい版は {window} 時間の経過が必要で、あと約 {hours} 時間です。",
			hostIncompatibleHeldTargetUnknown: "{version} は現在の DSH への対応を宣言していますが、まだ公開直後の待機期間中です。残り時間はこの環境では判定できません。",
			hostIncompatibleHeldButton: "待機中（約 {hours} 時間）",
			hostIncompatibleHeldButtonUnknown: "待機中",
			hostIncompatibleNoCompat: "現在の DSH への対応を宣言しているバージョンは見つかりませんでした。",
			hostIncompatibleSearchFailed: "互換性のあるバージョンを今は確認できません。",
			hostIncompatibleInstallCompat: "{version} をインストール",
			hostIncompatibleUpdateCompat: "{version} に更新",
			hostIncompatibleRetry: "再試行",
			hostIncompatibleKeep: "現在のバージョンのままにする",
			hostIncompatibleAnyway: "それでも更新する",
			hostStatusCompatible: "ホストの要件を満たしています（宣言にもとづく）",
			hostStatusIncompatible: "現在の DSH と互換性がないことが確認されています",
			hostIncompatibleBodyInstall: "{plugin} は DSH {requirement} が必要だと宣言していますが、現在動作しているのは {host} です。インストールしてもほぼ確実に使えなくなります。\n何もインストールされていません。\nバージョン番号が正しくないと分かっている場合（バージョンを報告しない同梱の DSH など）は、そのままインストールできます。",
			hostIncompatibleCancel: "インストールをキャンセル",
			hostIncompatibleInstallAnyway: "それでもインストールする",
			restoreNameOnlyHint: "あなたのローカルコピーには入手元のリポジトリが記されていないため、マーケットはパッケージ名で厳選カタログと照合することしかできませんでした。下のプラグインは、別の作者による同名のプラグインで、あなたのコピーの入手元ではない可能性があります。確認する前に作者とリポジトリのアドレスを確かめてください。この操作はローカル版をアンインストールしてそのプラグインをインストールし、取り消せません。",
			restoreContinue: "更新を続行",
			restoreProceed: "復元を確認",
			restoreNoCatalogTitle: "復元できません",
			restoreNoCatalog: "厳選カタログにこのプラグインがないため、オンライン版に復元できません。ローカル版をアンインストールするか、ローカル開発を続けてください。",
			restoreNoMatch: "カタログには同名のプラグインがありますが、あなたのローカルリポジトリと一致しないため、安全に復元できません。ローカル版をアンインストールするか、ローカル開発を続けてください。",
			restoreFail: "復元に失敗しました",
			exportLog: "ログをエクスポート",
			crashTitle: "プラグインマーケットを表示できません",
			crashHint: "マーケットの画面が正常に表示できませんでした。あなたのプラグインには影響はなく、何も変更されていません。\n「再読み込み」を押せば通常は復旧します。繰り返し発生する場合は、ログをエクスポートして issue に添付してください。ログにはエラーの発生箇所が記録されています。\nブラウザのページ翻訳をオンにしている場合は、オフにしてから再試行してください。これが既知の原因の 1 つです。",
			crashReload: "再読み込み",
			crashDetails: "エラーの詳細",
			exportingLog: "エクスポート中…",
			exportedLog: "ログをエクスポートしました：dsh-market-log.txt。issue に添付してください",
			exportLogFail: "ログのエクスポートに失敗しました",
			readme: "使い方",
			comments: "コメント",
			commentsTitle: "コメント",
			commentsNote: "コメントは GitHub Discussions から取得しています。開くと giscus.app と GitHub に接続します。コメントの投稿には GitHub アカウントが必要です。",
			commentsLoginHint: "ここでサインインするとこのページを離れ、戻るには dsh web を開き直す必要があります。故障ではありません。コメントは GitHub で投稿してください。このページは読むためだけのものです。",
			commentsLoading: "コメントを読み込み中…",
			commentsError: "コメントを読み込めませんでした。ネットワーク接続を確認して再試行してください。",
			commentsRetry: "再試行",
			commentsOnGitHub: "GitHub でサインインして議論に参加",
			conflictTitle: "インストールできません：インストール済みのプラグインと競合しています",
			conflictBody: "インストール済みのプラグインと競合しています。残せるのは 1 つだけです：",
			conflictReverted: "自動で元に戻しました。プラグインは何も変更されていません",
			conflictKeep: "既存のプラグインを残す",
			conflictKeepNote: "",
			conflictSwap: "こちらをインストールする",
			conflictSwapNote: "アンインストールされるプラグインの設定は保持されるため、後でインストールし直せます",
			conflictDetails: "詳細",
			conflictOutcomeInstall: "インストール",
			conflictOutcomeSkip: "インストールしない",
			conflictOutcomeKeep: "残す",
			conflictOutcomeRemove: "アンインストール",
			conflictWhy: "cordis は重複したエントリ id を受け付けません。これを残すと、DeepSeek Harness は次回起動できなくなります。",
			opTitle: "タスク",
			opInstalling: "インストール中",
			opNeedsYou: "件は対応が必要です",
			opQueued: "キュー待ち",
			opQueuedAhead: "前にあります：",
			opQueuedWaitingAgents: "{0} 件のセッションが空くのを待っています",
			opWaitingAgents: "{0} 件のタスクが Agent の空きを待っています",
			opRunning: "処理中",
			opNeedsChoice: "インストールできません · 自動で元に戻しました。何も変更されていません",
			opDone: "完了",
			opDoneRefresh: "インストールしました · ページを更新すると有効になります",
			opLeaveHint: "このページを離れても大丈夫です。完了したら通知します",
			opLeaveHintAgents: "Agent が空くと自動で始まります",
			opEmpty: "進行中の操作はありません",
			opEmptyHint: "インストール、更新、アンインストールの進捗がここに表示されます",
			opClose: "折りたたむ",
			opClear: "完了したものを消去",
			opDequeue: "キューから外す",
			opRunNow: "今すぐ実行",
			opUpdateNow: "今すぐ更新",
			opUninstallNow: "今すぐアンインストール",
			agentsRunningConfirm: "それでも続けますか？",
			agentsRunningRisk: "セッションが動作中です。この操作はプラグインのファイルを置き換えたり削除したりするため、動作中のセッションが途中でエラーになることがあります。リスクを取りたくなければキャンセルし、セッションが終わってから再試行してください。",
			opRetry: "再試行",
			opKind_install: "インストール",
			opKind_update: "更新",
			opKind_uninstall: "アンインストール",
			opBlockedCard: "インストールできません · 詳細を見る",
			conflictDeclined: "既存のプラグインを残したため、こちらはインストールされませんでした",
			conflictReplacing: "置き換え中…",
			conflictReplaceFailed: "置き換えが完了しませんでした。次のプラグインはアンインストールされ、復元されていません。再インストールしてください：",
			lightboxClose: "プレビューを閉じる",
			lightboxPrev: "前へ",
			lightboxNext: "次へ",
			envMissing: "プラグインをインストールする前に、pnpm 環境の設定が必要です",
			envFix: "自動で設定",
			envFixing: "設定中…",
			envFixFail: "自動設定に失敗しました。ログをエクスポートして issue に添付してください。",
			loading: "プラグインカタログを読み込み中…",
			backTop: "トップへ戻る",
			confirm: "確認",
			confirmInstall: "インストールを確認",
			cmdDetails: "インストールコマンド",
			cmdCopy: "インストールコマンドをコピー",
			cmdDesktopUnavailable: "デスクトップアプリはプラグインを自分でインストールします（上の「インストール」ボタンを使ってください）。`dsh plugin` はデスクトップアプリのこの profile を受け付けません。",
			cmdCopied: "コピーしました",
			catsMore: "カテゴリをさらに表示",
			catsLess: "カテゴリを減らす",
			filter: "絞り込み",
			filterSort: "並び替えの項目",
			filterDir: "並び順",
			filterTime: "公開時期",
			filterHost: "ホストのバージョン",
			hostAll: "すべて表示",
			hostCompatible: "現在の DSH {0} と互換性あり",
			hostDetecting: "ホストのバージョンを識別中…",
			hostUnknown: "ホストのバージョンは不明です",
			hostFilterLoading: "ホストの要件を確認中 {0}/{1}。宣言していない、または確認できないプラグインも引き続き表示されます",
			hostFilterActive: "DSH {0} と互換性のないプラグイン {1} 件を隠しました。バージョンを宣言していないものは一覧に残っています",
			hostRequirement: "DSH {0}",
			hostRequirementLoading: "ホストの要件を読み取り中…",
			hostRequirementUndeclared: "ホストの要件は宣言されていません",
			hostRequirementUnavailable: "ホストの要件は不明です",
			sortDownloads: "npm ダウンロード数（直近 30 日）",
			downloadsPeriod: "30日",
			downloadsMeaning: "直近 30 日の npm ダウンロード：{0}",
			githubReleaseDownloadsMeaning: "GitHub Release 添付ファイルの累計ダウンロード：{0}（パッケージ、チェックサム、関連ファイルを含む）",
			starsMeaning: "GitHub Star：{0}",
			statisticCheckedAt: "；取得日時 {0}",
			downloadsWindow: "（{0} ～ {1}）",
			catalogNpmLatest: "npm の現在の latest",
			catalogVersionDated: "カタログ（{0} 更新）に記録されたインストール用バージョンです。新しいリリースはカタログ更新後に表示されます",
			catalogVersionUndated: "カタログに記録されたインストール用バージョンです。新しいリリースがまだ反映されていない場合があります",
			sortStars: "スター数",
			sortAdded: "収録日時",
			recentlyAdded: "最近の収録",
			recentHide: "このブロックを隠す",
			recentShow: "最近の収録を表示",
			sortDesc: "降順",
			sortAsc: "昇順",
			sortNewest: "新しい順",
			sortOldest: "古い順",
			timeAll: "すべての期間",
			timeDay: "直近 1 日",
			timeWeek: "直近 7 日",
			timeMonth: "直近 30 日",
			timeQuarter: "直近 90 日",
			timeYear: "直近 1 年",
			published: "収録日時",
			prevPage: "前へ",
			nextPage: "次へ",
			loadMore: "もっと見る",
			pageInfo: "{0} / {1} ページ",
			perPage: "1 ページあたり",
			marketUpdate: "プラグインマーケットを更新",
			updateAll: "すべて更新",
			heldReleaseNotice: "インストールしましたが、最新版ではありません。この profile の minimumReleaseAge が {0} を保留したため、{1} がインストールされました。",
			versionUnverifiedNote: "インストールしましたが、バージョンを確認できませんでした。レジストリの照会が 2 回とも失敗したため、pnpm が選んだ {0} が入っています。実際のバージョンはプラグイン画面で確認できます。",
			versionUnverifiedNoteUnknown: "インストールしましたが、バージョンを確認できませんでした。レジストリの照会が 2 回とも失敗しました。実際のバージョンはプラグイン画面で確認できます。",
			installedDependencyNote: "ほかに {0} 個のパッケージが、プラグインの依存として取り込まれています。それらはプラグインではないため、上には表示されません。",
			heldReleaseAction: "それでも {0} をインストール",
			ignoreUpdateNotice: "再起動するまで通知しない",
			openInHostPage: "プラグインページで見る",
			ignoreAllUpdateNotices: "再起動するまですべて通知しない",
			updateNoticeIgnored: "再起動するまで通知しません",
			updateExemptAdd: "更新をずっと通知しない",
			updateExemptRemove: "更新の通知を再開",
			updateExemptMark: "通知はオフです",
			updateExemptRestore: "再び通知する",
			updateExemptHint: "新しいバージョンは引き続き一覧に表示されます。止まるのは通知だけです。",
			updateExemptOn: "更新の通知はオフです。新しいバージョンは引き続き一覧に表示されます。",
			updateExemptOff: "更新の通知を再開しました。",
			updateExemptFailed: "保存できませんでした。再試行してください。",
			updateAvailableShort: "新しいバージョン",
			copyPath: "パスをコピー",
			pathCopied: "コピーしました",
			tabThemes: "テーマ",
			tabBackup: "バックアップと復元",
			backupLocal: "ローカルファイル",
			backupExportFailed: "バックアップのエクスポートに失敗しました",
			backupDownload: "バックアップをエクスポート",
			backupImport: "インポートしてプレビュー",
			backupHint: "プラグインの一覧と profile の設定だけを含み、プラグインのファイルは含みません。復元時は一覧から再インストールします。",
			webdav: "WebDAV",
			webdavPreset: "サービス事業者のプリセット",
			webdavUrl: "バックアップファイルの URL",
			webdavUser: "ユーザー名（任意）",
			webdavPassword: "パスワード（任意）",
			webdavUpload: "バックアップをアップロード",
			webdavRestore: "WebDAV から復元",
			autoBackup: "毎日自動でバックアップ（マーケットを開いたとき）",
			webdavNote: "WebDAV のアドレスとユーザー名はこのブラウザにのみ保存されます。パスワードはこのページ内にのみ保持され、再読み込み後は再入力が必要です。",
			webdavAutoBackupPaused: "毎日の自動バックアップは完了できませんでした。このサーバーはパスワード認証が必要ですが、パスワードは保存されないため、再読み込み後の再入力が必要です。入力して「バックアップをアップロード」を押してください。",
			webdavPathHint: "ファイル名まで含めた完全なファイルアドレスを記入してください。バックアップはそのファイルに書き込まれ、復元もそこから読みます。自動バックアップをオンにすると、アップロードは 1 日に最大 1 回です。",
			localOnly: "WebDAV のアドレスとユーザー名はこのブラウザにのみ保存されます。",
			credsWarning: "注意：バックアップには profile の設定と、キーを含む可能性のあるファイル（config.toml、.env など）が含まれます。ローカルにエクスポートしたファイルにはそれらがそのまま入るため、WebDAV にアップロードする前に、送信先が信頼できることを確認してください。",
			gist: "GitHub Gist",
			gistToken: "GitHub token（このセッションのメモリにのみ保持され、更新後は再入力が必要です。空欄にすると、サーバー側の DSH_GITHUB_TOKEN またはサインイン済みの gh CLI を使います）",
			gistId: "Gist ID またはリンク（エクスポート時に空欄なら、新しい非公開 Gist を作成します）",
			gistVerify: "接続を確認",
			gistExport: "Gist にエクスポート…",
			gistImport: "Gist からインポート",
			gistExportDone: "Gist にエクスポートしました",
			gistVerifySource: "確認できました（Token の入手元：{0}）",
			gistSrcToken: "手動で入力",
			gistSrcEnv: "環境変数 DSH_GITHUB_TOKEN",
			gistSrcGh: "gh CLI",
			gistExportSelect: "エクスポートするプラグインを選択",
			gistExportHint: "すべて選択 = 完全なバックアップ（設定ファイルを含む）。それ以外は、選択したプラグインだけをエクスポートし、「設定ファイルを含める」にチェックがあればそれも加わります。",
			gistSelectAll: "すべて選択",
			gistSelectNone: "すべて解除",
			gistIncludeConfig: "設定ファイルを含める（キーを含むことがあります）",
			gistNoPlugins: "現在の profile にはエクスポートできるプラグインがありません",
			gistSpecLocal: "ローカル",
			gistExportGo: "エクスポート",
			gistCreated: "エクスポートしました：",
			gistErrTimeout: "GitHub へのリクエストがタイムアウトしました。ネットワークを確認して再試行してください",
			gistErrNetwork: "GitHub に接続できません。ネットワークまたはプロキシの設定を確認してください",
			gistErrAuth: "GitHub の認証に失敗しました。Token が無効か期限切れ、または gh CLI がサインインしていません",
			gistErrNotFound: "その Gist が見つかりません。ID またはリンクを確認してください",
			gistErrRateLimit: "GitHub のレート制限に達したか、Token に gist スコープがありません",
			gistErrInvalid: "Gist の内容が無効か、対応していないバックアップ形式です",
			gistModeUpdate: "入力欄の Gist を更新",
			gistModeCreate: "新しい非公開 Gist を作成",
			gistErrNoId: "更新モードには Gist ID が必要です。記入するか、「新規作成」に切り替えてください",
			gistNote: "ローカルエクスポート（このマシンのアーカイブ）と違い、Gist はマシン間の同期のためのものです。非公開 Gist にエクスポートすれば、他のコンピュータで同じアカウントからインポートして再利用できます。Token はこのセッションのメモリにのみ保持され、ブラウザのストレージに書き込まれることは決してありません。gh CLI にサインイン済みか DSH_GITHUB_TOKEN が設定されていれば、入力は不要です。Gist は非公開で、1 ファイルあたり上限 1 MB です。",
			backupWorking: "処理中…",
			backupDone: "バックアップをアップロードしました",
			restoreDone: "復元が完了しました。DeepSeek Harness を再起動してください",
			restorePartial: "復元は完了しましたが、次のプラグインのインストールに失敗しました：",
			restoreUnportable: "インストール元が別のコンピュータ上のローカルパスで、ここには存在しません。そのプラグインを再インストールするか、このマシンのパスを指すようにしてください",
			restoreSelfPinned: "市場自身のバージョンは復元では変わりません（復元中に実行中の市場を置き換えてしまうため）。必要なときは「更新」で個別にアップグレードしてください",
			restoreBootError: "復元してもまだ起動できません：",
			orphanBundle: "⚠️ 次回の起動に失敗します。profile はこれらのプラグインを宣言していますが、インストールされていません。再インストールするか、profile の package.json の dsh.profile.bundles から削除してください：",
			restoreConfirm: "復元すると現在の profile の設定が上書きされ、プラグインが再インストールされます。続けますか？",
			restorePreviewDone: "バックアップをインポートしました。「インストール済み」で確認してから復元を始めてください",
			restoreMissing: "このバックアップの {0} 件のプラグインはまだインストールされていません",
			restoreStart: "復元を開始",
			notInstalled: "未インストール",
			themeApply: "使う",
			themeActive: "使用中",
			themeDeactivate: "無効化",
			themeEmpty: "カタログにテーマはまだありません",
			themePreview: "プレビュー",
			themePreviewLoading: "プレビューを探しています…",
			themePreviewMissing: "プレビューはありません",
			themePreviewCount: "プレビュー {0} 枚",
			themeResultCount: "テーマ {0} 件",
			themeFullscreen: "全画面で見る",
			themeExitFullscreen: "全画面を終了",
			progressHint: "初回のインストールではプラグインの依存パッケージをダウンロードします。大きなプラグインでは 1〜3 分かかることがあります",
			progressSlow: "通常より時間がかかっています。ダウンロードやコンパイルが必要な依存があると数分かかります。待てない場合はキャンセルして、別のネットワークで再試行してください",
			toastReady: "インストールされ、有効になりました",
			toastTheme: "有効になりました。「設定 → プラグインマーケット → テーマ」でいつでも切り替えできます",
			toastToggledOn: "有効になりました",
			toastToggledOff: "無効になりました。機能は直ちに停止しました",
			gotIt: "閉じる",
			stateLive: "有効",
			stateRestart: "インストール済み。再起動後に有効になります",
			stateIncompatible: "インストール済み。現在の dsh と互換性がありません",
			stateInert: "インストール済み。未有効",
			stateLibrary: "依存ライブラリ",
			libraryUseHint: "他のプラグインが使う共有コードです。有効化する必要はありません。",
			stateDependencyLibrary: "{0} の依存ライブラリ",
			stateLoadedByProfile: "あなたの設定によって読み込まれています",
			stateBroken: "インストール済み。検証に失敗しました",
			stateFailed: "起動時に読み込めませんでした",
			stateDisabled: "無効",
			phaseResolving: "依存を準備中",
			phaseDownloading: "ダウンロード中",
			phaseLinking: "依存をリンク中",
			phaseBuilding: "ビルドスクリプトを実行中",
			cancelling: "キャンセル中…",
			packagesDone: "{0} 個のパッケージを処理しました",
			updatedLive: "✓ 更新しました。有効になっています",
			updatedLibrary: "✓ 更新しました",
			partialNote: "キャンセルしました。一部の変更は適用されています",
			reconciledNote: "アンインストールしましたが、pnpm は終了処理の段階でエラーを報告しました（通常はファイルが使用中です）。設定はすでに同期されているため、再試行は不要です",
			actWhy: "なぜ有効にならないのですか？",
			tabList: "一覧",
			tabGroups: "グループ",
			repoLink: "GitHub でリポジトリを見る",
			viewSourceRepo: "リポジトリを見る↗",
			disabledState: "無効",
			noteAdd: "メモを追加",
			noteEdit: "メモを編集",
			noteTheirs: "原文",
			noteMine: "自分のメモ",
			noteSave: "保存",
			notePlaceholder: "自分の言葉でこのプラグインを説明してください。作者の紹介の代わりに表示されます",
			noteSeeTheirs: "作者の紹介を見る",
			noteSeeMine: "自分のメモに戻る",
			switchOnLabel: "有効",
			enable: "有効化",
			disable: "無効化",
			toggleFail: "切り替えに失敗しました",
			deprecatedBadge: "非推奨",
			deprecatedWarn: "このプラグインはカタログによって非推奨とマークされています。新規の利用はおすすめしません。",
			configNamespaceNotice: "{0} の設定パネルは設定を読めません。「{1}」という名前で読み取っていますが、この環境にその名前のエントリ id はありません。そのプラグイン自身のエントリは「{2}」で、プラグインのクライアントはそちらを読むべきです。これはプラグイン自身の問題であり、マーケットは代わりに直せません。",
			brokenPluginTitle: "{0} は更新に失敗したため削除されました",
			brokenPluginBody: "DSH の動作中は更新できず、更新前の版もすでに破損していました。次回の起動が止まらないよう、マーケットはこれを profile から削除しました。プラグインのディレクトリはそのまま残っています。DSH を終了してからインストールし直してください。",
			brokenPluginTitleCancelled: "{0} は更新がキャンセルされたため削除されました",
			brokenPluginBodyCancelled: "キャンセルされた時点で、古い版はすでに一部が消去されていました。次回の起動が止まらないよう、マーケットはこれを profile から削除しました。プラグインのディレクトリはそのまま残っています。インストールし直してください。再び失敗する場合は、先に DSH を終了してからインストールしてください。",
			brokenPluginAction: "このプラグインを探す",
			brokenPluginDismiss: "この通知を今後表示しない",
			viewReplacement: "代替を見る",
			installReplacement: "代替をインストール",
			replacementHint: "カタログのおすすめの代替",
			groupNew: "新しいグループ",
			groupNamePh: "グループ名",
			groupRename: "名前を変更",
			groupDelete: "グループを削除",
			groupConfirmDelete: "グループを削除しますか？",
			groupExpand: "{0} を展開",
			groupFold: "{0} を折りたたむ",
			groupThemeTaken: "テーマはすでにあります",
			groupSearchEmpty: "一致するプラグインはありません",
			groupStateInert: "未有効",
			groupStateRestart: "再起動後に有効",
			groupStateBroken: "検証に失敗",
			ungrouped: "未グループ",
			groupAssign: "割り当て先",
			groupRemove: "外す",
			groupEmpty: "メンバーはまだいません",
			groupMixed: "一部が有効",
			noGroups: "グループはまだありません。まず作成してください",
			groupCreate: "作成",
			groupAdd: "メンバーを追加",
			groupAddEmpty: "追加できる未グループのプラグインはありません",
			groupAddPick: "追加",
			groupAddSearchPh: "プラグインを検索…",
			groupAddTitle: "「{0}」に追加",
			groupAddSelected: "{0} 件を選択中",
			groupAddConfirm: "{0} 件を追加",
			groupAddHint: "グループに追加してもプラグインは有効化されません",
			groupPickTheme: "テーマを選択",
			groupChangeTheme: "テーマを変更",
			groupThemeTitle: "「{0}」のテーマを選択",
			groupThemeUse: "使う",
			groupThemeEmpty: "未グループのテーマはありません",
			groupThemeHint: "1 つのグループにテーマは 1 つだけです。選んでも有効化はされません。変更すると、元のテーマはそのグループから外れます。",
			groupThemeCurrent: "現在",
			groupThemeRemove: "テーマを外す",
			groupThemeBadge: "テーマ",
			groupOrgHint: "グループは整理のためだけのもので、プラグインの有効状態は変わりません",
			groupMembersMeta: "{0} 件 · {1} 件が有効",
			groupMore: "もっと見る",
			groupRenameSave: "保存",
			groupRenameTitle: "グループの名前を変更",
			groupRenameHint: "変わるのはグループ名だけです。メンバーと有効状態はそのままです",
			tabDiagnostics: "診断",
			checkIssues: "問題が見つかりました",
			checkErrors: "エラー",
			checkWarnings: "警告",
			checkLoading: "profile を分析中…",
			checkLoadFail: "診断の読み込みに失敗しました：",
			checkProfile: "profile",
			checkErrorsEmpty: "エラーはありません",
			checkWarningsEmpty: "警告はありません",
			checkBundles: "プラグインの読み込み順（bundle）",
			checkBundlesEmpty: "プラグインパッケージは設定されていません",
			checkOfficial: "公式",
			checkCommunity: "コミュニティ",
			checkSource: "入手元",
			checkEntries: "読み込みエントリ（loader id）",
			checkPatch: "patch ファイル",
			checkDir: "ディレクトリ",
			checkDuplicates: "重複したプラグインエントリ",
			checkDuplicatesEmpty: "重複したプラグインエントリはありません",
			checkHoisted: "トップレベル",
			checkPeerMismatches: "依存のバージョン不一致",
			checkPeerEmpty: "依存のバージョン不一致はありません",
			checkPeerInfo: "ほかに未確認の情報が {0} 件あります",
			checkPeerOverview: "{0} 件の不一致 · {1} 件の情報",
			checkRange: "要求バージョン",
			checkResolved: "実際のバージョン",
			checkSatisfied: "満たしています",
			checkUnsatisfied: "満たしていません",
			checkUnknown: "不明",
			checkPeerRisk: "依存のリスク",
			checkPeerRiskEmpty: "依存のリスクはありません",
			checkPeerWarning: "依存の警告",
			checkPeerWarningEmpty: "依存の警告はありません",
			checkPeerInfoTier: "依存の情報",
			checkPeerInfoTierEmpty: "依存の情報はありません",
			checkPeerSatisfied: "満たされている依存",
			checkPeerSatisfiedEmpty: "満たされている依存の項目はありません",
			peerRiskBelowMin: "宣言された下限より下",
			peerRiskAboveMax: "明示された上限より上",
			peerWarnOptional: "任意の依存",
			peerWarnAboveMax: "宣言された上限を超えています",
			peerInfoUnverified: "未確認",
			checkMultiVersion: "コアパッケージの複数バージョン",
			checkMultiEmpty: "複数バージョンのコアパッケージはありません",
			checkOverrides: "上書き関係",
			checkOverridesEmpty: "上書き関係はありません",
			checkOverridden: "上書きしています",
			checkResiduals: "残ったディレクトリ",
			checkResidualsEmpty: "残ったディレクトリは見つかりませんでした。",
			checkResidualsHint: "これらのディレクトリはどのプラグインも使っておらず、起動にも影響しません。更新が中断された際に残ったものです。DSH を終了してから削除するか、該当するプラグインをインストールし直してください。",
			checkResidualTmp: "pnpm の一時ディレクトリ",
			checkResidualIncomplete: "不完全なパッケージディレクトリ（package.json なし）",
			checkConfigNamespaces: "設定を読めない名前で読んでいるプラグイン",
			checkConfigNamespacesEmpty: "このようなプラグインは見つかりませんでした。",
			checkConfigNamespacesHint: "プラグインのパネルは「エントリ id」で自分の設定を読みます。名前を書き間違えてもエラーにはならず、ただ静かに値が読めません。パネルが真っ白になったり、保存できなかったりし、プラグインはハードコードされた既定値に戻ります（そのためキャンバス系プラグインは白い画面になります）。名前が間違っているのはプラグイン自身のクライアントの中であり、マーケットは直せません。作者が 1 行のコードを変更する必要があります。",
			checkConfigNamespaceRow: "「{0}」で設定を読んでいますが、これはどのエントリ id でもありません",
			checkConfigNamespaceOwn: "そのプラグイン自身のエントリ id",
			checkConfigNamespaceNone: "そのプラグインは自身のエントリ id を何も宣言していません",
			checkOrphans: "無効な設定の項目",
			checkOrphansEmpty: "無効な設定の項目はありません",
			orphanInsertNotArray: "形式が不正です",
			orphanInsertTargetMissing: "対象が存在しません",
			orphanInsertTargetNotGroup: "対象はグループではありません",
			orphanIdRequired: "識別子がありません",
			orphanPatchTargetMissing: "対象が存在しません",
			orphanNameMismatch: "名前が一致しません",
			orphanReasonOther: "その他",
			diagExplain: "用語の説明",
			diagExplainText: "このページは、プラグインの競合、依存のバージョン不一致、読み込み順の問題を確認します。使われる用語：",
			diagTermBundle: "bundle = 1 つのプラグインパッケージ。順番に重ねて読み込まれます",
			diagTermEntry: "読み込みエントリ = プラグインが動作中の構成に登録する各項目",
			diagTermPeer: "対等な依存 = プラグインがホスト環境に求める、別のパッケージ",
			diagTermShadow: "シャドウイング = プラグイン同梱の古いコピーが、ホストの新しい版を覆ってしまうこと",
			diagTermOrphan: "無効な項目 = 設定が存在しないものを参照していること",
			diagTermOrder: "読み込み順 = プラグインが有効化される順序。後から読み込まれたものが先のものを上書きすることがあります",
			orderSection: "並び順",
			orderUp: "↑",
			orderDown: "↓",
			orderApply: "並び順を適用",
			orderDrag: "ドラッグで並び替え",
			orderDragHint: "⠿ をドラッグして並び替えます。変更は「並び順を適用」を選んだときに保存されます",
			orderConflicts: "現在の並び順における before/after の競合",
			orderApplied: "✓ 適用しました。再起動後に有効になります",
			orderSuggestApply: "おすすめの並び順を採用",
			orderSuggestHint: "おすすめの並び順（before/after のルールで自動並び替え）：",
			orderAutoSort: "自動並び替え",
			orderAlreadyOptimal: "現在の並び順はすべてのルールとプラグインの依存をすでに満たしています。並び替える必要はありません",
			orderTrialFail: "並び順の確認に失敗しました：{0}",
			orderDiffHint: "この並び順では構成が変わります。上書き {0} 件、無効な項目 {1} 件、重複した項目 {2} 件",
			duplicateNames: "同名のプラグイン（参考情報であり、競合ではありません）",
			orderReset: "下書きをリセット",
			checkRefresh: "再確認",
			aiFix: "AI で修正",
			aiFixHint: "診断の問題を、新しい会話の Agent に修正してもらいます（内容はクリップボードにコピー済みです。送るかどうかはあなたが決めます）",
			aiFixIntro: "DeepSeek Harness のプラグインの問題の修正を手伝ってください（profile：{0}）。診断で次のことが分かりました：",
			aiFixDetect: "始める前に判断してください。現在の Agent が動作しているプロセスは、この profile に対応する DeepSeek Harness のこのマシンのプロセスそのものですか（つまり、診断されたこの構成こそが、あなたが今動作している構成ですか）？判断の根拠：現在の作業ディレクトリ / $DSH_HOME / プロセスのコマンドラインがその profile を指しているか、または deepseek-harness プロセス内で動作しているかどうか。判断できない場合は、常にとして扱ってください（より安全です）。",
			aiFixIfSelf: "動作中の構成、harness、コアパッケージをその場で変更してはいけません。cordis.patch.yml の編集、bundle の並び替えや有効・無効の切り替え、プラグインのインストール/アンインストール/アップグレード、依存の再インストール、dsh のアップグレードや再起動は行わないでください。3 つのステップ：① まず読み取り専用の分析だけを行い、何も変更しないこと。② apply.sh/.bat（今回の修正の変更）と rollback.sh/.bat（apply を完全に取り消す）を用意すること。どちらも再実行しても安全です。apply はスナップショットが存在しないときだけ作成し、上書きはしません（既存のスナップショットがあることは apply が実行済みであることを意味するため、再実行の前にロールバックするか確認すること）。rollback はスナップショットから復元するため、apply が途中で失敗してもロールバックでき、ロールバックを繰り返しても安全です。③ 私が外部のターミナルで apply を実行し、stdout/stderr を貼り戻すので、それを見て判断してください。各ステップでは先に理由を述べ、私の確認を待ってください。決して自分で実行しないでください。",
			aiFixScope: "対象の harness 内で動作していない（独立したプロセス）と判断した場合に限り、次を検討できます：dsh.profile.bundles の並び替え、プラグインの無効化/有効化、cordis.patch.yml の調整。注意：公式 bundle は移動できません。変更する前にまず計画を述べてください。",
			aiFixConservative: "保守的にお願いします。上に列挙された明確なエラー（起動失敗/重複した項目/リスク級の依存の不一致）だけを修正してください。警告と情報レベルの問題（任意の依存、未確認の依存範囲など）は、明確なエラーに関連する場合にのみ扱ってください。不要なアップグレードや並び替えは行わないでください。各変更の前に理由を述べ、確認を待ってください。",
			aiFixCopied: "修正の説明をコピーしました。新しい会話に貼って送信してください",
			aiFixFail: "クリップボードにアクセスできません。下の診断内容を手動でコピーしてください",
			catConflict: "競合",
			catDeps: "依存",
			catRisk: "リスク",
			catWarn: "警告",
			catInfo: "情報",
			catOrder: "順序",
			checkOrderTip: "コミュニティ bundle の読み込み順が、プラグインが宣言した before/after ルールと競合しています",
			diagOkAll: "競合、依存、読み込み順の問題は見つかりませんでした",
			presetSection: "プラグインの組み合わせ",
			presetHint: "現在のプラグインの並び順と無効化したプラグインを組み合わせとして保存し、いつでも切り替えられます。適用の前に、まず一度試し起動を行い、自動でスナップショットを作成します。",
			presetName: "組み合わせの名前",
			presetSave: "現在の状態を保存",
			presetSaving: "保存中…",
			presetSaved: "組み合わせを保存しました",
			presetApply: "適用",
			presetApplied: "適用しました。再起動後に有効になります",
			presetDelete: "削除",
			presetDeleted: "組み合わせを削除しました",
			presetEmpty: "保存した組み合わせはまだありません",
			presetNameEmpty: "組み合わせの名前を入力してください",
			presetFail: "組み合わせの操作に失敗しました：",
			presetListFail: "組み合わせの一覧の読み込みに失敗しました：",
			presetBundleCount: "{0} 件のプラグイン",
			presetPreview: "プレビュー",
			presetPreviewTitle: "この組み合わせを適用すると：",
			presetReorder: "{0} 件のプラグインの位置を並び替えます",
			presetEnable: "{0} 件のプラグインを有効化します",
			presetDisable: "{0} 件のプラグインを無効化します",
			presetNoop: "変更はありません",
			presetPreviewFail: "プレビューに失敗しました：",
			snapSection: "スナップショットとロールバック",
			snapHint: "変更を適用する前にスナップショットが自動で作成されます。手動で作成することもでき、いつでも任意の状態にロールバックできます。",
			snapCreate: "スナップショットを作成",
			snapCreating: "作成中…",
			snapCreated: "スナップショットを作成しました",
			snapEmpty: "スナップショットはまだありません",
			snapListFail: "スナップショットの一覧の読み込みに失敗しました：",
			snapCreateFail: "スナップショットの作成に失敗しました：",
			snapRestore: "ロールバック",
			snapRestoring: "ロールバック中…",
			snapRestored: "ロールバックしました。再起動後に有効になります",
			snapRestoreFail: "ロールバックに失敗しました：",
			snapRestoreConfirm: "ロールバックを確認",
			snapRestoreConfirmText: "ロールバックすると、現在のプラグインと設定がスナップショットの内容で上書きされ、取り消せません（不安な場合は、先に新しいスナップショットを作成してからロールバックしてください）。",
			snapFiles: "含まれるファイル",
			snapDelete: "削除",
			snapDeleting: "削除中…",
			snapDeleted: "スナップショットを削除しました",
			snapDeleteFail: "スナップショットの削除に失敗しました：",
			snapDeleteConfirm: "削除を確認",
			snapDeleteConfirmText: "削除したスナップショットは復元できません。",
			marketNoToggle: "マーケット自身は無効化できません",
			hostDependencyWarning: "プラグインが、DSH がもともと提供している公開パッケージを依存に挙げています。DSH 自身のバージョンと干渉し合う可能性があります（宣言にもとづくもので、確認はされていません）：",
			hostDependencyMore: "ほかに {0} 件が省略されています",
			recoveryTitle: "起動に失敗 — プラグインを調整",
			recoveryLead: "今回の再起動は成功せず、dsh は終了しました。次回の起動で有効にしたいプラグインにチェックを入れてください。今回の起動でエラーになったプラグインは赤くマークされ、チェックが外れています。",
			recoveryOption: "プラグインを調整",
			recoveryBanner: "起動に失敗：",
			recoveryOpening: "失敗の詳細を読み取り中…",
			recoveryNoSummary: "ログには具体的な原因が書かれていません",
			recoveryRawLog: "dsh の元の出力（末尾部分）",
			recoveryBlamedHint: "下で赤くマークされたプラグインは、今回の起動でエラーになりました。チェックを外すと、次回の起動では有効化されません。",
			recoveryNoBlameHint: "ログは特定のプラグインを名指ししていません。下には、現在の有効状態のままで、調整できるプラグインが並んでいます。",
			recoveryCarrier: "他を無効化します",
			recoveryNotToggleable: "このページでは切り替えできません",
			recoveryUnmatched: "DSH が名指ししましたが、このページでは切り替えできないプラグイン：",
			recoveryLogPath: "完全なログ：",
			recoveryApply: "保存して再起動",
			recoveryApplying: "保存して再起動中…",
			recoveryStandalone: "独立した復旧ページを開く",
			recoveryRestarting: "再起動中：dsh が起動したらこのページは更新されます。また失敗した場合は、新しいエラーとともにここに戻ります。",
			recoveryApplyFailed: "保存に失敗しました：",
			recoveryWriteFailed: "前回の選択がすべて保存されなかったため、再起動はしていません：",
			recoveryTimeout: "DeepSeek Harness の起動を待つ間にタイムアウトしました。「プラグインを調整」で、どのプラグインが起動を止めているかを確認できます。",
			hostRecoveryTitle: "設定が空の殻に置き換えられました",
			hostRecoveryBody: "前回の起動の失敗の後、DSH の復旧フローがあなたの設定を既定のものに置き換えました。以前の {0} 件の設定は、バックアップにまだ残っています。",
			hostRecoverySource: "バックアップ：{0}、{1}",
			hostRecoveryRestore: "設定を復元",
			hostRecoveryRestored: "{0} 件の設定を復元しました。ページを更新すると表示されます。",
			hostRecoveryFail: "復元に失敗しました：",
			hostRecoveryNote: "復元の前にスナップショットが自動で保存されるため、元に戻せます。"
		};
		//#endregion
		//#region src/catalog-local-match.ts
		/**
		* Catalog matching for locally linked / file: installs. Shared by the host
		* restore route and the Market client so both refuse the same wrong guesses.
		*/
		const REPO_RE$1 = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
		function validSubpath$1(subpath) {
			if (!/^[A-Za-z0-9_./-]+$/.test(subpath)) return false;
			return !subpath.split("/").some((seg) => seg === "" || seg === "." || seg === "..");
		}
		/**
		* Keys a catalog URL contributes to restore matching.
		* A `/tree/` entry is ONLY its exact `#path:` id — never the bare repo —
		* so a collection-root identity cannot select a sibling subpackage.
		*/
		function catalogMatchKeys(url) {
			const m = /^https:\/\/github\.com\/([^/]+\/[^/]+?)(?:\/tree\/[^/]+\/(.+?))?\/?$/.exec(url);
			if (m === null || !REPO_RE$1.test(m[1])) return {
				path: null,
				repo: null
			};
			const subpath = m[2] ?? null;
			if (subpath !== null && !validSubpath$1(subpath)) return {
				path: null,
				repo: null
			};
			const repo = m[1].toLowerCase();
			return subpath === null ? {
				path: null,
				repo
			} : {
				path: `${repo}#path:/${subpath.toLowerCase()}`,
				repo: null
			};
		}
		function catalogEntryMatchesHints(url, hintSet) {
			const keys = catalogMatchKeys(url);
			return keys.path !== null && hintSet.has(keys.path) || keys.repo !== null && hintSet.has(keys.repo);
		}
		/**
		* The catalog entry a locally linked / file: install should restore to.
		* Exact `#path:` identities win, then collection-root identities against
		* root-only catalog rows, then a unique name/npm match when nothing
		* contradicts it. A bare repo identity never selects a root row while
		* `/tree/` siblings exist for that repo — the checkout did not say which
		* package it is, and guessing wrong installs a different plugin.
		* Same-named forks without identities or a matching hint stay unmatched
		* rather than guessing; declared repo evidence that matches nothing in the
		* catalog must not fall back to a coincidental unique name.
		*/
		/**
		* Memo for findCatalogEntryForLocal, keyed on the catalog array identity and
		* then the full lookup input (#589).
		*
		* The market client calls this once per rendered card for every link:/file:
		* dependency, and each call filtered the whole catalog and walked every URL —
		* measured ~300ms per render at 24 cards against a 3,627-entry catalog, on
		* every keystroke of the search box. The result is a pure function of the
		* catalog, the name, the identities, and the hints, so caching by the array
		* identity never serves a stale answer: a refetched catalog is a new array,
		* and the old inner map becomes collectable. Null results are cached too —
		* they are the common answer for same-named forks without evidence.
		*
		* The input key is the JSON form of the whole tuple, not a delimiter join:
		* an empty array and an array holding one empty string serialize
		* differently, and the matcher treats them differently (`identitySet.size >
		* 0` chooses the evidence branch), so the key must not conflate them
		* (#485's lesson: weak signals must never override strong ones).
		*/
		const localMatchCache = /* @__PURE__ */ new WeakMap();
		function findCatalogEntryForLocal(plugins, name, identities = [], hints = []) {
			const cacheKey = JSON.stringify([
				name,
				identities,
				hints
			]);
			let byCatalog = localMatchCache.get(plugins);
			if (byCatalog === void 0) {
				byCatalog = /* @__PURE__ */ new Map();
				localMatchCache.set(plugins, byCatalog);
			}
			const hit = byCatalog.get(cacheKey);
			if (hit !== void 0) return hit;
			const result = findCatalogEntryForLocalUncached(plugins, name, identities, hints);
			byCatalog.set(cacheKey, result);
			return result;
		}
		function findCatalogEntryForLocalUncached(plugins, name, identities, hints) {
			const nameKey = name.toLowerCase();
			const byName = plugins.filter((plugin) => plugin.name.toLowerCase() === nameKey || typeof plugin.npm === "string" && plugin.npm.toLowerCase() === nameKey);
			const identitySet = new Set(identities.map((value) => value.toLowerCase()));
			const hintSet = new Set(hints.map((value) => value.toLowerCase()));
			const treeRepos = /* @__PURE__ */ new Set();
			for (const plugin of plugins) {
				const keys = catalogMatchKeys(plugin.url);
				if (keys.path !== null) treeRepos.add(keys.path.slice(0, keys.path.indexOf("#path:/")));
			}
			if (identitySet.size > 0) {
				const pathHit = plugins.find((plugin) => {
					const keys = catalogMatchKeys(plugin.url);
					return keys.path !== null && identitySet.has(keys.path);
				});
				if (pathHit !== void 0) return pathHit;
				const rootHit = plugins.find((plugin) => {
					const keys = catalogMatchKeys(plugin.url);
					if (keys.repo === null || !identitySet.has(keys.repo)) return false;
					return !treeRepos.has(keys.repo) || byName.includes(plugin);
				});
				if (rootHit !== void 0) return rootHit;
				return null;
			}
			if (byName.length === 1) {
				const only = byName[0];
				if (hintSet.size > 0 && !catalogEntryMatchesHints(only.url, hintSet)) return null;
				return only;
			}
			if (byName.length > 1 && hintSet.size > 0) {
				const hinted = byName.find((plugin) => catalogEntryMatchesHints(plugin.url, hintSet));
				if (hinted !== void 0) return hinted;
			}
			return null;
		}
		function catalogEntriesByName(plugins, name) {
			const nameKey = name.toLowerCase();
			return plugins.filter((plugin) => plugin.name.toLowerCase() === nameKey || typeof plugin.npm === "string" && plugin.npm.toLowerCase() === nameKey);
		}
		/**
		* Why a local restore was blocked, when findCatalogEntryForLocal returned
		* null — and, when it matched, whether anything but the NAME agreed.
		*
		* `verified` is the difference between "put this back where it came from"
		* and "install the catalog's plugin that happens to share this name". A
		* local checkout with no declared repo — no git remote, no `repository`
		* field — gives the market nothing to match on, so a unique same-named
		* catalog entry is a guess. Usually a good one (#429: the local copy IS a
		* tweaked copy of that entry). Not always: @liuwenji007 reported a fork of
		* their own `dsh-humanizer` restored to a different author's plugin of the
		* same name (#485), which is someone else's code arriving under a button
		* labelled "restore".
		*
		* The match is kept, because refusing it would break the ordinary case, and
		* the caller is told not to present it as a certainty.
		*/
		function resolveCatalogRestore(plugins, name, identities = [], hints = []) {
			const entry = findCatalogEntryForLocal(plugins, name, identities, hints);
			if (entry !== null) return {
				ok: true,
				entry,
				verified: identities.length > 0 || hints.length > 0
			};
			if (catalogEntriesByName(plugins, name).length === 0) return {
				ok: false,
				reason: "no-catalog"
			};
			const identitySet = new Set(identities.map((value) => value.toLowerCase()));
			const hintSet = new Set(hints.map((value) => value.toLowerCase()));
			if (identitySet.size > 0 || hintSet.size > 0) return {
				ok: false,
				reason: "repo-mismatch"
			};
			return {
				ok: false,
				reason: "no-catalog"
			};
		}
		//#endregion
		//#region src/sources.ts
		/**
		* Registry-source knowledge: how a curated registry entry's URL maps to an
		* installable pnpm target. Pure string logic, no I/O.
		*/
		const REPO_RE = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
		function validSubpath(subpath) {
			if (!/^[A-Za-z0-9_./-]+$/.test(subpath)) return false;
			return !subpath.split("/").some((seg) => seg === "" || seg === "." || seg === "..");
		}
		/**
		* Parse a registry source url: a github repo, optionally with a
		* `/tree/<branch>/<subpath>` suffix (how the curated list links monorepo
		* subpackages, e.g. dsh-plugins#theme-gallery).
		*/
		function parseSourceUrl(url) {
			const m = /^https:\/\/github\.com\/([^/]+\/[^/]+?)(?:\/tree\/[^/]+\/(.+?))?\/?$/.exec(url);
			if (m === null || !REPO_RE.test(m[1])) return null;
			const subpath = m[2] ?? null;
			if (subpath !== null) {
				if (!validSubpath(subpath)) return null;
			}
			return {
				repo: m[1],
				subpath
			};
		}
		//#endregion
		//#region src/client/market-data.ts
		/** One registry entry from /dsh-market/registry. */
		/**
		* Resolve a market API path against the page the UI is served from.
		*
		* Every call used to be root-absolute (`/dsh-market/…`), which the browser
		* resolves against the ORIGIN — so behind a reverse proxy that mounts dsh
		* under a prefix (`https://host/app/my-dsh/`), the panel rendered and then
		* every request in it went to `https://host/dsh-market/…`, missed the prefix
		* rule entirely, and 404'd (#345).
		*
		* Anchored on `document.baseURI`, which is the directory the host serves its
		* UI from. Safe for root deployments because that directory is `/` there, and
		* safe generally because the dsh web UI does not use path routing — measured
		* against a real dsh: `location.pathname` is `/` on the market page, not
		* `/settings/...`, so the directory really is the mount point rather than
		* wherever the user happens to have navigated.
		*/
		function api(path) {
			const relative = path.replace(/^\/+/, "");
			if (typeof document === "undefined") return `/${relative}`;
			return new URL(relative, document.baseURI).pathname;
		}
		/** Category ids for one entry, de-duplicated in declaration order. */
		function pluginCategories(plugin) {
			const values = Array.isArray(plugin.category) ? plugin.category : [plugin.category];
			const categories = [];
			const seen = /* @__PURE__ */ new Set();
			for (const value of values) {
				if (typeof value !== "string" || value === "" || seen.has(value)) continue;
				seen.add(value);
				categories.push(value);
			}
			return categories;
		}
		/** Keep GitHub packages in one repository distinct, independently of their display names. */
		function hostCompatibilityKey(plugin) {
			if (typeof plugin.npm === "string" && plugin.npm !== "") return plugin.npm;
			return parseSourceUrl(plugin.url) === null ? null : plugin.url;
		}
		/**
		* Whether a queued operation still applies — `null` when it does.
		*
		* A queued row drains with NO confirmation; that is what queueing means. So a
		* row restored from an old session is a destructive operation launched from a
		* decision the user may have taken back since: queue an uninstall at 10:00,
		* remove the plugin by hand, open the market at 15:00 and it would run. Every
		* kind therefore has to be true RIGHT NOW, and this is the one place that
		* decides — the restore in MarketSection reports what it returns instead of
		* executing it.
		*
		* `install` asks the catalog (the entry may have been delisted), `uninstall`
		* asks the installed map (it may be gone, or the user may have reinstalled
		* it), and `update` asks both plus the update check (the pending release may
		* have landed already).
		*/
		function queuedRowApplies(row, world) {
			if (row.kind === "install") {
				if (row.url === void 0) return "gone";
				return world.plugins.some((plugin) => plugin.url === row.url) ? null : "gone";
			}
			if (world.installed[row.name] === void 0) return "gone";
			if (row.kind === "update" && world.updates[row.name]?.updateAvailable !== true) {
				if (row.restore === true && world.updates[row.name]?.kind === "linked" && findCatalogEntryForLocal(world.plugins, row.name) !== null) return null;
				return "no-update";
			}
			if (row.kind === "update" && row.eligibleVersion !== void 0 && row.eligibleVersion !== world.updates[row.name]?.eligibleVersion) return "target-changed";
			return null;
		}
		function installedForCatalog(installed, bundles) {
			return Object.fromEntries([...bundles.map((name) => [name, "*"]), ...Object.entries(installed)]);
		}
		/**
		* A `link:` the desktop host wrote for one of its generations (#497). The
		* test the server applies (`isGenerationLink` in sources.ts), repeated here
		* because the client bundle cannot import server modules.
		*/
		function isGenerationSpec(spec) {
			return /^link:/i.test(spec) && /(?:^|[\\/])\.generations[\\/]live[\\/]/i.test(spec);
		}
		function restartHintKey(state) {
			if (state.debuggerLatch !== null) return "restartHintDebugged";
			if (!state.restartReachable) return "restartHintViaProxy";
			if (state.supervisor !== null) return "restartHintSupervised";
			return "restartHint";
		}
		/**
		* The install command shown on a plugin's card, corrected for THIS profile
		* (#872).
		*
		* awesome-dsh-plugin generates the string once, for the catalog — always
		* `dsh plugin --profile web add <spec>` — which is right on a `web` profile
		* and wrong on every other one. On a desktop profile it is more than wrong:
		* the DSH CLI refuses a profile by that name, so the command as printed
		* cannot install anything there at all. Two outcomes, and the caller renders
		* them differently because the user's next step differs:
		*
		* - `command`: the text to show and copy, with the profile it names corrected;
		* - `unusable`: show no command at all (the market's own button is the way),
		*   because handing over a command that cannot work is worse than handing
		*   over none.
		*
		* A command with no `--profile` token is passed through untouched: it is not
		* this function's business to add one.
		*/
		function installCommandFor(command, profile) {
			if (typeof command !== "string" || command.trim() === "") return {
				command: null,
				unusable: false
			};
			const named = /--profile(?:=|\s+)(\S+)/u.exec(command);
			if (named === null) return {
				command,
				unusable: false
			};
			const wanted = typeof profile === "string" ? profile.trim() : "";
			if (wanted === "") return {
				command,
				unusable: false
			};
			if (wanted.toLowerCase() === "desktop") return {
				command: null,
				unusable: true
			};
			if (named[1] === wanted) return {
				command,
				unusable: false
			};
			return {
				command: command.replace(named[0], `--profile ${wanted}`),
				unusable: false
			};
		}
		function groupSwitchState(members, disabled) {
			const list = members ?? [];
			if (list.length === 0) return "empty";
			let anyOn = false;
			let anyOff = false;
			for (const member of list) if (disabled.has(member)) anyOff = true;
			else anyOn = true;
			return anyOn && anyOff ? "mixed" : anyOff ? "off" : "on";
		}
		function avatarColor(name) {
			let hash = 0;
			for (let i = 0; i < name.length; i++) hash = hash * 31 + name.charCodeAt(i) | 0;
			return "hsl(" + (hash % 360 + 360) % 360 + " 55% 52%)";
		}
		function readSession(key) {
			try {
				return JSON.parse(sessionStorage.getItem(key) || "null");
			} catch {
				return null;
			}
		}
		/** Heuristic: plugins that target a terminal surface rather than the web UI. */
		function looksTerminal(plugin, lang) {
			if (/\b(tui|cli|tty|terminal)\b|终端|命令行/i.test(plugin.name)) return true;
			const positiveDesc = (plugin.description && (plugin.description[lang] || plugin.description.en) || "").replace(/\b(?:no|without)\b[^.!?;:，。！？；\n]{0,80}\b(?:tui|cli|tty|terminal)\b/gi, "").replace(/(?:无需|无须|不需要|不用)[^。！？；\n]{0,48}(?:tui|cli|tty|terminal|终端|命令行)/gi, "");
			return /\b(?:terminal|cli)[ -]only\b|\btui (?:app|plugin|client)\b|\bterminal (?:ui|app|plugin|client)\b|\bcommand[- ]line (?:tool|interface|app|client|plugin)\b|命令行(?:工具|插件|应用|界面|客户端)|终端(?:工具|插件|应用|界面|客户端)|只在终端|仅在终端|需要(?:一个)?终端|在终端(?:里|中)运行/i.test(positiveDesc);
		}
		/** Days per TimeRange (`all` has no cutoff and is handled by the caller). */
		const TIME_RANGE_DAYS = {
			day: 1,
			week: 7,
			month: 30,
			quarter: 90,
			year: 365
		};
		/** True when `added` is a date within the last `days` days (inclusive). */
		function withinDays(added, days) {
			if (added === void 0 || added === "") return false;
			const time = Date.parse(added);
			if (Number.isNaN(time)) return false;
			const age = Date.now() - time;
			return age >= 0 && age <= days * 864e5;
		}
		/**
		* Whether a catalog entry IS the market itself. The catalog still carries
		* it — nothing about the data changes, and the Installed tab still shows it
		* — this is purely "a store has no reason to sell itself to someone already
		* standing in it."
		*/
		function isMarketItself(plugin) {
			return plugin.name === "dsh-market" || plugin.npm === "dshmarket";
		}
		/**
		* A single pass that inserts a separator after the character on the left of
		* every Han ↔ Latin/number boundary. Punctuation is normalized separately
		* below. Keeping this generic lets `MCP管理`, `管理MCP`, and `OAuth2授权`
		* behave like their space-separated forms without product-specific aliases.
		*/
		const searchScriptBoundary = /(?:\p{Script=Han}(?=[\p{Script=Latin}\p{N}])|[\p{Script=Latin}\p{N}](?=\p{Script=Han}))/gu;
		/** Normalize package names, human text, and adjacent mixed-script terms alike. */
		function searchText(value) {
			return value.normalize("NFKC").toLowerCase().replace(searchScriptBoundary, "$& ").replace(/[^\p{L}\p{N}]+/gu, " ").trim().replace(/\s+/g, " ");
		}
		/**
		* Normalized catalog fields are immutable for the lifetime of one registry
		* entry. Keep them with that entry so typing does not repeat unicode
		* normalization across the whole catalog, while replaced catalogs remain
		* collectible. The raw query is intentionally not cached: it is normalized
		* once per call and would otherwise grow the cache on every keystroke.
		*/
		const pluginSearchTextCache = /* @__PURE__ */ new WeakMap();
		function cachedPluginSearchText(plugin, value) {
			let fields = pluginSearchTextCache.get(plugin);
			if (fields === void 0) {
				fields = /* @__PURE__ */ new Map();
				pluginSearchTextCache.set(plugin, fields);
			}
			const hit = fields.get(value);
			if (hit !== void 0) return hit;
			const normalized = searchText(value);
			fields.set(value, normalized);
			return normalized;
		}
		/**
		* Relevance within one field. Exact matches beat phrase matches, which beat
		* words scattered through the field; for a multi-word query every word must
		* occur in the same field. A prefix match is NOT ranked above a phrase match
		* anywhere else in the field: most catalog names start with `dsh-`, so that
		* distinction mostly punished the naming convention and overrode the sort
		* the user picked (#815: `computer-use-vision` with 355 downloads above
		* `dsh-computer-use` with 3.6k, under "downloads").
		*/
		function fieldRelevance(plugin, value, query, tokens, weight) {
			if (!value) return 0;
			const text = cachedPluginSearchText(plugin, value);
			if (text === "" || !tokens.every((token) => text.includes(token))) return 0;
			if (text === query) return weight + 300;
			if (text.includes(query)) return weight + 200;
			return weight + 150;
		}
		/**
		* Search ranking is field-aware rather than a popularity-only filter:
		* package identities outrank owners, descriptions, and categories. The
		* selected popularity/date sort remains the tie-breaker between equally
		* relevant entries.
		*/
		function pluginRelevance(plugin, query, tokens, lang, categories) {
			const descriptions = plugin.description ?? {};
			const preferredLocale = descriptions[lang] ? lang : descriptions.en ? "en" : null;
			const preferredDescription = descriptions[lang] || descriptions.en;
			const otherDescriptions = Object.entries(descriptions).filter(([locale, value]) => locale !== preferredLocale && typeof value === "string").map(([, value]) => value);
			const categoryIds = pluginCategories(plugin);
			const categoryLabels = categoryIds.flatMap((category) => Object.values(categories?.[category] ?? {}));
			return Math.max(fieldRelevance(plugin, plugin.name, query, tokens, 700), fieldRelevance(plugin, plugin.npm ?? void 0, query, tokens, 700), fieldRelevance(plugin, plugin.owner, query, tokens, 400), fieldRelevance(plugin, preferredDescription, query, tokens, 280), ...otherDescriptions.map((value) => fieldRelevance(plugin, value, query, tokens, 240)), ...categoryIds.map((value) => fieldRelevance(plugin, value, query, tokens, 180)), ...categoryLabels.map((value) => fieldRelevance(plugin, value, query, tokens, 180)));
		}
		/** Compare two already-filtered entries using the user's selected sort. */
		function comparePlugins(a, b, sort) {
			const hasDownloads = (p) => typeof p.downloads === "number";
			if (sort === "downloads-desc") {
				if (hasDownloads(a) && hasDownloads(b)) return b.downloads - a.downloads;
				if (hasDownloads(a)) return -1;
				if (hasDownloads(b)) return 1;
				return (b.stars ?? -1) - (a.stars ?? -1);
			}
			if (sort === "downloads-asc") {
				if (hasDownloads(a) && hasDownloads(b)) return a.downloads - b.downloads;
				if (hasDownloads(a)) return -1;
				if (hasDownloads(b)) return 1;
				return (a.stars ?? -1) - (b.stars ?? -1);
			}
			if (sort === "stars-desc") return (b.stars ?? -1) - (a.stars ?? -1);
			if (sort === "stars-asc") return (a.stars ?? -1) - (b.stars ?? -1);
			if (sort === "added-desc") return String(b.added).localeCompare(String(a.added));
			if (sort === "added-asc") return String(a.added).localeCompare(String(b.added));
			return 0;
		}
		/**
		* The discover list: category filter, then the published-within window, then
		* relevance-ranked search across package identity / owner / every localized
		* description / category ids and labels. With no search, only the selected
		* sort applies, preserving the existing discover-list behaviour.
		* Pure — the section renders exactly this.
		*/
		function visiblePlugins(plugins, options) {
			const query = searchText(options.query);
			const tokens = query.split(" ").filter(Boolean);
			return plugins.flatMap((plugin, index) => {
				if (isMarketItself(plugin)) return [];
				const categories = pluginCategories(plugin);
				if (options.category !== "all" && !categories.includes(options.category)) return [];
				if (options.sinceDays !== void 0 && !withinDays(plugin.added, options.sinceDays)) return [];
				const compatibilityKey = hostCompatibilityKey(plugin);
				if (options.compatibleWithHost === true && compatibilityKey !== null && options.hostCompatibility?.[compatibilityKey]?.status === "incompatible") return [];
				const relevance = query === "" ? 0 : pluginRelevance(plugin, query, tokens, options.lang, options.categories);
				return relevance === 0 && query !== "" ? [] : [{
					plugin,
					relevance,
					index
				}];
			}).sort((a, b) => b.relevance - a.relevance || comparePlugins(a.plugin, b.plugin, options.sort) || a.index - b.index).map((row) => row.plugin);
		}
		/**
		* Favorites tab listing: only bookmarked catalog entries, then the usual
		* search/sort window. Pure — the section renders exactly this.
		*/
		function pluginsForFavorites(plugins, favoriteUrls, options) {
			return visiblePlugins(plugins.filter((plugin) => favoriteUrls.has(plugin.url)), {
				...options,
				category: "all"
			});
		}
		/** Bookmarked URLs with no matching catalog entry — delisted or URL changed. */
		function staleFavoriteUrls(urls, plugins) {
			if (urls.length === 0) return [];
			const catalog = new Set(plugins.map((plugin) => plugin.url));
			return urls.filter((url) => !catalog.has(url));
		}
		/** The themes tab listing: theme category only, most-starred first. */
		function themePlugins(plugins) {
			return plugins.filter((p) => pluginCategories(p).includes("theme")).sort((a, b) => (b.stars || 0) - (a.stars || 0));
		}
		/**
		* Category chip order: collapsed with an active non-'all' chip that would
		* otherwise be clipped out of the two-row preview, the active one moves to
		* the front so it stays visible.
		*
		* Reported as "点了某个分类，标签就跑到前面来了，好奇怪": the earlier version
		* moved the active chip to the front unconditionally, so clicking a category
		* that was ALREADY visible inside the two rows still reshuffled it — and
		* every chip after it — for no reason, since nothing was at risk of being
		* hidden. `visibleCount` is how many chips (the 'all' chip included) the
		* two-row clip fits; a category already within that budget in its natural
		* position is left exactly where it was.
		*
		* `visibleCount === null` (not yet measured, e.g. the very first collapsed
		* render) keeps the old unconditional behaviour: with no measurement to
		* check against, guaranteeing visibility is the safe default.
		*/
		function orderedCategories(categories, active, open, visibleCount = null) {
			if (open || active === "all") return categories;
			if (visibleCount !== null) {
				const budget = Math.max(0, visibleCount - 1);
				const naturalIndex = categories.indexOf(active);
				if (naturalIndex !== -1 && naturalIndex < budget) return categories;
			}
			return [active, ...categories.filter((id) => id !== active)];
		}
		/**
		* Page-number list for the discover pager. With few pages it is simply
		* 1..total; with many it windows around the current page —
		* `1 … n-1 n n+1 … total` (at most five numbered buttons) — so a
		* 400-plugin catalog stays compact instead of a long row of numbered
		* buttons. Always begins with 1 and ends with total, so the first/last
		* pages stay one click away even without the pager's «/» shortcuts.
		*/
		function pageItems(current, total) {
			if (total <= 7) {
				const all = [];
				for (let i = 1; i <= total; i++) all.push(i);
				return all;
			}
			const start = Math.max(2, current - 1);
			const end = Math.min(total - 1, current + 1);
			const items = [1];
			if (start > 2) items.push("…");
			for (let i = start; i <= end; i++) items.push(i);
			if (end < total - 1) items.push("…");
			items.push(total);
			return items;
		}
		/**
		* Unified installed-state matching (#15): both sides collapse to lowercase
		* identity sets — the registry entry contributes its bare name, npm name and
		* owner/repo; the dependency contributes its key and the repo inside its
		* spec — and any exact intersection counts. Exact equality, not substrings,
		* so prefix-related repo names cannot cross-match.
		*/
		/**
		* Memo for entryIdentities, keyed on the catalog entry object itself.
		*
		* Catalog entries are parsed once and never mutated, so the identity set is
		* a pure function of an object that outlives every call — a WeakMap holds
		* it for exactly as long as the catalog is alive and not one render longer.
		* Worth caching because this is the innermost step of the installed-state
		* matching that runs for every card on screen (#262).
		*/
		const entryIdCache = /* @__PURE__ */ new WeakMap();
		function entryIdentities(plugin) {
			const cached = entryIdCache.get(plugin);
			if (cached !== void 0) return cached;
			const ids = /* @__PURE__ */ new Set([plugin.name.toLowerCase()]);
			if (plugin.npm) ids.add(plugin.npm.toLowerCase());
			const m = /^https:\/\/github\.com\/([^/]+\/[^/]+?)(?:\/tree\/[^/]+\/(.+?))?\/?$/.exec(plugin.url);
			if (m !== null) ids.add(m[2] !== void 0 ? `${m[1].toLowerCase()}#path:/${m[2].toLowerCase()}` : m[1].toLowerCase());
			entryIdCache.set(plugin, ids);
			return ids;
		}
		const REPO_ID_RE = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+(?:#path:\/[A-Za-z0-9_./-]+)?$/;
		function addRepoIdentities(ids, values) {
			for (const value of values) {
				if (!REPO_ID_RE.test(value)) continue;
				const subpath = value.split("#path:/")[1];
				if (subpath !== void 0 && subpath.split("/").some((seg) => seg === "" || seg === "." || seg === "..")) continue;
				ids.add(value.toLowerCase());
			}
		}
		/** Repo identities carried by a github shortcut, including `#sha&path:`. */
		function githubSpecRepoIds(spec) {
			const ids = /* @__PURE__ */ new Set();
			const match = /^github:([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+?)(?:\.git)?(?:#(.*))?$/i.exec(spec);
			if (match === null) return ids;
			const repo = match[1].toLowerCase();
			let subpath = null;
			for (const selector of (match[2] ?? "").split("&")) {
				if (!selector.startsWith("path:/")) continue;
				const candidate = selector.slice(6);
				if (!REPO_ID_RE.test(`${repo}#path:/${candidate}`) || candidate.split("/").some((seg) => seg === "" || seg === "." || seg === "..") || subpath !== null) return /* @__PURE__ */ new Set();
				subpath = candidate.toLowerCase();
			}
			ids.add(repo);
			if (subpath !== null) ids.add(`${repo}#path:/${subpath}`);
			return ids;
		}
		function depIdentities(name, spec, repoIdentities = []) {
			const ids = /* @__PURE__ */ new Set([name.toLowerCase()]);
			const scoped = /^@([^/]+)\/(.+)$/.exec(name);
			if (scoped !== null) ids.add(`${scoped[1].toLowerCase()}/${scoped[2].toLowerCase()}`);
			for (const id of githubSpecRepoIds(spec)) ids.add(id);
			addRepoIdentities(ids, repoIdentities);
			return ids;
		}
		/**
		* Repo identities stated by the dependency SPEC itself (github: installs) —
		* hard evidence of where the package came from, unlike the name-derived
		* mirror in depIdentities, which is only a matching aid.
		*/
		function depRepoIds(spec, repoIdentities = []) {
			const ids = githubSpecRepoIds(spec);
			addRepoIdentities(ids, repoIdentities);
			return ids;
		}
		/** Repo identity of a registry entry's source url (repo or repo#path form). */
		function entryRepoIds(plugin) {
			const ids = /* @__PURE__ */ new Set();
			const m = /^https:\/\/github\.com\/([^/]+\/[^/]+?)(?:\/tree\/[^/]+\/(.+?))?\/?$/.exec(plugin.url);
			if (m !== null) ids.add(m[2] !== void 0 ? `${m[1].toLowerCase()}#path:/${m[2].toLowerCase()}` : m[1].toLowerCase());
			return ids;
		}
		/**
		* The curated registry lists distinct plugins sharing one name — twelve
		* name-groups at the time of #66 (both dsh-usage-stats, four dsh-memory…).
		* A name coincidence must not survive contradicting repo evidence: when the
		* dependency's spec pins a github repo AND the entry states one, the repos
		* decide — the loose name/npm identities only apply when at least one side
		* carries no repo evidence (npm installs, non-github entries).
		*
		* Repo evidence only ever decides by repository ROOT. A monorepo catalog
		* entry states `owner/repo#path:/pkg` while an npm-installed manifest
		* usually states the bare `owner/repo` (it rarely declares
		* `repository.directory`), and reading that asymmetry as a source conflict
		* kept a genuinely installed subpackage from ever reading as installed.
		*/
		/** Repository root: the part before any `#path:/…` subpath selection. */
		function repoRoots(ids) {
			return new Set([...ids].map((id) => id.split("#path:/")[0]));
		}
		function sameSourceConflict(plugin, spec, repoIdentities = []) {
			const entry = repoRoots(entryRepoIds(plugin));
			const dep = repoRoots(depRepoIds(spec, repoIdentities));
			if (entry.size === 0 || dep.size === 0) return false;
			for (const id of dep) if (entry.has(id)) return false;
			return true;
		}
		function repoHintMatches(plugin, hints) {
			const entry = entryRepoIds(plugin);
			const values = /* @__PURE__ */ new Set();
			addRepoIdentities(values, hints);
			for (const id of values) if (entry.has(id)) return true;
			return false;
		}
		/**
		* Memo for looseMatchCount, keyed on the catalog array then the dep name.
		*
		* This is THE hot path behind "the plugin list is very laggy" (#262). The
		* count answers "how many catalog entries could this installed dependency
		* be?", which depends only on the catalog and the name — not on the card
		* being drawn. But it was called from matchInstalledName, which runs once
		* per installed dependency, which runs once per rendered card: a full scan
		* of ~1800 entries, repeated cards × installed times, on every single
		* render. A profile from the reporter put it at 2.9 seconds, 28% of the
		* whole trace, and a local benchmark measured 48ms per render at 24 cards
		* and 224ms at 96 against a smaller 839-entry catalog.
		*
		* Keyed on the array identity so a refetched catalog gets a fresh map for
		* free — a new parse is a new array, and the old one is collectable.
		*/
		const looseMatchCountCache = /* @__PURE__ */ new WeakMap();
		function looseMatchCount(plugins, name) {
			let byName = looseMatchCountCache.get(plugins);
			if (byName === void 0) {
				byName = /* @__PURE__ */ new Map();
				looseMatchCountCache.set(plugins, byName);
			}
			const hit = byName.get(name);
			if (hit !== void 0) return hit;
			const dep = depIdentities(name, "");
			let count = 0;
			for (const plugin of plugins) for (const id of entryIdentities(plugin)) if (dep.has(id)) {
				count += 1;
				break;
			}
			byName.set(name, count);
			return count;
		}
		function looseMatches(plugin, name) {
			const dep = depIdentities(name, "");
			for (const id of entryIdentities(plugin)) if (dep.has(id)) return true;
			return false;
		}
		/** The installed dependency name a registry entry corresponds to, or null. */
		function matchInstalledName(plugin, installed, repoIdentities = {}, plugins, repoHints = {}) {
			const ids = entryIdentities(plugin);
			for (const [name, spec] of Object.entries(installed)) {
				const specStr = String(spec);
				const repos = repoIdentities[name] ?? [];
				if (/^(?:link|file):/i.test(specStr)) {
					if (plugins === void 0) continue;
					const entry = findCatalogEntryForLocal(plugins, name, repos, repoHints[name] ?? []);
					if (entry !== null && entry.url === plugin.url) return name;
					continue;
				}
				if (depRepoIds(specStr, repos).size === 0 && plugins !== void 0 && looseMatchCount(plugins, name) > 1 && !repoHintMatches(plugin, repoHints[name] ?? [])) continue;
				if (sameSourceConflict(plugin, specStr, repos)) continue;
				for (const id of depIdentities(name, specStr, repos)) if (ids.has(id)) return name;
			}
			return null;
		}
		/** The registry entry an installed dependency corresponds to, or undefined. */
		function entryForDep(plugins, name, spec, repoIdentities = [], repoHints = []) {
			if (depRepoIds(String(spec), repoIdentities).size === 0 && looseMatchCount(plugins, name) > 1) {
				if (plugins.find((plugin) => repoHintMatches(plugin, repoHints) && looseMatches(plugin, name)) === void 0) return void 0;
			}
			const ids = depIdentities(name, String(spec), repoIdentities);
			return plugins.find((plugin) => {
				if (sameSourceConflict(plugin, String(spec), repoIdentities)) return false;
				for (const id of entryIdentities(plugin)) if (ids.has(id)) return true;
				return false;
			});
		}
		function isInstalled(plugin, installed, repoIdentities = {}, plugins, repoHints = {}) {
			return matchInstalledName(plugin, installed, repoIdentities, plugins, repoHints) !== null;
		}
		/**
		* The header brand mark now lives in MarketSection.tsx as an inline SVG
		* (official-style monochrome glyph, fill="currentColor") so it follows the
		* active theme; the colored assets/logo.svg tile is no longer inlined here.
		*/
		/** Four representative colors for a theme card's preview strip. */
		function themeSwatch(def) {
			const tk = def.tokens || {};
			const pick = (names) => {
				for (const n of names) if (tk[n]) return tk[n];
				return null;
			};
			const dark = def.colorScheme === "dark";
			return [
				pick(["--dsw-alias-bg-base", "--dsw-alias-bg-layer-1"]) || (dark ? "#0f1115" : "#ffffff"),
				pick(["--dsw-alias-bg-layer-2", "--dsw-alias-bg-overlay"]) || (dark ? "#1a1d23" : "#f3f4f6"),
				pick(["--dsw-alias-brand-primary"]) || "#4f6ef7",
				pick(["--dsw-alias-label-primary"]) || (dark ? "#e5e7eb" : "#1f2328")
			];
		}
		let githubRoutes = {
			raw: [null],
			avatar: [null]
		};
		const preferredGithubRoutes = /* @__PURE__ */ new Map();
		function cleanGithubRoutes(value, fallback) {
			if (!Array.isArray(value)) return [fallback];
			const out = [];
			for (const item of value) {
				if (item !== null && typeof item !== "string") continue;
				const route = typeof item === "string" ? item.trim().replace(/\/+$/u, "") : null;
				if (route === "" || out.includes(route)) continue;
				out.push(route);
			}
			return out.length === 0 ? [fallback] : out;
		}
		/** Install server-resolved per-service candidates, with old-host fallback. */
		function setGithubRoutes(routes, fallback = null) {
			let changed = false;
			for (const service of ["raw", "avatar"]) {
				const next = cleanGithubRoutes(routes?.[service], fallback);
				if (next.length === githubRoutes[service].length && next.every((route, index) => route === githubRoutes[service][index])) continue;
				githubRoutes[service] = next;
				preferredGithubRoutes.delete(service);
				changed = true;
			}
			if (changed) readmeShotsCache.clear();
		}
		/** Apply either a current status payload or its legacy single-prefix shape. */
		function applyGithubRouting(status) {
			setGithubRoutes(status.githubRoutes, typeof status.githubProxy === "string" ? status.githubProxy : null);
		}
		/** Candidates for one request, with that service's last winner first. */
		function githubRouteCandidates(service, url) {
			const routes = [...githubRoutes[service]];
			if (preferredGithubRoutes.has(service)) {
				const preferred = preferredGithubRoutes.get(service);
				const index = routes.findIndex((route) => route === preferred);
				if (index > 0) routes.unshift(...routes.splice(index, 1));
			}
			return routes.map((proxy) => ({
				proxy,
				url: proxy === null ? url : `${proxy}/${url}`
			}));
		}
		/** Cache a route only after the consumer has validated its expected payload. */
		function rememberGithubRoute(service, proxy) {
			preferredGithubRoutes.set(service, proxy);
		}
		/**
		* Intranet mode, as the server reported it.
		*
		* A module-level bit rather than a React context because the three consumers
		* are not in one tree: the avatar tile, the screenshot strip and the comment
		* link each render from a different branch of a 9000-line section, and the
		* value only ever arrives once per page load from the status poll.
		*/
		let offlineMarket = false;
		/** Record the server's answer. Idempotent; safe to call on every poll. */
		function setMarketOffline(value) {
			offlineMarket = value;
		}
		/** Whether this market runs on a network with no public internet. */
		function marketOffline() {
			return offlineMarket;
		}
		/**
		* Image hosts screenshots may load from (#61) — GitHub's own hosting only.
		* Any other host is dropped BEFORE an <img> is created: a screenshot URL is
		* a request carrying the user's IP, so registry data and README content are
		* both treated as untrusted here, matching the upstream build gate.
		*/
		const SCREENSHOT_HOSTS = /* @__PURE__ */ new Set([
			"raw.githubusercontent.com",
			"user-images.githubusercontent.com",
			"camo.githubusercontent.com",
			"github.com"
		]);
		const MAX_SCREENSHOTS = 6;
		function gateScreenshot(value) {
			if (typeof value !== "string") return {
				ok: false,
				reason: "not a string"
			};
			let parsed;
			try {
				parsed = new URL(value);
			} catch {
				return {
					ok: false,
					reason: "not a parseable URL"
				};
			}
			if (parsed.protocol !== "https:") return {
				ok: false,
				reason: "not https"
			};
			if (!SCREENSHOT_HOSTS.has(parsed.hostname)) return {
				ok: false,
				reason: `host not allowlisted (${parsed.hostname})`
			};
			if (/\.svg$/iu.test(parsed.pathname)) return {
				ok: false,
				reason: "svg is not rendered"
			};
			return {
				ok: true,
				src: value
			};
		}
		/** Return one safe screenshot URL without applying the public list limit. */
		function safeScreenshot(value) {
			const gate = gateScreenshot(value);
			return gate.ok ? gate.src : null;
		}
		/**
		* A catalog-declared storefront tile. Same https/GitHub-only gate as
		* screenshots (an icon URL is still a request carrying the user's IP) and
		* raster-only, because an SVG tile is a document, not an image.
		*/
		function safeIcon(value) {
			return safeScreenshot(value);
		}
		/**
		* Prepare a GitHub release body for the update-notes dialog's tiny markdown
		* renderer. HTML — especially pasted `<img>` tags — must not surface as
		* literal text; markdown syntax is left intact for the dialog to render.
		*/
		function sanitizeReleaseNotesBody(md) {
			let s = md.replace(/<!--[\s\S]*?-->/g, "");
			s = s.replace(/<img\b[^>]*>/gi, "");
			s = s.replace(/<\/?[a-zA-Z][\w:-]*\b[^>]*>/g, "");
			s = s.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n");
			return s.trim();
		}
		/**
		* A whole-line markdown image with an allowlisted https URL, or null.
		* Relative paths and non-GitHub hosts stay out of the dialog (same gate as
		* install screenshots).
		*/
		function releaseNotesHttpsImage(line) {
			const match = /^!\[([^\]]*)\]\(\s*(?:<(https:\/\/[^>]+)>|(https:\/\/[^\s)]+))(?:\s+(?:"[^"]*"|'[^']*'|\([^)]*\)))?\s*\)$/u.exec(line.trim());
			if (match === null) return null;
			const src = safeScreenshot(match[2] ?? match[3] ?? "");
			if (src === null) return null;
			return {
				alt: match[1] ?? "",
				src
			};
		}
		/**
		* Keep only https URLs on allowlisted image hosts; SVG dropped (logos/badges).
		*
		* `onReject` is opt-in, because whether a refusal deserves a word depends on
		* where the list came from: a README contributes mostly badges, logos and
		* third-party hosts, where refusing IS the intended outcome. A curated
		* catalog list is different — every URL in it is declared intent — so
		* `pluginScreenshotCandidates` is the caller that reports (see there).
		*/
		function safeScreenshots(urls, options = {}) {
			if (!Array.isArray(urls)) return [];
			const { onReject } = options;
			const safe = [];
			for (const value of urls) {
				const gate = gateScreenshot(value);
				if (!gate.ok) {
					onReject?.({
						value,
						reason: gate.reason
					});
					continue;
				}
				if (!safe.includes(gate.src)) safe.push(gate.src);
				if (safe.length >= MAX_SCREENSHOTS) break;
			}
			return safe;
		}
		const PREVIEW_WORDS = /(?:preview|screen[ -]?shots?|shots?|demo|showcase|gallery|theme|skin|appearance|效果|预览|截图|演示|展示|界面|主题|皮肤)/iu;
		const FULL_PREVIEW_WORDS = /(?:full|overview|home|main|conversation|chat|workspace|dashboard|完整|主页|首页|全景|主界面)/iu;
		const PARTIAL_PREVIEW_WORDS = /(?:settings?|panel|dialog|modal|picker|menu|controls?|fragment|crop|detail|配置|设置|面板|弹窗|局部|细节)/iu;
		const NON_PREVIEW_WORDS = /(?:badge|shield|logo|icon|avatar|sponsor|donat|fund|qr(?:code)?|wechat|qq(?:group)?|npm|build|coverage|license|status|button|favicon|徽章|图标|头像|赞助|捐赠|二维码|微信|交流群)/iu;
		/** A quoted or unquoted HTML attribute; README HTML is data, never rendered. */
		function htmlAttribute(html, name) {
			const match = new RegExp(`\\b${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, "iu").exec(html);
			return match?.[1] ?? match?.[2] ?? match?.[3] ?? "";
		}
		function numericDimension(raw) {
			if (!/^\d+(?:\.\d+)?$/u.test(raw.trim())) return null;
			const value = Number(raw);
			return Number.isFinite(value) && value > 0 ? value : null;
		}
		/** Resolve one README image path to the canonical GitHub-hosted URL. */
		function resolveReadmeImage(raw, owner, repo, base) {
			const src = raw.trim().replace(/^<|>$/g, "");
			if (src === "" || src.startsWith("data:")) return null;
			let absolute;
			if (/^https?:\/\//iu.test(src)) absolute = src;
			else if (src.startsWith("/")) absolute = `https://raw.githubusercontent.com/${owner}/${repo}/HEAD${src}`;
			else try {
				absolute = new URL(src, base).href;
			} catch {
				return null;
			}
			return safeScreenshot(absolute);
		}
		/** Score evidence available without downloading the image itself. */
		function readmeSemanticScore(image, heading, nearby, order, offset) {
			const label = `${image.alt} ${image.title}`;
			const path = (() => {
				try {
					const parsed = new URL(image.src);
					if (parsed.hostname === "raw.githubusercontent.com") return "/" + parsed.pathname.split("/").slice(4).join("/");
					return parsed.pathname;
				} catch {
					return image.src;
				}
			})();
			let score = 20 + Math.max(0, 8 - order);
			if (PREVIEW_WORDS.test(label)) score += 55;
			if (PREVIEW_WORDS.test(path)) score += 40;
			if (PREVIEW_WORDS.test(heading)) score += 32;
			if (PREVIEW_WORDS.test(nearby)) score += 12;
			if (FULL_PREVIEW_WORDS.test(`${label} ${path}`)) score += 35;
			if (PARTIAL_PREVIEW_WORDS.test(`${label} ${path}`)) score -= 30;
			if (NON_PREVIEW_WORDS.test(label)) score -= 140;
			if (NON_PREVIEW_WORDS.test(path)) score -= 120;
			if (NON_PREVIEW_WORDS.test(heading)) score -= 55;
			if (NON_PREVIEW_WORDS.test(nearby)) score -= 18;
			if (offset < 500 && !PREVIEW_WORDS.test(`${label} ${path} ${heading}`)) score -= 20;
			if (image.width !== null && image.height !== null) score += previewDimensionScore(image.width, image.height) ?? -500;
			else if ((image.width ?? image.height ?? Number.POSITIVE_INFINITY) < 240) score -= 100;
			return score;
		}
		/**
		* Ranked README image candidates for use when the catalog has no curated
		* screenshots. Ranking uses the image label/path, nearest heading, nearby
		* prose, declared dimensions and document position. This prevents a title
		* logo or a row of tiny badges from consuming the six-candidate limit before
		* a later Screenshots section is reached.
		*/
		function extractReadmeImageCandidates(markdown, owner, repo, subpath) {
			const base = `https://raw.githubusercontent.com/${owner}/${repo}/HEAD/${subpath === null ? "" : subpath + "/"}`;
			const headings = [...markdown.matchAll(/^#{1,6}\s+(.+?)\s*#*\s*$/gmu)].map((match) => ({
				offset: match.index,
				text: match[1] ?? ""
			}));
			const found = /* @__PURE__ */ new Map();
			let headingIndex = -1;
			let order = 0;
			for (const match of markdown.matchAll(/!\[([^\]]*)\]\(\s*(?:<([^>]+)>|([^\s)]+))(?:\s+(?:"([^"]*)"|'([^']*)'|\(([^)]*)\)))?\s*\)|<img\b([^>]*?)\/?\s*>/gimu)) {
				while (headingIndex + 1 < headings.length && headings[headingIndex + 1].offset < match.index) headingIndex += 1;
				const html = match[7] ?? "";
				const src = resolveReadmeImage(match[2] ?? match[3] ?? htmlAttribute(html, "src"), owner, repo, base);
				if (src === null) continue;
				const candidate = {
					src,
					semanticScore: readmeSemanticScore({
						src,
						alt: match[1] ?? htmlAttribute(html, "alt"),
						title: match[4] ?? match[5] ?? match[6] ?? htmlAttribute(html, "title"),
						width: numericDimension(htmlAttribute(html, "width")),
						height: numericDimension(htmlAttribute(html, "height"))
					}, headings[headingIndex]?.text ?? "", markdown.slice(Math.max(0, match.index - 100), Math.min(markdown.length, match.index + match[0].length + 100)), order, match.index),
					order,
					curated: false
				};
				const previous = found.get(src);
				if (previous === void 0 || candidate.semanticScore > previous.semanticScore) found.set(src, candidate);
				order += 1;
			}
			return [...found.values()].filter((candidate) => candidate.semanticScore >= 20).sort((a, b) => b.semanticScore - a.semanticScore || a.order - b.order).slice(0, MAX_SCREENSHOTS);
		}
		/**
		* Score dimensions from a 240px-high, no-upscale probe.
		*
		* A theme preview should resemble a complete desktop surface: landscape,
		* neither a narrow crop nor a panoramic strip, and large enough to inspect.
		* Small square logos and portrait fragments intentionally return null.
		*/
		function previewDimensionScore(width, height) {
			if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) return null;
			const ratio = width / height;
			const area = width * height;
			if (width < 280 || height < 150 || area < 48e3 || ratio < 1.05 || ratio > 3.2) return null;
			let score = Math.min(28, Math.round(area / 4e3));
			if (ratio >= 1.35 && ratio <= 2.05) score += 48;
			else if (ratio >= 1.18 && ratio <= 2.4) score += 28;
			else score += 8;
			if (width >= 320 && height >= 180) score += 14;
			return score;
		}
		/** Combine README semantics with measured geometry and return the best set. */
		function rankThemeScreenshots(candidates, measurements) {
			const bySrc = new Map(measurements.map((item) => [item.src, item]));
			return candidates.flatMap((candidate) => {
				const measured = bySrc.get(candidate.src);
				if (measured === void 0) return [];
				const dimensionScore = previewDimensionScore(measured.width, measured.height);
				return dimensionScore === null ? [] : [{
					candidate,
					score: candidate.semanticScore + dimensionScore
				}];
			}).sort((a, b) => b.score - a.score || a.candidate.order - b.candidate.order).slice(0, MAX_SCREENSHOTS).map((item) => item.candidate.src);
		}
		const readmeShotsCache = /* @__PURE__ */ new Map();
		/**
		* Declared screenshots the market refuses, reported once per catalog entry.
		*
		* A curated entry is the publisher's declaration, and the registry gate that
		* accepts it (`scripts/validate-registry.mjs`, E12) allows any https URL on
		* the four GitHub hosts, while this client additionally refuses `.svg`. An
		* entry can therefore pass CI with a screenshot the market then drops, and
		* until this existed nothing said so: the card rendered fewer previews, or —
		* when every declared shot was refused — the client quietly fell back to
		* scraping the README. Keyed by entry plus the refused values, so a re-render,
		* a dialog and a theme card report one line between them, and cleared with the
		* README cache at each accepted catalog generation.
		*/
		const refusedCuratedScreenshots = /* @__PURE__ */ new Set();
		function warnRefusedCuratedScreenshots(plugin, rejections) {
			const details = [...new Set(rejections.map(({ value, reason }) => `${reason}: ${String(value)}`))];
			const key = `${plugin.url}\n${details.join("\n")}`;
			if (refusedCuratedScreenshots.has(key)) return;
			refusedCuratedScreenshots.add(key);
			console.warn(`[dsh-market] catalog entry "${plugin.name}" declares ${details.length} screenshot(s) the market will not load — ${details.join("; ")}`);
		}
		/** Clear README-derived media and refusal reporting at the boundary of an accepted catalog generation. */
		function resetScreenshotsCache() {
			readmeShotsCache.clear();
			refusedCuratedScreenshots.clear();
		}
		/**
		* Screenshot candidates for a plugin: the registry's curated list when
		* present, otherwise lazily extracted and semantically ranked from README.
		*/
		function pluginScreenshotCandidates(plugin) {
			if (marketOffline()) return Promise.resolve([]);
			const refused = [];
			const curated = safeScreenshots(plugin.screenshots, { onReject: (rejection) => {
				refused.push(rejection);
			} });
			if (refused.length > 0) warnRefusedCuratedScreenshots(plugin, refused);
			if (curated.length > 0) return Promise.resolve(curated.map((src, order) => ({
				src,
				order,
				semanticScore: 1e3 - order,
				curated: true
			})));
			const m = /^https:\/\/github\.com\/([^/]+)\/([^/]+?)(?:\/tree\/[^/]+\/(.+?))?\/?$/.exec(plugin.url);
			if (m === null) return Promise.resolve([]);
			const [, owner, repo, subpath = null] = m;
			const cacheKey = plugin.url;
			const cached = readmeShotsCache.get(cacheKey);
			if (cached !== void 0) return cached;
			const fetchReadme = async (path) => {
				const url = `https://raw.githubusercontent.com/${owner}/${repo}/HEAD/${path === null ? "" : path + "/"}README.md`;
				for (const candidate of githubRouteCandidates("raw", url)) {
					const controller = new AbortController();
					const timer = setTimeout(() => {
						controller.abort();
					}, 6e3);
					try {
						const res = await fetch(candidate.url, { signal: controller.signal });
						if (!res.ok) continue;
						const body = await res.text();
						if ((res.headers.get("content-type")?.toLowerCase() ?? "").includes("text/html") || /^\s*(?:<!doctype\s+html|<html[\s>])/iu.test(body)) continue;
						rememberGithubRoute("raw", candidate.proxy);
						return body;
					} catch {} finally {
						clearTimeout(timer);
					}
				}
				return null;
			};
			const task = (async () => {
				const sub = subpath === null ? null : await fetchReadme(subpath);
				if (sub !== null) return extractReadmeImageCandidates(sub, owner, repo, subpath);
				const root = await fetchReadme(null);
				return root === null ? [] : extractReadmeImageCandidates(root, owner, repo, null);
			})().catch(() => []);
			readmeShotsCache.set(cacheKey, task);
			return task;
		}
		/** Screenshot URLs for dialogs; theme covers use the richer candidate API. */
		async function pluginScreenshots(plugin) {
			return (await pluginScreenshotCandidates(plugin)).map((candidate) => candidate.src);
		}
		/**
		* The human-readable part of a failed command's output.
		*
		* pnpm's ndjson reporter writes one JSON object per progress tick, and a
		* large `github:` download emits thousands of them. When a failure matches
		* none of the known signatures there is no diagnosis to show, so the UI
		* falls back to the tail of stdout/stderr — which for exactly that case is
		* 600 characters of `{"name":"pnpm:fetching-progress","downloaded":…}`.
		* The user is handed machine noise at the one moment they need a sentence
		* (#148, and the same shape behind #161).
		*
		* Progress objects are dropped; anything else — including JSON carrying a
		* real message — is kept, because an unrecognized failure is precisely when
		* throwing information away is most expensive.
		*/
		function humanOutput(raw) {
			const lines = raw.split(/\r?\n/);
			const kept = [];
			for (const line of lines) {
				const trimmed = line.trim();
				if (trimmed === "") continue;
				if (!trimmed.startsWith("{")) {
					kept.push(line);
					continue;
				}
				try {
					const parsed = JSON.parse(trimmed);
					const name = typeof parsed.name === "string" ? parsed.name : "";
					if (parsed.err !== void 0 || typeof parsed.message === "string") {
						kept.push(line);
						continue;
					}
					if (name.startsWith("pnpm:")) continue;
					kept.push(line);
				} catch {
					kept.push(line);
				}
			}
			return kept.join("\n").trim();
		}
		/**
		* One failed operation's sentence for the user: the market's own when the
		* route sent one, otherwise the tail of pnpm's own output.
		*
		* The tail is for the stack, not for our sentences (#848). A route's message
		* is one bilingual sentence — Chinese first, then English — so keeping the
		* last 600 characters of it kept the English and threw the Chinese away, which
		* is the half a Chinese reader needs, and it cut the classifier's
		* `unused-patch` sentence through the middle of its actionable clause. Every
		* route sentence is bounded by construction; pnpm's output is not.
		*/
		function failureText(body, options = {}) {
			const { tail = 600, fallback = "" } = options;
			const field = (value) => typeof value === "string" ? value : value && typeof value.text === "string" ? value.text : value == null ? "" : JSON.stringify(value);
			const own = field(body.error);
			if (own !== "") return own;
			const machine = humanOutput([field(body.stderr), field(body.stdout)].filter(Boolean).join("\n"));
			if (machine !== "") return machine.slice(-tail);
			const exit = field(body.exitCode);
			return exit === "" ? fallback : `exit ${exit}`;
		}
		/** CJK ideographs — enough to tell a Chinese half from a Latin one. */
		const CJK_RE = /[\u3400-\u9FFF\uF900-\uFAFF]/gu;
		/** Count CJK code points in a string. */
		function cjkCount(text) {
			return text.match(CJK_RE)?.length ?? 0;
		}
		/**
		* Pick one language from a `中文 / English` (or reverse) pair. Ambiguous
		* strings stay unchanged. Callers that prepend `t(…)` must localize the
		* server half first, then concatenate — this function does not strip UI chrome.
		*/
		function pickBilingualPair(text, lang) {
			const sep = " / ";
			const parts = text.split(sep);
			if (parts.length < 2) return text;
			let bestLeft = parts[0];
			let bestRight = parts.slice(1).join(sep);
			let bestScore = Math.abs(cjkCount(bestLeft) - cjkCount(bestRight));
			for (let i = 1; i < parts.length - 1; i++) {
				const left = parts.slice(0, i + 1).join(sep);
				const right = parts.slice(i + 1).join(sep);
				const score = Math.abs(cjkCount(left) - cjkCount(right));
				if (score > bestScore) {
					bestScore = score;
					bestLeft = left;
					bestRight = right;
				}
			}
			if (bestScore === 0) return text;
			const zhPart = cjkCount(bestLeft) > cjkCount(bestRight) ? bestLeft : bestRight;
			const enPart = cjkCount(bestLeft) > cjkCount(bestRight) ? bestRight : bestLeft;
			return lang === "zh" ? zhPart : enPart;
		}
		/**
		* Pick the locale half of a server bilingual string (`中文 / English` or
		* `English / 中文`). Multiline input is handled line by line. Ambiguous
		* strings are returned unchanged.
		*/
		function localizeBilingual(text, lang) {
			if (text.includes("\n")) return text.split("\n").map((line) => localizeBilingual(line, lang)).join("\n");
			return pickBilingualPair(text, lang);
		}
		/**
		* Localize each bilingual reason and join for display. Reasons are separate
		* diagnoses; do not rejoin them with ` / `, which is the bilingual separator.
		*/
		function localizeBilingualList(parts, lang) {
			const sep = lang === "zh" ? "；" : "; ";
			return parts.map((part) => localizeBilingual(part, lang)).filter((part) => part !== "").join(sep);
		}
		/**
		* The plugin's own name, for display.
		*
		* The catalog's `name` is an IDENTITY, and for the 104 entries that live in
		* a repository holding several plugins it is a compound one:
		* `dsh-web#packages/dsh-web-all`. Shown verbatim it puts a repository
		* path in front of a user who did not ask about repositories — and worse, it
		* disagrees with the market's own installed list, which reads names out of
		* the profile manifest and calls the same plugin `dsh-web-all`. The same
		* thing had two names either side of the Install button.
		*
		* A card answers two questions: who made it, and what is it called. The
		* author is drawn beside their avatar as one unit, so the title is free to
		* be just the plugin. Duplicate titles across authors are fine — the byline
		* is what separates them — which is why this does not try to keep the
		* repository as a qualifier.
		*
		* The repository name IS the plugin name in the ordinary case, because a
		* repository holding one plugin is named after it. Only the compound form
		* needs unpicking. Prefer its mapped npm package when available: a generic
		* directory such as `plugin` is not the product name. Without that mapping,
		* keep the directory-leaf fallback for source-only entries.
		*
		* Not a substitute for the identity: every key, lookup and install still
		* uses `name` unchanged.
		*/
		function pluginName(name, npm) {
			const hash = name.indexOf("#");
			if (hash === -1) return name;
			if (typeof npm === "string" && npm.trim() !== "") return npm.trim();
			const sub = name.slice(hash + 1);
			const leaf = sub.slice(sub.lastIndexOf("/") + 1);
			return leaf === "" ? name.slice(0, hash) : leaf;
		}
		/**
		* The catalog package name used for the local block list (#657).
		*
		* Prefer the npm package when the catalog carries one. Fall back to the
		* repository name for entries that have not published one yet.
		*/
		function blockPackageName(plugin) {
			return typeof plugin.npm === "string" && plugin.npm !== "" ? plugin.npm : plugin.name;
		}
		/**
		* Names that count as one blocked plugin (#657).
		*
		* A linked checkout can be installed under a package name the catalog does
		* not use. The installed name comes first so a new block is stored as the
		* name Update all already filters on; the catalog name stays in the list so
		* a block made from either side still matches the other.
		*/
		function blockAliases(plugin, installedName) {
			const catalogName = blockPackageName(plugin);
			if (typeof installedName === "string" && installedName !== "" && installedName !== catalogName) return [installedName, catalogName];
			return [catalogName];
		}
		/**
		* Compact display for a count that can run into the tens of thousands
		* (npm downloads, star counts): "11.9k" instead of "11862". Reported —
		* the raw number made the card byline visibly cramped once downloads was
		* added alongside stars.
		*
		* Below 1000 the exact number is shown; a small count is exactly the case
		* where the precision matters and abbreviating it buys nothing.
		*/
		function formatCount(n) {
			if (!Number.isFinite(n) || n < 1e3) return String(n);
			const k = Math.round(n / 100) / 10;
			return `${Number.isInteger(k) ? k.toFixed(0) : k.toFixed(1)}k`;
		}
		/** Catalog row for an installed dependency — strict for local link:/file: specs. */
		function catalogEntryForInstalled(plugins, name, spec, repoIdentities = [], repoHints = []) {
			if (/^(?:link|file):/i.test(spec)) return findCatalogEntryForLocal(plugins, name, repoIdentities, repoHints) ?? void 0;
			return entryForDep(plugins, name, spec, repoIdentities, repoHints);
		}
		//#endregion
		//#region src/client/InstallToast.tsx
		/**
		* Post-reload confirmation via the official Toast primitive: shown once after
		* the refresh that follows a hot install or theme switch, so the user lands
		* back in their flow with visible proof.
		*/
		function InstallToast(props) {
			const t = props.t;
			const [mode] = (0, react.useState)(() => {
				const value = sessionStorage.getItem("dshm-toast-mode");
				sessionStorage.removeItem("dshm-toast-mode");
				return value;
			});
			const [names, setNames] = (0, react.useState)(() => {
				const value = readSession("dshm-toast");
				sessionStorage.removeItem("dshm-toast");
				return Array.isArray(value) ? value : [];
			});
			if (names.length === 0) return null;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
				text: names.join(", ") + " " + t(mode === "theme" ? "toastTheme" : "toastReady"),
				icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconSparkle16, { size: 14 }),
				onDone: () => setNames([])
			});
		}
		//#endregion
		//#region src/client/ErrorBoundary.tsx
		/**
		* The market's last line of defence: a crash renders a way out, not a blank.
		*
		* Every part of the market UI is inside one React tree. When that tree
		* throws during render or commit, React unmounts it — and what the user gets
		* is an empty settings panel, with the "export log" button gone along with
		* everything else. That is not hypothetical: it is #293, where browser page
		* translation replaced text nodes under React and the resulting
		* NotFoundError blanked the panel for months, and every request for a log
		* came back empty because there was no longer a button to press.
		*
		* #513 fixed that particular trigger. This exists because the next one will
		* be different, and the property worth having is not "translation is
		* handled" but "a crash is survivable and reportable".
		*
		* Deliberately not a retry loop. If the same render throws again the
		* boundary catches it again and the user is back here, which is honest —
		* an automatic remount would flicker between a broken UI and this panel
		* with no way to read either.
		*/
		/**
		* The last crash this boundary caught, for the exported log.
		*
		* Module-level rather than component state because the log export runs
		* outside this tree — and a crash the user has already dismissed is still
		* the most useful line in their report.
		*/
		let lastCrash = null;
		/** The crash to report in the exported log, or null when there was none. */
		function lastMarketCrash() {
			return lastCrash;
		}
		var MarketErrorBoundary = class extends react.Component {
			state = { error: null };
			static getDerivedStateFromError(error) {
				return { error };
			}
			componentDidCatch(error, info) {
				lastCrash = {
					message: error.message,
					stack: info.componentStack ?? error.stack ?? null,
					at: (/* @__PURE__ */ new Date()).toISOString()
				};
				console.error("[dsh-market] the market UI crashed and was replaced by its recovery panel", error, info.componentStack);
			}
			render() {
				const { error } = this.state;
				if (error === null) return this.props.children;
				const { text, actions } = this.props;
				return (0, react.createElement)("div", {
					"data-dsh-market-root": "",
					"data-dsh-market-crashed": "",
					translate: "no",
					className: "notranslate",
					style: {
						padding: "24px",
						display: "flex",
						flexDirection: "column",
						gap: "12px",
						alignItems: "flex-start"
					}
				}, [
					(0, react.createElement)("div", {
						key: "title",
						style: {
							fontSize: "14px",
							fontWeight: 600
						}
					}, text.title),
					(0, react.createElement)("div", {
						key: "hint",
						style: {
							fontSize: "12px",
							lineHeight: "19px",
							opacity: .8,
							whiteSpace: "pre-wrap"
						}
					}, text.hint),
					(0, react.createElement)("div", {
						key: "actions",
						style: {
							display: "flex",
							gap: "8px",
							flexWrap: "wrap"
						}
					}, [(0, react.createElement)("button", {
						key: "reload",
						type: "button",
						onClick: () => {
							this.setState({ error: null });
						}
					}, text.reload), actions]),
					(0, react.createElement)("details", {
						key: "details",
						style: {
							fontSize: "11px",
							opacity: .7
						}
					}, [(0, react.createElement)("summary", {
						key: "summary",
						style: { cursor: "pointer" }
					}, text.details), (0, react.createElement)("pre", {
						key: "body",
						style: {
							whiteSpace: "pre-wrap",
							wordBreak: "break-word",
							margin: "8px 0 0"
						}
					}, error.message)])
				]);
			}
		};
		//#endregion
		//#region src/client/optional-primitives.ts
		function optionalComponent(name) {
			let value;
			try {
				value = _deepseek_ai_dsh_client_ui_primitives[name];
			} catch {
				return null;
			}
			if (typeof value === "function") return value;
			if (value !== null && typeof value === "object" && "$$typeof" in value) return value;
			return null;
		}
		/**
		* `Tag` — the host's read-only chip, for facts with no status meaning
		* (capabilities, categories). Null on hosts older than 0.1.7-rc.2.
		*/
		const HostTag = optionalComponent("Tag");
		const HostSwitch = optionalComponent("Switch");
		const HostCheckbox = optionalComponent("Checkbox");
		//#endregion
		//#region \0dsh-css:src/client/Market.module.css.mjs
		const css = ".nUhMVa_root{min-width:0;height:100%;color:var(--dsw-alias-label-primary,#1f2328);flex-direction:column;display:flex;position:relative;container-type:inline-size}.nUhMVa_head{flex-direction:column;gap:8px;padding:0 4px 4px;display:flex}.nUhMVa_headTop{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:6px 16px;min-width:0;display:flex}.nUhMVa_headTop>.nUhMVa_titleRow>.nUhMVa_sub{max-width:100%}.nUhMVa_title{white-space:nowrap;color:var(--dsw-alias-label-primary,#1f2328);margin:0;font-size:15px;font-weight:600;line-height:22px}.nUhMVa_sub{min-width:0;color:var(--dsw-alias-label-tertiary,#8b93a1);flex:auto;margin:0;font-size:12px;line-height:18px}.nUhMVa_sidebarTip{color:var(--dsw-alias-label-secondary,#5c6570);flex-wrap:wrap;align-items:center;gap:6px 8px;margin:0;font-size:12px;line-height:18px;display:flex}.nUhMVa_submitLink{color:var(--dsw-alias-label-tertiary,#8b93a1);white-space:nowrap;font-size:12px;line-height:18px;text-decoration:none}.nUhMVa_submitLink:hover{color:var(--dsw-alias-brand-primary,#4f6ef7);text-decoration:underline}.nUhMVa_tabs{flex-wrap:wrap;align-items:center;gap:4px;padding:0 0 2px;display:flex;position:relative}.nUhMVa_tab{height:32px;font:inherit;color:var(--dsw-alias-label-secondary,#5c6570);border-radius:var(--dsw-radius-sm,#8px);cursor:pointer;white-space:nowrap;background:0 0;border:none;align-items:center;padding:0 10px;font-size:13px;line-height:20px;transition:background-color .12s,color .12s;display:inline-flex;position:relative}.nUhMVa_tab:hover:not(.nUhMVa_on){background:var(--dsw-alias-interactive-bg-hover,#2631480f);color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_tab.nUhMVa_on{color:var(--dsw-alias-label-primary,#1f2328);font-weight:600}.nUhMVa_tab.nUhMVa_on:after{content:\"\";background:var(--dsw-alias-label-primary,#1f2328);border-radius:1px;height:2px;position:absolute;bottom:3px;left:10px;right:10px}.nUhMVa_subTabs{flex-wrap:wrap;align-items:center;gap:4px;margin:0 0 2px;display:flex}.nUhMVa_banner{background:var(--dsw-alias-bg-layer-2,#fdf3e3);border:1px solid var(--dsw-alias-border-l2,#f3e3c3);border-radius:8px;align-items:center;gap:8px;margin:0;padding:8px 12px;font-size:12px;display:flex}.nUhMVa_bannerIcon{color:var(--dsw-alias-label-secondary,#6b7280);flex-shrink:0}.nUhMVa_bannerHint{color:var(--dsw-alias-label-tertiary,#8b93a1);cursor:help;display:inline-flex}.nUhMVa_body{overflow-anchor:none;flex:1;padding:8px 4px 64px;scroll-padding-bottom:64px;overflow-x:hidden;overflow-y:auto}.nUhMVa_stickyHead{z-index:5;background:var(--dsw-alias-bg-base,#fff);position:sticky;top:-1px}.nUhMVa_stickyHead:before{content:\"\";background:inherit;pointer-events:none;height:14px;position:absolute;bottom:100%;left:0;right:0}.nUhMVa_cats{margin:0 -4px 2px;padding:0 4px 4px}.nUhMVa_catsRow{align-items:flex-start;gap:6px;display:flex;position:relative}.nUhMVa_star{color:var(--dsw-alias-label-tertiary,#8b93a1);white-space:nowrap;flex:none;font-size:11px;line-height:18px}.nUhMVa_top{z-index:20;background:var(--dsw-alias-bg-layer-1,#fff);box-shadow:var(--dsw-shadow-lv1,0 4px 12px #1f232814);border-radius:99px;display:inline-flex;position:absolute;bottom:18px;right:18px}.nUhMVa_topBtn{border-radius:99px;width:38px;height:38px;padding:0}.nUhMVa_tag{border:.5px solid var(--dsw-alias-border-l3,#d9dde3);color:var(--dsw-alias-label-secondary,#5c6570);white-space:nowrap;border-radius:999px;flex-shrink:0;padding:1px 8px;font-size:11px;font-weight:500;line-height:17px}.nUhMVa_hostRequirement{border:.5px solid var(--dsw-alias-border-l3,#d9dde3);color:var(--dsw-alias-label-secondary,#5c6570);text-overflow:ellipsis;white-space:nowrap;border-radius:999px;min-width:0;max-width:18em;padding:1px 8px;font-size:11px;font-weight:500;line-height:17px;overflow:hidden}.nUhMVa_hostRequirementBad{border-color:var(--dsw-alias-state-error-primary,#dc2626);color:var(--dsw-alias-state-error-primary,#dc2626);background:#dc262614}.nUhMVa_hostFilterNote{color:var(--dsw-alias-label-tertiary,#8b93a1);margin-top:6px;font-size:12px;line-height:18px}.nUhMVa_okState{color:var(--dsw-alias-state-success-primary,#16a34a);white-space:nowrap;font-size:12px;font-weight:600}.nUhMVa_catsWrap{flex-wrap:wrap;flex:1;align-items:center;gap:6px;min-width:0;display:flex}.nUhMVa_catsCollapsed{max-height:62px;overflow:hidden}.nUhMVa_catsToggle.nUhMVa_catsToggle{height:26px;min-height:26px;color:var(--dsw-alias-label-secondary,#5c6570);flex:none;padding:0 6px}.nUhMVa_shots{-webkit-overflow-scrolling:touch;scrollbar-width:thin;gap:8px;margin:6px 0 8px;padding:2px 0 6px;display:flex;overflow-x:auto}.nUhMVa_shot{object-fit:cover;border-radius:var(--dsw-radius-lg,16px);border:.5px solid var(--dsw-alias-border-l3,#d9dde3);background:var(--dsw-alias-bg-layer-2,#f3f4f6);cursor:pointer;flex:none;width:220px;height:150px}.nUhMVa_cardShots{-webkit-overflow-scrolling:touch;scrollbar-width:thin;gap:6px;margin:0 0 6px;padding:0 0 2px;display:flex;overflow-x:auto}.nUhMVa_cardShot{object-fit:contain;border-radius:var(--dsw-radius-lg,16px);border:.5px solid var(--dsw-alias-border-l3,#d9dde3);background:var(--dsw-alias-bg-layer-2,#f3f4f6);cursor:pointer;flex:none;width:132px;height:88px;display:block}.nUhMVa_lightbox{z-index:10000;cursor:zoom-out;background:#000000d9;justify-content:center;align-items:center;display:flex;position:fixed;top:0;bottom:0;left:0;right:0}.nUhMVa_lightboxImg{object-fit:contain;cursor:default;border-radius:4px;max-width:90vw;max-height:85vh}.nUhMVa_lightboxClose{color:#fff;cursor:pointer;background:#ffffff1f;border:none;border-radius:99px;place-items:center;width:36px;height:36px;font-size:22px;line-height:1;display:grid;position:absolute;top:16px;right:16px}.nUhMVa_lightboxClose:hover{background:#ffffff38}.nUhMVa_lightboxNav{color:#fff;cursor:pointer;background:#ffffff1f;border:none;border-radius:99px;place-items:center;width:44px;height:44px;display:grid;position:absolute;top:50%;transform:translateY(-50%)}.nUhMVa_lightboxNav:hover{background:#ffffff38}.nUhMVa_lightboxPrev{left:16px}.nUhMVa_lightboxNext{right:16px}.nUhMVa_lightboxDots{gap:8px;display:flex;position:absolute;bottom:20px;left:50%;transform:translate(-50%)}.nUhMVa_lightboxDot{cursor:pointer;background:#fff6;border-radius:99px;width:7px;height:7px}.nUhMVa_lightboxDotOn{background:#fff}.nUhMVa_cmd{background:var(--dsw-alias-bg-layer-2,#f3f4f6);font-size:11px;line-height:18px;font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);word-break:break-all;border-radius:6px;margin:8px 0 0;padding:8px 10px}.nUhMVa_warnLine{color:var(--dsw-alias-state-warn-primary,#b45309);flex-wrap:wrap;align-items:center;gap:4px;margin:0;font-size:12px;font-weight:600;line-height:18px;display:flex}.nUhMVa_modalNote{color:var(--dsw-alias-label-tertiary,#8b93a1);align-items:center;gap:4px;margin:12px 0 0;font-size:12px;line-height:18px;display:flex}.nUhMVa_confirmBody{flex-direction:column;gap:12px;display:flex}.nUhMVa_confirmModal{width:min(560px,92vw);max-width:min(560px,92vw);max-height:100%}.nUhMVa_confirmContent{flex:auto;min-height:0;overflow:hidden}.nUhMVa_confirmContent>:first-child{flex-shrink:0}.nUhMVa_confirmContent>:last-child{overscroll-behavior:contain;flex:auto;min-height:0;margin-top:0;overflow-y:auto}.nUhMVa_confirmModal>:last-child{flex-shrink:0}.nUhMVa_confirmBody .nUhMVa_byline{flex-wrap:nowrap;margin-top:0}.nUhMVa_confirmBody .nUhMVa_owner{min-width:0}.nUhMVa_confirmBody .nUhMVa_shots{margin:0;padding:0}.nUhMVa_confirmBody .nUhMVa_modalNote{margin:0}.nUhMVa_confirmTags{flex-wrap:wrap;gap:6px;display:flex}.nUhMVa_confirmDesc{color:var(--dsw-alias-label-primary,#1f2328);white-space:pre-wrap;margin:0;font-size:13px;line-height:20px}.nUhMVa_confirmFold{border-top:1px solid var(--dsw-alias-border-l2,#e5e7eb);flex-direction:column;gap:8px;padding-top:12px;display:flex}.nUhMVa_confirmPanel{--fold-bg:#f7f8fa;--fold-border:#e7e8ea;--fold-ink:#1c1d1f;--fold-on-ink:#fff;background:var(--fold-bg);border:1px solid var(--fold-border);border-radius:8px}body[data-ds-dark-theme] .nUhMVa_confirmPanel{--fold-bg:var(--dsw-alias-bg-layer-3,#353638);--fold-border:var(--dsw-alias-border-l2,#ffffff1f);--fold-ink:var(--dsw-alias-label-primary,#f9fafb);--fold-on-ink:var(--dsw-alias-bg-layer-2,#2c2c2e)}.nUhMVa_confirmPanelRow{box-sizing:border-box;width:100%;min-height:40px;color:inherit;font:inherit;text-align:left;cursor:pointer;background:0 0;border:0;border-radius:8px;align-items:center;gap:8px;padding:0 12px;display:flex}.nUhMVa_confirmPanelRow:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,#4176e6);outline-offset:-2px}.nUhMVa_confirmPanelIcon{color:var(--fold-ink);flex:none;display:inline-flex}.nUhMVa_confirmTerminalIcon{color:var(--fold-ink);flex:none;display:block}.nUhMVa_confirmTerminalPrompt{stroke:var(--fold-on-ink);fill:none}.nUhMVa_confirmTerminalDot{fill:var(--fold-on-ink)}.nUhMVa_confirmPanelTitle{min-width:0;color:var(--fold-ink);flex:1 0 auto;font-size:13px;line-height:20px}.nUhMVa_confirmPanelRowStatic{cursor:default}.nUhMVa_confirmPanel[data-state=unchecked]{background:color-mix(in srgb, var(--fold-bg) 35%, transparent);border-style:dashed}.nUhMVa_confirmPanelMeta{min-width:0;color:var(--dsw-alias-label-secondary,#6b7280);text-align:right;flex:0 auto;font-size:12px;line-height:20px}.nUhMVa_confirmPanelChevron{color:var(--dsw-alias-label-tertiary,#8b93a1);flex:none}.nUhMVa_confirmPanelBody{flex-direction:column;gap:10px;padding:0 12px 10px 16px;display:flex}.nUhMVa_confirmCmd{align-items:center;gap:8px;display:flex}.nUhMVa_confirmPanel .nUhMVa_cmd{background:0 0;border-radius:0;flex:1;min-width:0;margin:0;padding:0;line-height:24px}.nUhMVa_confirmCopied{color:var(--dsw-alias-state-success-primary,#22c55e);white-space:nowrap;flex:none;font-size:12px;line-height:24px}.nUhMVa_confirmCopy{width:24px;height:24px;color:var(--fold-ink,#1c1d1f);cursor:pointer;background:0 0;border:0;border-radius:6px;flex:none;justify-content:center;align-items:center;padding:0;display:inline-flex}.nUhMVa_confirmCopy:hover{background:color-mix(in srgb, var(--fold-ink,#1c1d1f) 8%, transparent)}.nUhMVa_confirmCopy:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,#4176e6);outline-offset:1px}.nUhMVa_confirmPanel .nUhMVa_caps{gap:6px;padding:0}.nUhMVa_confirmPanel .nUhMVa_caps .nUhMVa_capChip{background:var(--fold-on-ink,#fff);border:1px solid var(--fold-border,#e7e8ea);color:var(--fold-ink,#1c1d1f);border-radius:999px;padding:2px 8px;font-size:12px;line-height:18px}.nUhMVa_confirmPanel .nUhMVa_caps .nUhMVa_capChip.nUhMVa_capChipUncommon{background:var(--fold-ink,#1c1d1f);border-color:var(--fold-ink,#1c1d1f);color:var(--fold-on-ink,#fff);font-weight:600}.nUhMVa_capGroups{grid-template-columns:auto minmax(0,1fr);align-items:baseline;gap:8px 12px;display:grid}.nUhMVa_capGroupLabel{color:var(--dsw-alias-label-secondary,#6b7280);white-space:nowrap;font-size:12px;line-height:22px}.nUhMVa_confirmPanel .nUhMVa_caps .nUhMVa_capMuted{border-color:var(--fold-border,#e7e8ea);color:var(--dsw-alias-label-secondary,#6b7280);padding:2px 8px;font-size:12px;line-height:18px}.nUhMVa_capAhead{flex-direction:column;gap:6px;display:flex}.nUhMVa_capAheadLabel{color:var(--dsw-alias-label-secondary,#6b7280);margin:0;font-size:12px;line-height:18px}.nUhMVa_capAheadRow{color:var(--dsw-alias-label-primary,#1f2328);align-items:flex-start;gap:8px;margin:0;font-size:13px;line-height:20px;display:flex}.nUhMVa_capAheadIcon{color:var(--dsw-alias-label-primary,#1f2328);flex:none;margin-top:2px}.nUhMVa_confirmPanel .nUhMVa_caps .nUhMVa_capAddress{color:var(--fold-ink,#1c1d1f);flex-basis:100%;margin:0 0 2px;font-size:13px;line-height:20px}.nUhMVa_capNote,.nUhMVa_confirmPanel .nUhMVa_capCaveat{color:var(--dsw-alias-label-secondary,#6b7280);margin:0;font-size:12px;line-height:18px}.nUhMVa_installCaution{background:color-mix(in srgb, var(--dsw-alias-state-warn-primary,#b45309) 12%, transparent);border-radius:8px;padding:12px 13px}.nUhMVa_installCautionLabel{color:var(--dsw-alias-label-secondary,#6b7280);margin:0 0 8px;font-size:12px;line-height:18px}.nUhMVa_installCautionHead{color:var(--dsw-alias-label-primary,#1f2328);align-items:center;gap:6px;margin:0;font-size:13px;font-weight:600;line-height:20px;display:flex}.nUhMVa_installCautionMark{flex:none;display:block}.nUhMVa_installCautionBody{color:var(--dsw-alias-label-primary,#1f2328);margin:6px 0 0;font-size:13px;line-height:20px}.nUhMVa_installCautionFoot{color:var(--dsw-alias-label-primary,#1f2328);align-items:baseline;gap:12px;margin:0;font-size:13px;line-height:20px;display:flex}.nUhMVa_installCautionLink{white-space:nowrap;color:var(--dsw-alias-link,#3b82f6);flex:none;margin-left:auto;font-size:13px;font-weight:600;line-height:20px;text-decoration:none}.nUhMVa_installCautionLink:hover{text-decoration:underline}.nUhMVa_confirmFineprint{color:var(--dsw-alias-label-secondary,#6b7280);margin:0;font-size:12px;line-height:18px}.nUhMVa_grid{grid-template-columns:repeat(2,minmax(0,1fr));align-items:start;gap:10px;display:grid}.nUhMVa_recentBlock{margin:2px 0 4px;padding:0 0 8px}.nUhMVa_recentRow{-webkit-overflow-scrolling:touch;scrollbar-width:thin;scrollbar-color:var(--dsw-alias-border-l3,#d9dde3) transparent;align-items:stretch;gap:8px;margin-bottom:0;padding-bottom:4px;display:flex;overflow-x:auto}.nUhMVa_recentRow::-webkit-scrollbar{height:6px}.nUhMVa_recentRow::-webkit-scrollbar-thumb{background:var(--dsw-alias-border-l3,#d9dde3);border-radius:99px}.nUhMVa_recentRow::-webkit-scrollbar-track{background:0 0}.nUhMVa_recentRow>*{box-sizing:border-box;flex:none;width:min(320px,30.7692% - 7.38462px);min-width:220px}.nUhMVa_recentRow.nUhMVa_recentCollapsed{visibility:hidden;max-height:0;margin-bottom:0;padding-bottom:0;overflow:hidden}.nUhMVa_recentTile{box-sizing:border-box;background:var(--dsw-alias-settings-card-fill,var(--dsw-alias-bg-layer-1,#fff));border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));border-radius:var(--dsw-radius-lg,16px);flex-direction:column;justify-content:space-between;gap:4px;height:80px;padding:8px 12px;transition:background-image .16s cubic-bezier(.16,1,.3,1);display:flex;overflow:hidden}.nUhMVa_recentTile .nUhMVa_installBtn.nUhMVa_installBtn{height:24px;min-height:24px;padding:0 8px}.nUhMVa_recentAv.nUhMVa_recentAv{flex-shrink:0;width:24px;height:24px;font-size:11px}.nUhMVa_recentTitle{align-items:center;gap:8px;min-width:0;display:flex}.nUhMVa_recentTitle>:last-child{flex-shrink:0}.nUhMVa_recentName{flex:1;min-width:0}.nUhMVa_recentTitle .nUhMVa_nm{font-size:14px;line-height:20px}.nUhMVa_recentBottom{align-items:flex-end;gap:8px;min-width:0;display:flex}.nUhMVa_recentBottom>:last-child{flex-shrink:0;margin-left:auto}.nUhMVa_recentBottom>:not(:last-child){flex:1;min-width:0}.nUhMVa_recentDesc{color:var(--dsw-alias-label-tertiary,#8b93a1);-webkit-line-clamp:2;-webkit-box-orient:vertical;margin:0;font-size:12px;line-height:16px;display:-webkit-box;overflow:hidden}.nUhMVa_recentBottom .nUhMVa_cardMore{padding:0}.nUhMVa_recentHead{justify-content:space-between;align-items:center;gap:8px;margin:10px 0 8px;padding:0 4px;display:flex}.nUhMVa_recentHead .nUhMVa_favoritesSectionHead{margin:0;padding:0;font-weight:600}.nUhMVa_recentToggle{font:inherit;color:inherit;cursor:pointer;background:0 0;border:0;align-items:center;gap:4px;margin:0;padding:0;display:inline-flex}.nUhMVa_recentToggle:hover{color:var(--dsw-alias-label-secondary,#6b7280)}.nUhMVa_recentHide.nUhMVa_recentHide{height:26px;min-height:26px;color:var(--dsw-alias-label-secondary,#6b7280);padding:0 6px}.nUhMVa_recentShow{font:inherit;color:var(--dsw-alias-label-secondary,#8b93a1);cursor:pointer;background:0 0;border:0;align-items:center;gap:4px;margin:0 0 8px;padding:0 4px;font-size:12px;line-height:18px;display:inline-flex}.nUhMVa_recentShow:hover{color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_masonry{align-items:flex-start;gap:10px;display:flex}.nUhMVa_masonryCol{flex-direction:column;flex:1;gap:10px;min-width:0;display:flex}.nUhMVa_masonry>.nUhMVa_masonryCol>*{align-self:stretch;min-width:0}@media (max-width:680px){.nUhMVa_masonry{flex-direction:column}.nUhMVa_masonryCol{width:100%}.nUhMVa_grid{grid-template-columns:minmax(0,1fr)}}.nUhMVa_swatches{border:1px solid var(--dsw-alias-border-l2,#e5e7eb);border-radius:8px;gap:0;height:34px;display:flex;overflow:hidden}.nUhMVa_themesGrid{margin-bottom:12px}.nUhMVa_swatches i{flex:1}.nUhMVa_themeToolbar{grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:8px;padding:0 4px 12px;display:grid}.nUhMVa_themeSearch{box-sizing:border-box;width:100%;min-width:0}.nUhMVa_themeToolbarActions{justify-content:flex-end;align-items:center;gap:8px;display:flex}.nUhMVa_themeFullscreenBtn.nUhMVa_themeFullscreenBtn{width:28px;min-width:28px;padding:0}.nUhMVa_themeResultBar{min-height:24px;color:var(--dsw-alias-label-tertiary,#8b93a1);align-items:center;padding:0 4px 8px;font-size:12px;line-height:18px;display:flex}.nUhMVa_favoritesSectionHead{color:var(--dsw-alias-label-primary,#1f2328);margin:16px 0 8px;padding:0 4px;font-size:14px;font-weight:500;line-height:22px}.nUhMVa_favoritesSectionHead:first-of-type{margin-top:0}.nUhMVa_brokenPluginNotice{flex-direction:column;gap:8px;margin:0 0 8px;display:flex}.nUhMVa_brokenPluginItem{border:1px solid var(--dsw-alias-state-warn-tertiary,#b4530933);background:var(--dsw-alias-state-warn-tertiary,#b453090f);color:var(--dsw-alias-state-warn-primary,#b45309);border-radius:8px;flex-wrap:wrap;justify-content:space-between;align-items:flex-start;gap:10px;padding:8px 10px;font-size:12px;line-height:18px;display:flex}.nUhMVa_brokenPluginText{flex-direction:column;gap:2px;min-width:0;display:flex}.nUhMVa_favoritesStaleBar{border:1px solid var(--dsw-alias-state-warn-tertiary,#b4530933);background:var(--dsw-alias-state-warn-tertiary,#b453090f);color:var(--dsw-alias-state-warn-primary,#b45309);border-radius:8px;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px;margin:0 0 8px;padding:8px 10px;font-size:12px;line-height:18px;display:flex}.nUhMVa_favoritesStaleOnly{flex-direction:column;align-items:flex-start;gap:10px;display:flex}.nUhMVa_themeGallery{grid-template-columns:repeat(4,minmax(0,1fr));align-items:stretch;gap:10px;display:grid}.nUhMVa_themeCard{border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));border-radius:var(--dsw-radius-lg,16px);background:var(--dsw-alias-bg-layer-1,#fff);flex-direction:column;min-width:0;transition:border-color .16s cubic-bezier(.16,1,.3,1),box-shadow .16s cubic-bezier(.16,1,.3,1),transform .16s cubic-bezier(.16,1,.3,1);display:flex;overflow:hidden}.nUhMVa_themeCard:hover{border-color:var(--dsw-alias-label-dimmed,#c8ccd4);box-shadow:var(--dsw-shadow-lv1,0 4px 12px #1f232814);transform:translateY(-1px)}.nUhMVa_themeCover{aspect-ratio:16/10;border:0;border-bottom:.5px solid var(--dsw-alias-border-l3,#d9dde3);background:var(--dsw-alias-bg-layer-2,#f3f4f6);width:100%;color:var(--dsw-alias-label-secondary,#6b7280);cursor:zoom-in;border-radius:0;padding:0;display:block;position:relative;overflow:hidden}.nUhMVa_themeCover img{object-fit:contain;background:var(--dsw-alias-bg-layer-2,#f3f4f6);width:100%;height:100%;transition:transform .18s cubic-bezier(.16,1,.3,1);display:block}.nUhMVa_themeCover:hover img{transform:scale(1.012)}.nUhMVa_themeCover:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,#4f6ef7);outline-offset:-3px}.nUhMVa_themeCoverEmpty{cursor:default;color:var(--dsw-alias-label-tertiary,#8b93a1);background:var(--dsw-alias-bg-module-platform,#f4f5f7);border-radius:var(--dsw-radius-lg,16px) 0 0 0;flex-direction:column;justify-content:center;align-items:center;gap:8px;font-size:12px;line-height:18px;display:flex}.nUhMVa_themePreviewAction,.nUhMVa_themePreviewCount{color:#fff;background:#14181fc7;border:1px solid #ffffff57;border-radius:4px;align-items:center;height:24px;padding:0 8px;font-size:11px;line-height:16px;display:inline-flex;position:absolute;bottom:8px}.nUhMVa_themePreviewAction{gap:4px;right:8px}.nUhMVa_themePreviewCount{left:8px}.nUhMVa_themeCardBody{flex-direction:column;flex:1;gap:8px;padding:14px;display:flex}.nUhMVa_themeCardHead{align-items:flex-start;gap:8px;min-width:0;display:flex}.nUhMVa_themeIdentity{flex:1;min-width:0}.nUhMVa_themeStatus,.nUhMVa_themeStatusMuted{white-space:nowrap;border-radius:4px;flex:none;align-items:center;min-height:22px;padding:0 8px;font-size:11px;font-weight:600;display:inline-flex}.nUhMVa_themeStatus{background:var(--dsw-alias-state-success-tertiary,#16a34a1a);color:var(--dsw-alias-state-success-primary,#15803d)}.nUhMVa_themeStatusMuted{background:var(--dsw-alias-bg-layer-2,#f3f4f6);color:var(--dsw-alias-label-secondary,#6b7280)}.nUhMVa_themeDescription{min-height:36px;color:var(--dsw-alias-label-tertiary,#8b93a1);-webkit-line-clamp:3;-webkit-box-orient:vertical;margin:0;font-size:12px;line-height:18px;display:-webkit-box;overflow:hidden}.nUhMVa_themeCardFooter{justify-content:space-between;align-items:center;gap:8px;margin-top:auto;padding-top:4px;display:flex}.nUhMVa_themeLifecycle{min-width:0;color:var(--dsw-alias-label-tertiary,#8b93a1);text-overflow:ellipsis;white-space:nowrap;font-size:11px;line-height:18px;overflow:hidden}.nUhMVa_themeActions{flex-wrap:wrap;justify-content:flex-end;align-items:center;gap:8px;margin-left:auto;display:flex}@container (width<=900px){.nUhMVa_themeGallery{grid-template-columns:repeat(3,minmax(0,1fr))}}@container (width<=680px){.nUhMVa_themeGallery{grid-template-columns:repeat(2,minmax(0,1fr))}}@container (width<=460px){.nUhMVa_themeGallery{grid-template-columns:minmax(0,1fr)}}.nUhMVa_exportLogBtn{white-space:nowrap;flex-shrink:0}@container (width<=560px){.nUhMVa_headTop{flex-direction:column;align-items:stretch}.nUhMVa_headTop>.nUhMVa_titleRow{margin-left:0}}@container (width<=420px){.nUhMVa_exportLogBtn{align-self:center}.nUhMVa_themeToolbar{grid-template-columns:minmax(0,1fr)}.nUhMVa_themeCardHead{flex-wrap:wrap}.nUhMVa_themeStatus,.nUhMVa_themeStatusMuted{order:3}}@container (width<=280px){.nUhMVa_themeCardFooter{flex-direction:column;align-items:flex-start}.nUhMVa_themeActions{justify-content:flex-start;width:100%;margin-left:0}}@media (max-width:560px){[role=dialog]:has([data-dsh-market-root])>nav{display:none}[role=dialog]:has([data-dsh-market-root])>div{flex:100%;width:100%;min-width:0}}.nUhMVa_panelHost{box-sizing:border-box;height:100%;min-height:0;padding:calc(28px + var(--dsh-frame-top-clearance,0px)) 0 0;flex-direction:column;display:flex}.nUhMVa_panelHost>.nUhMVa_root{flex:1;width:100%;min-width:0;min-height:0;container-type:normal}.nUhMVa_panelHost .nUhMVa_head,.nUhMVa_panelHost .nUhMVa_body{padding-left:max(max(16px,min(4vw,48px)),50% - 480px);padding-right:max(max(16px,min(4vw,48px)),50% - 480px);container-type:inline-size}[data-dsh-market-plugins-tab=true]{--dshm-host-sticky-top:0px;--dshm-plugins-head-height:0px}[data-dsh-market-plugins-tab=true]:not([data-dsh-market-fullscreen=true]){--dshm-empty-view-height:100vh;height:auto}[data-dsh-market-plugins-tab=true]:not([data-dsh-market-fullscreen=true]) .nUhMVa_body{min-height:calc(100vh - var(--dshm-host-sticky-top,0px) - var(--dshm-plugins-head-height,0px));flex-direction:column;flex:none;display:flex;overflow:visible}[data-dsh-market-plugins-tab=true]:not([data-dsh-market-fullscreen=true]) .nUhMVa_body>.nUhMVa_empty{box-sizing:border-box;width:100%;max-width:none;max-height:var(--dshm-empty-view-height,100vh);flex-direction:column;flex:auto;justify-content:center;align-items:center;margin:0;padding:32px;display:flex}[data-dsh-market-plugins-tab=true]:not([data-dsh-market-fullscreen=true]) .nUhMVa_top{position:fixed}[data-dsh-market-plugins-tab=true]:not([data-dsh-market-fullscreen=true]) .nUhMVa_stickyHead{display:contents}[data-dsh-market-plugins-tab=true]:not([data-dsh-market-fullscreen=true]) .nUhMVa_head{z-index:6;top:var(--dshm-host-sticky-top,0px);background:var(--dsw-alias-bg-base,#fff);margin:0 -4px;padding:4px 4px 6px;position:sticky}[data-dsh-market-plugins-tab=true]:not([data-dsh-market-fullscreen=true]) .nUhMVa_cats{z-index:5;top:calc(var(--dshm-host-sticky-top,0px) + var(--dshm-plugins-head-height,0px));background:var(--dsw-alias-bg-base,#fff);position:sticky}[role=dialog]:has([data-dsh-market-fullscreen=true]){border-radius:0;width:100vw;max-width:none;height:100vh;max-height:none;position:fixed;top:0;bottom:0;left:0;right:0}[data-dsh-market-plugins-tab=true][data-dsh-market-fullscreen=true]{z-index:60;background:var(--dsw-alias-bg-layer-1,#fff);position:fixed;top:0;bottom:0;left:0;right:0;height:100vh!important}@media (prefers-reduced-motion:reduce){.nUhMVa_themeCard,.nUhMVa_themeCover img{transition:none}.nUhMVa_themeCard:hover{transform:none}}.nUhMVa_card{background:var(--dsw-alias-settings-card-fill,var(--dsw-alias-bg-layer-1,#fff));border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));border-radius:var(--dsw-radius-xl,20px);flex-direction:column;align-self:start;gap:10px;min-width:0;padding:12px 14px;transition:background-image .16s cubic-bezier(.16,1,.3,1);display:flex}@media (hover:hover){.nUhMVa_card:hover,.nUhMVa_recentTile:hover{background-image:linear-gradient(var(--dsw-alias-interactive-bg-hover,#2631480f),var(--dsw-alias-interactive-bg-hover,#2631480f))}.nUhMVa_installBtn:hover:not(:disabled){background:var(--dsw-alias-button-primary-fill,#0f1115);color:var(--dsw-alias-label-primary-foreground,#fff);border-color:#0000}}.nUhMVa_row1{align-items:flex-start;gap:10px;min-width:0;display:flex}.nUhMVa_cardAction{flex-shrink:0;align-items:center;display:inline-flex}.nUhMVa_installBtn.nUhMVa_installBtn{min-width:64px}.nUhMVa_av{width:16px;height:16px;color:var(--dsw-alias-label-primary,#1f2328);object-fit:cover;background:var(--dsw-alias-bg-layer-2,#f3f4f6);border-radius:50%;flex-shrink:0;place-items:center;font-size:9px;font-weight:700;display:grid}.nUhMVa_nm{text-overflow:ellipsis;white-space:nowrap;font-size:14px;font-weight:500;line-height:20px;overflow:hidden}.nUhMVa_nmLink{color:inherit;text-decoration:none;display:block}.nUhMVa_nmLink:hover{color:var(--dsw-alias-brand-primary,#4f6ef7);text-decoration:underline}.nUhMVa_repoMark{color:var(--dsw-alias-label-secondary,#6b7280);vertical-align:-1px;flex-shrink:0;margin-left:5px;display:inline-block}.nUhMVa_nmLink:hover .nUhMVa_repoMark{color:var(--dsw-alias-brand-primary,#4f6ef7)}.nUhMVa_byline{flex-wrap:wrap;align-items:center;gap:6px;min-width:0;margin-top:2px;display:flex}.nUhMVa_meta{color:var(--dsw-alias-label-secondary,#9ca3af);margin-top:2px;font-size:11px}.nUhMVa_metaInline{color:var(--dsw-alias-label-secondary,#9ca3af);font-size:11px}.nUhMVa_owner{color:var(--dsw-alias-label-secondary,#5c6570);text-overflow:ellipsis;white-space:nowrap;flex:0 auto;min-width:44px;font-size:11px;line-height:18px;overflow:hidden}.nUhMVa_desc{color:var(--dsw-alias-label-tertiary,#8b93a1);margin:0;font-size:12px;line-height:18px}.nUhMVa_descClamp{-webkit-line-clamp:5;-webkit-box-orient:vertical;display:-webkit-box;overflow:hidden}.nUhMVa_descClamp3{-webkit-line-clamp:3;-webkit-box-orient:vertical;display:-webkit-box;overflow:hidden}.nUhMVa_descToggle{width:20px;height:16px;color:var(--dsw-alias-label-tertiary,#8b93a1);cursor:pointer;background:0 0;border:none;justify-content:center;align-items:center;margin-top:2px;padding:0;display:flex}.nUhMVa_descToggle:hover{color:var(--dsw-alias-brand-primary,#4f6ef7)}.nUhMVa_foot{flex-wrap:nowrap;align-items:flex-end;gap:8px;display:flex}.nUhMVa_foot .nUhMVa_metaInline,.nUhMVa_foot .nUhMVa_src{white-space:nowrap}.nUhMVa_footTags{flex-wrap:wrap;flex:1 1 0;align-items:center;gap:8px;min-width:0;display:flex}.nUhMVa_grow{flex:1}.nUhMVa_titleRow{flex-wrap:wrap;align-items:center;gap:8px 10px;display:flex}.nUhMVa_titleActions{flex-wrap:wrap;flex:0 auto;justify-content:flex-end;align-items:center;gap:4px 10px;min-width:0;margin-left:auto;display:flex}.nUhMVa_titleActions:empty{display:none}.nUhMVa_titleActions>*{white-space:nowrap;flex-shrink:0}.nUhMVa_version{color:var(--dsw-alias-label-tertiary,#8b93a1);font-variant-numeric:tabular-nums;flex-shrink:0;font-size:12px;line-height:20px}.nUhMVa_repoLink{color:var(--dsw-alias-label-tertiary,#8b93a1);flex-shrink:0;font-size:12px;line-height:20px;text-decoration:none}.nUhMVa_repoLink:hover{color:var(--dsw-alias-brand-primary,#4f6ef7)}.nUhMVa_noteRow{flex-wrap:wrap;align-items:baseline;gap:6px;min-width:0;display:flex}.nUhMVa_desc.nUhMVa_noteRow,.nUhMVa_desc.nUhMVa_noteRow+.nUhMVa_noteRow,.nUhMVa_noteEdit+.nUhMVa_noteRow{margin-top:6px}.nUhMVa_noteMine{color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_noteToggle{font:inherit;color:var(--dsw-alias-label-tertiary,#8b93a1);cursor:pointer;white-space:nowrap;background:0 0;border:none;flex-shrink:0;padding:0;font-size:11px;line-height:16px}.nUhMVa_noteToggle:hover{color:var(--dsw-alias-brand-primary,#4f6ef7);text-decoration:underline}.nUhMVa_noteEdit{flex-direction:column;gap:6px;min-width:0;margin-top:6px;display:flex}.nUhMVa_noteInput{box-sizing:border-box;width:100%;min-width:0;max-width:100%;display:flex}.nUhMVa_noteInput input{box-sizing:border-box;flex:auto;width:100%;min-width:0}.nUhMVa_noteEditBar{justify-content:flex-end;align-items:center;gap:6px;display:flex}.nUhMVa_noteCount{font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-tertiary,#8b93a1);margin-right:auto;font-size:11px;line-height:16px}.nUhMVa_descTight{min-height:0}.nUhMVa_src{color:var(--dsw-alias-label-secondary,#9ca3af);font-size:11px;text-decoration:none}.nUhMVa_src:hover{color:var(--dsw-alias-brand-primary,#4f6ef7)}.nUhMVa_dot{vertical-align:2px;margin-left:5px}.nUhMVa_act{flex-wrap:wrap;align-items:center;gap:6px;margin-top:6px;font-size:11px;display:flex}.nUhMVa_actLive{color:var(--dsw-alias-state-success-primary,#16a34a);align-items:center;gap:4px;font-weight:600;display:inline-flex}.nUhMVa_actWarn{color:var(--dsw-alias-state-warn-primary,#b45309);align-items:center;gap:4px;font-weight:600;display:inline-flex}.nUhMVa_actBroken{color:var(--dsw-alias-state-error-primary,#dc2626);align-items:center;gap:4px;font-weight:600;display:inline-flex}.nUhMVa_actWhy{color:var(--dsw-alias-label-secondary,#6b7280);margin-top:2px}.nUhMVa_loading{color:var(--dsw-alias-label-secondary,#9ca3af);flex-direction:column;align-items:center;gap:12px;padding:48px;font-size:13px;display:flex}.nUhMVa_spin{color:var(--dsw-alias-brand-primary,#4f6ef7);flex-shrink:0;animation:.8s linear infinite nUhMVa_sp;display:inline-flex}.nUhMVa_logoMark{color:var(--dsw-alias-brand-primary,#4f6ef7);flex-shrink:0;display:inline-flex}.nUhMVa_logoCell,.nUhMVa_logoPlug,.nUhMVa_logoPlugAmbient{--dshm-cycle:2.8s}.nUhMVa_logoMark .nUhMVa_logoCell,.nUhMVa_logoMark .nUhMVa_logoPlug{--dshm-cycle:2s}.nUhMVa_logoCell{--dshm-wave:0;animation:nUhMVa_dshmMarkWave var(--dshm-cycle) cubic-bezier(.4,0,.2,1) infinite;animation-delay:calc(var(--dshm-wave) * .11s)}.nUhMVa_logoPlug,.nUhMVa_logoPlugAmbient{transform-box:fill-box;transform-origin:50%;animation:nUhMVa_dshmMarkPlug var(--dshm-cycle) cubic-bezier(.4,0,.2,1) infinite}@keyframes nUhMVa_dshmMarkWave{0%,to{opacity:1}6%{opacity:.5}16%{opacity:1}}@keyframes nUhMVa_dshmMarkPlug{0%,8%{transform:rotate(9deg)}22%{transform:translate(-1.35px,1.34px)rotate(0)}30%,62%{transform:translate(-1.28px,1.27px)rotate(0)}76%,to{transform:rotate(9deg)}}@media (prefers-reduced-motion:reduce){.nUhMVa_logoCell,.nUhMVa_logoPlugAmbient{animation:none}.nUhMVa_logoPlug,.nUhMVa_spin{animation:1.5s ease-in-out infinite nUhMVa_dshmPlugFade}}@keyframes nUhMVa_dshmPlugFade{0%,to{opacity:1}50%{opacity:.35}}@keyframes nUhMVa_sp{to{transform:rotate(360deg)}}.nUhMVa_progress{background:var(--dsw-alias-bg-layer-2,#f3f4f6);border:1px solid var(--dsw-alias-border-l2,#e5e7eb);color:var(--dsw-alias-label-secondary,#6b7280);border-radius:8px;flex-wrap:wrap;align-items:center;gap:9px;margin:0;padding:8px 12px;font-size:12px;display:flex}.nUhMVa_bar{background:var(--dsw-alias-border-l1,#e5e7eb);border-radius:99px;width:100%;height:4px;overflow:hidden}.nUhMVa_barFill{background:var(--dsw-alias-brand-primary,#4f6ef7);border-radius:99px;height:100%;transition:width .6s}.nUhMVa_barWave{width:30%;animation:1.2s ease-in-out infinite nUhMVa_dshmSlide}@keyframes nUhMVa_dshmSlide{0%{margin-left:-30%}to{margin-left:100%}}.nUhMVa_irow .nUhMVa_progress{margin-top:8px}.nUhMVa_progress code{font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);text-overflow:ellipsis;white-space:nowrap;font-size:11px;overflow:hidden}.nUhMVa_empty{color:var(--dsw-alias-label-secondary,#5c6570);text-align:center;max-width:520px;margin:0 auto;padding:56px 32px 40px;font-size:13px;line-height:20px}.nUhMVa_err{color:var(--dsw-alias-state-error-primary,#dc2626);white-space:pre-wrap;word-break:break-all;margin:8px 0;font-size:12px}.nUhMVa_cardBlocked{border-color:var(--dsw-alias-state-error-primary,#dc2626)}.nUhMVa_conflictHead{align-items:flex-start;gap:8px;display:flex}.nUhMVa_conflictIcon{color:var(--dsw-alias-state-error-primary,#dc2626);flex-shrink:0;margin-top:1px}.nUhMVa_conflictTitle{color:var(--dsw-alias-state-error-primary,#dc2626);font-size:13px;font-weight:600;line-height:18px}.nUhMVa_conflictBody{margin:0;font-size:12px;line-height:19px}.nUhMVa_roster{background:var(--dsw-alias-border-l2,#e5e7eb);border:1px solid var(--dsw-alias-border-l2,#e5e7eb);border-radius:8px;flex-direction:column;gap:1px;display:flex;overflow:hidden}.nUhMVa_rosterRow{background:var(--dsw-alias-bg-layer-1,#fff);align-items:center;gap:8px;padding:7px 10px;display:flex}.nUhMVa_rosterMain{flex-direction:column;min-width:0;display:flex}.nUhMVa_rosterName{text-overflow:ellipsis;white-space:nowrap;min-width:0;font-size:12px;font-weight:600;overflow:hidden}.nUhMVa_rosterAuthor{color:var(--dsw-alias-label-secondary,#9ca3af);text-overflow:ellipsis;white-space:nowrap;font-size:10.5px;overflow:hidden}.nUhMVa_rosterTag{border-radius:4px;flex-shrink:0;margin-left:auto;padding:1px 6px;font-size:10.5px;font-weight:600}.nUhMVa_rosterTagKeep{color:var(--dsw-alias-state-success-primary,#16a34a);background:#16a34a1f}.nUhMVa_rosterTagDrop{color:var(--dsw-alias-state-error-primary,#dc2626);background:#dc26261f}.nUhMVa_rosterRowOut .nUhMVa_rosterName{text-decoration:line-through}.nUhMVa_rosterRowOut{opacity:.62}.nUhMVa_rosterSplit{background:var(--dsw-alias-border-l2,#e5e7eb);height:1px}.nUhMVa_reassure{color:var(--dsw-alias-label-secondary,#6b7280);align-items:center;gap:5px;margin:0;font-size:11.5px;line-height:17px;display:flex}.nUhMVa_reassureOk{color:var(--dsw-alias-state-success-primary,#16a34a);flex-shrink:0}.nUhMVa_conflictWhy{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:11px;line-height:17px;font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);overflow-wrap:anywhere;margin-top:2px}.nUhMVa_conflictWhyText{margin-top:5px;font-family:-apple-system,BlinkMacSystemFont,PingFang SC,sans-serif}.nUhMVa_choices{flex-direction:column;gap:7px;display:flex}.nUhMVa_choice{text-align:left;font:inherit;cursor:pointer;background:var(--dsw-alias-bg-layer-1,#fff);border:1px solid var(--dsw-alias-border-l3,#d9dde3);border-radius:9px;align-items:flex-start;gap:9px;padding:9px 11px;display:flex}.nUhMVa_choice:has(input:disabled){cursor:default;opacity:.6}.nUhMVa_choiceOn{border-color:var(--dsw-alias-brand-primary,#4f6ef7);background:var(--dsw-alias-bg-layer-2,#f5f7ff)}.nUhMVa_choiceRadio{width:13px;height:13px;accent-color:var(--dsw-alias-brand-primary,#4f6ef7);flex-shrink:0;margin:2px 0 0}.nUhMVa_choiceMain{flex-direction:column;gap:3px;min-width:0;display:flex}.nUhMVa_choiceTitle{font-size:12px;font-weight:600;line-height:17px}.nUhMVa_choiceNote{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:11px;line-height:16px}.nUhMVa_choiceSafe{color:var(--dsw-alias-state-success-primary,#16a34a)}.nUhMVa_stateTag{white-space:nowrap;background:var(--dsw-alias-bg-layer-2,#f3f4f6);min-height:20px;color:var(--dsw-alias-label-secondary,#6b7280);border-radius:5px;flex-shrink:0;align-items:center;gap:5px;padding:1px 7px;font-size:11px;line-height:16px;display:inline-flex}.nUhMVa_stateTag[data-on=true]{color:var(--dsw-alias-state-success-primary,#16a34a);background:color-mix(in srgb, var(--dsw-alias-state-success-primary,#16a34a) 10%, transparent)}.nUhMVa_stateDot{background:var(--dsw-alias-label-tertiary,#8b93a1);border-radius:999px;flex:none;width:6px;height:6px}.nUhMVa_stateDot[data-on=true]{background:var(--dsw-alias-state-success-primary,#16a34a)}.nUhMVa_metaTag{text-overflow:ellipsis;white-space:nowrap;background:var(--dsw-alias-bg-layer-2,#f3f4f6);min-width:0;max-width:100%;min-height:20px;color:var(--dsw-alias-label-tertiary,#8b93a1);border-radius:5px;flex-shrink:1;padding:1px 7px;font-size:11px;line-height:18px;display:inline-block;overflow:hidden}.nUhMVa_metaTagOk{color:var(--dsw-alias-state-success-primary,#16a34a);background:color-mix(in srgb, var(--dsw-alias-state-success-primary,#16a34a) 10%, transparent)}.nUhMVa_irow{transition:background-image .16s cubic-bezier(.16,1,.3,1)}.nUhMVa_irow:hover{background-image:linear-gradient(var(--dsw-alias-interactive-bg-hover,#2631480f),var(--dsw-alias-interactive-bg-hover,#2631480f))}.nUhMVa_irowHead{align-items:flex-start;gap:8px;min-width:0;display:flex}.nUhMVa_irowHead .nUhMVa_irowName{flex:1 1 0;min-width:0}.nUhMVa_irowMenu{flex-shrink:0;margin-top:-4px;margin-left:auto;margin-right:-6px}.nUhMVa_irowMeta{color:var(--dsw-alias-label-secondary,#6b7280);margin-top:2px;font-size:12px;line-height:18px}.nUhMVa_irowPath{align-items:center;gap:6px;min-width:0;margin-top:6px;display:flex}.nUhMVa_irowPath .nUhMVa_spec{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.nUhMVa_irowPathIcon,.nUhMVa_irowStatusIcon{color:var(--dsw-alias-label-tertiary,#8b93a1);flex-shrink:0;display:inline-flex}.nUhMVa_irowPathCopy{flex-shrink:0;align-items:center;gap:4px;margin-left:auto;display:inline-flex}.nUhMVa_irowPath .nUhMVa_confirmCopy{width:20px;height:20px;color:var(--dsw-alias-label-tertiary,#8b93a1)}.nUhMVa_irowPath .nUhMVa_confirmCopy:hover{color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_irowPath .nUhMVa_confirmCopied{color:var(--dsw-alias-label-secondary,#6b7280);order:1;font-size:11px}.nUhMVa_irowDesc{flex:100%;min-width:0}.nUhMVa_irowStatus{flex-wrap:wrap;align-items:center;gap:6px;min-width:0;margin-top:8px;font-size:12px;line-height:18px;display:flex}.nUhMVa_irowStatus+.nUhMVa_irowStatus{margin-top:4px}.nUhMVa_irowStatusPart{align-items:baseline;gap:6px;display:inline-flex}.nUhMVa_irowStatus .nUhMVa_notesLink{margin:0;display:inline}.nUhMVa_irowStatus .nUhMVa_metaInline{font-size:12px}.nUhMVa_irowStatusAction{margin-left:auto;display:inline-flex}.nUhMVa_irowStatusAction .nUhMVa_noteToggle{color:var(--dsw-alias-label-secondary,#6b7280);font-size:12px;line-height:18px}.nUhMVa_irowStatusAction .nUhMVa_noteToggle:hover{color:var(--dsw-alias-label-primary,#1f2328);text-decoration:none}.nUhMVa_descMore{cursor:pointer;font:inherit;color:var(--dsw-alias-label-secondary,#6b7280);background:0 0;border:none;align-items:center;gap:2px;margin-top:4px;padding:0;font-size:12px;line-height:18px;display:inline-flex}.nUhMVa_descMore:hover{color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_noteAdd{cursor:pointer;font:inherit;color:var(--dsw-alias-label-secondary,#6b7280);white-space:nowrap;background:0 0;border:none;align-items:center;gap:6px;margin-top:4px;padding:0;font-size:12px;line-height:18px;display:inline-flex}.nUhMVa_noteAdd:hover,.nUhMVa_irowStatusFact{color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_irowStatusSep{color:var(--dsw-alias-label-tertiary,#8b93a1)}.nUhMVa_nameLink{color:inherit;text-decoration:none}.nUhMVa_irowName{text-overflow:clip;flex-wrap:wrap;align-items:baseline;gap:6px;min-width:0;display:flex;overflow:visible}.nUhMVa_irowNameText{overflow-wrap:anywhere;white-space:normal;min-width:0}.nUhMVa_irowName>.nUhMVa_owner{flex:none}.nUhMVa_nameLink:hover{color:var(--dsw-alias-brand-primary,#4f6ef7);text-decoration:underline}.nUhMVa_opWrap{flex-shrink:0;margin-bottom:6px;display:inline-flex}.nUhMVa_opEntry{font:inherit;cursor:pointer;white-space:nowrap;height:28px;color:var(--dsw-alias-label-primary,#1f2328);background:var(--dsw-alias-bg-layer-1,#fff);border:.5px solid var(--dsw-alias-border-l3,#d9dde3);border-radius:8px;align-items:center;gap:5px;padding:0 7px 0 10px;font-size:12px;transition:background-color .12s,color .12s,border-color .12s;display:inline-flex;position:relative}.nUhMVa_opEntryQuiet{background:var(--dsw-alias-bg-module-platform,#f4f5f7);color:var(--dsw-alias-label-secondary,#5c6570)}.nUhMVa_opEntry:hover{color:var(--dsw-alias-label-primary,#1f2328);border-color:var(--dsw-alias-border-l2,#e5e7eb);background:var(--dsw-alias-bg-module-platform,#f4f5f7)}.nUhMVa_opChevron{color:var(--dsw-alias-label-tertiary,#8b93a1);flex-shrink:0;transition:transform .14s cubic-bezier(.16,1,.3,1);display:inline-flex}.nUhMVa_opChevronOpen{transform:rotate(180deg)}.nUhMVa_opEntryAlert{border-color:var(--dsw-alias-state-error-primary,#dc2626);color:var(--dsw-alias-state-error-primary,#dc2626)}.nUhMVa_opDot{background:var(--dsw-alias-state-error-primary,#dc2626);border-radius:99px;width:8px;height:8px;position:absolute;top:-3px;right:-3px}.nUhMVa_opPanel{z-index:40;background:var(--dsw-alias-bg-layer-1,#fff);border:1px solid var(--dsw-alias-border-l3,#d9dde3);border-radius:12px;width:460px;max-width:100%;max-height:70vh;position:absolute;top:calc(100% + 6px);right:0;overflow-y:auto;box-shadow:0 20px 52px #00000047}.nUhMVa_opHead{border-bottom:1px solid var(--dsw-alias-border-l2,#e5e7eb);align-items:center;gap:8px;padding:9px 14px;display:flex}.nUhMVa_opPanelTitle{font-size:12.5px;font-weight:600}.nUhMVa_opCloseBtn.nUhMVa_opCloseBtn{min-width:0;color:var(--dsw-alias-label-secondary,#6b7280);padding:0 6px}.nUhMVa_opAggregate{border-bottom:1px solid var(--dsw-alias-border-l2,#e5e7eb);background:var(--dsw-alias-bg-layer-2,#f7f8fa);padding:9px 14px}.nUhMVa_opAggregateTop{font-variant-numeric:tabular-nums;font-size:12px;font-weight:600}.nUhMVa_opAggregateHint{color:var(--dsw-alias-label-tertiary,#8b93a1);margin-top:4px;font-size:10.5px}.nUhMVa_opRow{border-bottom:1px solid var(--dsw-alias-border-l2,#e5e7eb);align-items:flex-start;gap:9px;padding:9px 14px;display:flex}.nUhMVa_opRow:last-child{border-bottom:none}.nUhMVa_opRowAlert{background:#dc26260f}.nUhMVa_opIcon{flex-shrink:0;place-items:center;width:14px;margin-top:1px;display:grid}.nUhMVa_opQueuedIcon{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:12px}.nUhMVa_opMain{flex-direction:column;flex:1;gap:3px;min-width:0;display:flex}.nUhMVa_opTop{align-items:baseline;gap:6px;min-width:0;display:flex}.nUhMVa_opVerb{color:var(--dsw-alias-label-secondary,#6b7280);flex-shrink:0;font-size:12px}.nUhMVa_opName{text-overflow:ellipsis;white-space:nowrap;font-size:12px;font-weight:600;overflow:hidden}.nUhMVa_opStatus{color:var(--dsw-alias-label-tertiary,#8b93a1);overflow-wrap:anywhere;font-size:10.5px;line-height:16px}.nUhMVa_opStatusBad{color:var(--dsw-alias-state-error-primary,#dc2626)}.nUhMVa_opAgents{color:var(--dsw-alias-label-tertiary,#8b93a1);margin:2px 0 0;font-size:10.5px;line-height:16px}.nUhMVa_opAgentsSummary{cursor:pointer;color:var(--dsw-alias-label-secondary,#5c6570);font-size:10.5px;line-height:16px;list-style:none}.nUhMVa_opAgentsSummary::-webkit-details-marker{display:none}.nUhMVa_opAgentsSummary:before{content:\"▸\";width:10px;transition:transform .12s cubic-bezier(.16,1,.3,1);display:inline-block}.nUhMVa_opAgents[open]>.nUhMVa_opAgentsSummary:before{transform:rotate(90deg)}.nUhMVa_opAgentsList{flex-direction:column;gap:1px;margin:2px 0 0;padding:0 0 0 12px;list-style:none;display:flex}.nUhMVa_opAgentsId{font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);white-space:nowrap;text-overflow:ellipsis;font-size:10.5px;line-height:15px;overflow:hidden}.nUhMVa_opActions{flex-shrink:0;align-items:center;gap:6px;margin-top:1px;display:flex}.nUhMVa_opDecision{border-top:1px dashed var(--dsw-alias-border-l2,#e5e7eb);flex-direction:column;gap:8px;margin-top:8px;padding-top:8px;display:flex}.nUhMVa_opDecisionFoot{align-items:center;gap:8px;display:flex}.nUhMVa_conflictDetailsToggle{font:inherit;cursor:pointer;color:var(--dsw-alias-label-tertiary,#8b93a1);background:0 0;border:none;align-items:center;gap:4px;padding:2px 0;font-size:11px;display:inline-flex}.nUhMVa_conflictDetailsToggle:hover{color:var(--dsw-alias-label-secondary,#6b7280)}.nUhMVa_opEmpty{text-align:center;color:var(--dsw-alias-label-secondary,#6b7280);padding:30px 14px;font-size:12px}.nUhMVa_opEmptyHint{color:var(--dsw-alias-label-tertiary,#8b93a1);margin-top:4px;font-size:11px}.nUhMVa_cardBlockedMark{font:inherit;cursor:pointer;color:var(--dsw-alias-state-error-primary,#dc2626);border:1px solid var(--dsw-alias-state-error-primary,#dc2626);background:#dc262614;border-radius:7px;align-items:center;gap:5px;padding:4px 9px;font-size:11px;display:inline-flex}.nUhMVa_dangerBtn.nUhMVa_dangerBtn{color:var(--dsw-alias-state-error-primary,#dc2626);border-color:var(--dsw-alias-state-error-primary,#dc2626)}.nUhMVa_dangerBtn.nUhMVa_dangerBtn:hover:not(:disabled){background:var(--dsw-alias-state-error-primary,#dc2626);color:#fff}.nUhMVa_dangerArmed.nUhMVa_dangerArmed{background:var(--dsw-alias-state-error-primary,#dc2626);border-color:var(--dsw-alias-state-error-primary,#dc2626);color:var(--dsw-alias-label-primary-foreground,#fff)}.nUhMVa_retryBtn{margin-top:4px}.nUhMVa_irow{background:var(--dsw-alias-settings-card-fill,var(--dsw-alias-bg-layer-1,#fff));border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));border-radius:var(--dsw-radius-xl,20px);flex-direction:column;gap:10px;min-width:0;padding:12px 14px;display:flex}.nUhMVa_irowActions{flex-wrap:wrap;justify-content:flex-start;align-items:center;gap:8px;min-width:0;display:flex}.nUhMVa_irowTrailing{flex-wrap:nowrap;flex-shrink:0;align-items:center;gap:8px;min-width:0;display:inline-flex}.nUhMVa_irowTrailing .nUhMVa_metaTag{flex-shrink:1;min-width:0}.nUhMVa_irowMissing{filter:grayscale();opacity:.5}.nUhMVa_irow>.nUhMVa_src,.nUhMVa_irow>.nUhMVa_owner,.nUhMVa_irow button{white-space:nowrap;flex-shrink:0}.nUhMVa_tabSearchRow{align-items:center;gap:8px;padding:0 4px 10px;display:flex}.nUhMVa_tabSearch{flex:1;min-width:0}.nUhMVa_caps{flex-wrap:wrap;align-items:center;gap:4px;min-width:0;padding:0 2px 6px;font-size:11px;line-height:1.5;display:flex}.nUhMVa_capsTitle{color:var(--dsw-alias-label-secondary,#8b949e);cursor:help}.nUhMVa_capChip{border:1px solid var(--dsw-alias-border-l2,#30363d);color:var(--dsw-alias-label-primary,#c9d1d9);white-space:nowrap;border-radius:999px;padding:0 6px}.nUhMVa_capMuted{border:1px dashed var(--dsw-alias-border-l2,#30363d);color:var(--dsw-alias-label-secondary,#8b949e);white-space:nowrap;border-radius:999px;padding:0 6px}.nUhMVa_capCaveat{color:var(--dsw-alias-label-tertiary,#8b93a1);align-items:baseline;gap:12px;margin:6px 0 0;font-size:11px;line-height:16px;display:flex}.nUhMVa_capCaveatNote{min-width:0}.nUhMVa_capCaveatAt{white-space:nowrap;flex:none;margin-left:auto}.nUhMVa_searchField{box-sizing:border-box;min-width:0;position:relative}.nUhMVa_searchInput.nUhMVa_searchInput{box-sizing:border-box;width:100%;min-width:0;padding-right:34px}.nUhMVa_searchClear{width:24px;height:24px;color:var(--dsw-alias-label-secondary,#59636e);font:inherit;cursor:pointer;background:0 0;border:0;border-radius:4px;justify-content:center;align-items:center;padding:0;font-size:20px;line-height:1;display:flex;position:absolute;top:50%;right:5px;transform:translateY(-50%)}.nUhMVa_searchClear:hover{background:var(--dsw-alias-bg-layer-2,#f3f4f6);color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_searchClear:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,#4f6ef7);outline-offset:1px}.nUhMVa_spec{color:var(--dsw-alias-label-secondary,#9ca3af);font-size:11px;font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);overflow-wrap:anywhere;min-width:0}.nUhMVa_specTag{white-space:nowrap;border-radius:4px;flex-shrink:0;align-items:center;height:16px;padding:0 5px;font-size:10px;font-weight:600;display:inline-flex}.nUhMVa_specTagGit{color:var(--dsw-alias-state-business-primary,#0b7285);background:#12a3c41f}.nUhMVa_specTagFile{color:var(--dsw-alias-state-warn-primary,#b07d1b);background:#f0b42924}.nUhMVa_backupCheckList .nUhMVa_grow{white-space:nowrap;text-overflow:ellipsis;flex:70%;min-width:0;overflow:hidden}.nUhMVa_backupCheckList .nUhMVa_spec{text-align:right;white-space:nowrap;text-overflow:ellipsis;flex:0 30%;max-width:30%;overflow:hidden}.nUhMVa_staleAction{word-break:normal;flex-wrap:wrap;align-items:center;gap:8px;margin-top:8px;display:flex}.nUhMVa_pct{color:var(--dsw-alias-label-secondary,#6b7280);flex-shrink:0;font-size:11px;font-weight:600}.nUhMVa_pager{flex-wrap:nowrap;justify-content:space-between;align-items:center;gap:8px;margin:16px 0 4px;display:flex}.nUhMVa_loadMore{justify-content:center;margin:16px 0 4px;display:flex}.nUhMVa_pagerPages{flex-wrap:nowrap;flex:1;justify-content:center;align-items:center;gap:4px;min-width:0;display:flex}.nUhMVa_pagerMeta{flex-wrap:nowrap;flex-shrink:0;align-items:center;gap:6px;display:flex}.nUhMVa_pagerPages button,.nUhMVa_pagerMeta button{min-width:0;padding:0 8px}.nUhMVa_pageEllipsis{color:var(--dsw-alias-label-secondary,#9ca3af);padding:0 1px;font-size:12px}.nUhMVa_pageInfo{color:var(--dsw-alias-label-secondary,#6b7280);white-space:nowrap;font-size:12px}@container (width<=544px){.nUhMVa_pager{flex-wrap:wrap;justify-content:center;gap:8px}.nUhMVa_pagerPages{flex-basis:100%}}.nUhMVa_depBadge{border:1px solid var(--dsw-alias-state-warn-primary,#b45309);color:var(--dsw-alias-state-warn-primary,#b45309);white-space:nowrap;border-radius:4px;flex-shrink:0;margin-left:6px;padding:1px 6px;font-size:11px;font-weight:600;line-height:16px}.nUhMVa_deprecate{color:var(--dsw-alias-state-warn-primary,#b45309);background:var(--dsw-alias-bg-layer-2,#fdf3e3);border:1px solid var(--dsw-alias-border-l2,#f3e3c3);border-radius:8px;margin:0;padding:8px 10px;font-size:12px;line-height:18px}.nUhMVa_deprecate a{color:var(--dsw-alias-state-warn-primary,#b45309);text-decoration:underline}.nUhMVa_deprecate .nUhMVa_src{margin-left:8px}.nUhMVa_depLine{flex-wrap:wrap;align-items:center;gap:8px;display:flex}.nUhMVa_switch{border:1px solid var(--dsw-alias-border-l2,#d9dde3);background:var(--dsw-alias-bg-layer-2,#e5e7eb);cursor:pointer;border-radius:99px;flex-shrink:0;width:38px;height:22px;padding:0;transition:background .15s,border-color .15s;position:relative}.nUhMVa_switchOn{background:var(--dsw-alias-state-success-primary,#16a34a);border-color:var(--dsw-alias-state-success-primary,#16a34a)}.nUhMVa_switchMixed{background:var(--dsw-alias-state-warn-primary,#b45309);border-color:var(--dsw-alias-state-warn-primary,#b45309)}.nUhMVa_switchKnob{background:#fff;border-radius:99px;width:16px;height:16px;transition:left .15s;position:absolute;top:2px;left:2px;box-shadow:0 1px 2px #00000040}.nUhMVa_switchOn .nUhMVa_switchKnob,.nUhMVa_switchMixed .nUhMVa_switchKnob{left:18px}.nUhMVa_switch:disabled{opacity:.5;cursor:default}.nUhMVa_viewBar{border-radius:var(--dsw-radius-md,12px);background:var(--dsw-alias-bg-module-platform,#f4f5f7);border:none;align-items:center;gap:2px;width:fit-content;margin-bottom:12px;padding:3px;display:flex}.nUhMVa_viewBtn{font:inherit;color:var(--dsw-alias-label-secondary,#5c6570);border-radius:var(--dsw-radius-sm,8px);cursor:pointer;white-space:nowrap;background:0 0;border:none;height:26px;padding:0 10px;font-size:12px;line-height:18px;transition:background-color .12s,color .12s}.nUhMVa_viewBtn:hover{color:var(--dsw-alias-brand-primary,#4f6ef7)}.nUhMVa_viewOn{background:var(--dsw-alias-bg-layer-3,#fff);color:var(--dsw-alias-label-primary,#1f2328);box-shadow:0 0 0 .5px var(--dsw-alias-border-l3,#0000001f);font-weight:600}.nUhMVa_groupRow{background:var(--dsw-alias-settings-card-fill,var(--dsw-alias-bg-layer-1,#fff));border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));border-radius:var(--dsw-radius-xl,20px);margin-bottom:10px;padding:12px 14px}.nUhMVa_groupHead{flex-wrap:wrap;align-items:center;gap:10px;min-width:0;display:flex}.nUhMVa_groupCollapse{width:22px;height:22px;color:var(--dsw-alias-label-secondary,#6b7280);cursor:pointer;background:0 0;border:none;border-radius:6px;flex-shrink:0;justify-content:center;align-items:center;padding:0;display:inline-flex}.nUhMVa_groupCollapse:hover{background:var(--dsw-alias-bg-layer-2,#eef0f4);color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_groupTitle{flex-direction:column;flex:auto;gap:1px;min-width:0;display:flex}.nUhMVa_groupTitle .nUhMVa_groupHint{margin-top:0}.nUhMVa_groupName{text-overflow:ellipsis;white-space:nowrap;font-size:13px;font-weight:600;line-height:20px;overflow:hidden}.nUhMVa_groupMeta{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:11px;line-height:16px}.nUhMVa_groupActions{flex-wrap:wrap;flex-shrink:0;align-items:center;gap:6px;margin-left:auto;display:flex}.nUhMVa_groupMembers{flex-direction:column;gap:6px;margin-top:10px;display:flex}.nUhMVa_groupMember{background:var(--dsw-alias-bg-layer-2,#f7f8fa);border-radius:8px;align-items:center;gap:8px;min-width:0;padding:6px 8px;font-size:12px;line-height:18px;display:flex}.nUhMVa_groupMember .nUhMVa_nm{flex:1;min-width:0;font-size:12px}.nUhMVa_memberName{flex:auto;align-items:center;gap:6px;min-width:0;display:flex}.nUhMVa_memberName .nUhMVa_nm{flex:0 auto;min-width:0}.nUhMVa_memberNameWithDesc{flex:0 auto;max-width:42%}.nUhMVa_memberKind{color:var(--dsw-alias-label-tertiary,#8b93a1);white-space:nowrap;flex:none;font-size:11px;line-height:16px}.nUhMVa_themeSlot{box-shadow:inset 0 -1px 0 var(--dsw-alias-border-l2,#e5e7eb);border-radius:8px 8px 0 0;margin-bottom:4px}.nUhMVa_groupMember>.nUhMVa_switch,.nUhMVa_groupMember>button{flex-shrink:0}.nUhMVa_groupMemberAction{flex:none;margin-left:auto}.nUhMVa_groupMemberAction button{white-space:nowrap}.nUhMVa_groupAddPanel{border-top:1px dashed var(--dsw-alias-border-l2,#e5e7eb);flex-direction:column;gap:6px;margin-top:10px;padding-top:10px;display:flex}.nUhMVa_groupAddModalBody{flex-direction:column;gap:10px;min-width:0;display:flex}.nUhMVa_groupAddFilters{flex-wrap:wrap;gap:6px;display:flex}.nUhMVa_groupAddModalList{flex-direction:column;gap:6px;max-height:min(50vh,360px);padding-right:2px;display:flex;overflow-y:auto}.nUhMVa_groupAddModalHint{color:var(--dsw-alias-label-secondary,#6b7280);margin:0;font-size:12px;line-height:18px}.nUhMVa_groupAddPick{background:var(--dsw-alias-bg-layer-2,#f7f8fa);cursor:pointer;border-radius:8px;align-items:center;gap:8px;min-width:0;padding:8px 10px;display:flex}.nUhMVa_groupAddPick:hover{background:var(--dsw-alias-bg-layer-2,#eef0f4)}.nUhMVa_groupAddPick input{flex-shrink:0;margin:0}.nUhMVa_groupAddPick .nUhMVa_nm{text-overflow:ellipsis;white-space:nowrap;flex:1;min-width:0;font-size:12px;overflow:hidden}.nUhMVa_groupAddFooterMeta{color:var(--dsw-alias-label-secondary,#6b7280);align-self:center;margin-right:auto;font-size:12px;line-height:18px}.nUhMVa_groupOrgHint{color:var(--dsw-alias-label-tertiary,#8b93a1);margin:4px 0 0;font-size:11px;line-height:16px}.nUhMVa_groupRenameField{flex-direction:column;gap:6px;min-width:min(100%,320px);display:flex}.nUhMVa_groupRenameField label{color:var(--dsw-alias-label-secondary,#6b7280);font-size:12px;line-height:18px}.nUhMVa_groupRenameField .nUhMVa_inlineInput{width:100%}.nUhMVa_groupCreate{align-items:center;gap:8px;margin-bottom:10px;display:flex}.nUhMVa_groupCreateInline{flex-shrink:0;align-items:center;gap:8px;display:flex}.nUhMVa_groupCreateInline .nUhMVa_inlineInput{flex:none;width:160px}.nUhMVa_inlineInput{flex:1;min-width:120px}.nUhMVa_ungroupedRow{flex-wrap:nowrap}.nUhMVa_ungroupedRow>.nUhMVa_nm{flex:0 auto;max-width:42%;font-size:12px;line-height:18px}.nUhMVa_ungroupedState{flex:0 auto;align-items:center;min-width:0;max-width:46%;margin:0;display:inline-flex}.nUhMVa_ungroupedState>span{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.nUhMVa_ungroupedDesc{text-overflow:ellipsis;white-space:nowrap;min-width:0;color:var(--dsw-alias-label-tertiary,#8b93a1);flex:1 1 0;font-size:12px;line-height:18px;overflow:hidden}.nUhMVa_ungroupedDesc.nUhMVa_noteMine{color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_groupHint{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:11px}.nUhMVa_sect{color:var(--dsw-alias-label-secondary,#6b7280);margin:14px 2px 8px;font-size:12px;font-weight:600}.nUhMVa_sectAction{color:var(--dsw-alias-label-secondary,#6b7280);align-items:center;gap:8px;margin:14px 2px 8px;font-size:12px;font-weight:600;display:flex}.nUhMVa_backupGrid{grid-template-columns:minmax(0,1fr);gap:12px;display:grid}.nUhMVa_backupCard{background:var(--dsw-alias-settings-card-fill,var(--dsw-alias-bg-layer-1,#fff));border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));border-radius:var(--dsw-radius-xl,20px);flex-direction:column;gap:10px;padding:16px;display:flex}.nUhMVa_backupCard h3{margin:0;font-size:14px}.nUhMVa_backupCard p{color:var(--dsw-alias-label-secondary,#6b7280);margin:0;font-size:12px;line-height:18px}.nUhMVa_backupActions{flex-wrap:wrap;gap:8px;display:flex;position:relative}.nUhMVa_hiddenFile{opacity:0;pointer-events:none;width:1px;height:1px;position:absolute}.nUhMVa_backupInput{box-sizing:border-box;width:100%}.nUhMVa_backupCheck{cursor:pointer;align-items:center;gap:6px;font-size:12px;display:flex}.nUhMVa_backupWarn{margin:0;font-size:12px;line-height:18px;color:var(--dsw-alias-state-warn-primary,#b45309)!important}.nUhMVa_backupMessage{color:var(--dsw-alias-label-secondary,#6b7280);grid-column:1/-1;font-size:12px}.nUhMVa_backupCheckList{flex-direction:column;gap:6px;max-height:260px;margin:10px 0 4px;padding-right:4px;display:flex;overflow-y:auto}.nUhMVa_backupCheckList .nUhMVa_backupCheck{justify-content:space-between;gap:8px}.nUhMVa_diagPage{flex-direction:column;gap:12px;height:100%;min-height:0;display:flex;overflow-y:auto}.nUhMVa_panelHost .nUhMVa_diagPage{height:auto;overflow:visible}.nUhMVa_diagSummary{background:var(--dsw-alias-settings-card-fill,var(--dsw-alias-bg-layer-1,#fff));border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));border-radius:var(--dsw-radius-lg,16px);flex-wrap:wrap;align-items:center;gap:12px;padding:10px 14px;font-size:12px;display:flex}.nUhMVa_diagSummaryItem{color:var(--dsw-alias-label-secondary,#6b7280);white-space:nowrap;align-items:center;gap:6px;display:inline-flex}.nUhMVa_diagSummaryMeta{color:var(--dsw-alias-label-tertiary,#9ca3af);font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);text-overflow:ellipsis;white-space:nowrap;max-width:320px;font-size:11px;overflow:hidden}.nUhMVa_diagSection{background:var(--dsw-alias-settings-card-fill,var(--dsw-alias-bg-layer-1,#fff));border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));border-radius:var(--dsw-radius-lg,16px);flex-direction:column;gap:8px;padding:12px 14px;display:flex}.nUhMVa_diagSection h3{color:var(--dsw-alias-label-primary,#1f2328);margin:0;font-size:13px;font-weight:600}.nUhMVa_diagCount{color:var(--dsw-alias-label-tertiary,#9ca3af);font-size:11px;font-weight:400}.nUhMVa_diagEmpty{color:var(--dsw-alias-label-secondary,#9ca3af);padding:8px 0;font-size:12px}.nUhMVa_diagBundle{border-top:1px solid var(--dsw-alias-border-l2,#f0f1f3);flex-direction:column;gap:6px;padding-top:8px;display:flex}.nUhMVa_diagBundle:first-of-type{border-top:none;padding-top:0}.nUhMVa_diagRow{flex-wrap:wrap;align-items:center;gap:8px;min-width:0;font-size:12px;line-height:18px;display:flex}.nUhMVa_diagMeta{align-items:baseline;gap:8px;min-width:0;font-size:12px;display:flex}.nUhMVa_diagKey{color:var(--dsw-alias-label-tertiary,#9ca3af);flex-shrink:0;min-width:64px;font-size:11px}.nUhMVa_diagVal{color:var(--dsw-alias-label-primary,#1f2328);font-size:12px;font-weight:500;font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);overflow-wrap:anywhere;min-width:0}.nUhMVa_diagIndex{background:var(--dsw-alias-bg-layer-2,#f3f4f6);min-width:18px;height:18px;color:var(--dsw-alias-label-secondary,#6b7280);border-radius:9px;flex-shrink:0;justify-content:center;align-items:center;font-size:11px;font-weight:600;display:inline-flex}.nUhMVa_diagArrow{color:var(--dsw-alias-label-tertiary,#9ca3af);flex-shrink:0;font-size:12px}.nUhMVa_diagBadgeOfficial{background:var(--dsw-alias-button-primary-fill,var(--dsw-alias-brand-primary,#4f6ef7));height:18px;color:var(--dsw-alias-label-primary-foreground,#fff);border-radius:9px;flex-shrink:0;align-items:center;padding:0 8px;font-size:11px;font-weight:600;display:inline-flex}.nUhMVa_diagBadgeCommunity{background:var(--dsw-alias-bg-layer-2,#f3f4f6);height:18px;color:var(--dsw-alias-label-secondary,#6b7280);border-radius:9px;flex-shrink:0;align-items:center;padding:0 8px;font-size:11px;display:inline-flex}.nUhMVa_diagBadgeShadow{background:var(--dsw-alias-state-error-primary,#dc2626);height:18px;color:var(--dsw-alias-label-primary-foreground,#fff);border-radius:9px;flex-shrink:0;align-items:center;padding:0 8px;font-size:11px;font-weight:600;display:inline-flex}.nUhMVa_diagBadgeWarn{background:var(--dsw-alias-state-warn-primary,#b45309);height:18px;color:var(--dsw-alias-label-primary-foreground,#fff);white-space:nowrap;border-radius:9px;flex-shrink:0;align-items:center;padding:0 8px;font-size:11px;font-weight:600;display:inline-flex}.nUhMVa_diagBadgeInfo{background:var(--dsw-alias-bg-layer-2,#f3f4f6);height:18px;color:var(--dsw-alias-label-secondary,#6b7280);white-space:nowrap;border-radius:9px;flex-shrink:0;align-items:center;padding:0 8px;font-size:11px;display:inline-flex}.nUhMVa_diagList{flex-direction:column;gap:6px;display:flex}.nUhMVa_sectionOverview{color:var(--dsw-alias-label-tertiary,#8b93a1);text-overflow:ellipsis;white-space:nowrap;max-width:100%;padding:2px 0 6px;font-size:12px;line-height:18px;overflow:hidden}.nUhMVa_diagAlert{color:var(--dsw-alias-state-warn-primary,#b45309)}.nUhMVa_ovRow{background:var(--dsw-alias-bg-layer-2,#f7f8fa);border-radius:8px;flex-wrap:wrap;align-items:center;gap:8px;min-width:0;padding:6px 10px;font-size:12px;line-height:18px;display:flex}.nUhMVa_ovArrow{color:var(--dsw-alias-label-tertiary,#9ca3af);flex-shrink:0;font-size:12px}.nUhMVa_ovByTag{background:var(--dsw-alias-button-primary-fill,var(--dsw-alias-brand-primary,#4f6ef7));height:18px;color:var(--dsw-alias-label-primary-foreground,#fff);text-overflow:ellipsis;white-space:nowrap;border-radius:9px;flex-shrink:0;align-items:center;max-width:260px;padding:0 8px;font-size:11px;font-weight:600;display:inline-flex;overflow:hidden}.nUhMVa_ovFrom{color:var(--dsw-alias-label-secondary,#6b7280);text-overflow:ellipsis;white-space:nowrap;min-width:0;font-size:12px;overflow:hidden}.nUhMVa_orphRow{background:var(--dsw-alias-bg-layer-2,#f7f8fa);border-radius:8px;flex-wrap:wrap;align-items:center;gap:8px;min-width:0;padding:6px 10px;font-size:12px;line-height:18px;display:flex}.nUhMVa_orphBadge{background:var(--dsw-alias-state-warn-primary,#b45309);height:18px;color:var(--dsw-alias-label-primary-foreground,#fff);white-space:nowrap;border-radius:9px;flex-shrink:0;align-items:center;padding:0 8px;font-size:11px;font-weight:600;display:inline-flex}.nUhMVa_dragHandle{width:20px;height:20px;color:var(--dsw-alias-label-tertiary,#9ca3af);cursor:grab;-webkit-user-select:none;user-select:none;flex-shrink:0;justify-content:center;align-items:center;font-size:12px;line-height:20px;display:inline-flex}.nUhMVa_dragOver{outline:2px dashed var(--dsw-alias-brand-primary,#4f6ef7);outline-offset:2px;background:var(--dsw-alias-bg-layer-2,#f0f2f8);border-radius:8px}.nUhMVa_dragging{opacity:.45;background:var(--dsw-alias-bg-layer-2,#f3f4f6)}.nUhMVa_collapseHead{font:inherit;color:var(--dsw-alias-label-primary,#1f2328);cursor:pointer;text-align:left;background:0 0;border:none;align-items:center;gap:8px;width:100%;padding:0;font-size:13px;font-weight:600;display:flex}.nUhMVa_collapseIcon{color:var(--dsw-alias-label-secondary,#6b7280);flex-shrink:0;display:inline-flex}.nUhMVa_collapseTitle{flex:0 auto;min-width:0}.nUhMVa_collapseHead .nUhMVa_diagCount{flex-shrink:0}.nUhMVa_collapseBody{border-top:1px solid var(--dsw-alias-border-l2,#f0f1f3);overflow-wrap:anywhere;flex-direction:column;gap:10px;min-width:0;margin-top:8px;padding-top:10px;display:flex}.nUhMVa_orderPanel{flex-direction:column;gap:10px;min-width:0;display:flex}.nUhMVa_panelNote{color:var(--dsw-alias-label-secondary,#6b7280);margin:0;font-size:12px;line-height:18px}.nUhMVa_panelActions{flex-wrap:wrap;align-items:center;gap:8px;display:flex}.nUhMVa_presetList{flex-direction:column;gap:6px;min-width:0;display:flex}.nUhMVa_presetRow{background:var(--dsw-alias-bg-layer-2,#f7f8fa);border-radius:8px;flex-direction:column;align-items:stretch;gap:6px;min-width:0;max-width:100%;padding:8px 10px;font-size:12px;line-height:18px;display:flex}.nUhMVa_presetName{text-overflow:ellipsis;white-space:nowrap;min-width:0;font-size:13px;font-weight:600;overflow:hidden}.nUhMVa_snapList{flex-direction:column;gap:6px;min-width:0;display:flex}.nUhMVa_snapRow{background:var(--dsw-alias-bg-layer-2,#f7f8fa);border-radius:8px;flex-direction:column;align-items:stretch;gap:8px;padding:10px 12px;font-size:12px;line-height:18px;display:flex}.nUhMVa_snapMeta{flex-wrap:wrap;align-items:center;gap:8px;min-width:0;display:flex}.nUhMVa_snapConfirmText{color:var(--dsw-alias-state-warn-primary,#b45309);margin:0;font-size:12px;line-height:18px}.nUhMVa_confirmRow{flex-wrap:wrap;align-items:center;gap:6px;display:inline-flex}.nUhMVa_fixFallback{flex-direction:column;gap:6px;margin:8px 0;display:flex}.nUhMVa_fixFallbackText,.nUhMVa_envEditor{box-sizing:border-box;width:100%;font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);color:var(--dsw-alias-label-primary,#1f2328);background:var(--dsw-alias-bg-layer-2,#f3f4f6);border:1px solid var(--dsw-alias-border-l2,#e5e7eb);resize:vertical;white-space:pre-wrap;word-break:break-all;border-radius:6px;padding:8px 10px;font-size:11px;line-height:16px}.nUhMVa_setCard{border:.5px solid var(--dsw-alias-settings-card-stroke,var(--dsw-alias-border-l4,#00000029));background:var(--dsw-alias-bg-layer-3,#fff);border-radius:var(--dsw-radius-lg,16px);list-style:none;transition:border-color .16s,background .16s}.nUhMVa_setCard:hover{border-color:var(--dsw-alias-label-dimmed,#c8ccd4)}.nUhMVa_setCardOpen{background:var(--dsw-alias-bg-layer-2,#f7f8fa);border-color:var(--dsw-alias-label-dimmed,#c8ccd4)}.nUhMVa_setHeader{-webkit-appearance:none;appearance:none;width:100%;font:inherit;color:inherit;text-align:left;cursor:pointer;border-radius:var(--dsw-radius-lg,16px);background:0 0;border:0;align-items:center;gap:12px;padding:14px 16px;display:flex}.nUhMVa_setHeader:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,#4f6ef7);outline-offset:-2px}.nUhMVa_setHeadText{flex-direction:column;flex:1;gap:4px;min-width:0;display:flex}.nUhMVa_setName{color:var(--dsw-alias-label-primary,#1f2328);font-size:15px;font-weight:600;line-height:1.4}.nUhMVa_setDesc{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:13px;line-height:1.5}.nUhMVa_setChevron{color:var(--dsw-alias-label-tertiary,#8b93a1);flex:none;transition:transform .16s;display:inline-flex}.nUhMVa_setChevronOpen{transform:rotate(180deg)}.nUhMVa_setBody{border-top:1px solid var(--dsw-alias-border-l2,#e5e7eb);margin:0 16px;padding-bottom:8px}.nUhMVa_setRow{align-items:center;gap:12px;padding:12px 0;display:flex}.nUhMVa_setRow+.nUhMVa_setRow{border-top:1px solid var(--dsw-alias-border-l2,#e5e7eb)}.nUhMVa_setLabelBox{flex-direction:column;flex:1;gap:3px;min-width:0;display:flex}.nUhMVa_setLabel{font-size:13px;line-height:20px}.nUhMVa_setHint{color:var(--dsw-alias-label-tertiary,#8b93a1);font-size:12px;line-height:18px}.nUhMVa_setAdvanced{border-bottom:1px solid var(--dsw-alias-border-l2,#e5e7eb)}.nUhMVa_setAdvancedHead{-webkit-appearance:none;appearance:none;width:100%;font:inherit;color:inherit;text-align:left;cursor:pointer;background:0 0;border:0;align-items:center;gap:12px;padding:12px 0;display:flex}.nUhMVa_setAdvancedHead:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,#4f6ef7);outline-offset:-2px}.nUhMVa_setAdvancedBody{padding-bottom:4px}.nUhMVa_setConfirm{border-top:1px solid var(--dsw-alias-border-l2,#e5e7eb);flex-direction:column;gap:8px;padding:12px 0 4px;display:flex}.nUhMVa_setCheck{cursor:pointer;align-items:center;gap:8px;font-size:12px;line-height:18px;display:flex}.nUhMVa_setActions{border-top:1px solid var(--dsw-alias-border-l2,#e5e7eb);justify-content:flex-end;align-items:center;gap:8px;padding:12px 0 4px;display:flex}.nUhMVa_setInlineActions{flex-wrap:wrap;justify-content:flex-end;align-items:center;gap:6px;display:flex}.nUhMVa_setProxyEditor{border-top:1px solid var(--dsw-alias-border-l2,#e5e7eb);flex-wrap:wrap;align-items:flex-end;gap:10px;padding:12px 0;display:flex}.nUhMVa_setProxyLabel{min-width:180px;color:var(--dsw-alias-label-secondary,#6b7280);flex-direction:column;flex:1;gap:5px;font-size:12px;line-height:18px;display:flex}.nUhMVa_setProxyInput{box-sizing:border-box;border:1px solid var(--dsw-alias-border-l2,#d1d5db);background:var(--dsw-alias-bg-layer-3,#fff);width:100%;min-width:0;color:var(--dsw-alias-label-primary,#1f2328);font:inherit;border-radius:7px;padding:6px 8px;font-size:12px;line-height:18px}.nUhMVa_setProxyInput:focus{border-color:var(--dsw-alias-brand-primary,#4f6ef7);outline:2px solid color-mix(in srgb,var(--dsw-alias-brand-primary,#4f6ef7) 18%,transparent)}.nUhMVa_setDanger{color:var(--dsw-alias-state-error-primary,#dc2626)}.nUhMVa_setSeg{border-radius:var(--dsw-radius-md,12px);background:var(--dsw-alias-bg-module-platform,#f4f5f7);border:none;flex-shrink:0;gap:2px;padding:3px;display:inline-flex}.nUhMVa_setSegBtn{font:inherit;border-radius:var(--dsw-radius-sm,8px);height:26px;color:var(--dsw-alias-label-secondary,#5c6570);cursor:pointer;background:0 0;border:none;padding:0 10px;font-size:12px;line-height:18px}.nUhMVa_setSegBtn:disabled{cursor:default;opacity:.5}.nUhMVa_setSegOn{background:var(--dsw-alias-bg-layer-3,#fff);color:var(--dsw-alias-label-primary,#1f2328);box-shadow:0 0 0 .5px var(--dsw-alias-border-l3,#0000001f);font-weight:600}.nUhMVa_setBetaTag{background:var(--dsw-alias-bg-module-platform,#eef0f4);color:var(--dsw-alias-label-secondary,#6b7280);border-radius:9px;margin-left:6px;padding:0 6px;font-size:11px;font-weight:600;line-height:17px}.nUhMVa_commentsLink{cursor:pointer;white-space:nowrap;color:var(--dsw-alias-label-tertiary,#8b93a1);background:0 0;border:0;padding:0;font-size:12px;line-height:18px}.nUhMVa_commentsLink:hover{color:var(--dsw-alias-brand-primary,#4f6ef7)}.nUhMVa_footActions{flex-shrink:0;align-items:center;gap:8px;display:inline-flex}.nUhMVa_favoriteBtn{cursor:pointer;color:var(--dsw-alias-label-secondary,#9ca3af);background:0 0;border:0;align-items:center;padding:0;display:inline-flex}.nUhMVa_favoriteMark{transform-box:fill-box;transform-origin:50% 0;display:block}.nUhMVa_favoriteBtn:hover,.nUhMVa_favoriteOn{color:var(--dsw-alias-brand-primary,#4f6ef7)}.nUhMVa_cardMore{cursor:pointer;font:inherit;letter-spacing:1px;color:var(--dsw-alias-label-secondary,#9ca3af);background:0 0;border:0;padding:0 2px;font-size:14px;line-height:16px}.nUhMVa_cardMore:hover{color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_blockedTabHint{color:var(--dsw-alias-label-secondary,#9ca3af);margin:0 0 12px;font-size:12px;line-height:18px}.nUhMVa_blockedMissing{flex-direction:column;gap:4px;margin-top:8px;display:flex}.nUhMVa_blockedBarRow{justify-content:space-between;align-items:center;gap:8px;min-width:0;display:flex}.nUhMVa_blockedBarName{text-overflow:ellipsis;white-space:nowrap;min-width:0;font-size:13px;line-height:20px;overflow:hidden}.nUhMVa_blockedBarUndo{cursor:pointer;font:inherit;color:var(--dsw-alias-brand-primary,#4f6ef7);background:0 0;border:0;padding:0;font-size:12px;line-height:18px}.nUhMVa_commentsNote{color:var(--dsw-alias-label-secondary,#9ca3af);margin:0 0 8px;font-size:11px;line-height:16px}.nUhMVa_commentsGithubPrompt{border:1px solid color-mix(in srgb,var(--dsw-alias-brand-primary,#4f6ef7) 24%,transparent);background:color-mix(in srgb,var(--dsw-alias-brand-primary,#4f6ef7) 6%,transparent);border-radius:8px;margin:0 0 10px;padding:10px}.nUhMVa_commentsGithubHint{color:var(--dsw-alias-label-primary,#1f2328);margin:0 0 8px;font-size:12px;line-height:17px}.nUhMVa_commentsGithubAction{box-sizing:border-box;border:1px solid var(--dsw-alias-brand-primary,#4f6ef7);min-height:28px;color:var(--dsw-alias-brand-primary,#4f6ef7);border-radius:6px;justify-content:center;align-items:center;padding:5px 10px;font-size:12px;font-weight:600;line-height:16px;text-decoration:none;display:inline-flex}.nUhMVa_commentsGithubAction:hover{background:color-mix(in srgb,var(--dsw-alias-brand-primary,#4f6ef7) 9%,transparent)}.nUhMVa_commentsStatus{color:var(--dsw-alias-label-secondary,#9ca3af);margin:0;font-size:12px}.nUhMVa_commentsStatus:empty{display:none}.nUhMVa_commentsError{color:var(--dsw-alias-label-primary,#1f2328);margin:0 0 8px;font-size:12px}.nUhMVa_commentsFail{flex-direction:column;align-items:flex-start;gap:8px;padding:12px 0;display:flex}.nUhMVa_commentsMount{width:100%;min-height:240px;max-height:56vh;overflow:auto}.nUhMVa_commentsMount iframe{width:100%}.nUhMVa_notesLink{font:inherit;color:var(--dsw-alias-label-secondary,#6b7280);cursor:pointer;text-align:left;background:0 0;border:none;margin:2px 0 0;padding:0;font-size:12px;line-height:18px;display:block}.nUhMVa_notesLink:hover{color:var(--dsw-alias-label-primary,#1f2328)}.nUhMVa_notesModalWide{width:min(640px,92vw);max-width:min(640px,92vw)}.nUhMVa_notesBody{overscroll-behavior:contain;flex-direction:column;flex:0 auto;gap:10px;min-width:0;max-height:min(60vh,520px);padding:0 2px 8px 0;display:flex;overflow-y:auto}.nUhMVa_notesRange{align-items:center;gap:8px;margin-bottom:4px;font-size:12px;line-height:18px;display:flex}.nUhMVa_notesArrow{color:var(--dsw-alias-label-tertiary,#8b93a1)}.nUhMVa_notesMeta{letter-spacing:.02em;text-transform:uppercase;color:var(--dsw-alias-label-secondary,#6b7280);flex-wrap:wrap;align-items:baseline;gap:6px;margin-top:4px;font-size:12px;line-height:18px;display:flex}.nUhMVa_notesBody>.nUhMVa_notesMeta:first-child{margin-top:0}.nUhMVa_notesPre{white-space:pre-wrap;word-break:break-word;background:var(--dsw-alias-bg-layer-2,#eef0f4);border-radius:8px;max-height:40vh;margin:0;padding:10px 12px;font-size:13px;line-height:20px;overflow:auto}.nUhMVa_notesRendered{flex-direction:column;gap:8px;min-width:0;display:flex}.nUhMVa_notesImg{border-radius:6px;max-width:100%;height:auto;margin:4px 0;display:block}.nUhMVa_notesH{margin-top:4px;font-size:13px;font-weight:650;line-height:20px}.nUhMVa_notesP{font-size:13px;line-height:20px}.nUhMVa_notesQuote{border-left:3px solid var(--dsw-alias-border-l3,#d9dde3);background:var(--dsw-alias-bg-layer-2,#f7f8fa);color:var(--dsw-alias-label-primary,#1f2328);border-radius:0 6px 6px 0;margin:0;padding:8px 10px;font-size:13px;line-height:20px}.nUhMVa_notesFence{background:var(--dsw-alias-bg-layer-2,#eef0f4);font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);white-space:pre;border-radius:8px;margin:0;padding:10px 12px;font-size:12px;line-height:18px;overflow-x:auto}.nUhMVa_notesFence code{font:inherit;background:0 0;padding:0}.nUhMVa_notesBullets{flex-direction:column;gap:4px;margin:0;padding-left:18px;font-size:13px;line-height:20px;display:flex}.nUhMVa_notesA{color:var(--dsw-alias-brand-primary,#4f6ef7);text-decoration:none}.nUhMVa_notesA:hover{text-decoration:underline}.nUhMVa_notesCode{font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);background:var(--dsw-alias-bg-layer-2,#eef0f4);border-radius:5px;padding:1px 5px;font-size:12px}.nUhMVa_notesList{flex-direction:column;margin:0;padding:0;list-style:none;display:flex}.nUhMVa_notesRow{border-bottom:1px solid var(--dsw-alias-border-l2,#e5e7eb);align-items:baseline;gap:12px;padding:6px 0;display:flex}.nUhMVa_notesRow:last-child{border-bottom:none}.nUhMVa_notesDate{color:var(--dsw-alias-label-tertiary,#8b93a1);font-variant-numeric:tabular-nums;flex-shrink:0;font-size:12px}.nUhMVa_notesMsg{word-break:break-word;word-break:break-word;-webkit-line-clamp:3;-webkit-box-orient:vertical;min-width:0;font-size:13px;line-height:20px;display:-webkit-box;overflow:hidden}.nUhMVa_notesSha{color:var(--dsw-alias-label-secondary,#6b7280);font-variant-numeric:tabular-nums;flex-shrink:0;margin-left:auto;font-size:12px;text-decoration:none}.nUhMVa_recoverySummary{color:var(--dsw-alias-state-error-primary,#dc2626);word-break:break-word;align-items:flex-start;gap:8px;margin-bottom:8px;font-size:12px;display:flex}.nUhMVa_recoveryHint{color:var(--dsw-alias-label-secondary,#6b7280);margin:8px 0;font-size:12px}.nUhMVa_recoveryList{border:1px solid var(--dsw-alias-border-l2,#e5e7eb);border-radius:8px;flex-direction:column;max-height:320px;display:flex;overflow-x:hidden;overflow-y:auto}.nUhMVa_recoveryRow{border-top:1px solid var(--dsw-alias-border-l2,#eef0f4);align-items:flex-start;gap:8px;padding:6px 10px;font-size:12px;display:flex}.nUhMVa_recoveryRow:first-child{border-top:none}.nUhMVa_recoveryBlamed{box-shadow:inset 3px 0 0 var(--dsw-alias-state-error-primary,#dc2626);background:#dc262612}.nUhMVa_recoveryMuted{opacity:.6}.nUhMVa_recoveryName{word-break:break-word;flex-direction:column;gap:2px;min-width:0;display:flex}.nUhMVa_recoveryReason{color:var(--dsw-alias-state-error-primary,#dc2626);word-break:break-word;font-size:11px}.nUhMVa_recoveryNote{color:var(--dsw-alias-label-tertiary,#8b93a1);word-break:break-word;margin-top:8px;font-size:11px}.nUhMVa_recoveryBadge{background:var(--dsw-alias-bg-layer-2,#eef0f4);color:var(--dsw-alias-label-secondary,#6b7280);border-radius:5px;margin-left:6px;padding:0 5px;font-size:10px}.nUhMVa_recoveryLog{color:var(--dsw-alias-label-secondary,#6b7280);margin:4px 0 8px;font-size:11px}.nUhMVa_recoveryLog pre{white-space:pre-wrap;word-break:break-word;max-height:180px;margin:6px 0 0;overflow:auto}.nUhMVa_notesSha:hover{color:var(--dsw-alias-label-primary,#1f2328);text-decoration:underline}.nUhMVa_notesVer{color:inherit;font-weight:600;text-decoration:none}.nUhMVa_notesVer:hover{text-decoration:underline}.nUhMVa_notesSourceLink{color:var(--dsw-alias-brand-primary,#4f6ef7);white-space:nowrap;text-decoration:none}.nUhMVa_notesSourceLink:hover{text-decoration:underline}.nUhMVa_migrationSources{flex-direction:column;gap:8px;margin-top:4px;display:flex}.nUhMVa_migrationSource{border:1px solid var(--dsw-alias-border-l2,#e5e7eb);border-radius:8px;flex-direction:column;gap:4px;padding:10px 12px;display:flex}.nUhMVa_migrationSource code{font-size:12px;font-family:var(--ds-font-family-code,ui-monospace,Menlo,Consolas,monospace);overflow-wrap:anywhere}.nUhMVa_migrationLabel{color:var(--dsw-alias-label-secondary,#9ca3af);font-size:11px}.nUhMVa_migrationArrow{text-align:center;color:var(--dsw-alias-label-secondary,#9ca3af)}.nUhMVa_migrationWarning{color:var(--dsw-alias-state-warn-primary,#b45309);align-items:flex-start;gap:6px;margin:12px 0 0;font-size:12px;line-height:18px;display:flex}.nUhMVa_migrationNote{color:var(--dsw-alias-label-secondary,#6b7280);margin:12px 0 0;font-size:12px;line-height:18px}.nUhMVa_sourceRepo{color:var(--dsw-alias-label-secondary,#5c6570);align-self:flex-end;align-items:center;gap:2px;font-size:13px;line-height:20px;text-decoration:none;display:inline-flex}.nUhMVa_sourceRepo:hover{color:var(--dsw-alias-brand-primary,#4f6ef7);text-decoration:underline}.nUhMVa_sourceRepo:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,#4f6ef7);outline-offset:2px;border-radius:4px}";
		const tagId = "dshmarket/Market.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "dshmarket";
			tag.dataset.pluginCss = tagId;
			tag.textContent = css;
			document.head.appendChild(tag);
		}
		var Market_module_css_default = {
			"act": "nUhMVa_act",
			"actBroken": "nUhMVa_actBroken",
			"actLive": "nUhMVa_actLive",
			"actWarn": "nUhMVa_actWarn",
			"actWhy": "nUhMVa_actWhy",
			"av": "nUhMVa_av",
			"backupActions": "nUhMVa_backupActions",
			"backupCard": "nUhMVa_backupCard",
			"backupCheck": "nUhMVa_backupCheck",
			"backupCheckList": "nUhMVa_backupCheckList",
			"backupGrid": "nUhMVa_backupGrid",
			"backupInput": "nUhMVa_backupInput",
			"backupMessage": "nUhMVa_backupMessage",
			"backupWarn": "nUhMVa_backupWarn",
			"banner": "nUhMVa_banner",
			"bannerHint": "nUhMVa_bannerHint",
			"bannerIcon": "nUhMVa_bannerIcon",
			"bar": "nUhMVa_bar",
			"barFill": "nUhMVa_barFill",
			"barWave": "nUhMVa_barWave",
			"blockedBarName": "nUhMVa_blockedBarName",
			"blockedBarRow": "nUhMVa_blockedBarRow",
			"blockedBarUndo": "nUhMVa_blockedBarUndo",
			"blockedMissing": "nUhMVa_blockedMissing",
			"blockedTabHint": "nUhMVa_blockedTabHint",
			"body": "nUhMVa_body",
			"brokenPluginItem": "nUhMVa_brokenPluginItem",
			"brokenPluginNotice": "nUhMVa_brokenPluginNotice",
			"brokenPluginText": "nUhMVa_brokenPluginText",
			"byline": "nUhMVa_byline",
			"capAddress": "nUhMVa_capAddress",
			"capAhead": "nUhMVa_capAhead",
			"capAheadIcon": "nUhMVa_capAheadIcon",
			"capAheadLabel": "nUhMVa_capAheadLabel",
			"capAheadRow": "nUhMVa_capAheadRow",
			"capCaveat": "nUhMVa_capCaveat",
			"capCaveatAt": "nUhMVa_capCaveatAt",
			"capCaveatNote": "nUhMVa_capCaveatNote",
			"capChip": "nUhMVa_capChip",
			"capChipUncommon": "nUhMVa_capChipUncommon",
			"capGroupLabel": "nUhMVa_capGroupLabel",
			"capGroups": "nUhMVa_capGroups",
			"capMuted": "nUhMVa_capMuted",
			"capNote": "nUhMVa_capNote",
			"caps": "nUhMVa_caps",
			"capsTitle": "nUhMVa_capsTitle",
			"card": "nUhMVa_card",
			"cardAction": "nUhMVa_cardAction",
			"cardBlocked": "nUhMVa_cardBlocked",
			"cardBlockedMark": "nUhMVa_cardBlockedMark",
			"cardMore": "nUhMVa_cardMore",
			"cardShot": "nUhMVa_cardShot",
			"cardShots": "nUhMVa_cardShots",
			"cats": "nUhMVa_cats",
			"catsCollapsed": "nUhMVa_catsCollapsed",
			"catsRow": "nUhMVa_catsRow",
			"catsToggle": "nUhMVa_catsToggle",
			"catsWrap": "nUhMVa_catsWrap",
			"choice": "nUhMVa_choice",
			"choiceMain": "nUhMVa_choiceMain",
			"choiceNote": "nUhMVa_choiceNote",
			"choiceOn": "nUhMVa_choiceOn",
			"choiceRadio": "nUhMVa_choiceRadio",
			"choices": "nUhMVa_choices",
			"choiceSafe": "nUhMVa_choiceSafe",
			"choiceTitle": "nUhMVa_choiceTitle",
			"cmd": "nUhMVa_cmd",
			"collapseBody": "nUhMVa_collapseBody",
			"collapseHead": "nUhMVa_collapseHead",
			"collapseIcon": "nUhMVa_collapseIcon",
			"collapseTitle": "nUhMVa_collapseTitle",
			"commentsError": "nUhMVa_commentsError",
			"commentsFail": "nUhMVa_commentsFail",
			"commentsGithubAction": "nUhMVa_commentsGithubAction",
			"commentsGithubHint": "nUhMVa_commentsGithubHint",
			"commentsGithubPrompt": "nUhMVa_commentsGithubPrompt",
			"commentsLink": "nUhMVa_commentsLink",
			"commentsMount": "nUhMVa_commentsMount",
			"commentsNote": "nUhMVa_commentsNote",
			"commentsStatus": "nUhMVa_commentsStatus",
			"confirmBody": "nUhMVa_confirmBody",
			"confirmCmd": "nUhMVa_confirmCmd",
			"confirmContent": "nUhMVa_confirmContent",
			"confirmCopied": "nUhMVa_confirmCopied",
			"confirmCopy": "nUhMVa_confirmCopy",
			"confirmDesc": "nUhMVa_confirmDesc",
			"confirmFineprint": "nUhMVa_confirmFineprint",
			"confirmFold": "nUhMVa_confirmFold",
			"confirmModal": "nUhMVa_confirmModal",
			"confirmPanel": "nUhMVa_confirmPanel",
			"confirmPanelBody": "nUhMVa_confirmPanelBody",
			"confirmPanelChevron": "nUhMVa_confirmPanelChevron",
			"confirmPanelIcon": "nUhMVa_confirmPanelIcon",
			"confirmPanelMeta": "nUhMVa_confirmPanelMeta",
			"confirmPanelRow": "nUhMVa_confirmPanelRow",
			"confirmPanelRowStatic": "nUhMVa_confirmPanelRowStatic",
			"confirmPanelTitle": "nUhMVa_confirmPanelTitle",
			"confirmRow": "nUhMVa_confirmRow",
			"confirmTags": "nUhMVa_confirmTags",
			"confirmTerminalDot": "nUhMVa_confirmTerminalDot",
			"confirmTerminalIcon": "nUhMVa_confirmTerminalIcon",
			"confirmTerminalPrompt": "nUhMVa_confirmTerminalPrompt",
			"conflictBody": "nUhMVa_conflictBody",
			"conflictDetailsToggle": "nUhMVa_conflictDetailsToggle",
			"conflictHead": "nUhMVa_conflictHead",
			"conflictIcon": "nUhMVa_conflictIcon",
			"conflictTitle": "nUhMVa_conflictTitle",
			"conflictWhy": "nUhMVa_conflictWhy",
			"conflictWhyText": "nUhMVa_conflictWhyText",
			"dangerArmed": "nUhMVa_dangerArmed",
			"dangerBtn": "nUhMVa_dangerBtn",
			"depBadge": "nUhMVa_depBadge",
			"depLine": "nUhMVa_depLine",
			"deprecate": "nUhMVa_deprecate",
			"desc": "nUhMVa_desc",
			"descClamp": "nUhMVa_descClamp",
			"descClamp3": "nUhMVa_descClamp3",
			"descMore": "nUhMVa_descMore",
			"descTight": "nUhMVa_descTight",
			"descToggle": "nUhMVa_descToggle",
			"diagAlert": "nUhMVa_diagAlert",
			"diagArrow": "nUhMVa_diagArrow",
			"diagBadgeCommunity": "nUhMVa_diagBadgeCommunity",
			"diagBadgeInfo": "nUhMVa_diagBadgeInfo",
			"diagBadgeOfficial": "nUhMVa_diagBadgeOfficial",
			"diagBadgeShadow": "nUhMVa_diagBadgeShadow",
			"diagBadgeWarn": "nUhMVa_diagBadgeWarn",
			"diagBundle": "nUhMVa_diagBundle",
			"diagCount": "nUhMVa_diagCount",
			"diagEmpty": "nUhMVa_diagEmpty",
			"diagIndex": "nUhMVa_diagIndex",
			"diagKey": "nUhMVa_diagKey",
			"diagList": "nUhMVa_diagList",
			"diagMeta": "nUhMVa_diagMeta",
			"diagPage": "nUhMVa_diagPage",
			"diagRow": "nUhMVa_diagRow",
			"diagSection": "nUhMVa_diagSection",
			"diagSummary": "nUhMVa_diagSummary",
			"diagSummaryItem": "nUhMVa_diagSummaryItem",
			"diagSummaryMeta": "nUhMVa_diagSummaryMeta",
			"diagVal": "nUhMVa_diagVal",
			"dot": "nUhMVa_dot",
			"dragging": "nUhMVa_dragging",
			"dragHandle": "nUhMVa_dragHandle",
			"dragOver": "nUhMVa_dragOver",
			"dshmMarkPlug": "nUhMVa_dshmMarkPlug",
			"dshmMarkWave": "nUhMVa_dshmMarkWave",
			"dshmPlugFade": "nUhMVa_dshmPlugFade",
			"dshmSlide": "nUhMVa_dshmSlide",
			"empty": "nUhMVa_empty",
			"envEditor": "nUhMVa_envEditor",
			"err": "nUhMVa_err",
			"exportLogBtn": "nUhMVa_exportLogBtn",
			"favoriteBtn": "nUhMVa_favoriteBtn",
			"favoriteMark": "nUhMVa_favoriteMark",
			"favoriteOn": "nUhMVa_favoriteOn",
			"favoritesSectionHead": "nUhMVa_favoritesSectionHead",
			"favoritesStaleBar": "nUhMVa_favoritesStaleBar",
			"favoritesStaleOnly": "nUhMVa_favoritesStaleOnly",
			"fixFallback": "nUhMVa_fixFallback",
			"fixFallbackText": "nUhMVa_fixFallbackText",
			"foot": "nUhMVa_foot",
			"footActions": "nUhMVa_footActions",
			"footTags": "nUhMVa_footTags",
			"grid": "nUhMVa_grid",
			"groupActions": "nUhMVa_groupActions",
			"groupAddFilters": "nUhMVa_groupAddFilters",
			"groupAddFooterMeta": "nUhMVa_groupAddFooterMeta",
			"groupAddModalBody": "nUhMVa_groupAddModalBody",
			"groupAddModalHint": "nUhMVa_groupAddModalHint",
			"groupAddModalList": "nUhMVa_groupAddModalList",
			"groupAddPanel": "nUhMVa_groupAddPanel",
			"groupAddPick": "nUhMVa_groupAddPick",
			"groupCollapse": "nUhMVa_groupCollapse",
			"groupCreate": "nUhMVa_groupCreate",
			"groupCreateInline": "nUhMVa_groupCreateInline",
			"groupHead": "nUhMVa_groupHead",
			"groupHint": "nUhMVa_groupHint",
			"groupMember": "nUhMVa_groupMember",
			"groupMemberAction": "nUhMVa_groupMemberAction",
			"groupMembers": "nUhMVa_groupMembers",
			"groupMeta": "nUhMVa_groupMeta",
			"groupName": "nUhMVa_groupName",
			"groupOrgHint": "nUhMVa_groupOrgHint",
			"groupRenameField": "nUhMVa_groupRenameField",
			"groupRow": "nUhMVa_groupRow",
			"groupTitle": "nUhMVa_groupTitle",
			"grow": "nUhMVa_grow",
			"head": "nUhMVa_head",
			"headTop": "nUhMVa_headTop",
			"hiddenFile": "nUhMVa_hiddenFile",
			"hostFilterNote": "nUhMVa_hostFilterNote",
			"hostRequirement": "nUhMVa_hostRequirement",
			"hostRequirementBad": "nUhMVa_hostRequirementBad",
			"inlineInput": "nUhMVa_inlineInput",
			"installBtn": "nUhMVa_installBtn",
			"installCaution": "nUhMVa_installCaution",
			"installCautionBody": "nUhMVa_installCautionBody",
			"installCautionFoot": "nUhMVa_installCautionFoot",
			"installCautionHead": "nUhMVa_installCautionHead",
			"installCautionLabel": "nUhMVa_installCautionLabel",
			"installCautionLink": "nUhMVa_installCautionLink",
			"installCautionMark": "nUhMVa_installCautionMark",
			"irow": "nUhMVa_irow",
			"irowActions": "nUhMVa_irowActions",
			"irowDesc": "nUhMVa_irowDesc",
			"irowHead": "nUhMVa_irowHead",
			"irowMenu": "nUhMVa_irowMenu",
			"irowMeta": "nUhMVa_irowMeta",
			"irowMissing": "nUhMVa_irowMissing",
			"irowName": "nUhMVa_irowName",
			"irowNameText": "nUhMVa_irowNameText",
			"irowPath": "nUhMVa_irowPath",
			"irowPathCopy": "nUhMVa_irowPathCopy",
			"irowPathIcon": "nUhMVa_irowPathIcon",
			"irowStatus": "nUhMVa_irowStatus",
			"irowStatusAction": "nUhMVa_irowStatusAction",
			"irowStatusFact": "nUhMVa_irowStatusFact",
			"irowStatusIcon": "nUhMVa_irowStatusIcon",
			"irowStatusPart": "nUhMVa_irowStatusPart",
			"irowStatusSep": "nUhMVa_irowStatusSep",
			"irowTrailing": "nUhMVa_irowTrailing",
			"lightbox": "nUhMVa_lightbox",
			"lightboxClose": "nUhMVa_lightboxClose",
			"lightboxDot": "nUhMVa_lightboxDot",
			"lightboxDotOn": "nUhMVa_lightboxDotOn",
			"lightboxDots": "nUhMVa_lightboxDots",
			"lightboxImg": "nUhMVa_lightboxImg",
			"lightboxNav": "nUhMVa_lightboxNav",
			"lightboxNext": "nUhMVa_lightboxNext",
			"lightboxPrev": "nUhMVa_lightboxPrev",
			"loading": "nUhMVa_loading",
			"loadMore": "nUhMVa_loadMore",
			"logoCell": "nUhMVa_logoCell",
			"logoMark": "nUhMVa_logoMark",
			"logoPlug": "nUhMVa_logoPlug",
			"logoPlugAmbient": "nUhMVa_logoPlugAmbient",
			"masonry": "nUhMVa_masonry",
			"masonryCol": "nUhMVa_masonryCol",
			"memberKind": "nUhMVa_memberKind",
			"memberName": "nUhMVa_memberName",
			"memberNameWithDesc": "nUhMVa_memberNameWithDesc",
			"meta": "nUhMVa_meta",
			"metaInline": "nUhMVa_metaInline",
			"metaTag": "nUhMVa_metaTag",
			"metaTagOk": "nUhMVa_metaTagOk",
			"migrationArrow": "nUhMVa_migrationArrow",
			"migrationLabel": "nUhMVa_migrationLabel",
			"migrationNote": "nUhMVa_migrationNote",
			"migrationSource": "nUhMVa_migrationSource",
			"migrationSources": "nUhMVa_migrationSources",
			"migrationWarning": "nUhMVa_migrationWarning",
			"modalNote": "nUhMVa_modalNote",
			"nameLink": "nUhMVa_nameLink",
			"nm": "nUhMVa_nm",
			"nmLink": "nUhMVa_nmLink",
			"noteAdd": "nUhMVa_noteAdd",
			"noteCount": "nUhMVa_noteCount",
			"noteEdit": "nUhMVa_noteEdit",
			"noteEditBar": "nUhMVa_noteEditBar",
			"noteInput": "nUhMVa_noteInput",
			"noteMine": "nUhMVa_noteMine",
			"noteRow": "nUhMVa_noteRow",
			"notesA": "nUhMVa_notesA",
			"notesArrow": "nUhMVa_notesArrow",
			"notesBody": "nUhMVa_notesBody",
			"notesBullets": "nUhMVa_notesBullets",
			"notesCode": "nUhMVa_notesCode",
			"notesDate": "nUhMVa_notesDate",
			"notesFence": "nUhMVa_notesFence",
			"notesH": "nUhMVa_notesH",
			"notesImg": "nUhMVa_notesImg",
			"notesLink": "nUhMVa_notesLink",
			"notesList": "nUhMVa_notesList",
			"notesMeta": "nUhMVa_notesMeta",
			"notesModalWide": "nUhMVa_notesModalWide",
			"notesMsg": "nUhMVa_notesMsg",
			"notesP": "nUhMVa_notesP",
			"notesPre": "nUhMVa_notesPre",
			"notesQuote": "nUhMVa_notesQuote",
			"notesRange": "nUhMVa_notesRange",
			"notesRendered": "nUhMVa_notesRendered",
			"notesRow": "nUhMVa_notesRow",
			"notesSha": "nUhMVa_notesSha",
			"notesSourceLink": "nUhMVa_notesSourceLink",
			"notesVer": "nUhMVa_notesVer",
			"noteToggle": "nUhMVa_noteToggle",
			"okState": "nUhMVa_okState",
			"on": "nUhMVa_on",
			"opActions": "nUhMVa_opActions",
			"opAgents": "nUhMVa_opAgents",
			"opAgentsId": "nUhMVa_opAgentsId",
			"opAgentsList": "nUhMVa_opAgentsList",
			"opAgentsSummary": "nUhMVa_opAgentsSummary",
			"opAggregate": "nUhMVa_opAggregate",
			"opAggregateHint": "nUhMVa_opAggregateHint",
			"opAggregateTop": "nUhMVa_opAggregateTop",
			"opChevron": "nUhMVa_opChevron",
			"opChevronOpen": "nUhMVa_opChevronOpen",
			"opCloseBtn": "nUhMVa_opCloseBtn",
			"opDecision": "nUhMVa_opDecision",
			"opDecisionFoot": "nUhMVa_opDecisionFoot",
			"opDot": "nUhMVa_opDot",
			"opEmpty": "nUhMVa_opEmpty",
			"opEmptyHint": "nUhMVa_opEmptyHint",
			"opEntry": "nUhMVa_opEntry",
			"opEntryAlert": "nUhMVa_opEntryAlert",
			"opEntryQuiet": "nUhMVa_opEntryQuiet",
			"opHead": "nUhMVa_opHead",
			"opIcon": "nUhMVa_opIcon",
			"opMain": "nUhMVa_opMain",
			"opName": "nUhMVa_opName",
			"opPanel": "nUhMVa_opPanel",
			"opPanelTitle": "nUhMVa_opPanelTitle",
			"opQueuedIcon": "nUhMVa_opQueuedIcon",
			"opRow": "nUhMVa_opRow",
			"opRowAlert": "nUhMVa_opRowAlert",
			"opStatus": "nUhMVa_opStatus",
			"opStatusBad": "nUhMVa_opStatusBad",
			"opTop": "nUhMVa_opTop",
			"opVerb": "nUhMVa_opVerb",
			"opWrap": "nUhMVa_opWrap",
			"orderPanel": "nUhMVa_orderPanel",
			"orphBadge": "nUhMVa_orphBadge",
			"orphRow": "nUhMVa_orphRow",
			"ovArrow": "nUhMVa_ovArrow",
			"ovByTag": "nUhMVa_ovByTag",
			"ovFrom": "nUhMVa_ovFrom",
			"ovRow": "nUhMVa_ovRow",
			"owner": "nUhMVa_owner",
			"pageEllipsis": "nUhMVa_pageEllipsis",
			"pageInfo": "nUhMVa_pageInfo",
			"pager": "nUhMVa_pager",
			"pagerMeta": "nUhMVa_pagerMeta",
			"pagerPages": "nUhMVa_pagerPages",
			"panelActions": "nUhMVa_panelActions",
			"panelHost": "nUhMVa_panelHost",
			"panelNote": "nUhMVa_panelNote",
			"pct": "nUhMVa_pct",
			"presetList": "nUhMVa_presetList",
			"presetName": "nUhMVa_presetName",
			"presetRow": "nUhMVa_presetRow",
			"progress": "nUhMVa_progress",
			"reassure": "nUhMVa_reassure",
			"reassureOk": "nUhMVa_reassureOk",
			"recentAv": "nUhMVa_recentAv",
			"recentBlock": "nUhMVa_recentBlock",
			"recentBottom": "nUhMVa_recentBottom",
			"recentCollapsed": "nUhMVa_recentCollapsed",
			"recentDesc": "nUhMVa_recentDesc",
			"recentHead": "nUhMVa_recentHead",
			"recentHide": "nUhMVa_recentHide",
			"recentName": "nUhMVa_recentName",
			"recentRow": "nUhMVa_recentRow",
			"recentShow": "nUhMVa_recentShow",
			"recentTile": "nUhMVa_recentTile",
			"recentTitle": "nUhMVa_recentTitle",
			"recentToggle": "nUhMVa_recentToggle",
			"recoveryBadge": "nUhMVa_recoveryBadge",
			"recoveryBlamed": "nUhMVa_recoveryBlamed",
			"recoveryHint": "nUhMVa_recoveryHint",
			"recoveryList": "nUhMVa_recoveryList",
			"recoveryLog": "nUhMVa_recoveryLog",
			"recoveryMuted": "nUhMVa_recoveryMuted",
			"recoveryName": "nUhMVa_recoveryName",
			"recoveryNote": "nUhMVa_recoveryNote",
			"recoveryReason": "nUhMVa_recoveryReason",
			"recoveryRow": "nUhMVa_recoveryRow",
			"recoverySummary": "nUhMVa_recoverySummary",
			"repoLink": "nUhMVa_repoLink",
			"repoMark": "nUhMVa_repoMark",
			"retryBtn": "nUhMVa_retryBtn",
			"root": "nUhMVa_root",
			"roster": "nUhMVa_roster",
			"rosterAuthor": "nUhMVa_rosterAuthor",
			"rosterMain": "nUhMVa_rosterMain",
			"rosterName": "nUhMVa_rosterName",
			"rosterRow": "nUhMVa_rosterRow",
			"rosterRowOut": "nUhMVa_rosterRowOut",
			"rosterSplit": "nUhMVa_rosterSplit",
			"rosterTag": "nUhMVa_rosterTag",
			"rosterTagDrop": "nUhMVa_rosterTagDrop",
			"rosterTagKeep": "nUhMVa_rosterTagKeep",
			"row1": "nUhMVa_row1",
			"searchClear": "nUhMVa_searchClear",
			"searchField": "nUhMVa_searchField",
			"searchInput": "nUhMVa_searchInput",
			"sect": "nUhMVa_sect",
			"sectAction": "nUhMVa_sectAction",
			"sectionOverview": "nUhMVa_sectionOverview",
			"setActions": "nUhMVa_setActions",
			"setAdvanced": "nUhMVa_setAdvanced",
			"setAdvancedBody": "nUhMVa_setAdvancedBody",
			"setAdvancedHead": "nUhMVa_setAdvancedHead",
			"setBetaTag": "nUhMVa_setBetaTag",
			"setBody": "nUhMVa_setBody",
			"setCard": "nUhMVa_setCard",
			"setCardOpen": "nUhMVa_setCardOpen",
			"setCheck": "nUhMVa_setCheck",
			"setChevron": "nUhMVa_setChevron",
			"setChevronOpen": "nUhMVa_setChevronOpen",
			"setConfirm": "nUhMVa_setConfirm",
			"setDanger": "nUhMVa_setDanger",
			"setDesc": "nUhMVa_setDesc",
			"setHeader": "nUhMVa_setHeader",
			"setHeadText": "nUhMVa_setHeadText",
			"setHint": "nUhMVa_setHint",
			"setInlineActions": "nUhMVa_setInlineActions",
			"setLabel": "nUhMVa_setLabel",
			"setLabelBox": "nUhMVa_setLabelBox",
			"setName": "nUhMVa_setName",
			"setProxyEditor": "nUhMVa_setProxyEditor",
			"setProxyInput": "nUhMVa_setProxyInput",
			"setProxyLabel": "nUhMVa_setProxyLabel",
			"setRow": "nUhMVa_setRow",
			"setSeg": "nUhMVa_setSeg",
			"setSegBtn": "nUhMVa_setSegBtn",
			"setSegOn": "nUhMVa_setSegOn",
			"shot": "nUhMVa_shot",
			"shots": "nUhMVa_shots",
			"sidebarTip": "nUhMVa_sidebarTip",
			"snapConfirmText": "nUhMVa_snapConfirmText",
			"snapList": "nUhMVa_snapList",
			"snapMeta": "nUhMVa_snapMeta",
			"snapRow": "nUhMVa_snapRow",
			"sourceRepo": "nUhMVa_sourceRepo",
			"sp": "nUhMVa_sp",
			"spec": "nUhMVa_spec",
			"specTag": "nUhMVa_specTag",
			"specTagFile": "nUhMVa_specTagFile",
			"specTagGit": "nUhMVa_specTagGit",
			"spin": "nUhMVa_spin",
			"src": "nUhMVa_src",
			"staleAction": "nUhMVa_staleAction",
			"star": "nUhMVa_star",
			"stateDot": "nUhMVa_stateDot",
			"stateTag": "nUhMVa_stateTag",
			"stickyHead": "nUhMVa_stickyHead",
			"sub": "nUhMVa_sub",
			"submitLink": "nUhMVa_submitLink",
			"subTabs": "nUhMVa_subTabs",
			"swatches": "nUhMVa_swatches",
			"switch": "nUhMVa_switch",
			"switchKnob": "nUhMVa_switchKnob",
			"switchMixed": "nUhMVa_switchMixed",
			"switchOn": "nUhMVa_switchOn",
			"tab": "nUhMVa_tab",
			"tabs": "nUhMVa_tabs",
			"tabSearch": "nUhMVa_tabSearch",
			"tabSearchRow": "nUhMVa_tabSearchRow",
			"tag": "nUhMVa_tag",
			"themeActions": "nUhMVa_themeActions",
			"themeCard": "nUhMVa_themeCard",
			"themeCardBody": "nUhMVa_themeCardBody",
			"themeCardFooter": "nUhMVa_themeCardFooter",
			"themeCardHead": "nUhMVa_themeCardHead",
			"themeCover": "nUhMVa_themeCover",
			"themeCoverEmpty": "nUhMVa_themeCoverEmpty",
			"themeDescription": "nUhMVa_themeDescription",
			"themeFullscreenBtn": "nUhMVa_themeFullscreenBtn",
			"themeGallery": "nUhMVa_themeGallery",
			"themeIdentity": "nUhMVa_themeIdentity",
			"themeLifecycle": "nUhMVa_themeLifecycle",
			"themePreviewAction": "nUhMVa_themePreviewAction",
			"themePreviewCount": "nUhMVa_themePreviewCount",
			"themeResultBar": "nUhMVa_themeResultBar",
			"themeSearch": "nUhMVa_themeSearch",
			"themesGrid": "nUhMVa_themesGrid",
			"themeSlot": "nUhMVa_themeSlot",
			"themeStatus": "nUhMVa_themeStatus",
			"themeStatusMuted": "nUhMVa_themeStatusMuted",
			"themeToolbar": "nUhMVa_themeToolbar",
			"themeToolbarActions": "nUhMVa_themeToolbarActions",
			"title": "nUhMVa_title",
			"titleActions": "nUhMVa_titleActions",
			"titleRow": "nUhMVa_titleRow",
			"top": "nUhMVa_top",
			"topBtn": "nUhMVa_topBtn",
			"ungroupedDesc": "nUhMVa_ungroupedDesc",
			"ungroupedRow": "nUhMVa_ungroupedRow",
			"ungroupedState": "nUhMVa_ungroupedState",
			"version": "nUhMVa_version",
			"viewBar": "nUhMVa_viewBar",
			"viewBtn": "nUhMVa_viewBtn",
			"viewOn": "nUhMVa_viewOn",
			"warnLine": "nUhMVa_warnLine"
		};
		//#endregion
		//#region src/client/market-mark.ts
		/**
		* The market's block mark as geometry rather than as a component.
		*
		* Two consumers draw this mark and they must not drift:
		*
		* - `MarketLogo` (MarketSection.tsx) renders it inside the section as an
		*   ordinary React SVG in `currentColor`, including the animated variant;
		* - `settings-nav-icon.ts` serialises it into a CSS mask for the settings
		*   navigation glyph, which cannot use `currentColor` (a mask is an
		*   independent image) and so needs it as standalone markup.
		*
		* Keeping the numbers here means a change to the mark is one edit, and the
		* suite can hold both renderings to the same source.
		*
		* The mark is the brand asset in `assets/logo.svg`: an 8-cell grid plus the
		* block being plugged into its empty corner, offset and tilted 9°.
		*/
		/** Side of one block, and its corner radius. */
		const MARK_BLOCK_SIZE = 3.3;
		const MARK_BLOCK_RADIUS = .53;
		/**
		* The eight grid cells, row-major. The ninth slot stays empty on purpose.
		*
		* `wave` is the cell's diagonal, `row + column` in the 3×3 grid. The animated
		* variants stagger on it, so the breath travels across the grid instead of
		* sweeping it left to right; the empty slot sits at `wave` 2, which is what
		* the plug block's own timing is keyed to (see `dshmMarkPlug`). It is geometry
		* like the coordinates are, so it lives here rather than being re-derived by
		* both renderers — the mask serialiser ignores it.
		*/
		const MARK_GRID_BLOCKS = [
			{
				x: 1.96,
				y: 3.36,
				wave: 0
			},
			{
				x: 5.71,
				y: 3.36,
				wave: 1
			},
			{
				x: 1.96,
				y: 7.11,
				wave: 1
			},
			{
				x: 5.71,
				y: 7.11,
				wave: 2
			},
			{
				x: 9.46,
				y: 7.11,
				wave: 3
			},
			{
				x: 1.96,
				y: 10.86,
				wave: 2
			},
			{
				x: 5.71,
				y: 10.86,
				wave: 3
			},
			{
				x: 9.46,
				y: 10.86,
				wave: 4
			}
		];
		/**
		* The block being plugged in: OUTSIDE the grid's empty corner, offset
		* (+1.28, -1.27) and tilted 9deg, exactly as in assets/logo.svg. The earlier
		* icon sat it neatly in the empty slot, which reads as one crooked tile
		* rather than a block arriving — the whole idea of the mark, and the reason
		* it no longer matched the GitHub logo.
		*/
		const MARK_PLUG_BLOCK = {
			x: 10.74,
			y: 2.09,
			degrees: 9,
			/** Rotation origin: the plug block's own centre. */
			originX: 12.39,
			originY: 3.74
		};
		//#endregion
		//#region src/client/comments.ts
		/**
		* giscus wiring for the in-market comment thread.
		*
		* A plugin has ONE discussion, whether the reader reached it from
		* dshmarket.com, from the awesome-dsh-plugin catalog, or from inside the
		* market itself. That is only true as long as three things agree across the
		* three surfaces: the repository ids below, the `plugin:<slug>` term, and the
		* slug those terms are built from. The ids here mirror site/comments.mjs and
		* the slug mirrors scripts/build-site.mjs; both are asserted in
		* tests/client/comments.client.spec.ts against the real files, because a
		* silent disagreement does not fail — it forks the conversation in half and
		* nobody notices until someone asks why their comment vanished.
		*/
		const GISCUS = Object.freeze({
			repo: "awesome-dsh-plugin/awesome-dsh-plugin",
			repoId: "R_kgDOT3ajCQ",
			category: "Plugins",
			categoryId: "DIC_kwDOT3ajCc4DES8_"
		});
		/**
		* The plugin's slug, derived from its GitHub URL exactly as the two site
		* builders derive it. Entries that live in a subdirectory of a monorepo
		* (`.../tree/<ref>/packages/x`) get the `owner/repo--packages-x` form, so two
		* plugins from one repository do not share a thread.
		*/
		function pluginSlug(url) {
			const repoPath = url.replace("https://github.com/", "");
			const repo = repoPath.split("/").slice(0, 2).join("/");
			const sub = repoPath.includes("/tree/") ? repoPath.split("/tree/")[1].replace(/^[^/]+\//, "") : null;
			return sub ? `${repo}--${sub.replaceAll("/", "-")}` : repo;
		}
		/** The giscus discussion term for a plugin. */
		const commentsTerm = (url) => `plugin:${pluginSlug(url)}`;
		/**
		* GitHub's discussion search narrowed to this plugin's exact shared term.
		*
		* This is deliberately composed from constants and the catalog URL only.
		* In particular it never copies the current page URL: a local dsh web page
		* may carry its one-time host token there, and sending that to GitHub would
		* trade a comment-login inconvenience for credential disclosure.
		*/
		function commentsDiscussionUrl(url) {
			const term = `"${commentsTerm(url)}"`;
			return `https://github.com/${GISCUS.repo}/discussions?discussions_q=${encodeURIComponent(term)}`;
		}
		/** giscus's own locale codes, which are not the ones this plugin uses. */
		const giscusLang = (lang) => lang === "zh" ? "zh-CN" : "en";
		//#endregion
		//#region src/client/CommentsModal.tsx
		/**
		* The comment thread for one plugin, rendered inside the market.
		*
		* Opening this is the request to read the comments, so it loads on open —
		* there is no second click to confirm what the first one already said. What
		* the reader does have to be told, once and plainly, is that reading here
		* contacts giscus.app and GitHub: nothing else in the market talks to a third
		* party at the reader's request, and a comment box that quietly opens that
		* connection would be a surprise, not a feature.
		*
		* The thread itself lives in GitHub Discussions, keyed on the same
		* `plugin:<slug>` term the two websites use — see comments.ts.
		*/
		/**
		* Whether the host is currently showing a dark theme.
		*
		* Read off the rendered page rather than from `prefers-color-scheme`: the host
		* lets the reader pick a theme (including custom ones) independently of the
		* OS, and a light comment box dropped into a dark window is the kind of seam
		* that makes an embed look bolted on.
		*/
		function hostIsDark() {
			if (typeof window === "undefined") return false;
			const bg = getComputedStyle(document.body).backgroundColor;
			const m = /rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/.exec(bg);
			if (!m) return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
			const [r, g, b] = [
				Number(m[1]),
				Number(m[2]),
				Number(m[3])
			];
			return .299 * r + .587 * g + .114 * b < 128;
		}
		function CommentsModal(props) {
			const { name, url, lang, onClose, t } = props;
			const mount = (0, react.useRef)(null);
			const [state, setState] = (0, react.useState)("loading");
			const [attempt, setAttempt] = (0, react.useState)(0);
			(0, react.useEffect)(() => {
				const host = mount.current;
				if (host === null) return;
				host.replaceChildren();
				setState("loading");
				const script = document.createElement("script");
				script.src = "https://giscus.app/client.js";
				script.async = true;
				script.crossOrigin = "anonymous";
				Object.assign(script.dataset, {
					repo: GISCUS.repo,
					repoId: GISCUS.repoId,
					category: GISCUS.category,
					categoryId: GISCUS.categoryId,
					mapping: "specific",
					term: commentsTerm(url),
					strict: "1",
					reactionsEnabled: "1",
					emitMetadata: "0",
					inputPosition: "bottom",
					theme: hostIsDark() ? "dark" : "light",
					lang: giscusLang(lang),
					loading: "lazy"
				});
				script.onload = () => setState("ready");
				script.onerror = () => {
					script.remove();
					setState("failed");
				};
				host.append(script);
				return () => {
					host.replaceChildren();
				};
			}, [
				url,
				lang,
				attempt
			]);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
				open: true,
				onClose,
				title: t("commentsTitle") + " — " + name,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: Market_module_css_default.commentsNote,
						children: t("commentsNote")
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.commentsGithubPrompt,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							className: Market_module_css_default.commentsGithubHint,
							children: t("commentsLoginHint")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
							className: Market_module_css_default.commentsGithubAction,
							href: commentsDiscussionUrl(url),
							target: "_blank",
							rel: "noreferrer",
							children: t("commentsOnGitHub")
						})]
					}),
					state === "failed" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.commentsFail,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							className: Market_module_css_default.commentsError,
							children: t("commentsError")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setAttempt((n) => n + 1),
							children: t("commentsRetry")
						})]
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: Market_module_css_default.commentsStatus,
						role: "status",
						"aria-live": "polite",
						children: state === "loading" ? t("commentsLoading") : ""
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						ref: mount,
						className: Market_module_css_default.commentsMount,
						"aria-busy": state === "loading"
					})
				]
			});
		}
		/** Keep keystrokes out of the market's large render tree, not just its filter.
		* Only settled queries reach the parent. Explicit navigation remains immediate.
		*
		* The clear control lives in here rather than at the call sites (#524 by
		* @bulingbuling688, whose clear button reached the same four fields from
		* outside this component). Two things made the difference:
		*
		* - it has to clear the DRAFT, not the committed query. Between a keystroke
		*   and the 250ms commit, the text on screen and the parent's `value` are
		*   different strings; a button that only reset `value` would leave the old
		*   text visible until the effect below rewrote the draft, and would schedule
		*   its own debounce on the way out.
		* - the padding that keeps a long query off the button belongs to whoever
		*   renders the button. As a prop of the call sites it is a rule four rows
		*   have to remember and a fifth would forget.
		*/
		function SearchInput({ value, onCommit, className, placeholder, resetToken, t }) {
			const [draft, setDraft] = (0, react.useState)(value);
			const field = (0, react.useRef)(null);
			const timer = (0, react.useRef)(null);
			const composing = (0, react.useRef)(false);
			const cancel = (0, react.useCallback)(() => {
				if (timer.current !== null) clearTimeout(timer.current);
				timer.current = null;
			}, []);
			const commit = (next) => {
				cancel();
				onCommit(next);
			};
			const schedule = (next) => {
				cancel();
				if (composing.current) return;
				if (next === "") commit(next);
				else timer.current = setTimeout(() => commit(next), 250);
			};
			/**
			* Clear what is on screen and what the parent filters by, now.
			*
			* `commit('')` also cancels a debounce that is already in flight — without
			* that, clearing during the 250ms gap would let the old query land after
			* the clear and re-filter the list the user just emptied.
			*/
			const clear = () => {
				setDraft("");
				commit("");
				field.current?.querySelector("input")?.focus();
			};
			(0, react.useLayoutEffect)(() => {
				cancel();
				setDraft(value);
			}, [
				value,
				resetToken,
				cancel
			]);
			(0, react.useEffect)(() => cancel, [cancel]);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				ref: field,
				className: className === void 0 ? Market_module_css_default.searchField : `${Market_module_css_default.searchField} ${className}`,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
					className: Market_module_css_default.searchInput,
					icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconSearchOutline16, { size: 14 }),
					placeholder,
					value: draft,
					spellCheck: false,
					onChange: (event) => {
						const next = event.target.value;
						setDraft(next);
						schedule(next);
					},
					onCompositionStart: () => {
						composing.current = true;
						cancel();
					},
					onCompositionEnd: (event) => {
						composing.current = false;
						const next = event.currentTarget.value;
						setDraft(next);
						schedule(next);
					},
					onKeyDown: (event) => {
						if (event.key === "Enter" && !composing.current && !event.nativeEvent.isComposing && event.keyCode !== 229) commit(event.currentTarget.value);
					},
					onBlur: (event) => {
						if (!composing.current) commit(event.currentTarget.value);
					}
				}), draft !== "" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					className: Market_module_css_default.searchClear,
					"aria-label": t("clearSearch"),
					onClick: clear,
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: "×"
					})
				})]
			});
		}
		//#endregion
		//#region src/client/download-stats.ts
		const validCount = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
		/** Keep the established npm window first; the two sources are never added together. */
		function downloadStatistic(plugin) {
			if (validCount(plugin.downloads)) return {
				count: plugin.downloads,
				source: "npm"
			};
			if (validCount(plugin.githubReleaseDownloads)) return {
				count: plugin.githubReleaseDownloads,
				source: "github"
			};
			return null;
		}
		function checkedAt(value, t) {
			if (dateOnly(value)) return t("statisticCheckedAt").replace("{0}", value);
			if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) return "";
			const date = new Date(value);
			if (!Number.isFinite(date.getTime()) || date.toISOString() !== value) return "";
			return t("statisticCheckedAt").replace("{0}", value.slice(0, 16).replace("T", " ") + " UTC");
		}
		function starStatsText(plugin, t) {
			return validCount(plugin.stars) ? t("starsMeaning").replace("{0}", String(plugin.stars)) + checkedAt(plugin.starsCheckedAt, t) : null;
		}
		/** Date-only values stay date-only; never derive a window from today's date. */
		function dateOnly(value) {
			if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
			const parsed = new Date(value);
			return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
		}
		/** Exact count and, when the catalog sent one, the 30-day window. */
		function downloadStatsText(plugin, t) {
			const statistic = downloadStatistic(plugin);
			if (statistic === null) return null;
			const { count, source } = statistic;
			if (source === "github") return t("githubReleaseDownloadsMeaning").replace("{0}", String(count)) + checkedAt(plugin.githubReleaseDownloadsCheckedAt, t);
			const meaning = t("downloadsMeaning").replace("{0}", String(count));
			if (!(dateOnly(plugin.downloadsStart) && dateOnly(plugin.downloadsEnd) && plugin.downloadsStart <= plugin.downloadsEnd)) return meaning;
			return meaning + t("downloadsWindow").replace("{0}", plugin.downloadsStart).replace("{1}", plugin.downloadsEnd);
		}
		//#endregion
		//#region src/client/operations.ts
		const BUCKETS = {
			queued: "busy",
			running: "busy",
			input: "attention",
			failed: "attention",
			done: "ok",
			warned: "ok"
		};
		/** Which of the three visual groups a state belongs to. */
		function bucketOf(state) {
			return BUCKETS[state];
		}
		/** Whether a record has stopped moving on its own. */
		function isSettled(record) {
			return record.state === "done" || record.state === "warned" || record.state === "failed";
		}
		/** Whether a record is waiting on the user rather than on the host. */
		function needsUser(record) {
			return record.state === "input";
		}
		/** Append a record. Ids are supplied by the caller so tests stay deterministic. */
		function enqueue(list, record) {
			return [...list, record];
		}
		/**
		* Apply changes to one record.
		* @returns a new list; unchanged (same contents) when no record matches.
		*/
		function patch(list, id, changes) {
			return list.map((record) => record.id === id ? {
				...record,
				...changes
			} : record);
		}
		/** Drop one record outright — the panel's per-row dismiss. */
		function drop(list, id) {
			return list.filter((record) => record.id !== id);
		}
		/**
		* Clear finished records, keeping anything still moving or still waiting on
		* the user. A record in `input` survives: the user has not answered it yet,
		* and clearing it would delete the only route back to that decision.
		*/
		function clearSettled(list) {
			return list.filter((record) => !isSettled(record));
		}
		/**
		* How many queued records sit ahead of this one. The panel shows it because
		* "queued" without a position reads as stuck; the host runs one mutation at a
		* time, so the order shown is the order that will run.
		* @returns the count ahead, or null when the record is not queued.
		*/
		function queuePosition(list, id) {
			const index = list.filter((record) => record.state === "queued").findIndex((record) => record.id === id);
			return index < 0 ? null : index;
		}
		/**
		* Counts for the panel entry. The entry reports the batch, never one row:
		* one aggregate line beats seven notifications racing each other.
		*/
		function summarize(list) {
			let running = 0;
			let queued = 0;
			let blocked = 0;
			let attention = 0;
			let settled = 0;
			for (const record of list) if (record.state === "running") running += 1;
			else if (record.state === "queued") {
				queued += 1;
				if ((record.blockedBy?.length ?? 0) > 0) blocked += 1;
			} else if (needsUser(record)) attention += 1;
			else settled += 1;
			return {
				running,
				queued,
				blocked,
				attention,
				settled,
				total: running + queued + settled,
				progressed: settled + running
			};
		}
		/**
		* Panel order: what needs the user first, then what is still moving, then
		* what is finished. Within a group the original order is kept so a queue
		* reads top-to-bottom in the order it will run.
		*/
		function sortForPanel(list) {
			const rank = (record) => needsUser(record) ? 0 : isSettled(record) ? 2 : 1;
			return [...list].map((record, index) => ({
				record,
				index
			})).sort((a, b) => rank(a.record) - rank(b.record) || a.index - b.index).map((entry) => entry.record);
		}
		/**
		* The record a plugin card should reflect, newest first. A card shows the
		* button state for an operation in flight and a terminal marker for one that
		* ended without installing — without that marker a rejected install leaves
		* the card looking untouched, and the obvious next move is to press Install
		* again.
		*/
		function recordForUrl(list, url) {
			for (let index = list.length - 1; index >= 0; index -= 1) {
				const record = list[index];
				if (record.url === url) return record;
			}
			return null;
		}
		/**
		* Where finished rows survive a page load. Only rows that ended: `queued`
		* belongs to the queue key and `running` to the dshm-pending markers, and an
		* `input` row is a question this session asked, not one a later one can
		* answer.
		*/
		const SETTLED_STORAGE_KEY = "dshm-settled-v1";
		/**
		* The finished rows worth putting back after a reload, oldest first and newest
		* last, capped to the most recent SETTLED_LIMIT.
		*
		* It keeps only what a restored row needs to be re-rendered and acted on: the
		* id actions address, the kind/name/url the row is about, the terminal state,
		* and the decision or sentence attached to it — the reason it failed, the build
		* scripts awaiting approval, a held release. `detail` is kept for the same
		* reason: it is the row's own report.
		*
		* Failed updates awaiting build approval also keep their original update
		* options so approving after a reload cannot select a different target.
		* `blockedBy` and `conflicts` are deliberately dropped. `needsRefresh` is written so the
		* stored shape stays the record's own, but the restore drops it: only the page
		* that wrote it can still be waiting for that reload.
		*/
		function serializeSettled(list) {
			return list.filter(isSettled).filter((record) => record.hostOperationId === void 0).slice(-20).map((record) => ({
				id: record.id,
				kind: record.kind,
				name: record.name,
				...record.url === void 0 ? {} : { url: record.url },
				state: record.state,
				...record.reason === void 0 ? {} : { reason: record.reason },
				...record.detail === void 0 ? {} : { detail: record.detail },
				...record.blockedBuilds === void 0 ? {} : { blockedBuilds: [...record.blockedBuilds] },
				...record.kind === "update" && record.state === "failed" && (record.blockedBuilds?.length ?? 0) > 0 && record.updateOptions !== void 0 ? { updateOptions: { ...record.updateOptions } } : {},
				...record.needsRefresh === true ? { needsRefresh: true } : {},
				...record.heldRelease === void 0 ? {} : { heldRelease: { ...record.heldRelease } }
			}));
		}
		/** A non-empty string, or undefined — storage entries are not trusted. */
		function asText(value) {
			return typeof value === "string" && value !== "" ? value : void 0;
		}
		/** The string entries of a stored array, or undefined when there are none. */
		function asStringList(value) {
			if (!Array.isArray(value)) return void 0;
			const list = value.filter((entry) => typeof entry === "string" && entry !== "");
			return list.length === 0 ? void 0 : list;
		}
		/**
		* The release a `warned` row was held back from. Validated as a whole: the row
		* offers it as an action, and half of it would offer the wrong version.
		*/
		function asHeldRelease(value) {
			if (value === null || typeof value !== "object" || Array.isArray(value)) return void 0;
			const entry = value;
			const latest = asText(entry.latest);
			const because = asText(entry.because);
			const installed = entry.installed === null ? null : asText(entry.installed);
			if (latest === void 0 || because === void 0 || installed === void 0) return void 0;
			return {
				latest,
				installed,
				because
			};
		}
		/**
		* One stored row, or null when it is not a finished operation this code can
		* still show. Malformed optional fields are dropped rather than taken as a
		* reason to lose the row: the failure itself is still the only place the user
		* can read what happened.
		*/
		function restoreSettledRecord(value) {
			if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
			const row = value;
			if (asText(row.hostOperationId) !== void 0) return null;
			const id = asText(row.id);
			const name = asText(row.name);
			const kind = row.kind === "install" || row.kind === "update" || row.kind === "uninstall" ? row.kind : void 0;
			const state = row.state === "done" || row.state === "warned" || row.state === "failed" ? row.state : void 0;
			if (id === void 0 || name === void 0 || kind === void 0 || state === void 0) return null;
			const url = asText(row.url);
			const reason = asText(row.reason);
			const detail = asText(row.detail);
			const blockedBuilds = asStringList(row.blockedBuilds);
			const heldRelease = asHeldRelease(row.heldRelease);
			const options = row.updateOptions !== null && typeof row.updateOptions === "object" && !Array.isArray(row.updateOptions) ? row.updateOptions : void 0;
			const updateOptions = kind === "update" && state === "failed" && blockedBuilds !== void 0 && options !== void 0 ? {
				...typeof options.force === "boolean" ? { force: options.force } : {},
				...typeof options.restore === "boolean" ? { restore: options.restore } : {},
				...asText(options.compatVersion) === void 0 ? {} : { compatVersion: asText(options.compatVersion) },
				...asText(options.eligibleVersion) === void 0 ? {} : { eligibleVersion: asText(options.eligibleVersion) }
			} : void 0;
			return {
				id,
				kind,
				name,
				...url === void 0 ? {} : { url },
				state,
				...reason === void 0 ? {} : { reason },
				...detail === void 0 ? {} : { detail },
				...blockedBuilds === void 0 ? {} : { blockedBuilds },
				...updateOptions === void 0 ? {} : { updateOptions },
				...heldRelease === void 0 ? {} : { heldRelease }
			};
		}
		/**
		* Rows read back from storage, or an empty list for anything that cannot be
		* trusted. localStorage is user-writable and outlives versions of this code, so
		* every entry is re-checked instead of cast: an unknown kind, a state that is
		* not terminal, a missing id, or a field of the wrong type must never reach the
		* panel. A malformed value yields no rows rather than throwing — a bad key is a
		* lost history, not a broken market.
		*/
		function restoreSettled(raw) {
			let parsed = raw;
			if (typeof raw === "string") try {
				parsed = JSON.parse(raw);
			} catch {
				return [];
			}
			if (!Array.isArray(parsed)) return [];
			const restored = [];
			const seen = /* @__PURE__ */ new Set();
			for (const value of parsed) {
				const record = restoreSettledRecord(value);
				if (record === null || seen.has(record.id)) continue;
				seen.add(record.id);
				restored.push(record);
			}
			return restored.slice(-20);
		}
		//#endregion
		//#region src/client/OperationsPanel.tsx
		/**
		* The activity entry and its panel: every install, update and uninstall the
		* user started, with the action each outcome calls for.
		*
		* The entry lives in the tab row rather than above the plugin grid, so
		* paginating, searching or switching tab cannot take a record — or a pending
		* decision — off screen. It reports the batch as one aggregate ("installing
		* 3 / 7") instead of one line per plugin.
		*/
		/** What the two clash outcomes are, in the order they are offered. */
		const CHOICES = [{
			id: "keep",
			label: "conflictKeep",
			note: "conflictKeepNote"
		}, {
			id: "swap",
			label: "conflictSwap",
			note: "conflictSwapNote"
		}];
		/**
		* What each plugin ends up as under the selected outcome.
		*
		* The consequence is drawn ON the plugins rather than described beside them:
		* pick "keep what I have" and the installed rows tick while the candidate
		* crosses out; pick the other and they swap. The candidate is in this list
		* for the same reason — a decision about which plugin survives has to show
		* what happens to the one being installed, not only to the others.
		*/
		function OutcomePreview(props) {
			const { t, record, choice } = props;
			const swap = choice === "swap";
			const candidate = props.describe(record.name);
			const row = (key, info, kept, tag) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: kept ? Market_module_css_default.rosterRow : `${Market_module_css_default.rosterRow} ${Market_module_css_default.rosterRowOut}`,
				children: [
					info.avatar,
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
						className: Market_module_css_default.rosterMain,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.rosterName,
							title: key,
							children: info.title
						}), info.author !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.rosterAuthor,
							children: info.author
						})]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
						className: kept ? `${Market_module_css_default.rosterTag} ${Market_module_css_default.rosterTagKeep}` : `${Market_module_css_default.rosterTag} ${Market_module_css_default.rosterTagDrop}`,
						children: [
							kept ? "✓" : "✕",
							" ",
							tag
						]
					})
				]
			}, key);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.roster,
				children: [
					row(record.name, candidate, swap, t(swap ? "conflictOutcomeInstall" : "conflictOutcomeSkip")),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { className: Market_module_css_default.rosterSplit }),
					(record.conflicts ?? []).map((group) => row(group.owner, props.describe(group.owner), !swap, t(swap ? "conflictOutcomeRemove" : "conflictOutcomeKeep")))
				]
			});
		}
		/**
		* The decision attached to a clash. Two outcomes rather than an error plus a
		* destructive button: the default changes nothing, and selecting the other
		* one is itself the consent step, so its cost is stated here.
		*/
		function ConflictChoice(props) {
			const { t, record, replacing, envReady } = props;
			const [choice, setChoice] = (0, react.useState)("keep");
			const [whyOpen, setWhyOpen] = (0, react.useState)(false);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.opDecision,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: Market_module_css_default.conflictBody,
						children: t("conflictBody")
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(OutcomePreview, {
						t,
						record,
						choice,
						describe: props.describe
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.choices,
						children: CHOICES.map(({ id, label, note }) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
							className: choice === id ? `${Market_module_css_default.choice} ${Market_module_css_default.choiceOn}` : Market_module_css_default.choice,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								type: "radio",
								className: Market_module_css_default.choiceRadio,
								name: `dshm-conflict-${record.id}`,
								checked: choice === id,
								disabled: replacing,
								onChange: () => setChoice(id)
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.choiceMain,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.choiceTitle,
									children: t(label)
								}), t(note) !== "" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.choiceNote,
									children: t(note)
								})]
							})]
						}, id))
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.opDecisionFoot,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
								type: "button",
								className: Market_module_css_default.conflictDetailsToggle,
								"aria-expanded": whyOpen,
								onClick: () => setWhyOpen((open) => !open),
								children: [t("conflictDetails"), whyOpen ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, { size: 12 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 12 })]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: choice === "swap" ? "outline" : "primary",
								size: "sm",
								className: choice === "swap" ? Market_module_css_default.dangerBtn : void 0,
								disabled: replacing || choice === "swap" && !envReady,
								onClick: () => props.onResolve(choice),
								children: replacing ? t("conflictReplacing") : t("confirm")
							})
						]
					}),
					whyOpen && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.conflictWhy,
						children: [(record.conflicts ?? []).map((group) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [
							group.owner,
							": ",
							group.ids.join(", ")
						] }, group.owner)), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.conflictWhyText,
							children: t("conflictWhy")
						})]
					})
				]
			});
		}
		/** Icon for a record's visual bucket — three, not one per state. */
		function BucketIcon(props) {
			const bucket = bucketOf(props.record.state);
			if (bucket === "busy") return props.record.state === "running" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: Market_module_css_default.spin,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLoadingOutline16, { size: 13 })
			}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: Market_module_css_default.opQueuedIcon,
				children: "⋯"
			});
			if (bucket === "ok") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconCheckOutline16, {
				size: 13,
				className: Market_module_css_default.reassureOk
			});
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
				size: 14,
				className: Market_module_css_default.conflictIcon
			});
		}
		/** The one-line status under a record's name; the bucket carries the rest. */
		function statusLine(t, lang, record, ahead) {
			switch (record.state) {
				case "queued": {
					const blockers = record.blockedBy?.length ?? 0;
					if (record.hostOperationId !== void 0) {
						const elapsed = record.waitSince === void 0 ? null : Math.max(0, Math.floor((Date.now() - record.waitSince) / 1e3));
						const base = blockers > 0 ? t("agentDrainWaiting").replace("{0}", String(blockers)) : t("agentBusyQueued");
						return elapsed === null ? base : `${base} (${String(elapsed)}s)`;
					}
					if (blockers > 0) return `${t("opQueued")} · ${t("opQueuedWaitingAgents").replace("{0}", String(blockers))}`;
					return ahead === null || ahead === 0 ? t("opQueued") : `${t("opQueued")} · ${t("opQueuedAhead")} ${String(ahead)}`;
				}
				case "running": return record.detail ?? t("opRunning");
				case "input": return t("opNeedsChoice");
				case "failed": return record.reason !== void 0 ? localizeBilingual(record.reason, lang) : t("installFail");
				case "warned": return record.reason !== void 0 ? localizeBilingual(record.reason, lang) : t("opDone");
				case "done": return record.needsRefresh === true ? t("opDoneRefresh") : t("opDone");
			}
		}
		function OperationsPanel(props) {
			const { t, records, open } = props;
			const setOpen = props.onOpenChange;
			const wrapRef = (0, react.useRef)(null);
			const summary = summarize(records);
			const busy = summary.running + summary.queued > 0;
			const waitingOnHost = records.some((record) => record.hostOperationId !== void 0 && record.state === "queued" && record.waitSince !== void 0);
			const [, setClock] = (0, react.useState)(0);
			(0, react.useEffect)(() => {
				if (!waitingOnHost) return void 0;
				const timer = setInterval(() => setClock((value) => value + 1), 1e3);
				return () => clearInterval(timer);
			}, [waitingOnHost]);
			(0, react.useEffect)(() => {
				if (!open) return void 0;
				const onKey = (event) => {
					if (event.key === "Escape") setOpen(false);
				};
				const onPointer = (event) => {
					const wrap = wrapRef.current;
					if (wrap !== null && !wrap.contains(event.target)) setOpen(false);
				};
				document.addEventListener("keydown", onKey);
				document.addEventListener("mousedown", onPointer);
				return () => {
					document.removeEventListener("keydown", onKey);
					document.removeEventListener("mousedown", onPointer);
				};
			}, [open, setOpen]);
			const waitingOnAgents = summary.running === 0 && summary.blocked > 0;
			const batchLabel = waitingOnAgents ? t("opWaitingAgents").replace("{0}", String(summary.blocked)) : `${t("opInstalling")} ${String(summary.progressed)}/${String(summary.total)}`;
			const label = busy ? batchLabel : summary.attention > 0 ? `${String(summary.attention)} ${t("opNeedsYou")}` : t("opTitle");
			const quiet = records.length === 0 && !open;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.opWrap,
				ref: wrapRef,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
					type: "button",
					className: quiet ? `${Market_module_css_default.opEntry} ${Market_module_css_default.opEntryQuiet}` : summary.attention > 0 ? `${Market_module_css_default.opEntry} ${Market_module_css_default.opEntryAlert}` : Market_module_css_default.opEntry,
					"aria-expanded": open,
					onClick: () => setOpen(quiet ? true : !open),
					children: [
						!quiet && busy && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.spin,
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLoadingOutline16, { size: 12 })
						}),
						quiet ? t("opTitle") : label,
						!busy && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: open ? `${Market_module_css_default.opChevron} ${Market_module_css_default.opChevronOpen}` : Market_module_css_default.opChevron,
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 12 })
						}),
						!quiet && summary.attention > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.opDot })
					]
				}), open && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: Market_module_css_default.opPanel,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.opHead,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.opPanelTitle,
									children: t("opTitle")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow }),
								summary.settled > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									size: "sm",
									onClick: props.onClearSettled,
									children: t("opClear")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									size: "sm",
									"aria-label": t("opClose"),
									title: t("opClose"),
									className: Market_module_css_default.opCloseBtn,
									onClick: () => setOpen(false),
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, { size: 14 })
								})
							]
						}),
						busy && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.opAggregate,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.opAggregateTop,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: batchLabel })
								}),
								!waitingOnAgents && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.bar,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.barFill,
										style: { width: `${String(Math.round(summary.progressed / Math.max(1, summary.total) * 100))}%` }
									})
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.opAggregateHint,
									children: waitingOnAgents ? t("opLeaveHintAgents") : t("opLeaveHint")
								})
							]
						}),
						records.length === 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.opEmpty,
							children: [t("opEmpty"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.opEmptyHint,
								children: t("opEmptyHint")
							})]
						}),
						sortForPanel(records).map((record) => {
							const ahead = queuePosition(records, record.id);
							return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: needsUser(record) ? `${Market_module_css_default.opRow} ${Market_module_css_default.opRowAlert}` : Market_module_css_default.opRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.opIcon,
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(BucketIcon, { record })
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: Market_module_css_default.opMain,
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
												className: Market_module_css_default.opTop,
												children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: Market_module_css_default.opVerb,
													children: t(`opKind_${record.kind}`)
												}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: Market_module_css_default.opName,
													title: record.name,
													children: record.name
												})]
											}),
											record.state === "running" && typeof record.percent === "number" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
												className: Market_module_css_default.bar,
												children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
													className: Market_module_css_default.barFill,
													style: { width: `${String(record.percent)}%` }
												})
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
												className: bucketOf(record.state) === "attention" ? `${Market_module_css_default.opStatus} ${Market_module_css_default.opStatusBad}` : Market_module_css_default.opStatus,
												children: statusLine(t, props.lang, record, ahead)
											}),
											record.hostOperationId !== void 0 && record.state === "queued" && (record.blockedBy?.length ?? 0) > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("details", {
												className: Market_module_css_default.opAgents,
												children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("summary", {
													className: Market_module_css_default.opAgentsSummary,
													children: t("agentDrainShowAgents")
												}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("ul", {
													className: Market_module_css_default.opAgentsList,
													children: record.blockedBy.map((id) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("li", {
														className: Market_module_css_default.opAgentsId,
														title: id,
														children: id
													}, id))
												})]
											}),
											needsUser(record) && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ConflictChoice, {
												t,
												record,
												replacing: props.replacing,
												envReady: props.envReady,
												describe: props.describe,
												onResolve: (choice) => props.onResolveConflict(record, choice)
											})
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: Market_module_css_default.opActions,
										children: [
											record.state === "running" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												onClick: () => props.onCancel(record),
												children: t("cancelOp")
											}),
											record.state === "queued" && (record.hostOperationId !== void 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												onClick: () => props.onCancel(record),
												children: t("cancelOp")
											}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [props.onRunNow !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "primary",
												size: "sm",
												onClick: () => props.onRunNow?.(record),
												children: t(record.kind === "update" ? "opUpdateNow" : record.kind === "uninstall" ? "opUninstallNow" : "opRunNow")
											}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "ghost",
												size: "sm",
												onClick: () => props.onDismiss(record),
												children: t("opDequeue")
											})] })),
											record.state === "done" && record.needsRefresh === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "primary",
												size: "sm",
												onClick: props.onRefresh,
												children: t("refresh")
											}),
											record.state === "failed" && (record.blockedBuilds ?? []).length > 0 && props.onApproveBuilds !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "primary",
												size: "sm",
												onClick: () => props.onApproveBuilds?.(record),
												children: t("approveBuilds")
											}),
											record.state === "failed" && (record.blockedBuilds ?? []).length === 0 && props.onRetry !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												onClick: () => props.onRetry?.(record),
												children: t("opRetry")
											}),
											record.state === "warned" && record.heldRelease !== void 0 && props.onForceInstall !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												onClick: () => props.onForceInstall?.(record),
												children: t("heldReleaseAction").replace("{0}", record.heldRelease.latest)
											}),
											isSettled(record) && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "ghost",
												size: "sm",
												onClick: () => props.onDismiss(record),
												children: t("dismissNotice")
											})
										]
									})
								]
							}, record.id);
						})
					]
				})]
			});
		}
		//#endregion
		//#region src/client/RecoveryPanel.tsx
		/**
		* The failure prompt's way out: what to enable at the next start, after a
		* restart the market triggered never came back.
		*
		* The surface this talks to is not the host. When the replacement fails to
		* boot, DSH has already exited — its loader refuses the whole tree for one
		* bad entry — so the detached restart helper starts a small recovery server
		* on the SAME origin (src/recovery.ts). That is why every call here can use
		* the market's ordinary `api()` paths: the origin did not change, only the
		* process answering it. It is also why this module has to tolerate requests
		* that fail outright — the recovery server closes its listener for a moment
		* whenever it hands the port back to a boot attempt.
		*
		* Two surfaces read the same endpoints: this React panel inside the market
		* page (for the tab that clicked restart), and the standalone page the
		* recovery server renders at `/` (for a fresh visit, or when that tab is
		* gone).
		*/
		/**
		* The switch positions a surface OPENS on, taken straight from the payload.
		*
		* Extracted because this is the production initialisation both surfaces
		* depend on: the payload already carries the recommended position (off for a
		* plugin this boot blamed — see RecoveryPluginView.enabled in
		* src/recovery.ts), so the client's job is to copy it, not to re-derive it. A
		* test that hand-builds `keep` proves nothing about what a user actually
		* sees, which is how "unticked by default" shipped unimplemented once.
		* @param view - the recovery payload.
		* @returns the initial checkbox state, keyed by plugin name.
		*/
		function initialKeep(view) {
			return Object.fromEntries(view.plugins.map((plugin) => [plugin.name, plugin.enabled]));
		}
		/** Whether a payload really is the recovery surface's answer. */
		function isRecoveryView(value) {
			if (value === null || typeof value !== "object") return false;
			const candidate = value;
			return candidate.recovery === true && typeof candidate.failure === "object" && candidate.failure !== null && Array.isArray(candidate.plugins);
		}
		/**
		* Read the recovery surface, or null when the host (or nothing) answers.
		* @returns the view, or null.
		*/
		async function fetchRecovery() {
			try {
				const response = await fetch(api("/dsh-market/recovery"), { cache: "no-store" });
				if (!response.ok) return null;
				const body = await response.json();
				return isRecoveryView(body) ? body : null;
			} catch {
				return null;
			}
		}
		/**
		* Write the chosen enable set and ask for a boot.
		*
		* The full desired set travels, not a delta — see src/recovery.ts's
		* applyRecovery for why. A response is not guaranteed: the server closes
		* itself to free the port, so a thrown fetch is the SUCCESS path here, and
		* the caller's job is then to watch for the new boot.
		* @param enabled - plugin names to leave enabled at the next start.
		* @returns whether the write was accepted, with the reason when it was not.
		*/
		async function applyRecovery(enabled) {
			try {
				const response = await fetch(api("/dsh-market/recovery/apply"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({ enabled: [...enabled] })
				});
				const body = await response.json();
				if (response.status !== 200 || body.ok !== true) {
					const errors = Array.isArray(body.errors) ? body.errors.map(String) : [];
					return {
						ok: false,
						error: typeof body.error === "string" ? body.error : errors.join("; ")
					};
				}
				return { ok: true };
			} catch {
				return { ok: true };
			}
		}
		/**
		* Watch the origin through one restart attempt.
		*
		* Every outcome is a legitimate state of this window: the host coming up
		* (reload), the recovery server coming back with a NEW failure (re-render the
		* panel rather than pretend the first attempt is still the story), or silence
		* (the caller's timeout message). Failures of the fetch itself are not
		* failures at all — that is what a released port looks like.
		* @param previousBoot - the boot id the restart started from.
		* @param watch - the callbacks above.
		* @param deadlineMs - how long to keep looking.
		*/
		async function watchRestart(previousBoot, watch, deadlineMs = 3e5) {
			const deadline = Date.now() + deadlineMs;
			for (;;) {
				try {
					const body = await (await fetch(api("/dsh-market/status"), { cache: "no-store" })).json();
					if (body.recovery === true) {
						const view = await fetchRecovery();
						if (view !== null) {
							watch.onRecovery(view);
							return;
						}
					} else if (typeof body.boot === "string" && body.boot !== previousBoot) {
						watch.onBoot(body.boot);
						return;
					}
				} catch {}
				if (Date.now() > deadline) {
					watch.onTimeout();
					return;
				}
				await new Promise((resolve) => setTimeout(resolve, 1500));
			}
		}
		/**
		* The checklist itself.
		*
		* Red marks the plugins THIS boot named — not "recently changed", not "maybe
		* suspicious" — because the one question a user has here is "which one do I
		* untick", and an answer that is a guess is worse than no answer.
		*/
		function RecoveryPanel(props) {
			const { open, view, keep, busy, onToggle, onApply, onClose, t } = props;
			const blamed = (0, react.useMemo)(() => view.plugins.filter((plugin) => plugin.implicated), [view]);
			const openStandalone = (0, react.useCallback)(() => {
				window.open("/", "_blank", "noopener,noreferrer");
			}, []);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
				open,
				onClose,
				title: t("recoveryTitle"),
				description: t("recoveryLead"),
				footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						variant: "ghost",
						size: "sm",
						onClick: openStandalone,
						children: t("recoveryStandalone")
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						variant: "ghost",
						size: "sm",
						onClick: onClose,
						children: t("cancel")
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						variant: "primary",
						size: "sm",
						disabled: busy,
						onClick: onApply,
						children: busy ? t("recoveryApplying") : t("recoveryApply")
					})
				] }),
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.recoverySummary,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
							size: 14,
							className: Market_module_css_default.bannerIcon
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: view.failure.summary || t("recoveryNoSummary") })]
					}),
					view.lastErrors.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.recoverySummary,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
							size: 14,
							className: Market_module_css_default.bannerIcon
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [t("recoveryWriteFailed"), view.lastErrors.join("; ")] })]
					}),
					view.failure.tail !== "" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("details", {
						className: Market_module_css_default.recoveryLog,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("summary", { children: t("recoveryRawLog") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("pre", { children: view.failure.tail })]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.recoveryHint,
						children: blamed.length > 0 ? t("recoveryBlamedHint") : t("recoveryNoBlameHint")
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.recoveryList,
						children: view.plugins.map((plugin) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
							className: [
								Market_module_css_default.recoveryRow,
								plugin.implicated ? Market_module_css_default.recoveryBlamed : "",
								plugin.toggleable ? "" : Market_module_css_default.recoveryMuted
							].filter(Boolean).join(" "),
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: keep[plugin.name] ?? plugin.enabled,
								disabled: !plugin.toggleable,
								onChange: (event) => {
									onToggle(plugin.name, event.target.checked);
								}
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.recoveryName,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", { children: plugin.name }),
									plugin.carrier && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.recoveryBadge,
										children: t("recoveryCarrier")
									}),
									plugin.reason !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.recoveryReason,
										children: plugin.reason
									}),
									!plugin.toggleable && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.recoveryNote,
										children: plugin.note ?? t("recoveryNotToggleable")
									})
								]
							})]
						}, plugin.name))
					}),
					view.unmatched.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.recoveryNote,
						children: [
							t("recoveryUnmatched"),
							" ",
							view.unmatched.map((entry) => entry.name).join(", ")
						]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.recoveryNote,
						children: [
							t("recoveryLogPath"),
							" ",
							view.logPath
						]
					})
				]
			});
		}
		//#endregion
		//#region src/client/HostRecoveryBanner.tsx
		/**
		* #875: the way back from DSH's own fatal recovery.
		*
		* `sanitizeProfile` renames the profile patch to a `.bak-<epoch ms>` sibling
		* and writes a stub in its place, then boots normally — 22 KB of providers,
		* models and permission presets disappeared that way with nothing on screen
		* saying so. The server decides whether the shape is really the wipe
		* (`GET /dsh-market/host-recovery`); this banner is what the user sees when it
		* is, and it only appears then. Nothing else on the page changes, because for
		* every other profile this is not a thing that happened.
		*
		* Restoring is a single click, deliberately: it is undoable (the server
		* snapshots first and keeps the current file under a new `.bak` name), and a
		* confirmation here would be asking the user to judge something they cannot
		* see — the two patches side by side.
		*/
		function hostRecoveryOf(value) {
			if (value === null || typeof value !== "object") return null;
			const view = value;
			if (typeof view.offerRestore !== "boolean" || !Array.isArray(view.backups) || !Array.isArray(view.lostRowIds)) return null;
			const backups = [];
			for (const entry of view.backups) {
				if (entry === null || typeof entry !== "object") continue;
				const item = entry;
				if (typeof item.name !== "string" || typeof item.bytes !== "number") continue;
				backups.push({
					name: item.name,
					stamp: typeof item.stamp === "number" ? item.stamp : null,
					bytes: item.bytes,
					rowIds: Array.isArray(item.rowIds) ? item.rowIds.filter((id) => typeof id === "string") : []
				});
			}
			return {
				patchName: typeof view.patchName === "string" ? view.patchName : "cordis.patch.yml",
				currentBytes: typeof view.currentBytes === "number" ? view.currentBytes : 0,
				backups,
				lostRowIds: view.lostRowIds.filter((id) => typeof id === "string"),
				offerRestore: view.offerRestore
			};
		}
		/** "22.7 KB" / "1.2 MB" — the size is what makes the backup believable. */
		function formatBytes(bytes) {
			if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(1)} MB`;
			if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
			return `${bytes} B`;
		}
		function HostRecoveryBanner(props) {
			const { t, bootId } = props;
			const [view, setView] = (0, react.useState)(null);
			const [busy, setBusy] = (0, react.useState)(false);
			const [done, setDone] = (0, react.useState)(null);
			const [error, setError] = (0, react.useState)(null);
			const [dismissed, setDismissed] = (0, react.useState)(false);
			(0, react.useEffect)(() => {
				try {
					setDismissed(sessionStorage.getItem("dshm-host-recovery-dismissed") === String(bootId ?? ""));
				} catch {}
			}, [bootId]);
			const dismiss = (0, react.useCallback)(() => {
				setDismissed(true);
				try {
					sessionStorage.setItem("dshm-host-recovery-dismissed", String(bootId ?? ""));
				} catch {}
			}, [bootId]);
			(0, react.useEffect)(() => {
				let live = true;
				fetch(api("/dsh-market/host-recovery"), { cache: "no-store" }).then((res) => res.json()).then((body) => {
					if (live) setView(hostRecoveryOf(body));
				}).catch(() => {});
				return () => {
					live = false;
				};
			}, [bootId]);
			const restore = (0, react.useCallback)(() => {
				const newest = view?.backups[0];
				if (newest === void 0 || busy) return;
				setBusy(true);
				setError(null);
				fetch(api("/dsh-market/host-recovery/restore"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({ name: newest.name })
				}).then(async (res) => ({
					ok: res.ok,
					body: await res.json().catch(() => null)
				})).then(({ ok, body }) => {
					if (ok) setDone(typeof body?.restored?.rows === "number" ? body.restored.rows : 0);
					else setError(body?.error ?? "");
				}).catch(() => setError("network")).finally(() => setBusy(false));
			}, [busy, view]);
			if (dismissed) return null;
			if (done !== null) return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.banner,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: Market_module_css_default.grow,
					children: t("hostRecoveryRestored").replace("{0}", String(done))
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "primary",
					size: "sm",
					onClick: () => location.reload(),
					children: t("refresh")
				})]
			});
			if (view === null || !view.offerRestore) return null;
			const newest = view.backups[0];
			const when = newest?.stamp != null ? new Date(newest.stamp).toLocaleString() : "";
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.banner,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
						size: 14,
						className: Market_module_css_default.bannerIcon
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
						className: Market_module_css_default.grow,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: t("hostRecoveryTitle") }) }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { children: t("hostRecoveryBody").replace("{0}", String(view.lostRowIds.length)) }),
							newest !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.spec,
								children: [
									t("hostRecoverySource").replace("{0}", formatBytes(newest.bytes)).replace("{1}", when),
									" — ",
									t("hostRecoveryNote")
								]
							}),
							error !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.spec,
								children: [t("hostRecoveryFail"), error]
							})
						]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						variant: "primary",
						size: "sm",
						disabled: busy || newest === void 0,
						onClick: restore,
						children: busy ? t("backupWorking") : t("hostRecoveryRestore")
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						variant: "ghost",
						size: "sm",
						onClick: dismiss,
						children: t("dismiss")
					})
				]
			});
		}
		//#endregion
		//#region src/client/preset-panel.tsx
		/**
		* Diagnostics sub-panel — issue #98 phase 3 (plugin presets).
		*
		* Rendered at the bottom of the Diagnostics tab inside a collapsible section
		* (the parent keeps it mounted and passes `open`, so it lazy-loads on first
		* expand and keeps its state across collapses). Lists named presets
		* (GET /dsh-market/presets), saves the current community bundle order as a
		* new preset (POST /dsh-market/presets {action:'save', name, bundleOrder,
		* disabled}), applies one (action:'apply' — the host trial-validates and
		* auto-snapshots before writing; on success the parent refreshes the check
		* report) and deletes one after an inline double confirmation
		* (action:'delete').
		*
		* The list payload is read defensively (bare array or {presets: [...]}).
		*/
		async function postJson$1(url, body) {
			let res;
			try {
				res = await fetch(url, {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify(body)
				});
			} catch {
				return {
					status: 0,
					body: null
				};
			}
			let payload = null;
			try {
				payload = await res.json();
			} catch {}
			return {
				status: res.status,
				body: payload
			};
		}
		const errorText = (status, body, fallback) => body !== null && typeof body.error === "string" ? body.error : status === 0 ? fallback + "network error" : fallback + `HTTP ${String(status)}`;
		function PresetPanel(props) {
			const { t, open, bundleOrder, onRefresh } = props;
			const [presets, setPresets] = (0, react.useState)(null);
			const [error, setError] = (0, react.useState)(null);
			const [msg, setMsg] = (0, react.useState)(null);
			const [busy, setBusy] = (0, react.useState)(null);
			const [name, setName] = (0, react.useState)("");
			/** Preset name awaiting the second confirm click, or null. */
			const [confirmDelete, setConfirmDelete] = (0, react.useState)(null);
			/** Hidden <input type="file"> for the import action. */
			const loaded = (0, react.useRef)(false);
			const load = (0, react.useCallback)(() => {
				fetch(api("/dsh-market/presets"), { cache: "no-store" }).then((res) => res.json()).then((body) => {
					const list = Array.isArray(body) ? body : Array.isArray(body.presets) ? body.presets : [];
					setPresets(list.map((item) => {
						const preset = item ?? {};
						return {
							name: String(preset.name ?? ""),
							bundleOrder: Array.isArray(preset.bundleOrder) ? preset.bundleOrder.map(String) : [],
							disabled: Array.isArray(preset.disabled) ? preset.disabled.map(String) : []
						};
					}));
					setError(null);
					loaded.current = true;
				}).catch(() => setError(t("presetListFail") + "network"));
			}, [t]);
			(0, react.useEffect)(() => {
				if (open && !loaded.current) load();
			}, [open, load]);
			(0, react.useCallback)(() => {
				const presetName = name.trim();
				if (presetName === "") {
					setError(t("presetNameEmpty"));
					return;
				}
				if (busy !== null) return;
				setBusy("save");
				setMsg(null);
				setError(null);
				fetch(api("/dsh-market/installed"), { cache: "no-store" }).then((res) => res.json()).then((installed) => postJson$1(api("/dsh-market/presets"), {
					action: "save",
					name: presetName,
					bundleOrder,
					disabled: Array.isArray(installed.disabled) ? installed.disabled.map(String) : []
				})).then(({ status, body }) => {
					if (status >= 200 && status < 300 && body?.ok === true) {
						setName("");
						setMsg(t("presetSaved"));
						load();
					} else setError(errorText(status, body, t("presetFail")));
				}).catch(() => setError(t("presetFail") + "network")).finally(() => setBusy(null));
			}, [
				busy,
				bundleOrder,
				load,
				name,
				t
			]);
			const apply = (0, react.useCallback)((presetName) => {
				if (busy !== null) return;
				setBusy("apply");
				setMsg(null);
				setError(null);
				postJson$1(api("/dsh-market/presets"), {
					action: "apply",
					name: presetName
				}).then(({ status, body }) => {
					if (status >= 200 && status < 300 && body?.ok === true) {
						setMsg(t("presetApplied"));
						onRefresh();
					} else setError(errorText(status, body, t("presetFail")));
				}).catch(() => setError(t("presetFail") + "network")).finally(() => setBusy(null));
			}, [
				busy,
				onRefresh,
				t
			]);
			const remove = (0, react.useCallback)((presetName) => {
				if (busy !== null) return;
				setBusy("delete");
				setMsg(null);
				setError(null);
				postJson$1(api("/dsh-market/presets"), {
					action: "delete",
					name: presetName
				}).then(({ status, body }) => {
					if (status >= 200 && status < 300 && body?.ok === true) {
						setConfirmDelete(null);
						setMsg(t("presetDeleted"));
						load();
					} else setError(errorText(status, body, t("presetFail")));
				}).catch(() => setError(t("presetFail") + "network")).finally(() => setBusy(null));
			}, [
				busy,
				load,
				t
			]);
			/** Change preview of one preset: {reordered[], enabled[], disabled[], noop}. */
			const [previewed, setPreviewed] = (0, react.useState)(null);
			const preview = (0, react.useCallback)((presetName) => {
				if (busy !== null) return;
				setBusy("preview");
				setMsg(null);
				setError(null);
				if (previewed?.name === presetName) {
					setPreviewed(null);
					setBusy(null);
					return;
				}
				postJson$1(api("/dsh-market/presets"), {
					action: "preview",
					name: presetName
				}).then(({ status, body }) => {
					if (status >= 200 && status < 300 && body?.ok === true && body.changes !== null && typeof body.changes === "object") {
						const changes = body.changes;
						setPreviewed({
							name: presetName,
							changes: {
								reordered: Array.isArray(changes.reordered) ? changes.reordered.map(String) : [],
								enabled: Array.isArray(changes.enabled) ? changes.enabled.map(String) : [],
								disabled: Array.isArray(changes.disabled) ? changes.disabled.map(String) : [],
								noop: changes.noop === true
							}
						});
					} else setError(errorText(status, body, t("presetPreviewFail")));
				}).catch(() => setError(t("presetPreviewFail") + "network")).finally(() => setBusy(null));
			}, [
				busy,
				previewed,
				t
			]);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.orderPanel,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: Market_module_css_default.panelNote,
						children: t("presetHint")
					}),
					error !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.err,
						children: error
					}),
					presets === null || presets.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.diagEmpty,
						children: t("presetEmpty")
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.presetList,
						children: presets.map((preset) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.presetRow,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.confirmRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.presetName,
										children: preset.name
									}),
									preset.bundleOrder.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spec,
										children: t("presetBundleCount").replace("{0}", String(preset.bundleOrder.length))
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow }),
									confirmDelete === preset.name ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.confirmRow,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "primary",
											size: "sm",
											disabled: busy !== null,
											onClick: () => remove(preset.name),
											children: t("presetDelete")
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "ghost",
											size: "sm",
											disabled: busy !== null,
											onClick: () => setConfirmDelete(null),
											children: t("cancel")
										})]
									}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.confirmRow,
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: busy !== null,
												onClick: () => apply(preset.name),
												children: t("presetApply")
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "ghost",
												size: "sm",
												disabled: busy !== null,
												onClick: () => preview(preset.name),
												children: previewed?.name === preset.name ? t("cancel") : t("presetPreview")
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "ghost",
												size: "sm",
												disabled: busy !== null,
												onClick: () => setConfirmDelete(preset.name),
												children: t("presetDelete")
											})
										]
									})
								]
							}), previewed?.name === preset.name && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagList,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.diagKey,
									children: t("presetPreviewTitle")
								}), previewed.changes.noop ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.spec,
									children: t("presetNoop")
								}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.spec,
									children: [
										previewed.changes.reordered.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.warnLine,
											children: [
												t("presetReorder").replace("{0}", String(previewed.changes.reordered.length)),
												": ",
												previewed.changes.reordered.join(", ")
											]
										}),
										previewed.changes.enabled.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.warnLine,
											children: [
												t("presetEnable").replace("{0}", String(previewed.changes.enabled.length)),
												": ",
												previewed.changes.enabled.join(", ")
											]
										}),
										previewed.changes.disabled.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.warnLine,
											children: [
												t("presetDisable").replace("{0}", String(previewed.changes.disabled.length)),
												": ",
												previewed.changes.disabled.join(", ")
											]
										})
									]
								})]
							})]
						}, preset.name))
					}),
					msg !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.okState,
						children: msg
					})
				]
			});
		}
		//#endregion
		//#region src/client/snapshot-panel.tsx
		/**
		* Diagnostics sub-panel — issue #98 phase 3 (snapshots & rollback).
		*
		* Rendered at the bottom of the Diagnostics tab inside a collapsible section
		* (the parent keeps it mounted and passes `open`, so it lazy-loads on first
		* expand and keeps its state across collapses). Lists profile snapshots
		* (GET /dsh-market/snapshots), creates one (POST /dsh-market/snapshots) and
		* restores one after an inline double confirmation
		* (POST /dsh-market/restore-snapshot {snapshot}).
		*
		* The list payload is read defensively (bare array or {snapshots: [...]});
		* `files` entries are {path, json|lines} objects, from which only `path` is
		* displayed.
		*/
		async function postJson(url, body) {
			let res;
			try {
				res = await fetch(url, {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify(body)
				});
			} catch {
				return {
					status: 0,
					body: null
				};
			}
			let payload = null;
			try {
				payload = await res.json();
			} catch {}
			return {
				status: res.status,
				body: payload
			};
		}
		/** Snapshot file entries may be plain names or {path, json|lines} objects. */
		function fileNames(files) {
			if (!Array.isArray(files)) return [];
			const names = [];
			for (const file of files) if (typeof file === "string") names.push(file);
			else if (file !== null && typeof file === "object") {
				const path = file.path;
				if (typeof path === "string") names.push(path);
			}
			return names;
		}
		function snapshotOf(value) {
			if (value === null || typeof value !== "object") return null;
			const item = value;
			if (typeof item.id !== "string" && typeof item.id !== "number") return null;
			return {
				id: String(item.id),
				createdAt: typeof item.createdAt === "string" || typeof item.createdAt === "number" ? item.createdAt : 0,
				files: fileNames(item.files)
			};
		}
		function formatTime(value) {
			const date = new Date(value);
			return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString();
		}
		function SnapshotPanel(props) {
			const { t, open, onRefresh } = props;
			const [snapshots, setSnapshots] = (0, react.useState)(null);
			const [error, setError] = (0, react.useState)(null);
			const [msg, setMsg] = (0, react.useState)(null);
			const [busy, setBusy] = (0, react.useState)(null);
			/** Snapshot id awaiting the second confirm click (restore), or null. */
			const [confirmId, setConfirmId] = (0, react.useState)(null);
			/** Snapshot id awaiting the second confirm click (delete), or null. */
			const [confirmDeleteId, setConfirmDeleteId] = (0, react.useState)(null);
			const loaded = (0, react.useRef)(false);
			const load = (0, react.useCallback)(() => {
				fetch(api("/dsh-market/snapshots"), { cache: "no-store" }).then((res) => res.json()).then((body) => {
					const list = Array.isArray(body) ? body : Array.isArray(body.snapshots) ? body.snapshots : [];
					setSnapshots(list.map(snapshotOf).filter((snap) => snap !== null));
					setError(null);
					loaded.current = true;
				}).catch(() => setError(t("snapListFail") + "network"));
			}, [t]);
			(0, react.useEffect)(() => {
				if (open && !loaded.current) load();
			}, [open, load]);
			const create = (0, react.useCallback)(() => {
				if (busy !== null) return;
				setBusy("create");
				setMsg(null);
				setError(null);
				postJson(api("/dsh-market/snapshots"), {}).then(({ status, body }) => {
					if (status >= 200 && status < 300 && body?.ok === true) {
						setMsg(t("snapCreated"));
						load();
					} else {
						const detail = body !== null && typeof body.error === "string" ? body.error : status === 0 ? "network error" : `HTTP ${String(status)}`;
						setError(t("snapCreateFail") + detail);
					}
				}).catch(() => setError(t("snapCreateFail") + "network")).finally(() => setBusy(null));
			}, [
				busy,
				load,
				t
			]);
			const restore = (0, react.useCallback)((id) => {
				if (busy !== null) return;
				setBusy("restore");
				setMsg(null);
				setError(null);
				postJson(api("/dsh-market/restore-snapshot"), { snapshot: id }).then(({ status, body }) => {
					if (status >= 200 && status < 300 && body?.ok === true) {
						setConfirmId(null);
						setMsg(t("snapRestored"));
						onRefresh();
					} else {
						const detail = body !== null && typeof body.error === "string" ? body.error : status === 0 ? "network error" : `HTTP ${String(status)}`;
						setError(t("snapRestoreFail") + detail);
					}
				}).catch(() => setError(t("snapRestoreFail") + "network")).finally(() => setBusy(null));
			}, [
				busy,
				onRefresh,
				t
			]);
			/** Delete one snapshot after inline double confirmation. */
			const remove = (0, react.useCallback)((id) => {
				if (busy !== null) return;
				setBusy("delete");
				setMsg(null);
				setError(null);
				postJson(api("/dsh-market/delete-snapshot"), { snapshot: id }).then(({ status, body }) => {
					if (status >= 200 && status < 300 && body?.ok === true) {
						setConfirmDeleteId(null);
						setMsg(t("snapDeleted"));
						load();
					} else {
						const detail = body !== null && typeof body.error === "string" ? body.error : status === 0 ? "network error" : `HTTP ${String(status)}`;
						setError(t("snapDeleteFail") + detail);
					}
				}).catch(() => setError(t("snapDeleteFail") + "network")).finally(() => setBusy(null));
			}, [
				busy,
				load,
				t
			]);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.orderPanel,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: Market_module_css_default.panelNote,
						children: t("snapHint")
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.panelActions,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "primary",
							size: "sm",
							disabled: busy !== null,
							onClick: create,
							children: busy === "create" ? t("snapCreating") : t("snapCreate")
						})
					}),
					error !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.err,
						children: error
					}),
					snapshots === null || snapshots.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.diagEmpty,
						children: t("snapEmpty")
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.snapList,
						children: snapshots.map((snap) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.snapRow,
							children: confirmId === snap.id ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: Market_module_css_default.snapConfirmText,
								children: t("snapRestoreConfirmText")
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.confirmRow,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "primary",
									size: "sm",
									disabled: busy !== null,
									onClick: () => restore(snap.id),
									children: busy === "restore" ? t("snapRestoring") : t("snapRestoreConfirm")
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									size: "sm",
									disabled: busy !== null,
									onClick: () => setConfirmId(null),
									children: t("cancel")
								})]
							})] }) : confirmDeleteId === snap.id ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: Market_module_css_default.snapConfirmText,
								children: t("snapDeleteConfirmText")
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.confirmRow,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "primary",
									size: "sm",
									disabled: busy !== null,
									onClick: () => remove(snap.id),
									children: busy === "delete" ? t("snapDeleting") : t("snapDeleteConfirm")
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									size: "sm",
									disabled: busy !== null,
									onClick: () => setConfirmDeleteId(null),
									children: t("cancel")
								})]
							})] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.snapMeta,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.diagVal,
										children: formatTime(snap.createdAt)
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spec,
										children: snap.id
									}),
									snap.files.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("snapFiles"),
											": ",
											snap.files.join(", ")
										]
									})
								]
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.confirmRow,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									disabled: busy !== null,
									onClick: () => setConfirmId(snap.id),
									children: t("snapRestore")
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									size: "sm",
									disabled: busy !== null,
									onClick: () => setConfirmDeleteId(snap.id),
									children: t("snapDelete")
								})]
							})] })
						}, snap.id))
					}),
					msg !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.okState,
						children: msg
					})
				]
			});
		}
		//#endregion
		//#region src/client/Diagnostics.tsx
		/**
		* Diagnostics tab — issue #98: renders the profile composition check report
		* served by the host route /dsh-market/check (see src/check.ts). Below the
		* report sit the phase 2/3 action panels: a community-bundle ordering block
		* (reorder locally with ↑/↓, POST to /dsh-market/bundle-order) and a
		* snapshots & rollback panel (snapshot-panel.tsx) — collapsible, default
		* collapsed, and lazy-fetching on first expand. The plugin presets panel
		* ships in a later stacked PR.
		*
		* Read-only view of the loading-layer stack and the conflict surface: bundle
		* order (official vs community), duplicate loader entry ids, peer dependency
		* mismatches, multi-version core packages, overrides and orphan patches. The
		* report
		* shape mirrors the CheckReport interface in src/check.ts; it is re-declared
		* here because the client bundle is built independently of the host tree.
		*/
		/**
		* A collapsible report section: header shows title + count + chevron; the
		* body stays mounted (hidden via CSS when collapsed) so every block keeps
		* its state. ALL blocks are collapsed by default — the summary strip above
		* gives the overview, and a problem block's title is highlighted and its
		* collapsed `overview` line shows the first issue, so nothing important is
		* hidden. Expand a block to see its full content.
		*/
		function Section(props) {
			const { title, count, empty, defaultOpen, problem = true, overview, alwaysShowBody = false, children } = props;
			const [open, setOpen] = (0, react.useState)(defaultOpen ?? false);
			const alert = problem && count > 0;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
				className: Market_module_css_default.diagSection,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
						type: "button",
						className: Market_module_css_default.collapseHead,
						onClick: () => setOpen((o) => !o),
						"aria-expanded": open,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.collapseIcon,
								children: open ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronRightOutline14, { size: 14 })
							}),
							alert && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.diagAlert,
								children: "⚠"
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: `${Market_module_css_default.collapseTitle}${alert ? ` ${Market_module_css_default.diagAlert}` : ""}`,
								children: title
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.diagCount,
								children: [
									"(",
									count,
									")"
								]
							})
						]
					}),
					!open && overview !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.sectionOverview,
						children: overview
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.collapseBody,
						style: open ? void 0 : { display: "none" },
						children: count === 0 && !alwaysShowBody ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagEmpty,
							children: empty
						}) : children
					})
				]
			});
		}
		/** A collapsible section that KEEPS its children mounted (hidden via CSS when
		* collapsed) so the phase 3 panels below retain their loaded data and
		* in-progress edits across collapses. Children mount from the start, but the
		* panels only fetch when `open` first becomes true.
		*/
		function CollapsibleSection(props) {
			const { title, count, open, onToggle, children } = props;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
				className: Market_module_css_default.diagSection,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
					type: "button",
					className: Market_module_css_default.collapseHead,
					onClick: onToggle,
					"aria-expanded": open,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.collapseIcon,
							children: open ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronRightOutline14, { size: 14 })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.collapseTitle,
							children: title
						}),
						count !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
							className: Market_module_css_default.diagCount,
							children: [
								"(",
								count,
								")"
							]
						})
					]
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					className: Market_module_css_default.collapseBody,
					style: open ? void 0 : { display: "none" },
					children
				})]
			});
		}
		/** Map an orphan patch reason (src/check.ts) to a locale key for its badge. */
		function orphanKindLabel(reason) {
			if (reason === "insert is not an array") return "orphanInsertNotArray";
			if (reason === "insert target not found") return "orphanInsertTargetMissing";
			if (reason === "insert target is not a group") return "orphanInsertTargetNotGroup";
			if (reason === "id required for non-insert patch") return "orphanIdRequired";
			if (reason === "patch target not found") return "orphanPatchTargetMissing";
			if (reason.startsWith("name mismatch")) return "orphanNameMismatch";
			return "orphanReasonOther";
		}
		/** Badge label for one risk-tier peer row (#201). */
		function peerRiskLabel(peer, t) {
			return peer.verdict?.kind === "risk" && peer.verdict.risk.direction === "aboveMax" ? t("peerRiskAboveMax") : t("peerRiskBelowMin");
		}
		/** Badge label for one warning-tier peer row (optional / aboveMax / legacy). */
		function peerWarningLabel(peer, t) {
			if (peer.verdict?.kind !== "warning") return t("checkUnsatisfied");
			return peer.verdict.warning.reason === "optional" ? t("peerWarnOptional") : t("peerWarnAboveMax");
		}
		/**
		* Fetch and render the profile check report. Refetches on every mount, so
		* switching tabs away and back re-runs the (cheap, read-only) analysis; the
		* phase 3 panels below call `refresh()` after applying changes.
		*/
		function Diagnostics(props) {
			const { t } = props;
			const [report, setReport] = (0, react.useState)(null);
			const [error, setError] = (0, react.useState)(null);
			const [orderOpen, setOrderOpen] = (0, react.useState)(false);
			const [explainOpen, setExplainOpen] = (0, react.useState)(false);
			const [snapOpen, setSnapOpen] = (0, react.useState)(false);
			const [presetOpen, setPresetOpen] = (0, react.useState)(false);
			const [fixMsg, setFixMsg] = (0, react.useState)(null);
			/** The built AI-fix prompt when the clipboard path failed — rendered as a
			* selectable text block so the user can still copy it manually. */
			const [fixFallback, setFixFallback] = (0, react.useState)(null);
			/** Bump to re-run the /dsh-market/check fetch after an order/snapshot-restore apply. */
			const [version, setVersion] = (0, react.useState)(0);
			const refresh = (0, react.useCallback)(() => setVersion((v) => v + 1), []);
			/** Community bundle names from the report, in declared order. */
			const communityNames = (0, react.useMemo)(() => report === null ? [] : report.bundles.filter((bundle) => bundle.kind === "community").map((bundle) => bundle.name), [report]);
			/** Local editing state: re-synced whenever the report (re)loads. */
			const [order, setOrder] = (0, react.useState)(communityNames);
			const [orderMsg, setOrderMsg] = (0, react.useState)(null);
			const [orderErr, setOrderErr] = (0, react.useState)(null);
			const [orderBusy, setOrderBusy] = (0, react.useState)(false);
			/** Current-vs-candidate composition diff from a rejected static-composition
			* validation (#125 review): what the candidate would change, shown as a hint. */
			const [orderDiff, setOrderDiff] = (0, react.useState)(null);
			/**
			* Content identity of the last community order this draft synced to. A
			* refresh() refetch returns a NEW array even when the order is unchanged,
			* so a naive `setOrder(communityNames)` effect would wipe the user's
			* in-progress drag/↑↓ edits on every unrelated re-check. Only resync when
			* the report's community order actually CHANGED (apply order / snapshot
			* restore) — an identical refetch keeps the draft (review M2).
			*/
			const syncedOrderRef = (0, react.useRef)(null);
			(0, react.useEffect)(() => {
				const synced = syncedOrderRef.current;
				if (synced !== null && synced.length === communityNames.length && communityNames.every((name, i) => name === synced[i])) return;
				syncedOrderRef.current = communityNames;
				setOrder(communityNames);
			}, [communityNames]);
			/** Swap one community bundle with its neighbour (-1 up, +1 down). */
			const moveBundle = (index, delta) => {
				setOrder((prev) => {
					const next = [...prev];
					const target = index + delta;
					if (target < 0 || target >= next.length) return prev;
					[next[index], next[target]] = [next[target], next[index]];
					return next;
				});
			};
			/** Row being dragged (index into the local `order` draft). */
			const [dragIndex, setDragIndex] = (0, react.useState)(null);
			/** Row currently under the pointer, highlighted as the drop target. */
			const [dragOverIndex, setDragOverIndex] = (0, react.useState)(null);
			const onRowDragStart = (index) => (event) => {
				if (orderBusy) {
					event.preventDefault();
					return;
				}
				setDragIndex(index);
				event.dataTransfer?.setData?.("text/plain", order[index] ?? "");
				if (event.dataTransfer !== void 0) event.dataTransfer.effectAllowed = "move";
			};
			const onRowDragOver = (index) => (event) => {
				if (dragIndex === null || dragIndex === index) return;
				event.preventDefault();
				if (event.dataTransfer !== void 0) event.dataTransfer.dropEffect = "move";
				setDragOverIndex(index);
			};
			const onRowDragLeave = (index) => () => {
				setDragOverIndex((prev) => prev === index ? null : prev);
			};
			const onRowDrop = (index) => (event) => {
				event.preventDefault();
				const from = dragIndex;
				setDragIndex(null);
				setDragOverIndex(null);
				if (from === null || from === index) return;
				setOrder((prev) => {
					const next = [...prev];
					const [moved] = next.splice(from, 1);
					next.splice(index, 0, moved);
					return next;
				});
			};
			const onRowDragEnd = () => {
				setDragIndex(null);
				setDragOverIndex(null);
			};
			/** POST the current community order; the host statically validates the
			* candidate composition (dry-run replay) before writing. */
			const applyOrder = (target) => {
				if (orderBusy) return;
				setOrderBusy(true);
				setOrderMsg(null);
				setOrderErr(null);
				setOrderDiff(null);
				fetch(api("/dsh-market/bundle-order"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({ order: target ?? order })
				}).then(async (res) => {
					const body = await res.json().catch(() => null);
					if (!res.ok || body?.ok !== true) {
						const diff = body?.trial?.diff;
						const overrides = diff?.overrides?.length ?? 0;
						const orphans = diff?.orphans?.length ?? 0;
						const duplicates = diff?.duplicates?.length ?? 0;
						setOrderDiff(overrides + orphans + duplicates > 0 ? {
							overrides,
							orphans,
							duplicates
						} : null);
						const firstMessage = body?.trial?.errors?.[0]?.message;
						setOrderErr(body?.trial !== void 0 ? t("orderTrialFail").replace("{0}", firstMessage !== void 0 ? String(firstMessage) : "") : String(body?.error ?? `HTTP ${String(res.status)}`));
						return;
					}
					setOrderDiff(null);
					setOrderMsg(t("orderApplied"));
					refresh();
				}).catch((err) => setOrderErr(err instanceof Error ? err.message : String(err))).finally(() => setOrderBusy(false));
			};
			(0, react.useEffect)(() => {
				let live = true;
				setError(null);
				fetch(api("/dsh-market/check"), { cache: "no-store" }).then(async (res) => {
					if (!res.ok) throw new Error(`HTTP ${String(res.status)}`);
					const body = await res.json();
					if (live) setReport(body);
				}).catch((err) => {
					if (live) setError(err instanceof Error ? err.message : String(err));
				});
				return () => {
					live = false;
				};
			}, [version]);
			if (error !== null) return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.err,
				children: [t("checkLoadFail"), error]
			});
			if (report === null) return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.loading,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: Market_module_css_default.spin,
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLoadingOutline16, { size: 22 })
				}), t("checkLoading")]
			});
			const summary = report.summary;
			const suggested = report.suggestedOrder ?? null;
			const peerRisk = report.peerMismatches.filter((peer) => peer.satisfied === false && peer.verdict?.kind === "risk");
			const peerWarning = report.peerMismatches.filter((peer) => peer.satisfied === false && (peer.verdict === void 0 || peer.verdict.kind === "warning"));
			const peerInfo = report.peerMismatches.filter((peer) => peer.satisfied === false && peer.verdict?.kind === "none" || peer.satisfied === null);
			const peerSatisfied = report.peerMismatches.filter((peer) => peer.satisfied === true);
			const catConflict = report.duplicates.length;
			const catRisk = peerRisk.length;
			const catWarn = peerWarning.length;
			const catInfo = peerInfo.length;
			const catMulti = report.multiVersion.length;
			const catOrder = report.orderConflicts?.length ?? 0;
			const anyIssue = catConflict + catRisk + catWarn + catInfo + catMulti + catOrder > 0;
			const hasHardIssues = summary.errors.length > 0 || report.duplicates.length > 0 || catRisk > 0;
			/**
			* Build the AI-fix prompt (structured errors / duplicates / peer risks /
			* order conflicts + scope) and copy it to the clipboard. The user pastes it
			* into a new conversation and decides whether to send — the agent never runs
			* automatically.
			* (A previous auto-open/prefill attempt was dropped: it was unreliable
			* across host versions, so plain copy + toast is the contract.)
			*/
			const startAgentFix = () => {
				const lines = [];
				lines.push(t("aiFixIntro").replace("{0}", report.profile));
				lines.push("");
				lines.push(t("aiFixDetect"));
				lines.push("");
				lines.push(t("aiFixIfSelf"));
				lines.push("");
				const errorLines = summary.errors.filter((line) => !line.startsWith("duplicate loader entry id"));
				if (errorLines.length > 0) {
					lines.push(`${t("checkErrors")}:`);
					for (const e of errorLines) lines.push(`- ${e}`);
					lines.push("");
				}
				if (report.duplicates.length > 0) {
					lines.push(`${t("checkDuplicates")}:`);
					for (const dup of report.duplicates) lines.push(`- ${dup.id} × ${dup.count} (${dup.layers.join(" / ")})`);
					lines.push("");
				}
				if (peerRisk.length > 0) {
					lines.push(`${t("checkPeerRisk")}:`);
					for (const peer of peerRisk) {
						const direction = peer.verdict?.kind === "risk" && peer.verdict.risk.direction === "aboveMax" ? t("peerRiskAboveMax") : t("peerRiskBelowMin");
						lines.push(`- ${peer.plugin} → ${peer.name}@${peer.range} (${t("checkResolved")}: ${peer.resolved ?? "—"}, ${direction})`);
					}
					lines.push("");
				}
				if ((report.orderConflicts ?? []).length > 0) {
					lines.push(`${t("catOrder")}:`);
					for (const c of report.orderConflicts ?? []) lines.push(`- ${c.name}: ${c.reason}`);
					lines.push("");
				}
				lines.push(t("aiFixScope"));
				lines.push("");
				lines.push(t("aiFixConservative"));
				const prompt = lines.join("\n");
				setFixMsg(null);
				setFixFallback(null);
				const fallback = () => setFixFallback(prompt);
				if (typeof navigator.clipboard?.writeText === "function") navigator.clipboard.writeText(prompt).then(() => setFixMsg(t("aiFixCopied"))).catch(fallback);
				else fallback();
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.diagPage,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.diagSummary,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: summary.ok ? Market_module_css_default.okState : Market_module_css_default.err,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
									state: summary.ok ? "done" : "error",
									size: 8
								}), summary.ok ? anyIssue ? t("checkIssues") : t("diagOkAll") : t("checkIssues")]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.diagSummaryItem,
								title: t("checkDuplicates"),
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
										state: "error",
										size: 8
									}),
									t("catConflict"),
									": ",
									catConflict
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.diagSummaryItem,
								title: t("checkPeerRisk"),
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
										state: "error",
										size: 8
									}),
									t("catRisk"),
									": ",
									catRisk
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.diagSummaryItem,
								title: t("checkPeerWarning"),
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
										state: "warning",
										size: 8
									}),
									t("catWarn"),
									": ",
									catWarn
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.diagSummaryItem,
								title: t("checkPeerInfoTier"),
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
										state: "ongoing",
										size: 8
									}),
									t("catInfo"),
									": ",
									catInfo
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.diagSummaryItem,
								title: t("checkMultiVersion"),
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
										state: "warning",
										size: 8
									}),
									t("checkMultiVersion"),
									": ",
									catMulti
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.diagSummaryItem,
								title: t("checkOrderTip"),
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
										state: "warning",
										size: 8
									}),
									t("catOrder"),
									": ",
									catOrder
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow }),
							hasHardIssues && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "outline",
								size: "sm",
								onClick: startAgentFix,
								title: t("aiFixHint"),
								children: t("aiFix")
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "ghost",
								size: "sm",
								"aria-label": t("checkRefresh"),
								onClick: refresh,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconRefreshOutline14, { size: 14 })
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.diagSummaryMeta,
								title: report.profile,
								children: [
									t("checkProfile"),
									": ",
									report.profile
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.diagSummaryMeta,
								children: new Date(report.scannedAt).toLocaleString()
							})
						]
					}),
					fixMsg !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.okState,
						children: fixMsg
					}),
					fixFallback !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.fixFallback,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							className: Market_module_css_default.panelNote,
							children: t("aiFixFail")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
							readOnly: true,
							rows: 10,
							className: Market_module_css_default.fixFallbackText,
							value: fixFallback,
							onFocus: (e) => e.currentTarget.select()
						})]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)(CollapsibleSection, {
						title: t("diagExplain"),
						open: explainOpen,
						onToggle: () => setExplainOpen((o) => !o),
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							className: Market_module_css_default.panelNote,
							children: t("diagExplainText")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.diagList,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.spec,
									children: t("diagTermBundle")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.spec,
									children: t("diagTermEntry")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.spec,
									children: t("diagTermPeer")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.spec,
									children: t("diagTermShadow")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.spec,
									children: t("diagTermOrphan")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.spec,
									children: t("diagTermOrder")
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkErrors"),
						count: summary.errors.length,
						empty: t("checkErrorsEmpty"),
						overview: summary.errors.length > 0 ? summary.errors[0] : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: summary.errors.map((line, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.err,
								children: line
							}, i))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkWarnings"),
						count: summary.warnings.length,
						empty: t("checkWarningsEmpty"),
						overview: summary.warnings.length > 0 ? summary.warnings[0] : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: summary.warnings.map((line, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.warnLine,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: line })
							}, i))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkBundles"),
						count: report.bundles.length,
						empty: t("checkBundlesEmpty"),
						problem: false,
						overview: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [
							t("checkOfficial"),
							" × ",
							report.bundles.filter((b) => b.kind === "official").length,
							" · ",
							t("checkCommunity"),
							" × ",
							report.bundles.filter((b) => b.kind === "community").length
						] }),
						children: report.bundles.map((bundle, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.diagBundle,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.diagRow,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.diagIndex,
											children: i + 1
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.diagArrow,
											children: "→"
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.nm,
											children: bundle.name
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: bundle.kind === "official" ? Market_module_css_default.diagBadgeOfficial : Market_module_css_default.diagBadgeCommunity,
											children: bundle.kind === "official" ? t("checkOfficial") : t("checkCommunity")
										}),
										bundle.error !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.err,
											children: bundle.error
										}),
										bundle.parseError !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
											className: Market_module_css_default.err,
											children: [
												t("checkPatch"),
												": ",
												bundle.parseError
											]
										})
									]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.diagMeta,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.diagKey,
										children: t("checkSource")
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.spec,
										children: bundle.source
									})]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.diagMeta,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.diagKey,
										children: t("checkEntries")
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.spec,
										children: bundle.entries.length > 0 ? bundle.entries.join(", ") : "—"
									})]
								}),
								bundle.directory !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.diagMeta,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.diagKey,
										children: t("checkDir")
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.spec,
										children: bundle.directory
									})]
								}),
								bundle.patchPath !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.diagMeta,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.diagKey,
										children: t("checkPatch")
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.spec,
										children: bundle.patchPath
									})]
								})
							]
						}, bundle.name))
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkDuplicates"),
						count: report.duplicates.length,
						empty: t("checkDuplicatesEmpty"),
						overview: report.duplicates.length > 0 ? `${report.duplicates[0]?.id} × ${report.duplicates[0]?.count}` : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: report.duplicates.map((dup) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.diagVal,
										children: dup.id
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.err,
										children: ["× ", dup.count]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spec,
										children: dup.layers.join(" / ")
									})
								]
							}, dup.id))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkPeerRisk"),
						count: peerRisk.length,
						empty: t("checkPeerRiskEmpty"),
						overview: peerRisk.length > 0 ? `${peerRisk[0].plugin} → ${peerRisk[0].name}@${peerRisk[0].range}（${t("checkResolved")}: ${peerRisk[0].resolved ?? "—"}）` : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: peerRisk.map((peer, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.diagVal,
										children: peer.name
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.nm,
										children: peer.plugin
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("checkRange"),
											": ",
											peer.range
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("checkResolved"),
											": ",
											peer.resolved ?? "—"
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.diagBadgeShadow,
										children: peerRiskLabel(peer, t)
									})
								]
							}, i))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkPeerWarning"),
						count: peerWarning.length,
						empty: t("checkPeerWarningEmpty"),
						overview: peerWarning.length > 0 ? `${peerWarning[0].plugin} → ${peerWarning[0].name}@${peerWarning[0].range}（${peerWarningLabel(peerWarning[0], t)}）` : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: peerWarning.map((peer, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.diagVal,
										children: peer.name
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.nm,
										children: peer.plugin
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("checkRange"),
											": ",
											peer.range
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("checkResolved"),
											": ",
											peer.resolved ?? "—"
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.diagBadgeWarn,
										children: peerWarningLabel(peer, t)
									})
								]
							}, i))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkPeerInfoTier"),
						count: peerInfo.length,
						empty: t("checkPeerInfoTierEmpty"),
						problem: false,
						overview: peerInfo.length > 0 ? `${peerInfo[0].plugin} → ${peerInfo[0].name}@${peerInfo[0].range}` : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: peerInfo.map((peer, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.diagVal,
										children: peer.name
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.nm,
										children: peer.plugin
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("checkRange"),
											": ",
											peer.range
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("checkResolved"),
											": ",
											peer.resolved ?? "—"
										]
									}),
									peer.satisfied === null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.diagBadgeInfo,
										children: t("checkUnknown")
									}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.diagBadgeInfo,
										children: t("peerInfoUnverified")
									})
								]
							}, i))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkPeerSatisfied"),
						count: peerSatisfied.length,
						empty: t("checkPeerSatisfiedEmpty"),
						problem: false,
						overview: peerSatisfied.length > 0 ? `${peerSatisfied[0].plugin} → ${peerSatisfied[0].name}@${peerSatisfied[0].range}` : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: peerSatisfied.map((peer, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.diagVal,
										children: peer.name
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.nm,
										children: peer.plugin
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("checkRange"),
											": ",
											peer.range
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("checkResolved"),
											": ",
											peer.resolved ?? "—"
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.okState,
										children: t("checkSatisfied")
									})
								]
							}, i))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkMultiVersion"),
						count: report.multiVersion.length,
						empty: t("checkMultiEmpty"),
						overview: report.multiVersion.length > 0 ? `${report.multiVersion[0]?.name}: ${report.multiVersion[0]?.versions.join(" / ")}` : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: report.multiVersion.map((mv) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.diagVal,
										children: mv.name
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spec,
										children: mv.versions.join(" / ")
									}),
									mv.hoisted !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.spec,
										children: [
											t("checkHoisted"),
											": ",
											mv.hoisted
										]
									})
								]
							}, mv.name))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkOverrides"),
						count: report.overrides.length,
						empty: t("checkOverridesEmpty"),
						overview: report.overrides.length > 0 ? `${report.overrides[0]?.id} ← ${report.overrides[0]?.layer}` : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: report.overrides.map((ov, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.ovRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.diagVal,
										children: ov.id
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.ovArrow,
										children: "←"
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.ovByTag,
										children: ov.layer
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spec,
										children: t("checkOverridden")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.ovFrom,
										children: ov.overriddenLayers.join(", ")
									})
								]
							}, i))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Section, {
						title: t("checkOrphans"),
						count: report.orphans.length,
						empty: t("checkOrphansEmpty"),
						overview: report.orphans.length > 0 ? `${report.orphans[0]?.id}（${t(orphanKindLabel(report.orphans[0]?.reason ?? ""))}）` : void 0,
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: report.orphans.map((orphan, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.orphRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.orphBadge,
										children: t(orphanKindLabel(orphan.reason))
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.diagVal,
										children: orphan.id
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.nm,
										children: orphan.layer
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spec,
										children: orphan.reason
									})
								]
							}, i))
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)(Section, {
						title: t("checkResiduals"),
						count: report.residuals?.length ?? 0,
						empty: t("checkResidualsEmpty"),
						problem: false,
						overview: report.residuals?.[0]?.path,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							className: Market_module_css_default.panelNote,
							children: t("checkResidualsHint")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: (report.residuals ?? []).map((residual) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagRow,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.nm,
										children: residual.name
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spec,
										children: t(residual.kind === "tmp-directory" ? "checkResidualTmp" : "checkResidualIncomplete")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.diagVal,
										children: residual.path
									})
								]
							}, residual.path))
						})]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)(Section, {
						title: t("checkConfigNamespaces"),
						count: report.configNamespaces?.length ?? 0,
						empty: t("checkConfigNamespacesEmpty"),
						overview: report.configNamespaces?.[0]?.name,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							className: Market_module_css_default.panelNote,
							children: t("checkConfigNamespacesHint")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.diagList,
							children: (report.configNamespaces ?? []).map((finding) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagRow,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.nm,
									children: finding.name
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
									className: Market_module_css_default.spec,
									children: [
										finding.namespaces.map((namespace) => t("checkConfigNamespaceRow").replace("{0}", namespace)).join("；"),
										" — ",
										finding.ownEntryIds.length > 0 ? `${t("checkConfigNamespaceOwn")}: ${finding.ownEntryIds.join(", ")}` : t("checkConfigNamespaceNone")
									]
								})]
							}, finding.name))
						})]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)(CollapsibleSection, {
						title: t("orderSection"),
						count: order.length,
						open: orderOpen,
						onToggle: () => setOrderOpen((o) => !o),
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: Market_module_css_default.panelNote,
								children: t("orderDragHint")
							}),
							report.orderConflicts !== void 0 && report.orderConflicts.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagList,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.diagKey,
									children: t("orderConflicts")
								}), report.orderConflicts.map((conflict, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.warnLine,
									children: [
										conflict.name,
										" — ",
										conflict.reason
									]
								}, i))]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								style: {
									display: "flex",
									alignItems: "center",
									gap: 8,
									flexWrap: "wrap"
								},
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "primary",
										size: "sm",
										disabled: order.length === 0 || orderBusy,
										onClick: () => applyOrder(),
										children: orderBusy ? "…" : t("orderApply")
									}),
									suggested !== null && suggested.ok === true && suggested.order.join("\0") !== communityNames.join("\0") && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "outline",
										size: "sm",
										disabled: orderBusy,
										onClick: () => applyOrder(suggested.order),
										children: t("orderSuggestApply")
									}),
									suggested !== null && suggested.ok === true && suggested.order.join("\0") === communityNames.join("\0") && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.okState,
										children: t("orderAlreadyOptimal")
									}),
									order.join("\0") !== communityNames.join("\0") && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "ghost",
										size: "sm",
										disabled: orderBusy,
										onClick: () => setOrder(communityNames),
										children: t("orderReset")
									}),
									orderMsg !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.okState,
										children: orderMsg
									}),
									orderErr !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.err,
										children: orderErr
									})
								]
							}),
							orderDiff !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.panelNote,
								children: t("orderDiffHint").replace("{0}", String(orderDiff.overrides)).replace("{1}", String(orderDiff.orphans)).replace("{2}", String(orderDiff.duplicates))
							}),
							suggested !== null && suggested.ok === false && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.warnLine,
								children: [
									t("orderSuggestHint"),
									" ⚠ ",
									suggested.cycle.join(" → ")
								]
							}),
							report.duplicateNames !== void 0 && report.duplicateNames.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.diagList,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.diagKey,
									children: t("duplicateNames")
								}), report.duplicateNames.map((dup, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.panelNote,
									children: [
										dup.name,
										" × ",
										dup.count,
										" — ",
										dup.layers.join(" / ")
									]
								}, i))]
							}),
							order.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.diagEmpty,
								children: "—"
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.diagList,
								children: order.map((name, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									draggable: !orderBusy,
									className: [
										Market_module_css_default.diagRow,
										dragIndex === i ? Market_module_css_default.dragging : "",
										dragOverIndex === i ? Market_module_css_default.dragOver : ""
									].filter(Boolean).join(" "),
									onDragStart: onRowDragStart(i),
									onDragOver: onRowDragOver(i),
									onDragLeave: onRowDragLeave(i),
									onDrop: onRowDrop(i),
									onDragEnd: onRowDragEnd,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.dragHandle,
											"aria-label": t("orderDrag"),
											title: t("orderDrag"),
											children: "⠿"
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.diagIndex,
											children: i + 1
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.nm,
											children: name
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow }),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "ghost",
											size: "sm",
											draggable: false,
											"aria-label": t("orderUp"),
											disabled: i === 0 || orderBusy,
											onClick: () => moveBundle(i, -1),
											children: t("orderUp")
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "ghost",
											size: "sm",
											draggable: false,
											"aria-label": t("orderDown"),
											disabled: i >= order.length - 1 || orderBusy,
											onClick: () => moveBundle(i, 1),
											children: t("orderDown")
										})
									]
								}, name))
							})
						]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(CollapsibleSection, {
						title: t("presetSection"),
						open: presetOpen,
						onToggle: () => setPresetOpen((o) => !o),
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(PresetPanel, {
							t,
							open: presetOpen,
							bundleOrder: order,
							onRefresh: refresh
						})
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(CollapsibleSection, {
						title: t("snapSection"),
						open: snapOpen,
						onToggle: () => setSnapOpen((o) => !o),
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(SnapshotPanel, {
							t,
							open: snapOpen,
							onRefresh: refresh
						})
					})
				]
			});
		}
		//#endregion
		//#region src/client/self-check.ts
		/**
		* What the browser can see about the market that the server cannot.
		*
		* This exists because of a pattern, not a hypothesis. #293 ("市场显示空白")
		* and #384 ("lightbox cannot be closed") are both reproducible for their
		* reporters and for nobody else, on clean profiles, across host versions.
		* Both investigations then stalled in the same place: I asked the reporter to
		* open a console and paste the result of an expression. That costs a day per
		* question, asks a non-developer to run code from a stranger, and is the one
		* step where a report goes quiet.
		*
		* Meanwhile the exported log — which the issue template already asks for, and
		* which reporters do send — describes only the server: dependencies, bundle
		* resolution, events. Everything it says was already true of a machine where
		* the bug does not happen. The interesting half was in a page nobody looked
		* at.
		*
		* So the browser answers the questions I have actually had to ask, in the
		* artefact people already know how to produce. Nothing here diagnoses
		* anything on its own; it is evidence, collected before it is needed.
		*/
		/**
		* Download the exported log: the server's account plus what only the browser
		* can see.
		*
		* A free function rather than a hook, because the market's error boundary
		* has to offer it too — a crashed market is exactly when the log matters,
		* and for months it was exactly when the button did not exist (#293).
		* @throws when the server half cannot be fetched; callers show their own state.
		*/
		async function exportMarketLog() {
			const res = await fetch(api("/dsh-market/logs"));
			if (!res.ok) throw new Error(`HTTP ${String(res.status)}`);
			const serverText = await res.text();
			const browser = clientDiagnostics();
			const blob = new Blob([serverText, ...browser.length > 0 ? [
				"## browser\n",
				browser.join("\n"),
				"\n"
			] : []], { type: "text/plain;charset=utf-8" });
			const url = URL.createObjectURL(blob);
			const anchor = document.createElement("a");
			anchor.href = url;
			anchor.download = "dsh-market-log.txt";
			document.body.appendChild(anchor);
			anchor.click();
			anchor.remove();
			URL.revokeObjectURL(url);
		}
		/**
		* How many times this module has been evaluated in this page.
		*
		* Module scope runs once per module instance, so >1 means the market's client
		* bundle was loaded twice — two React copies, two of every module singleton,
		* two portal containers. That is a specific hypothesis for #384: two React
		* roots each attach delegated listeners to their own portal container, and a
		* click lands on whichever container is last in `body` while the handlers
		* live on the other one, so the buttons look present and do nothing.
		*
		* Counted on `window` rather than in a module variable for the obvious
		* reason: a module variable would be duplicated along with everything else
		* and each copy would confidently report 1.
		*/
		const globals = globalThis;
		globals.__dshmarketClientLoads = (globals.__dshmarketClientLoads ?? 0) + 1;
		/**
		* The marks Chrome and Edge leave on `<html>` when they translate a page.
		*
		* Both add a `translated-*` class for the direction they rendered into; Edge
		* also flags the document it worked on. Reported verbatim rather than
		* reduced to a boolean, because which engine did it is the next question
		* after "was it translated at all".
		* @returns the marks found, or null when there are none.
		*/
		function translatedMarks() {
			const root = document.documentElement;
			const marks = [
				...[...root.classList].filter((name) => name.startsWith("translated")),
				...root.hasAttribute("_msthash") ? ["edge (_msthash)"] : [],
				...root.hasAttribute("_msttexthash") ? ["edge (_msttexthash)"] : []
			];
			return marks.length === 0 ? null : marks.join(", ");
		}
		/** The market crash the error boundary caught, if there was one. */
		function crashLines() {
			const crash = lastMarketCrash();
			if (crash === null) return [];
			return [
				`market UI crashed at: ${crash.at}`,
				`market crash message: ${crash.message}`,
				...crash.stack === null ? [] : [`market crash component stack:${crash.stack}`]
			];
		}
		/** Whether `value` looks like a browser environment worth inspecting. */
		const hasDom = () => typeof document !== "undefined" && document.body !== null;
		/**
		* The browser-side section of the exported log.
		*
		* Deliberately facts, not verdicts. "portal containers: 2" is something a
		* reporter can paste without judging it, and something I can act on; "your
		* bundle is double-loaded" would be a guess printed in the user's face, and
		* wrong the first time a host legitimately renders two markets.
		* @returns the lines to append, or an empty array outside a browser.
		*/
		function clientDiagnostics() {
			if (!hasDom()) return [];
			const portals = document.querySelectorAll("[data-dsh-market-portal]");
			const roots = document.querySelectorAll("[data-dsh-market-root]");
			const last = portals.length > 0 ? portals[portals.length - 1] : null;
			return [
				`client bundle evaluations: ${String(globals.__dshmarketClientLoads ?? 0)}`,
				`market roots in the document: ${String(roots.length)}`,
				`portal containers: ${String(portals.length)}` + (last === null ? "" : ` (last one is body's last child: ${String(last === document.body.lastElementChild)})`),
				`plugin cards rendered: ${String(document.querySelectorAll("[data-dsh-market-root] [class*=\"_card\"]").length)}`,
				`page translated by the browser: ${translatedMarks() ?? "no"}`,
				`document baseURI: ${document.baseURI}`,
				`page URL: ${location.origin}${location.pathname}`,
				...crashLines(),
				`user agent: ${navigator.userAgent}`
			];
		}
		//#endregion
		//#region src/client/MarketSection.tsx
		/**
		* The Market settings section: Discover / Favorites / Themes / Installed tabs over the
		* /dsh-market/* host routes, with install/update/uninstall flows and the
		* pending-restart bookkeeping in sessionStorage.
		*/
		function isHostDependencyFinding(value) {
			if (value === null || typeof value !== "object") return false;
			const finding = value;
			return finding.code === "shared-host-package-dependency" && finding.severity === "warning" && finding.subject?.kind === "package" && typeof finding.subject.name === "string" && finding.evidence?.basis === "manifest-declaration" && typeof finding.evidence?.dependency === "string" && typeof finding.evidence.declaredRange === "string" && finding.evidence.declaredIn === "dependencies";
		}
		const HOST_DEPENDENCY_PREVIEW_LIMIT = 5;
		/** After this long without a structured phase, the install line adds a note that waiting is normal (#1011). */
		const SLOW_INSTALL_SECONDS = 90;
		/** How long the page keeps asking for a market DSH unloaded, and how long one ask may take (#1151). */
		const RECONNECT_BUDGET_MS = 9e4;
		const RECONNECT_REQUEST_MS = 4e3;
		const IGNORED_UPDATES_SESSION_KEY = "dshm-updates-ignored";
		const UNAVAILABLE_HOST_COMPATIBILITY = {
			status: "unknown",
			basis: "unavailable",
			requirement: null,
			declarations: []
		};
		/**
		* Read the update reminders dismissed for this host process. The boot id is
		* part of the value rather than the key so sessionStorage never accumulates
		* one orphaned entry per process. Invalid and stale records fail open: an
		* update reminder is safer than silently hiding one we cannot account for.
		*/
		function ignoredUpdatesForBoot(boot) {
			const saved = readSession(IGNORED_UPDATES_SESSION_KEY);
			if (!(saved !== null && typeof saved === "object" && !Array.isArray(saved) && saved.boot === boot && Array.isArray(saved.names) && saved.names.every((name) => typeof name === "string" && name !== ""))) {
				try {
					sessionStorage.removeItem(IGNORED_UPDATES_SESSION_KEY);
				} catch {}
				return [];
			}
			return [...new Set(saved.names)];
		}
		function HostDependencyDiagnostics({ findings, t }) {
			if (findings.length === 0) return null;
			const preview = findings.slice(0, HOST_DEPENDENCY_PREVIEW_LIMIT);
			const remaining = findings.length - preview.length;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.banner,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
					size: 14,
					className: Market_module_css_default.bannerIcon
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
					className: Market_module_css_default.grow,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { children: t("hostDependencyWarning") }),
						preview.map((finding) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.spec,
							children: [
								finding.subject.name,
								" → ",
								finding.evidence.dependency,
								"@",
								finding.evidence.declaredRange
							]
						}, `${finding.subject.name}:${finding.evidence.dependency}`)),
						remaining > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.spec,
							children: t("hostDependencyMore").replace("{0}", String(remaining))
						})
					]
				})]
			});
		}
		/** The state label + dot for one activation result (P0-2). */
		function activationMeta(state, t, dependencyOf, loadedByProfile, library) {
			if (library === true) return {
				label: t("stateLibrary"),
				dot: "done"
			};
			if (state === "inert" && loadedByProfile === true) return {
				label: t("stateLoadedByProfile"),
				dot: "done"
			};
			if (state === "inert" && dependencyOf !== void 0) return {
				label: t("stateDependencyLibrary").replace("{0}", dependencyOf),
				dot: "done"
			};
			if (state === "live") return {
				label: t("stateLive"),
				dot: "done"
			};
			if (state === "restart") return {
				label: t("stateRestart"),
				dot: "warning"
			};
			if (state === "incompatible") return {
				label: t("stateIncompatible"),
				dot: "error"
			};
			if (state === "inert") return {
				label: t("stateInert"),
				dot: "warning"
			};
			if (state === "broken") return {
				label: t("stateBroken"),
				dot: "error"
			};
			if (state === "failed") return {
				label: t("stateFailed"),
				dot: "error"
			};
			if (state === "disabled") return {
				label: t("stateDisabled"),
				dot: "warning"
			};
			return {
				label: "—",
				dot: "warning"
			};
		}
		function phaseLabel(phase, t) {
			if (phase === "resolving") return t("phaseResolving");
			if (phase === "downloading") return t("phaseDownloading");
			if (phase === "linking") return t("phaseLinking");
			return t("phaseBuilding");
		}
		/**
		* Page/page-size state shared by every paged list in this file (Discover,
		* Themes) — each caller owns its OWN instance (their filters are
		* independent, a search in one tab has no business resetting the other's
		* page), but the mechanics (clamp against a shrinking list, reset to page 1
		* when the filters that produced `count` change, scroll back to the top of
		* the shared body on any page move) are one implementation, not two.
		*/
		function usePagination(count, resetDeps, scrollToTop) {
			const [page, setPage] = (0, react.useState)(1);
			const [pageSize, setPageSize] = (0, react.useState)(DEFAULT_PAGE_SIZE);
			(0, react.useEffect)(() => {
				setPage(1);
			}, resetDeps);
			const totalPages = Math.max(1, Math.ceil(count / pageSize));
			const currentPage = Math.min(page, totalPages);
			const goToPage = (next) => {
				setPage(Math.max(1, Math.min(next, totalPages)));
				scrollToTop();
			};
			const changePageSize = (size) => {
				setPageSize(size);
				setPage(1);
				scrollToTop();
			};
			return {
				currentPage,
				totalPages,
				pageSize,
				goToPage,
				changePageSize
			};
		}
		/**
		* A growing window for the Plugins page tab.
		*
		* The catalog is already in memory; the page number existed to cap the DOM.
		* On a page that scrolls with the host, turning the page jumps back to the
		* top. Appending a chunk leaves the reader where they are. A filter change
		* starts over, the same moment `usePagination` returns to page 1.
		*/
		function useShownCount(count, resetDeps, chunk) {
			const [limit, setLimit] = (0, react.useState)(chunk);
			(0, react.useEffect)(() => {
				setLimit(chunk);
			}, resetDeps);
			const shown = Math.min(count, limit);
			return {
				shown,
				more: Math.max(0, count - shown),
				loadMore: () => {
					setLimit((current) => current + chunk);
				}
			};
		}
		/**
		* The sort/time-range dropdown (primitives Menu): three independent option
		* groups, ids namespaced so one onSelect routes by prefix. Owns its own
		* open state — a caller wires only the sort VALUES, not the dropdown's UI
		* state, so Discover and Themes can each mount one without threading an
		* extra `filterOpen`/`setFilterOpen` pair through their own state.
		*/
		function FilterMenu({ sortField, sortDir, timeRange, hostVersion, compatibleWithHost, onSortField, onSortDir, onTimeRange, onCompatibleWithHost, t }) {
			const [open, setOpen] = (0, react.useState)(false);
			const sortDirLabel = (dir) => sortField === "added" ? dir === "desc" ? "sortNewest" : "sortOldest" : dir === "desc" ? "sortDesc" : "sortAsc";
			const items = (0, react.useMemo)(() => [
				{
					type: "label",
					id: "f-sort",
					text: t("filterSort")
				},
				...SORT_FIELD_OPTIONS.map((opt) => ({
					id: "field:" + opt.key,
					label: t(opt.label)
				})),
				{
					type: "separator",
					id: "f-sep1"
				},
				{
					type: "label",
					id: "f-dir",
					text: t("filterDir")
				},
				...SORT_DIR_OPTIONS.map((dir) => ({
					id: "dir:" + dir,
					label: t(sortDirLabel(dir))
				})),
				{
					type: "separator",
					id: "f-sep2"
				},
				{
					type: "label",
					id: "f-time",
					text: t("filterTime")
				},
				...TIME_OPTIONS.map((opt) => ({
					id: "time:" + opt.key,
					label: t(opt.label)
				})),
				...onCompatibleWithHost === void 0 ? [] : [
					{
						type: "separator",
						id: "f-sep3"
					},
					{
						type: "label",
						id: "f-host",
						text: t("filterHost")
					},
					{
						id: "host:all",
						label: t("hostAll")
					},
					{
						id: "host:compatible",
						label: hostVersion === void 0 ? t("hostDetecting") : hostVersion === null ? t("hostUnknown") : t("hostCompatible").replace("{0}", hostVersion)
					}
				]
			], [
				t,
				sortField,
				hostVersion,
				onCompatibleWithHost
			]);
			const selectedIds = (0, react.useMemo)(() => [
				"field:" + sortField,
				"dir:" + sortDir,
				"time:" + timeRange,
				...onCompatibleWithHost === void 0 ? [] : [compatibleWithHost === true ? "host:compatible" : "host:all"]
			], [
				sortField,
				sortDir,
				timeRange,
				compatibleWithHost,
				onCompatibleWithHost
			]);
			const onSelect = (id) => {
				if (id.startsWith("field:")) onSortField(id.slice(6));
				else if (id.startsWith("dir:")) onSortDir(id.slice(4));
				else if (id.startsWith("time:")) onTimeRange(id.slice(5));
				else if (id === "host:all") onCompatibleWithHost?.(false);
				else if (id === "host:compatible" && typeof hostVersion === "string") onCompatibleWithHost?.(true);
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
				open,
				onClose: () => setOpen(false),
				onSelect,
				selectedIds,
				align: "end",
				portal: true,
				anchor: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "outline",
					size: "sm",
					icon: open ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 }),
					onClick: () => setOpen((o) => !o),
					children: t("filter")
				}),
				items
			});
		}
		/** Keep an empty search actionable without changing the user's sort or block list. */
		function EmptyResults({ blocked, onClear, t }) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.empty,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { children: t(blocked ? "blockedFilteredEmpty" : "empty") }), onClear && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "outline",
					size: "sm",
					className: Market_module_css_default.retryBtn,
					onClick: onClear,
					children: t("clearFilters")
				})]
			});
		}
		/** Prev/numbered/next controls plus a per-page-size menu — one
		* implementation for every paged list, driven entirely by `usePagination`'s
		* return value. Owns its own page-size dropdown open state for the same
		* reason `FilterMenu` owns its own.
		*
		* Layout: the numbered cluster (`.pagerPages`) centers in the row and the
		* page-info + page-size menu (`.pagerMeta`) sit on the right, all on ONE
		* line. The host settings dialog gives this row ~556px (800px panel − 188px
		* section nav − 48px options padding − 8px body padding), which fits only a
		* compact pager: `pageItems` caps the numbered window (its 1 and N are
		* always present, so skipping to either end stays one click away) and
		* `.pager`/`.pagerPages` are nowrap with tight paddings — a wrapping pager
		* reads as broken here. */
		/** Plugins tab: one more chunk, in place. Settings and the sidebar keep Pager. */
		function LoadMore({ more, onLoad, t }) {
			if (more <= 0) return null;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
				className: Market_module_css_default.loadMore,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "outline",
					size: "sm",
					onClick: onLoad,
					children: t("loadMore")
				})
			});
		}
		function Pager({ currentPage, totalPages, pageSize, onGoToPage, onChangePageSize, t }) {
			const [sizeOpen, setSizeOpen] = (0, react.useState)(false);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.pager,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					className: Market_module_css_default.pagerPages,
					children: totalPages > 1 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "outline",
							size: "sm",
							icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronLeftOutline14, { size: 14 }),
							disabled: currentPage === 1,
							onClick: () => onGoToPage(currentPage - 1),
							children: t("prevPage")
						}),
						pageItems(currentPage, totalPages).map((item, i) => item === "…" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.pageEllipsis,
							children: "…"
						}, "e" + i) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: item === currentPage ? "primary" : "outline",
							size: "sm",
							onClick: () => onGoToPage(item),
							children: item
						}, item)),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "outline",
							size: "sm",
							disabled: currentPage === totalPages,
							onClick: () => onGoToPage(currentPage + 1),
							children: [t("nextPage"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronRightOutline14, { size: 14 })]
						})
					] })
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: Market_module_css_default.pagerMeta,
					children: [totalPages > 1 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: Market_module_css_default.pageInfo,
						children: t("pageInfo").replace("{0}", String(currentPage)).replace("{1}", String(totalPages))
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
						open: sizeOpen,
						onClose: () => setSizeOpen(false),
						onSelect: (id) => {
							onChangePageSize(Number(id));
							setSizeOpen(false);
						},
						selectedId: String(pageSize),
						align: "end",
						portal: true,
						anchor: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "outline",
							size: "sm",
							icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 }),
							onClick: () => setSizeOpen((o) => !o),
							children: t("perPage") + " " + pageSize
						}),
						items: PAGE_SIZES.map((size) => ({
							id: String(size),
							label: String(size)
						}))
					})]
				})]
			});
		}
		/**
		* Card avatar: the plugin owner's GitHub avatar (no API, browser-cached),
		* falling back to the initial-letter tile when it can't load.
		*/
		/** Inline pass: links, `code`, **bold**; everything else plain text. */
		function mdInline(text) {
			return text.split(/(\[[^\]]+\]\(\s*https:\/\/[^)\s]+\s*\)|\*\*[^*]+\*\*|`[^`]+`)/g).map((part, i) => {
				const link = /^\[([^\]]+)\]\(\s*(https:\/\/[^)\s]+)\s*\)$/u.exec(part);
				if (link !== null) return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
					className: Market_module_css_default.notesA,
					href: link[2],
					target: "_blank",
					rel: "noreferrer",
					children: link[1]
				}, i);
				if (part.startsWith("**") && part.endsWith("**") && part.length > 4) return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: part.slice(2, -2) }, i);
				if (part.startsWith("`") && part.endsWith("`") && part.length > 2) return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
					className: Market_module_css_default.notesCode,
					children: part.slice(1, -1)
				}, i);
				return part;
			});
		}
		/**
		* Release-body markdown, reduced to what a reading dialog needs: headings,
		* bullets, quotes, fenced code, paragraphs, bold, inline code, https links,
		* and allowlisted https images. HTML from the repo is stripped first (never
		* interpreted as markup); remaining text arrives as React children or
		* controlled nodes only.
		*/
		/**
		* An <img> whose src lives on raw.githubusercontent.com, walked through the
		* raw GitHub route candidates on failure (#1070 follow-up): the update-notes
		* dialog was the last place still loading those images directly, so on
		* networks where raw is unreachable the notes rendered with holes. When every
		* candidate fails the last one is the direct URL, exactly the old behavior.
		*/
		function GithubRoutedImg({ src, alt, className, key }) {
			const [routeIndex, setRouteIndex] = (0, react.useState)(0);
			if (marketOffline()) return null;
			const candidates = githubRouteCandidates("raw", src);
			const candidate = candidates[Math.min(routeIndex, candidates.length - 1)];
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("img", {
				className,
				src: candidate.url,
				alt,
				loading: "lazy",
				onLoad: () => rememberGithubRoute("raw", candidate.proxy),
				onError: () => {
					if (routeIndex + 1 < candidates.length) setRouteIndex(routeIndex + 1);
				}
			}, key);
		}
		function renderMarkdown(md) {
			const out = [];
			let bullets = null;
			let fence = null;
			const flushList = () => {
				if (bullets === null) return;
				const items = bullets;
				out.push(/* @__PURE__ */ (0, react_jsx_runtime.jsx)("ul", {
					className: Market_module_css_default.notesBullets,
					children: items.map((item, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("li", { children: mdInline(item) }, i))
				}, `l${out.length}`));
				bullets = null;
			};
			const flushFence = () => {
				if (fence === null) return;
				const body = fence.join("\n");
				out.push(/* @__PURE__ */ (0, react_jsx_runtime.jsx)("pre", {
					className: Market_module_css_default.notesFence,
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", { children: body })
				}, `c${out.length}`));
				fence = null;
			};
			for (const line of sanitizeReleaseNotesBody(md).split("\n")) {
				const trimmed = line.trim();
				if (fence !== null) {
					if (/^```/.test(trimmed)) flushFence();
					else fence.push(line.replace(/\s+$/u, ""));
					continue;
				}
				if (/^```/.test(trimmed)) {
					flushList();
					fence = [];
					continue;
				}
				if (trimmed === "") {
					flushList();
					continue;
				}
				const image = releaseNotesHttpsImage(trimmed);
				if (image !== null) {
					flushList();
					out.push(/* @__PURE__ */ (0, react_jsx_runtime.jsx)(GithubRoutedImg, {
						className: Market_module_css_default.notesImg,
						src: image.src,
						alt: image.alt
					}, `i${out.length}`));
					continue;
				}
				const heading = /^#{1,6}\s+(.*)$/.exec(trimmed);
				if (heading !== null) {
					flushList();
					out.push(/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.notesH,
						children: mdInline(heading[1])
					}, `h${out.length}`));
					continue;
				}
				const quote = /^>\s?(.*)$/u.exec(trimmed);
				if (quote !== null) {
					flushList();
					out.push(/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.notesQuote,
						children: mdInline(quote[1])
					}, `q${out.length}`));
					continue;
				}
				const bullet = /^[-*]\s+(.*)$/.exec(trimmed);
				if (bullet !== null) {
					(bullets ??= []).push(bullet[1]);
					continue;
				}
				flushList();
				out.push(/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					className: Market_module_css_default.notesP,
					children: mdInline(line)
				}, `p${out.length}`));
			}
			flushList();
			flushFence();
			return out;
		}
		function OwnerAvatar({ name, owner, icon, className }) {
			const [failed, setFailed] = (0, react.useState)(false);
			const [routeIndex, setRouteIndex] = (0, react.useState)(0);
			const [iconFailed, setIconFailed] = (0, react.useState)(false);
			const [iconRouteIndex, setIconRouteIndex] = (0, react.useState)(0);
			const av = className === void 0 ? Market_module_css_default.av : `${Market_module_css_default.av} ${className}`;
			const tile = marketOffline() || iconFailed ? null : safeIcon(icon);
			if (tile !== null) {
				const candidates = githubRouteCandidates("raw", tile);
				const candidate = candidates[Math.min(iconRouteIndex, candidates.length - 1)];
				return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("img", {
					className: av,
					src: candidate.url,
					alt: "",
					loading: "lazy",
					decoding: "async",
					referrerPolicy: "no-referrer",
					onLoad: () => rememberGithubRoute("raw", candidate.proxy),
					onError: () => {
						if (iconRouteIndex + 1 < candidates.length) setIconRouteIndex(iconRouteIndex + 1);
						else setIconFailed(true);
					}
				});
			}
			if (failed || owner === "" || marketOffline()) return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
				className: av,
				style: { background: avatarColor(name) },
				children: name.replace(/^dsh[-_]/i, "").charAt(0).toUpperCase() || "P"
			});
			const candidates = githubRouteCandidates("avatar", `https://avatars.githubusercontent.com/${encodeURIComponent(owner)}?size=96`);
			const candidate = candidates[Math.min(routeIndex, candidates.length - 1)];
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("img", {
				className: av,
				src: candidate.url,
				alt: "",
				loading: "lazy",
				onLoad: () => rememberGithubRoute("avatar", candidate.proxy),
				onError: () => {
					if (routeIndex + 1 < candidates.length) setRouteIndex(routeIndex + 1);
					else setFailed(true);
				}
			});
		}
		/**
		* AppStore-style screenshot strip in the install detail dialog (#61).
		* Curated registry screenshots win; otherwise images are extracted from the
		* repo README. Requests start only once the dialog opens; failures — no
		* README, no images, broken links — degrade to rendering nothing at all.
		*/
		function ScreenshotStrip({ plugin, onOpen }) {
			const [shots, setShots] = (0, react.useState)([]);
			const [broken, setBroken] = (0, react.useState)([]);
			(0, react.useEffect)(() => {
				let live = true;
				setShots([]);
				setBroken([]);
				pluginScreenshots(plugin).then((list) => {
					if (live) setShots(list);
				});
				return () => {
					live = false;
				};
			}, [plugin]);
			const visible = shots.filter((src) => !broken.includes(src));
			if (visible.length === 0) return null;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
				className: Market_module_css_default.shots,
				children: visible.map((src, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("img", {
					className: Market_module_css_default.shot,
					src: thumbUrl(src, 300),
					alt: "",
					loading: "lazy",
					decoding: "async",
					referrerPolicy: "no-referrer",
					onClick: () => onOpen(visible, i),
					onError: () => setBroken((prev) => prev.includes(src) ? prev : prev.concat(src))
				}, src))
			});
		}
		/**
		* Advances an index every `intervalMs` while `count > 1` — the shared clock
		* behind both a card's auto-cycling thumbnail and the lightbox. A manual
		* jump (clicking a dot, an arrow, opening on a specific shot) restarts the
		* clock instead of letting it fire again moments later: without that, a
		* deliberate "go back one" reads as broken when it auto-advances right past
		* where the user just navigated to.
		*
		* `intervalMs <= 0` disables the timer entirely (no auto-advance at all);
		* manual jumps still work. The lightbox uses this: a full-bleed image needs
		* to stay put until the viewer moves on, so it must never page itself.
		*/
		function useAutoCarousel(count, initial, intervalMs = 3500) {
			const [index, setIndexState] = (0, react.useState)(initial);
			const [resetTick, setResetTick] = (0, react.useState)(0);
			(0, react.useEffect)(() => {
				if (count <= 1 || intervalMs <= 0) return;
				const timer = setInterval(() => {
					setIndexState((i) => (i + 1) % count);
				}, intervalMs);
				return () => clearInterval(timer);
			}, [
				count,
				intervalMs,
				resetTick
			]);
			const setIndex = (i) => {
				if (count <= 0) return;
				setIndexState((i % count + count) % count);
				setResetTick((t) => t + 1);
			};
			return [index, setIndex];
		}
		/**
		* A card thumbnail (or dialog strip image) renders at well under 150px on
		* screen; the curated screenshot behind it can be a full-resolution PNG
		* several hundred KB to a few MB — GitHub's own hosts offer no resized
		* variant, so rendering the original meant downloading full-size images for
		* a strip nobody asked to see full-size. images.weserv.nl resizes
		* server-side (by decoded HEIGHT, `fit=inside` so it never crops, `we=1` so
		* it never upscales something already smaller) before the bytes reach the
		* browser. The lightbox — an explicit "show me this big" — still requests
		* the ORIGINAL directly: proxying that one too would add a hop with nothing
		* left to save, and once the thumbnail is genuinely smaller it can no longer
		* share a cache entry with the full-size open anyway.
		*/
		function thumbUrl(src, height, options = {}) {
			let url = `https://images.weserv.nl/?url=${encodeURIComponent(src.replace(/^https?:\/\//, ""))}&h=${String(height)}&fit=inside&we=1`;
			if (options.webp === true && /\.(?:png|jpe?g|webp)(?:$|[?#])/iu.test(src)) url += "&output=webp";
			else if (/\.gif(?:$|[?#])/iu.test(src)) {
				const still = `${url}&output=webp`;
				url = `${url}&n=-1&output=webp&errorredirect=${encodeURIComponent(still)}`;
			}
			return url;
		}
		/**
		* True once the wrapped element has scrolled within `rootMargin` of the
		* viewport. Falls back to true immediately where IntersectionObserver is
		* unavailable (old browsers, jsdom without a stub) — a missing observer
		* should degrade to eager loading, not a permanently empty thumbnail.
		* Native `img loading="lazy"` already defers the network fetch on its own,
		* but its trigger distance isn't ours to tune, and scrolling a 400+ entry
		* catalog queues every off-screen card's request the instant the browser
		* decides to start prefetching — this hook is what lets CardShot not even
		* SET `src` until a card is actually close.
		*/
		function useNearViewport(rootMargin = "200px") {
			const [near, setNear] = (0, react.useState)(typeof IntersectionObserver === "undefined");
			const [node, setNode] = (0, react.useState)(null);
			(0, react.useEffect)(() => {
				if (near || node === null) return;
				const obs = new IntersectionObserver((entries) => {
					if (entries.some((entry) => entry.isIntersecting)) setNear(true);
				}, { rootMargin });
				obs.observe(node);
				return () => obs.disconnect();
			}, [
				near,
				node,
				rootMargin
			]);
			return [setNode, near];
		}
		/**
		* A card's own thumbnail strip — curated screenshots only (#61 supplement):
		* this data already rode along with the catalog fetch that drew the grid,
		* so showing it costs nothing extra. README-scraped fallback images stay
		* dialog-only, where fetching one repo's README on click is a single
		* request instead of one per visible card.
		*
		* Horizontal scroll at each image's own aspect ratio, not an auto-cycling
		* single crop: cropping every shot into one fixed box hid most of a tall
		* screenshot, and cycling on a timer meant the card you were looking at
		* kept changing under you. Scrolling is a gesture the user drives.
		*/
		/** Thumbnails per card. The dialog shows every screenshot; a grid of cards
		* pulling six full-size PNGs each is what makes the first paint crawl. */
		const CARD_SHOT_LIMIT = 3;
		/**
		* Theme gallery is 4-up (16:10 tile ≈ 150px tall in a typical panel). 320px
		* is ~2× that; 520 was a near-full-bleed PNG and still hundreds of KB (#1060).
		*/
		const THEME_COVER_HEIGHT = 320;
		/** About half a cover row — off-screen theme cards must not prefetch. */
		const THEME_COVER_ROOT_MARGIN = "80px";
		/** First-pass geometry probes for a README fallback. If none of these
		* pass as a cover, the remaining candidates (still capped at six) are
		* measured too — otherwise a later landscape is dropped before ranking. */
		const THEME_PREVIEW_PROBE_LIMIT = 3;
		function CardShot({ plugin, onOpen }) {
			const shots = safeScreenshots(plugin.screenshots);
			const [broken, setBroken] = (0, react.useState)([]);
			const visible = shots.filter((src) => !broken.includes(src)).slice(0, CARD_SHOT_LIMIT);
			const [setStripRef, near] = useNearViewport();
			if (visible.length === 0) return null;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
				ref: setStripRef,
				className: Market_module_css_default.cardShots,
				children: visible.map((src, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("img", {
					className: Market_module_css_default.cardShot,
					src: near ? thumbUrl(src, 200) : void 0,
					alt: "",
					loading: "lazy",
					decoding: "async",
					fetchPriority: "low",
					referrerPolicy: "no-referrer",
					onClick: (e) => {
						e.stopPropagation();
						onOpen(visible, i);
					},
					onError: () => setBroken((prev) => prev.includes(src) ? prev : prev.concat(src))
				}, src))
			});
		}
		/**
		* Read dimensions through the same low-resolution, no-upscale route used by
		* card thumbnails. Large originals therefore stay off the wire, while a
		* genuinely tiny image remains tiny and can be rejected by the scorer.
		*/
		function measureThemeCandidates(candidates) {
			if (typeof Image === "undefined") return Promise.resolve([]);
			const measureBatch = (batch) => Promise.all(batch.map((candidate) => new Promise((resolve) => {
				const probe = new Image();
				let settled = false;
				const finish = (measurement) => {
					if (settled) return;
					settled = true;
					window.clearTimeout(timer);
					probe.onload = null;
					probe.onerror = null;
					resolve(measurement);
				};
				const timer = window.setTimeout(() => finish(null), 6e3);
				probe.onload = () => finish({
					src: candidate.src,
					width: probe.naturalWidth,
					height: probe.naturalHeight
				});
				probe.onerror = () => finish(null);
				probe.referrerPolicy = "no-referrer";
				probe.decoding = "async";
				probe.src = thumbUrl(candidate.src, 240);
			}))).then((results) => results.filter((result) => result !== null));
			return measureBatch(candidates.slice(0, THEME_PREVIEW_PROBE_LIMIT)).then((first) => {
				if (first.some((item) => previewDimensionScore(item.width, item.height) !== null) || candidates.length <= THEME_PREVIEW_PROBE_LIMIT) return first;
				return measureBatch(candidates.slice(THEME_PREVIEW_PROBE_LIMIT)).then((rest) => first.concat(rest));
			});
		}
		const measuredThemePreviewTasks = /* @__PURE__ */ new Map();
		const measuredThemePreviewResults = /* @__PURE__ */ new Map();
		/** Clear measured theme media at the boundary of an accepted catalog generation. */
		function resetThemePreviewCache() {
			measuredThemePreviewTasks.clear();
			measuredThemePreviewResults.clear();
		}
		/** README fetch + geometry probes, shared across search/page remounts. */
		function measuredThemePreview(plugin) {
			const cached = measuredThemePreviewTasks.get(plugin.url);
			if (cached !== void 0) return cached;
			const task = pluginScreenshotCandidates(plugin).then(async (candidates) => {
				const ranked = rankThemeScreenshots(candidates, await measureThemeCandidates(candidates));
				measuredThemePreviewResults.set(plugin.url, ranked);
				return ranked;
			}).catch(() => {
				measuredThemePreviewResults.set(plugin.url, []);
				return [];
			});
			measuredThemePreviewTasks.set(plugin.url, task);
			return task;
		}
		/**
		* Themes are chosen visually, so their catalog card gets one stable, large
		* preview instead of the generic plugin card's horizontal thumbnail strip.
		* Curated screenshots keep their declared order. A missing curated set is
		* filled lazily from README only when the card nears the viewport, then
		* ranked by both README semantics and measured image geometry.
		*/
		function ThemeCover({ plugin, onOpen, t }) {
			const curated = safeScreenshots(plugin.screenshots);
			const curatedKey = curated.join("\n");
			const cachedFallback = curated.length === 0 ? measuredThemePreviewResults.get(plugin.url) : void 0;
			const [fallback, setFallback] = (0, react.useState)({
				loading: curated.length === 0 && cachedFallback === void 0,
				shots: cachedFallback ?? []
			});
			const [broken, setBroken] = (0, react.useState)([]);
			const [setCoverRef, near] = useNearViewport(THEME_COVER_ROOT_MARGIN);
			(0, react.useEffect)(() => {
				setBroken([]);
				if (curated.length > 0) {
					setFallback({
						loading: false,
						shots: []
					});
					return;
				}
				const cached = measuredThemePreviewResults.get(plugin.url);
				if (cached !== void 0) {
					setFallback({
						loading: false,
						shots: cached
					});
					return;
				}
				setFallback({
					loading: true,
					shots: []
				});
				if (!near) return;
				let live = true;
				measuredThemePreview(plugin).then((shots) => {
					if (live) setFallback({
						loading: false,
						shots
					});
				});
				return () => {
					live = false;
				};
			}, [
				curatedKey,
				near,
				plugin.url
			]);
			const visible = (curated.length > 0 ? curated : fallback.shots).filter((src) => !broken.includes(src));
			const name = pluginName(plugin.name, plugin.npm);
			if (visible.length === 0) return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
				ref: setCoverRef,
				type: "button",
				className: `${Market_module_css_default.themeCover} ${Market_module_css_default.themeCoverEmpty}`,
				"aria-label": `${name}: ${fallback.loading ? t("themePreviewLoading") : t("themePreviewMissing")}`,
				disabled: true,
				children: [fallback.loading ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: Market_module_css_default.spin,
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLoadingOutline16, { size: 20 })
				}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconSparkle16, { size: 20 }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: fallback.loading ? t("themePreviewLoading") : t("themePreviewMissing") })]
			});
			const src = visible[0];
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
				ref: setCoverRef,
				type: "button",
				className: Market_module_css_default.themeCover,
				"aria-label": `${t("themePreview")} ${name}`,
				onClick: () => onOpen(visible, 0),
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("img", {
						src: near ? thumbUrl(src, THEME_COVER_HEIGHT, { webp: true }) : void 0,
						alt: "",
						loading: "lazy",
						decoding: "async",
						fetchPriority: "low",
						referrerPolicy: "no-referrer",
						onError: () => setBroken((prev) => prev.includes(src) ? prev : prev.concat(src))
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
						className: Market_module_css_default.themePreviewAction,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconSearchOutline16, { size: 14 }), t("themePreview")]
					}),
					visible.length > 1 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: Market_module_css_default.themePreviewCount,
						children: t("themePreviewCount").replace("{0}", String(visible.length))
					})
				]
			});
		}
		/**
		* Masonry columns holding items in their input order.
		*
		* Items are dealt alternately (0,2,4… left; 1,3,5… right) rather than split
		* down the middle, so the sort order still reads left-to-right then down —
		* the ranking is the whole point of the sort menu above it. Each column is
		* its own flex stack, so a tall item only pushes down the items beneath IT
		* instead of leaving a hole beside its shorter neighbour.
		*
		* Below the two-up breakpoint the CSS collapses to one column, and dealing
		* alternately would then interleave the list wrongly — so at one column the
		* items stay in a single stack in their original order.
		*
		* Two columns at the settings dialog's width; the sidebar page is wider and
		* gets a third once each column still has room for a full card.
		*/
		function Masonry({ items, render }) {
			const wide = useMediaWide();
			const ref = (0, react.useRef)(null);
			const [columns, setColumns] = (0, react.useState)(2);
			(0, react.useLayoutEffect)(() => {
				const el = ref.current;
				if (el === null || typeof ResizeObserver === "undefined") return;
				const observer = new ResizeObserver(([entry]) => {
					if (entry !== void 0) setColumns(Math.min(3, Math.max(2, Math.floor((entry.contentRect.width + 10) / 290))));
				});
				observer.observe(el);
				return () => observer.disconnect();
			}, [wide]);
			if (!wide) return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
				className: Market_module_css_default.masonry,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					className: Market_module_css_default.masonryCol,
					children: items.map(render)
				})
			});
			const buckets = Array.from({ length: columns }, () => []);
			items.forEach((item, index) => {
				buckets[index % columns].push(item);
			});
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
				ref,
				className: Market_module_css_default.masonry,
				children: buckets.map((bucket, index) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					className: Market_module_css_default.masonryCol,
					children: bucket.map(render)
				}, index))
			});
		}
		/**
		* Whether the layout is at its two-up width. Matches the CSS breakpoint
		* exactly: the column split is decided in JS but rendered by CSS, and the
		* two disagreeing would deal cards into columns the stylesheet has already
		* stacked.
		*/
		function useMediaWide() {
			const query = "(min-width: 681px)";
			const subscribe = (0, react.useCallback)((notify) => {
				if (typeof matchMedia !== "function") return () => {};
				const list = matchMedia(query);
				list.addEventListener("change", notify);
				return () => list.removeEventListener("change", notify);
			}, []);
			return (0, react.useSyncExternalStore)(subscribe, () => typeof matchMedia === "function" ? matchMedia(query).matches : true, () => true);
		}
		/**
		* A card's description, clamped to 5 lines so one wordy entry doesn't blow
		* the two-up grid's row height out for whatever sits beside it — the grid
		* already tolerates SOME height variance by design (`.card`'s `align-self:
		* start`), just not an unbounded one. The toggle only renders when the text
		* actually overflows the clamp: a two-line description has nothing to
		* "expand", so no button beats a button that does nothing.
		*/
		function CardDesc({ text, t, lines = 5, className, textClassName }) {
			const ref = (0, react.useRef)(null);
			const [expanded, setExpanded] = (0, react.useState)(false);
			const [canExpand, setCanExpand] = (0, react.useState)(false);
			const base = textClassName === void 0 ? Market_module_css_default.desc : `${Market_module_css_default.desc} ${textClassName}`;
			const clamp = lines === 3 ? Market_module_css_default.descClamp3 : Market_module_css_default.descClamp;
			(0, react.useLayoutEffect)(() => {
				const el = ref.current;
				if (el === null) return;
				const measure = () => {
					if (!el.classList.contains(clamp)) return;
					setCanExpand(el.scrollHeight > el.clientHeight + 1);
				};
				measure();
				if (typeof ResizeObserver === "undefined") return;
				const observer = new ResizeObserver(measure);
				observer.observe(el);
				return () => observer.disconnect();
			}, [text, clamp]);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						ref,
						className: expanded ? base : `${base} ${clamp}`,
						children: text
					}),
					canExpand && lines === 3 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
						type: "button",
						className: Market_module_css_default.descMore,
						onClick: () => setExpanded((e) => !e),
						children: [expanded ? t("descCollapse") : t("descMore"), expanded ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, { size: 12 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronRightOutline14, { size: 12 })]
					}),
					canExpand && lines === 5 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						className: Market_module_css_default.descToggle,
						"aria-label": expanded ? t("descCollapse") : t("descExpand"),
						onClick: () => setExpanded((e) => !e),
						children: expanded ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 })
					})
				]
			});
		}
		/**
		* Native window controls can own the top band even though DOM hit-testing
		* still reports the page element underneath. The official Windows desktop
		* shell has been observed with a 42px band while the lightbox close button
		* starts at 16px (#384), leaving only its bottom edge clickable.
		*
		* Read the shell's geometry instead of hard-coding a desktop height: titlebar
		* overlays differ between shells, and ordinary browsers have no such API.
		*/
		function useWindowTitlebarHeight() {
			const [height, setHeight] = (0, react.useState)(0);
			(0, react.useLayoutEffect)(() => {
				if (typeof navigator === "undefined") return;
				const overlay = navigator.windowControlsOverlay;
				if (overlay?.getTitlebarAreaRect === void 0) return;
				const sync = () => {
					try {
						if (overlay.visible === false) {
							setHeight(0);
							return;
						}
						const next = overlay.getTitlebarAreaRect().height;
						setHeight(Number.isFinite(next) && next > 0 ? next : 0);
					} catch {
						setHeight(0);
					}
				};
				sync();
				overlay.addEventListener?.("geometrychange", sync);
				return () => overlay.removeEventListener?.("geometrychange", sync);
			}, []);
			return height;
		}
		/**
		* Full-bleed image preview, opened from a card thumbnail or a dialog's
		* screenshot strip. Not the shared Modal primitive: Modal is chrome for a
		* decision (title, description, footer actions); this is just the same
		* already-downloaded image shown bigger — there is no separate "thumbnail"
		* vs "full size" asset to fetch.
		*/
		/**
		* The full-size screenshot, loaded through the configured GitHub route (#1070).
		*
		* Screenshots are GitHub-hosted, and on a mainland connection
		* `raw.githubusercontent.com` is the slowest part of the page — the avatars
		* next to them already go through the proxy the user chose, while this one
		* still went direct. The thumbnail keeps its own resizer; this is the one
		* place that wants the original bytes, so it is the one place the proxy
		* itself is worth a hop.
		*
		* The route order is the same one avatars use: the prefix that last worked
		* first, then the region's other prefixes, then direct. A failed load walks
		* the list rather than leaving a blank image.
		*/
		function LightboxImage({ src, className, onClick }) {
			const [routeIndex, setRouteIndex] = (0, react.useState)(0);
			(0, react.useEffect)(() => {
				setRouteIndex(0);
			}, [src]);
			const candidates = githubRouteCandidates("raw", src);
			const candidate = candidates[Math.min(routeIndex, candidates.length - 1)];
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("img", {
				className,
				src: candidate.url,
				alt: "",
				onClick,
				onLoad: () => rememberGithubRoute("raw", candidate.proxy),
				onError: () => {
					if (routeIndex + 1 < candidates.length) setRouteIndex((current) => current + 1);
				}
			});
		}
		function ScreenshotLightbox({ shots, startIndex, onClose, t }) {
			const [index, setIndex] = useAutoCarousel(shots.length, startIndex, 0);
			const titlebarHeight = useWindowTitlebarHeight();
			const host = useMarketPortalHost();
			(0, react.useEffect)(() => {
				const onKey = (e) => {
					if (e.key === "Escape") {
						e.stopPropagation();
						onClose();
					} else if (e.key === "ArrowLeft") {
						e.stopPropagation();
						setIndex(index - 1);
					} else if (e.key === "ArrowRight") {
						e.stopPropagation();
						setIndex(index + 1);
					}
				};
				window.addEventListener("keydown", onKey, true);
				return () => window.removeEventListener("keydown", onKey, true);
			}, [index]);
			return (0, react_dom.createPortal)(/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.lightbox,
				onClick: onClose,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						className: Market_module_css_default.lightboxClose,
						style: titlebarHeight > 0 ? { top: titlebarHeight + 16 } : void 0,
						"aria-label": t("lightboxClose"),
						onClick: onClose,
						children: "×"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(LightboxImage, {
						className: Market_module_css_default.lightboxImg,
						src: shots[index],
						onClick: (e) => e.stopPropagation()
					}),
					shots.length > 1 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							className: `${Market_module_css_default.lightboxNav} ${Market_module_css_default.lightboxPrev}`,
							"aria-label": t("lightboxPrev"),
							onClick: (e) => {
								e.stopPropagation();
								setIndex(index - 1);
							},
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronLeftOutline14, { size: 18 })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							className: `${Market_module_css_default.lightboxNav} ${Market_module_css_default.lightboxNext}`,
							"aria-label": t("lightboxNext"),
							onClick: (e) => {
								e.stopPropagation();
								setIndex(index + 1);
							},
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronRightOutline14, { size: 18 })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.lightboxDots,
							onClick: (e) => e.stopPropagation(),
							children: shots.map((src, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: i === index ? `${Market_module_css_default.lightboxDot} ${Market_module_css_default.lightboxDotOn}` : Market_module_css_default.lightboxDot,
								onClick: () => setIndex(i)
							}, src))
						})
					] })
				]
			}), host);
		}
		/**
		* The one DOM node this package portals into, created on first use and kept
		* for the life of the page.
		*
		* Created imperatively rather than rendered, and never removed: the point is
		* that `document.body`'s child list stops being shared state between two
		* React roots. A container that came and went would put the same churn back
		* into body, just less often — and "less often" is what made this bug
		* intermittent and hard to believe in the first place.
		*
		* Re-appended on every open so it stays last among body's children. That is
		* what keeps the lightbox above the host's own portalled dialog, which is
		* why the portal exists at all; moving a node we own is not something the
		* host's root tracks, so it cannot disturb it.
		*/
		let portalHost = null;
		function marketPortalHost() {
			if (portalHost === null) {
				portalHost = document.createElement("div");
				portalHost.setAttribute("data-dsh-market-portal", "");
				portalHost.setAttribute("translate", "no");
				portalHost.classList.add("notranslate");
			}
			return portalHost;
		}
		/**
		* Move the container to the end of `document.body`, which is what keeps this
		* package's layers above the host's own portalled dialog.
		*
		* In a layout effect, NOT during render. `createPortal` needs the element
		* while rendering, but appending it does not belong there: React may start a
		* render, abandon it and start again, so a mutation in the render body runs
		* for passes that never commit — and this particular mutation reorders
		* `document.body`, the one container this package shares with the host's
		* separate React root. That is the same shared-child-list hazard #293 was
		* about, just arrived at from the other side. Committing it in an effect
		* means it happens once, after React is done, in the order React expects.
		*/
		function useMarketPortalHost() {
			const host = marketPortalHost();
			(0, react.useLayoutEffect)(() => {
				document.body.appendChild(host);
			}, [host]);
			return host;
		}
		/**
		* Official-style market glyph: the shared block-grid brand mark converted to
		* the official monochrome icon form (16×16, fill="currentColor") so it
		* follows the active theme. Mirrors the settings-nav glyph used for the
		* "market" section id — both now draw the geometry in market-mark.ts, so the
		* nav entry and the section it opens cannot drift apart.
		*
		* Two animated forms, differing in what they are for rather than in looks:
		*
		* - `animated` — the loading state. Motion is the whole signal, so under
		*   `prefers-reduced-motion` it still moves, just without displacement.
		* - `ambient` — the section's own heading mark. Decoration, so the same
		*   preference stops it dead.
		*
		* Both draw the one timeline in the stylesheet: the grid breathes along the
		* diagonal and the block rides in behind that wave. They share `--dshm-cycle`
		* so the block cannot arrive after the wave it is supposed to follow.
		*/
		function MarketLogo({ size = 16, style, animated = false, ambient = false }) {
			const moving = animated || ambient;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
				width: size,
				height: size,
				viewBox: `0 0 16 16`,
				fill: "none",
				xmlns: "http://www.w3.org/2000/svg",
				"aria-hidden": "true",
				style,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("g", {
					fill: "currentColor",
					children: MARK_GRID_BLOCKS.map((block) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("rect", {
						className: moving ? Market_module_css_default.logoCell : void 0,
						style: moving ? { "--dshm-wave": block.wave } : void 0,
						x: block.x,
						y: block.y,
						width: MARK_BLOCK_SIZE,
						height: MARK_BLOCK_SIZE,
						rx: MARK_BLOCK_RADIUS
					}, `${block.x},${block.y}`))
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("rect", {
					className: animated ? Market_module_css_default.logoPlug : ambient ? Market_module_css_default.logoPlugAmbient : void 0,
					x: MARK_PLUG_BLOCK.x,
					y: MARK_PLUG_BLOCK.y,
					width: MARK_BLOCK_SIZE,
					height: MARK_BLOCK_SIZE,
					rx: MARK_BLOCK_RADIUS,
					fill: "currentColor",
					transform: `rotate(${MARK_PLUG_BLOCK.degrees} ${MARK_PLUG_BLOCK.originX} ${MARK_PLUG_BLOCK.originY})`
				})]
			});
		}
		/**
		* GitHub mark beside catalog card titles (#256, #365). Catalog intake in
		* awesome-dsh-plugin rejects any entry whose `url` is not
		* `https://github.com/owner/repo` (scripts/lib/entries.mjs), so this renders
		* unconditionally — not a bet that today's snapshot happens to be all
		* GitHub. The generic outbound arrow did not say so until hover. This rides
		* the title's own line — no second link, no extra row.
		*/
		function GithubRepoMark({ size = 12, className }) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
				width: size,
				height: size,
				viewBox: "0 0 16 16",
				fill: "currentColor",
				xmlns: "http://www.w3.org/2000/svg",
				"aria-hidden": "true",
				className,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
					fillRule: "evenodd",
					d: "M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"
				})
			});
		}
		/**
		* Sweeping cards or the recent strip must not flash tips. Same dwell as
		* the recent-tile name/blurb tips.
		*/
		const HOVER_TIP_DELAY_MS = 700;
		/**
		* Hover tips on catalog cards. Matches official Discover placement
		* (`portal`, `side="bottom"`) so the bubble escapes card overflow and the
		* theme-card hover transform, and does not cover the name. Extra props
		* are ignored on hosts whose Tooltip is older than portal.
		*/
		function CardTip({ label, maxWidth, children }) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
				label,
				side: "bottom",
				delayMs: HOVER_TIP_DELAY_MS,
				portal: true,
				maxWidth,
				children
			});
		}
		/** Bookmark toggle on catalog cards (#414). Outline when off, filled when on —
		* deliberately not a star, which the byline already uses for GitHub popularity. */
		/**
		* The bookmark, with the click felt rather than only seen.
		*
		* Filling the mark is the state; the pop is what makes it read as something
		* the reader did. It is a bookmark, so the mark is pulled down from its top
		* edge and snaps back — a ribbon tugged and released, not a checkbox ticking.
		*
		* Web Animations rather than a class toggled through React state: a second
		* click has to restart the gesture, and "set a flag, clear it on a timer"
		* either coalesces the two renders or leaves the flag set when the click
		* lands mid-animation. Each call here owns its own animation object.
		*
		* `prefers-reduced-motion` skips the gesture; the fill still changes, so the
		* action is never silent.
		*/
		function FavoriteButton({ filled, label, onToggle }) {
			const markRef = (0, react.useRef)(null);
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(CardTip, {
				label,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
					type: "button",
					className: filled ? `${Market_module_css_default.favoriteBtn} ${Market_module_css_default.favoriteOn}` : Market_module_css_default.favoriteBtn,
					"aria-pressed": filled,
					"aria-label": label,
					onClick: () => {
						onToggle();
						const el = markRef.current;
						if (el === null || typeof el.animate !== "function") return;
						if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true) return;
						el.animate([
							{
								transform: "scaleY(1) translateY(0)",
								easing: "cubic-bezier(.32,.72,.42,1)"
							},
							{
								transform: "scaleY(1.42) translateY(1px)",
								offset: .18,
								easing: "cubic-bezier(.42,0,.58,1)"
							},
							{
								transform: "scaleY(.84) translateY(-1px)",
								offset: .42,
								easing: "cubic-bezier(.3,.75,.5,1)"
							},
							{
								transform: "scaleY(1.1) translateY(.4px)",
								offset: .62,
								easing: "cubic-bezier(.3,.75,.5,1)"
							},
							{
								transform: "scaleY(.96) translateY(0)",
								offset: .8,
								easing: "ease-out"
							},
							{ transform: "scaleY(1) translateY(0)" }
						], { duration: 460 });
					},
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(BookmarkMark, {
						filled,
						className: Market_module_css_default.favoriteMark,
						markRef
					})
				})
			});
		}
		function BookmarkMark({ size = 14, filled = false, className, markRef }) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
				ref: markRef,
				width: size,
				height: size,
				viewBox: "0 0 16 16",
				xmlns: "http://www.w3.org/2000/svg",
				"aria-hidden": "true",
				className,
				children: filled ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
					d: "M4 1.5h8a1 1 0 0 1 1 1v11.8a.5.5 0 0 1-.78.41L8 12.2 3.78 14.71A.5.5 0 0 1 3 14.3V2.5a1 1 0 0 1 1-1z",
					fill: "currentColor"
				}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
					d: "M4 1.5h8a1 1 0 0 1 1 1v11.8a.5.5 0 0 1-.78.41L8 12.2 3.78 14.71A.5.5 0 0 1 3 14.3V2.5a1 1 0 0 1 1-1z",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.25",
					strokeLinejoin: "round"
				})
			});
		}
		/** Compact count; hover names the exact figure, source and reporting scope. */
		function DownloadCount({ plugin, t }) {
			const tip = downloadStatsText(plugin, t);
			const statistic = downloadStatistic(plugin);
			if (tip === null || statistic === null) return null;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(CardTip, {
				label: tip,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: Market_module_css_default.star,
					tabIndex: 0,
					"aria-label": tip,
					children: "· " + (statistic.source === "github" ? "GitHub " : "") + "↓ " + formatCount(statistic.count)
				})
			});
		}
		function StarCount({ plugin, t }) {
			const tip = starStatsText(plugin, t);
			if (tip === null) return null;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(CardTip, {
				label: tip,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: Market_module_css_default.star,
					tabIndex: 0,
					"aria-label": tip,
					children: "· ★ " + formatCount(plugin.stars)
				})
			});
		}
		/** Monochrome mark for one fact in front of the capability fold. Ink, not a warning colour. */
		function AheadMark({ fact }) {
			if (fact === "dynamic-code") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconCodeOutline16, {
				size: 16,
				className: Market_module_css_default.capAheadIcon
			});
			if (fact.startsWith("reads credentials")) return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
				className: Market_module_css_default.capAheadIcon,
				viewBox: "0 0 16 16",
				width: 16,
				height: 16,
				"aria-hidden": "true",
				focusable: "false",
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("circle", {
					cx: "5.5",
					cy: "8",
					r: "2.25",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.25"
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
					d: "M7.6 8H13M10.6 8v2M12.4 8v1.4",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.25",
					strokeLinecap: "round"
				})]
			});
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
				className: Market_module_css_default.capAheadIcon,
				viewBox: "0 0 16 16",
				width: 16,
				height: 16,
				"aria-hidden": "true",
				focusable: "false",
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("circle", {
					cx: "8",
					cy: "8",
					r: "2",
					fill: "currentColor"
				})
			});
		}
		/** Circle with a question mark, in the same dark badge and light glyph as the
		* terminal mark below it. */
		function ConfirmCapabilityIcon() {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
				className: Market_module_css_default.confirmTerminalIcon,
				viewBox: "0 0 16 16",
				width: 16,
				height: 16,
				"aria-hidden": "true",
				focusable: "false",
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("circle", {
						cx: "8",
						cy: "8",
						r: "8",
						fill: "currentColor"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
						className: Market_module_css_default.confirmTerminalPrompt,
						d: "M6.2 6.25a1.8 1.8 0 1 1 2.7 1.55C8.35 8.1 8 8.5 8 9.05",
						fill: "none",
						strokeWidth: "1.4",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("circle", {
						className: Market_module_css_default.confirmTerminalDot,
						cx: "8",
						cy: "11.2",
						r: "0.75"
					})
				]
			});
		}
		/** Design-spec terminal mark for the install-command fold: dark rounded
		* square with a light `>_` prompt. Host ui-primitives has no matching glyph. */
		function ConfirmTerminalIcon() {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
				className: Market_module_css_default.confirmTerminalIcon,
				viewBox: "0 0 16 16",
				width: 16,
				height: 16,
				"aria-hidden": "true",
				focusable: "false",
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("rect", {
					width: "16",
					height: "16",
					rx: "3.5",
					fill: "currentColor"
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
					className: Market_module_css_default.confirmTerminalPrompt,
					d: "M4.25 5.25 L7.25 8 L4.25 10.75 M8.25 10.75 H12",
					fill: "none",
					strokeWidth: "1.4",
					strokeLinecap: "round",
					strokeLinejoin: "round"
				})]
			});
		}
		/** execCommand only succeeds inside the click. writeText rejects later, after
		* Chrome has already dropped the user activation, so the textarea copy has
		* to happen before that promise. The field stays inside the dialog; removing
		* a focused node outside it would drop the keyboard onto document.body. */
		function copyInstallCommandNow(text, anchor) {
			const area = document.createElement("textarea");
			area.value = text;
			area.setAttribute("readonly", "");
			area.setAttribute("aria-hidden", "true");
			area.tabIndex = -1;
			area.style.position = "fixed";
			area.style.top = "0";
			area.style.left = "-9999px";
			(anchor.parentElement ?? document.body).appendChild(area);
			area.select();
			let ok = false;
			try {
				ok = document.execCommand("copy");
			} catch {
				ok = false;
			}
			area.remove();
			anchor.focus();
			return ok;
		}
		function writeInstallCommand(text, anchor) {
			const copiedNow = copyInstallCommandNow(text, anchor);
			const write = navigator.clipboard?.writeText;
			if (typeof write !== "function") return copiedNow ? Promise.resolve() : Promise.reject(/* @__PURE__ */ new Error("copy failed"));
			return write.call(navigator.clipboard, text).then(() => void 0, () => {
				if (copiedNow) return;
				throw new Error("copy failed");
			});
		}
		/** Copy control for the install command. Success shows 「已复制」 beside the
		* icon; the command stays selectable if both copy paths fail. */
		function ConfirmCopyButton({ text, label, copiedLabel }) {
			const [copied, setCopied] = (0, react.useState)(false);
			const timer = (0, react.useRef)(null);
			(0, react.useEffect)(() => () => {
				if (timer.current !== null) clearTimeout(timer.current);
			}, []);
			const markCopied = () => {
				setCopied(true);
				if (timer.current !== null) clearTimeout(timer.current);
				timer.current = setTimeout(() => setCopied(false), 1500);
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [copied && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: Market_module_css_default.confirmCopied,
				role: "status",
				children: copiedLabel
			}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
				type: "button",
				className: Market_module_css_default.confirmCopy,
				"aria-label": copied ? copiedLabel : label,
				onClick: (event) => {
					writeInstallCommand(text, event.currentTarget).then(markCopied, () => {});
				},
				children: copied ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconCheckOutline16, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconCopyOutline16, { size: 14 })
			})] });
		}
		/** Stroke glyphs the host primitives do not ship. They inherit the text colour. */
		function IconPlus({ size = 14 }) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 16 16",
				width: size,
				height: size,
				"aria-hidden": "true",
				focusable: "false",
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
					d: "M8 3v10M3 8h10",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.3",
					strokeLinecap: "round"
				})
			});
		}
		/** Reminders off (Lucide `bell-off` geometry): the body breaks where the slash crosses it. */
		function IconBellOff({ size = 16 }) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 24 24",
				width: size,
				height: size,
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.75",
				strokeLinecap: "round",
				strokeLinejoin: "round",
				"aria-hidden": "true",
				focusable: "false",
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M10.268 21a2 2 0 0 0 3.464 0" }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M17 17H4a1 1 0 0 1-.74-1.673C4.59 13.956 6 12.499 6 8a6 6 0 0 1 .258-1.742" }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M8.668 3.01A6 6 0 0 1 18 8c0 2.687.77 4.653 1.707 6.05" }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "m2 2 20 20" })
				]
			});
		}
		/** Design-spec warning mark: filled amber triangle, same visual size as the
		* terminal badge above it. Title stays body ink. */
		function ConfirmWarnIcon() {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
				className: Market_module_css_default.installCautionMark,
				viewBox: "0 0 16 16",
				width: 16,
				height: 16,
				"aria-hidden": "true",
				focusable: "false",
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
						fill: "#f8b428",
						d: "M8 1.15Q8.72 1.15 9.15 2.05L14.4 12.35Q15.15 13.85 13.75 14.55H2.25Q0.85 13.85 1.6 12.35L6.85 2.05Q7.28 1.15 8 1.15Z"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
						d: "M8 6.05v3.15",
						fill: "none",
						stroke: "#fff",
						strokeWidth: "1.25",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("circle", {
						cx: "8",
						cy: "11.15",
						r: "0.68",
						fill: "#fff"
					})
				]
			});
		}
		/**
		* Whether a red line is one a reader has to weigh BEFORE installing, rather
		* than a fact about what the plugin does once it runs.
		*
		* Two families qualify, for one reason: they happen at install time. There is
		* no "afterwards" to inspect, so this is the last moment the decision can be
		* made. The other families — credentials+network above all, 73% of every red
		* line the catalog holds — describe what plugins normally do, and calling
		* that urgent is how a warning gets trained away.
		*/
		function redLineIsUrgent(line) {
			return line.startsWith("runs code at install time") || line.startsWith("tampers with a core bundle");
		}
		/**
		* Red lines that name one address: a plaintext http:// host or a literal IP.
		*
		* The scanner keeps at most one of each, matched from source text, and many
		* are schema or documentation URLs inside a bundled library. They stay in the
		* capability list as sentences instead of standing in front of it.
		*/
		function redLineNamesAddress(line) {
			return line.startsWith("uses plaintext http://") || line.startsWith("uses literal IP ");
		}
		/**
		* Facts shown in front of the capability list: the credentials red line,
		* any red-line family this build does not know, then dynamic code.
		*
		* Each is something the static scan can only point at, not inspect: a secret
		* leaving over the network, or code that exists only once it runs. A
		* host-runtime dependency is a package.json declaration, not that, and stays
		* in the list.
		*/
		/**
		* The fold's groups: what a capability touches, not how bad it is. A name the
		* build does not know goes under "other" rather than being dropped.
		*/
		const CAPABILITY_GROUPS = [
			["capGroupFiles", [
				"fs-read",
				"fs-write",
				"env"
			]],
			["capGroupNetwork", ["network", "llm"]],
			["capGroupRun", [
				"shell",
				"dynamic-code",
				"subagent"
			]],
			["capGroupKeys", ["credentials"]],
			["capGroupHost", ["host-runtime"]]
		];
		/**
		* Found in under 15% of the 3844 scanned catalog records (2026-09). A
		* frequency, stated as one; it says nothing about harm.
		*/
		const UNCOMMON_CAPABILITIES = /* @__PURE__ */ new Set([
			"credentials",
			"llm",
			"dynamic-code",
			"host-runtime",
			"subagent"
		]);
		function groupCapabilities(names) {
			const known = new Set(CAPABILITY_GROUPS.flatMap(([, members]) => members));
			const groups = CAPABILITY_GROUPS.map(([key, members]) => [key, members.filter((name) => names.includes(name))]).filter(([, members]) => members.length > 0);
			const other = names.filter((name) => !known.has(name));
			if (other.length > 0) groups.push(["capGroupOther", other]);
			return groups;
		}
		function aheadFacts(plugin) {
			const quiet = (plugin.capabilityRedLines ?? []).filter((line) => !redLineIsUrgent(line) && !redLineNamesAddress(line));
			const dynamic = (plugin.capabilities ?? []).includes("dynamic-code") ? ["dynamic-code"] : [];
			return [...quiet, ...dynamic];
		}
		/** Install-dialog fold (#739). A gray block, not an outlined frame: the icon
		* stays on the left and the chevron stays on the right, open or closed. */
		function ConfirmFold({ icon, title, meta, open, onToggle, children }) {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: Market_module_css_default.confirmPanel,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
					type: "button",
					className: Market_module_css_default.confirmPanelRow,
					"aria-expanded": open,
					onClick: onToggle,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.confirmPanelIcon,
							children: icon
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.confirmPanelTitle,
							children: title
						}),
						meta !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.confirmPanelMeta,
							children: meta
						}),
						open ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, {
							size: 14,
							className: Market_module_css_default.confirmPanelChevron
						}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronRightOutline14, {
							size: 14,
							className: Market_module_css_default.confirmPanelChevron
						})
					]
				}), open && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					className: Market_module_css_default.confirmPanelBody,
					children
				})]
			});
		}
		/** Catalog npm latest, omitted for github-only and not-yet-backfilled rows. */
		function CatalogVersionMark({ version, tip }) {
			if (typeof version !== "string" || version.length === 0) return null;
			const label = /^v/i.test(version) ? version : `v${version}`;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(CardTip, {
				label: tip,
				maxWidth: 280,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: Market_module_css_default.star,
					children: `· ${label}`
				})
			});
		}
		/**
		* Module-scope caches so re-entering the section renders instantly instead
		* of refetching and rebuilding from a spinner (#30 by @StarsTom). Module
		* state survives section switches; a background refetch keeps it current.
		*
		* #846 adds the sidebar page as a second mount of MarketSection. Anything
		* that paints buttons or badges (updates, live/disabled, tab counts, host
		* filter) has to live here too — otherwise each open starts from empty and
		* the Installed tab's red dot / 「更新」buttons flash off then on, and the
		* two entries disagree until both refetches finish.
		*/
		let cachedRegistry = null;
		let cachedInstalled = null;
		let cachedRepoIdentities = null;
		let cachedRepoHints = null;
		let cachedHostCompatibility = {};
		let cachedHostVersion = void 0;
		/** Names with an in-flight discovery-compatibility request (module-wide). */
		const hostCompatibilityInFlight = /* @__PURE__ */ new Set();
		/** Subscribers for useSyncExternalStore — every mounted MarketSection. */
		const hostCompatibilityListeners = /* @__PURE__ */ new Set();
		let cachedUpdates = {};
		/** False until /dsh-market/updates has answered at least once this process. */
		let cachedUpdatesReady = false;
		let cachedInstalledReady = false;
		let cachedSkins = [];
		let cachedDisabledNames = [];
		let cachedInstalledFiles = [];
		let cachedFavoriteUrls = [];
		let cachedBlockedNames = [];
		let cachedInstalledBundles = [];
		let cachedActivations = {};
		/** Market package version from /status — the 「v1.66.x」 next to the title. */
		let cachedMarketVersion = null;
		/** Keep a React state setter and its module cache in lockstep. */
		function cacheState(write, setState) {
			return (value) => {
				setState((current) => {
					const next = typeof value === "function" ? value(current) : value;
					write(next);
					return next;
				});
			};
		}
		/** Any cached answer counts — including unavailable. Re-querying every
		* remount used to re-POST thousands of names; a host-version change (below)
		* is what drops the map for a fresh scan. */
		function hostCompatibilitySettled(name) {
			return cachedHostCompatibility[name] !== void 0;
		}
		function clearHostCompatibilityCache() {
			cachedHostCompatibility = {};
			hostCompatibilityInFlight.clear();
			for (const listener of hostCompatibilityListeners) listener();
		}
		function subscribeHostCompatibility(onStoreChange) {
			hostCompatibilityListeners.add(onStoreChange);
			return () => {
				hostCompatibilityListeners.delete(onStoreChange);
			};
		}
		/** Merge into the module cache and notify every mounted MarketSection — a
		* sidebar/settings switch used to drop in-flight setStates and leave the
		* note frozen at 「正在检查 665/2455」. */
		function commitHostCompatibility(accepted) {
			cachedHostCompatibility = {
				...cachedHostCompatibility,
				...accepted
			};
			for (const listener of hostCompatibilityListeners) listener();
		}
		/** Discover grid page-size choices — the catalog grows daily, so cap each page. */
		const PAGE_SIZES = [
			24,
			48,
			96
		];
		const DEFAULT_PAGE_SIZE = 24;
		const WEBDAV_STORAGE_KEY = "dshm-webdav";
		function savedWebdav() {
			try {
				const value = JSON.parse(localStorage.getItem(WEBDAV_STORAGE_KEY) ?? "{}");
				return {
					url: typeof value.url === "string" ? value.url : "",
					username: typeof value.username === "string" ? value.username : "",
					password: "",
					auto: value.auto === true
				};
			} catch {
				return {
					url: "",
					username: "",
					password: "",
					auto: false
				};
			}
		}
		function backupDependencies(value) {
			if (value === null || typeof value !== "object") throw new Error("invalid backup");
			const backup = value;
			if (backup.format !== "dsh-profile-backup" || backup.version !== .2) throw new Error("unsupported backup format");
			const files = backup.files;
			if (!Array.isArray(files)) throw new Error("unsupported backup format");
			const manifest = files.find((file) => file !== null && typeof file === "object" && file.path === "package.json");
			if (manifest?.json === null || typeof manifest?.json !== "object" || Array.isArray(manifest.json)) throw new Error("backup package.json is invalid");
			const dependencies = manifest.json.dependencies;
			if (dependencies === null || typeof dependencies !== "object" || Array.isArray(dependencies)) return {};
			if (!Object.values(dependencies).every((spec) => typeof spec === "string")) throw new Error("backup dependencies are invalid");
			return dependencies;
		}
		function installedRepoIdentities(value) {
			if (value === null || typeof value !== "object" || Array.isArray(value)) return {};
			const identities = {};
			for (const [name, ids] of Object.entries(value)) {
				if (!Array.isArray(ids)) continue;
				const strings = ids.filter((id) => typeof id === "string");
				if (strings.length > 0) identities[name] = strings;
			}
			return identities;
		}
		function installedRepoHints(value) {
			return installedRepoIdentities(value);
		}
		function installedMap(value) {
			if (value === null || typeof value !== "object" || Array.isArray(value)) return {};
			const installed = {};
			for (const [name, spec] of Object.entries(value)) if (typeof spec === "string") installed[name] = spec;
			return installed;
		}
		/** A `{name: {...}}` map, or anything else — for untyped server fields. */
		function isRecordOfRecords(value) {
			return value !== null && typeof value === "object" && !Array.isArray(value);
		}
		function sameInstalledMap(left, right) {
			const names = Object.keys(left);
			return names.length === Object.keys(right).length && names.every((name) => left[name] === right[name]);
		}
		/** Same cap as `MAX_NOTE` in hot.ts; the server trims anything longer. */
		const NOTE_MAX = 200;
		/** `latest` is a semver for npm installs and a commit sha for github ones. */
		function displayLatest(latest) {
			if (/^\d/.test(latest)) return "v" + latest;
			if (/^[0-9a-f]{12,40}$/i.test(latest)) return latest.slice(0, 7);
			return latest;
		}
		/** The tail of a local checkout path; the full path stays in the title and the copy button. */
		function shortLocalPath(path) {
			const parts = path.replace(/[\\/]+$/, "").split(/[\\/]/).filter(Boolean);
			return parts.length <= 2 ? path : "…/" + parts.slice(-2).join("/");
		}
		/** A relative spec is resolved against the profile directory, so copying it elsewhere is meaningless. */
		function isAbsoluteLocalPath(path) {
			return /^(?:\/|~[\\/]|[A-Za-z]:[\\/]|\\\\)/.test(path);
		}
		/** `file:///abs` keeps one leading slash, like `file:/abs`. */
		function localPathOf(spec) {
			const match = /^(?:link|file):(?:\/\/(?=\/))?(.+)$/i.exec(spec);
			return match !== null ? match[1] : null;
		}
		/**
		* A development checkout or local package. A generation is the desktop host's
		* own install (#497) and is never one, even though its spec is a link:.
		*/
		function isLocalDev(spec, status) {
			if (status?.kind === "generation" || isGenerationSpec(spec)) return false;
			return /^(?:link|file):/i.test(spec) || status?.kind === "linked";
		}
		/**
		* Whether one installed plugin has a pending update (either an ordinary
		* upgrade via npm/git/restore, or a host-managed generation release), and has
		* not already been updated in the current session.
		*
		* THE answer to that question. It used to have three copies that disagreed —
		* the reminder count, the card's pill, and the installed list's ordering —
		* which is the shape this repository already paid for once
		* (`src/entry-identity.ts`: one assumption, several copies, each fixed at a
		* different time). Callers now pass the two things that are genuinely their
		* own policy:
		*
		* - `ignored`: a session-level "ignore this update" (#657). The NOTICE
		*   surfaces pass it — the badge and the ordering, because a row the user
		*   dismissed should not keep jumping to the top or counting toward
		*   attention. The row's own pill does NOT, because the pill answers "is
		*   there an update" (which dismissing does not change) and the row shows the
		*   dismissal right beside it.
		* - whether a disabled plugin counts, which the reminder count says no to and
		*   the list says yes to: a disabled row is still a row someone may want to
		*   update from the list, but it is not asking for attention.
		*/
		function isPluginUpdatable(name, spec, status, updatedNames, ignored = /* @__PURE__ */ new Set()) {
			if (updatedNames.includes(name) || ignored.has(name) || status === void 0) return false;
			if (status.updateAvailable === true) return true;
			return (status.kind === "generation" || isGenerationSpec(spec)) && status.latest != null;
		}
		/** Sort field choices in the filter panel. */
		const SORT_FIELD_OPTIONS = [
			{
				key: "downloads",
				label: "sortDownloads"
			},
			{
				key: "stars",
				label: "sortStars"
			},
			{
				key: "added",
				label: "sortAdded"
			}
		];
		/** Sort direction choices in the filter panel (labels depend on the field). */
		const SORT_DIR_OPTIONS = ["desc", "asc"];
		/** Published-within choices in the filter panel. */
		const TIME_OPTIONS = [
			{
				key: "all",
				label: "timeAll"
			},
			{
				key: "day",
				label: "timeDay"
			},
			{
				key: "week",
				label: "timeWeek"
			},
			{
				key: "month",
				label: "timeMonth"
			},
			{
				key: "quarter",
				label: "timeQuarter"
			},
			{
				key: "year",
				label: "timeYear"
			}
		];
		/**
		* What the two moves say (#1012). Same dialog and same transaction, so the
		* difference belongs in one branch rather than a ternary per line.
		*/
		function sourceMigrationCopy(confirm, t) {
			if (confirm.kind === "npm-rename") return {
				title: t("renameTitle"),
				description: t("renameDescription"),
				confirmLabel: t("renameContinue"),
				currentLabel: t("renameCurrentPackage"),
				targetLabel: t("renameTargetPackage"),
				note: t("renameWarning"),
				noteTone: "plain"
			};
			return {
				title: t("migrateTitle"),
				description: t("migrateDescription"),
				confirmLabel: t("migrateContinue"),
				currentLabel: t("migrateCurrentSource"),
				targetLabel: t("migrateTargetSource"),
				note: t("migrateWarning"),
				noteTone: "warning"
			};
		}
		/**
		* The sessions a host 409 named as blocking (#752).
		*
		* The agent guard refuses before it touches pnpm and answers with the sessions
		* that are running. Keeping them on the record is what lets a queued row say
		* WHY it is not moving: a queue entry with no reason reads as an operation
		* that is merely last in line, and "it never starts" is what the user reports.
		*
		* @returns the session names, or undefined when the host named none.
		*/
		function blockedSessions(body) {
			if (!Array.isArray(body.runningAgents)) return void 0;
			const names = body.runningAgents.map(String).filter((name) => name !== "");
			return names.length === 0 ? void 0 : names;
		}
		/**
		* Drop a Host-projected row before the page's own record adopts the same
		* operation id (#411).
		*
		* The status poll can create `host-<id>` while a slow probe is still running;
		* without this the 202 would leave both rows pointing at one Host operation,
		* and the panel's first match would keep the synthetic one forever.
		*/
		function withoutHostProjection(list, operationId, keepId) {
			return list.filter((record) => record.id === keepId || record.id !== `host-${operationId}` && record.hostOperationId !== operationId);
		}
		/**
		* Whether the "compatible with this host" filter starts on, and remembers the
		* answer once the user disagrees with the default (#872).
		*
		* Storage may be unavailable (private mode, a locked-down webview); the
		* default is what matters, so a failure to read it is not a failure.
		*/
		const HOST_FILTER_KEY = "dshm-host-filter";
		function readHostFilterPreference() {
			try {
				return localStorage.getItem(HOST_FILTER_KEY) !== "all";
			} catch {
				return true;
			}
		}
		/**
		* 最近收录 display preferences: collapsed / hidden (#940).
		*
		* The block only appears on the discover tab with an empty search and both
		* filters on "all", so it cannot be avoided without changing what the user is
		* looking at. It is a one-row teaser, not a second catalog. Both states
		* are display preferences, not profile settings: since 0.1.7 the settings
		* surface is deliberately just `allowRestart`.
		*
		* Same read discipline as HOST_FILTER_KEY above: an unavailable store falls
		* back to the default, and the default is "expanded and shown".
		*/
		const RECENT_COLLAPSED_KEY = "dshm-recent-collapsed";
		const RECENT_HIDDEN_KEY = "dshm-recent-hidden";
		/** Cap for the Discover teaser. Extra tiles live in a quiet horizontal
		* scroll so the block stays one row tall. */
		const RECENT_STRIP_LIMIT = 8;
		function readRecentFlag(key) {
			try {
				return localStorage.getItem(key) === "1";
			} catch {
				return false;
			}
		}
		function writeRecentFlag(key, next) {
			try {
				localStorage.setItem(key, next ? "1" : "0");
			} catch {}
		}
		/** "不再提示" on the settings-page sidebar tip. A missing store means show it. */
		const SIDEBAR_TIP_KEY = "dshm-sidebar-tip-dismissed";
		function readSidebarTipDismissed() {
			try {
				return localStorage.getItem(SIDEBAR_TIP_KEY) === "1";
			} catch {
				return false;
			}
		}
		function writeSidebarTipDismissed() {
			try {
				localStorage.setItem(SIDEBAR_TIP_KEY, "1");
			} catch {}
		}
		/**
		* The element that actually scrolls the list.
		*
		* Settings and the sidebar own `.body`. The Plugins page tab is content-sized
		* inside the host's page, so the scroller is the first ancestor with overflow
		* auto or scroll — the same walk the old height measurement used. Themes
		* fullscreen puts the market back in an overlay with `.body` as the scroller
		* again (the CSS already drops the flatten rules), so that path returns body.
		* No host ancestor (jsdom, a host that has not laid out) falls back to the
		* document's scrolling element when there is one.
		*/
		function listScroller(surface, root, body, fullscreen = false) {
			if (surface !== "plugins" || fullscreen) return body;
			for (let node = root?.parentElement ?? null; node !== null; node = node.parentElement) if (/^(auto|scroll|overlay)$/.test(getComputedStyle(node).overflowY)) return node;
			const scrolling = root?.ownerDocument.scrollingElement;
			return scrolling instanceof HTMLElement ? scrolling : null;
		}
		/**
		* How far the host's own stuck chrome already occupies the top of the
		* Plugins page scroller. The market's tab row sticks just below that, so it
		* does not cover 已安装 / 插件市场 / 发现 after the page header compactifies.
		*
		* Only preceding siblings on the path from this panel up to the scroller —
		* the host chrome sits above us. Walking the whole scroller would crawl the
		* catalog on every frame.
		*
		* dsh 0.2.2 keeps the plugin-page header's layout box at its resting height
		* and paints only the compact slice: an absolutely positioned ::before of
		* `--plugin-header-paint-height`, with the title clipped away. The border box
		* still reports the resting height, so sticking under `rect.bottom` parks
		* the market's own rows in that clipped gap and the catalog scrolls through
		* them. The cover is that ::before only when it is the opaque bar: shorter
		* than the box, flush to the top and both sides, and filled. A marker or a
		* strip hung from the bottom keeps the border box. Hosts without one keep
		* the border box.
		*/
		/**
		* Bottom of a stuck bar's opaque ::before, in the same coordinate space as
		* `rect`, or null when that pseudo-element is not the cover.
		*
		* The 0.2.2 page bar's cover is `inset: 0 0 auto` with the page background,
		* so it starts at the padding edge (no border, no padding-top on that bar)
		* and is shorter than the resting box. A marker, a hairline, or a strip
		* anchored with `bottom` does not qualify — those keep the border box.
		*/
		function paintedCoverBottom(node, rect) {
			const before = getComputedStyle(node, "::before");
			if (before.content === "none" || before.content === "normal") return null;
			if (before.position !== "absolute" && before.position !== "fixed") return null;
			const height = Number.parseFloat(before.height);
			if (!Number.isFinite(height) || height <= 0 || height >= rect.height - 1) return null;
			const top = Number.parseFloat(before.top);
			const left = Number.parseFloat(before.left);
			const right = Number.parseFloat(before.right);
			if (!Number.isFinite(top) || Math.abs(top) > 1) return null;
			if (!Number.isFinite(left) || !Number.isFinite(right) || Math.abs(left) > 1 || Math.abs(right) > 1) return null;
			if (before.backgroundColor === "transparent" || before.backgroundColor === "rgba(0, 0, 0, 0)") return null;
			const borderTop = Number.parseFloat(getComputedStyle(node).borderTopWidth);
			const border = Number.isFinite(borderTop) ? borderTop : 0;
			return rect.top + border + top + height;
		}
		/**
		* Painted height of a stuck bar that keeps its layout box and clips the rest.
		*
		* dsh 0.2.2's plugin page writes the drawn height onto the bar every frame as
		* an inline `--plugin-header-paint-height` and clips the box with it, so the
		* border box keeps reporting the resting height the bar no longer occupies.
		* Sticking under that number left a bare strip above the market's tab row
		* with cards scrolling through it (#1125). Read the drawn number when the
		* host publishes one; null means the border box is the honest one.
		*/
		function paintedBarHeight(node, rect) {
			const inline = node.style?.getPropertyValue("--plugin-header-paint-height");
			if (inline === void 0 || inline.trim() === "") return null;
			const value = Number.parseFloat(inline);
			if (!Number.isFinite(value)) return null;
			return Math.max(0, Math.min(rect.height, value));
		}
		function hostStickyOffset(scroller, market) {
			const scrollerTop = scroller.getBoundingClientRect().top;
			let bottom = scrollerTop;
			const consider = (node) => {
				const position = getComputedStyle(node).position;
				if (position !== "sticky" && position !== "fixed") return;
				const rect = node.getBoundingClientRect();
				if (rect.height <= 0 || rect.top > scrollerTop + 4 || rect.bottom <= scrollerTop) return;
				const painted = paintedBarHeight(node, rect);
				if (painted !== null) {
					bottom = Math.max(bottom, rect.top + painted);
					return;
				}
				bottom = Math.max(bottom, paintedCoverBottom(node, rect) ?? rect.bottom);
			};
			const walkPreceding = (node) => {
				consider(node);
				for (const child of node.children) walkPreceding(child);
			};
			let node = market;
			while (node !== null && node !== scroller) {
				const parent = node.parentElement;
				if (parent === null) break;
				for (const sibling of parent.children) {
					if (sibling === node) break;
					walkPreceding(sibling);
				}
				node = parent;
			}
			return Math.max(0, Math.round(bottom - scrollerTop));
		}
		/** True when `el` is sitting on its sticky line, not still in flow and not scrolled away. */
		function isPinned(scroller, el, inset) {
			if (scroller.scrollTop <= 0 || el.getBoundingClientRect().height <= 0) return false;
			const line = scroller.getBoundingClientRect().top + inset;
			const top = el.getBoundingClientRect().top;
			return top <= line + 2 && top >= line - 4;
		}
		/**
		* ScrollTop where the market's tab row first sticks under the host chrome.
		* Unsticks for one measurement so a currently-pinned head still reports its
		* in-flow offset. That is the "top" Plugins back-to-top aims for — tabs stay
		* stuck, the host title does not reopen.
		*/
		function headPinScrollTop(scroller, market, head) {
			const hostTop = hostStickyOffset(scroller, market);
			const prev = head.style.position;
			head.style.position = "static";
			const y = head.getBoundingClientRect().top - scroller.getBoundingClientRect().top + scroller.scrollTop;
			head.style.position = prev;
			return Math.max(0, Math.round(y - hostTop));
		}
		function MarketSection(props) {
			const t = props.t;
			const initialWebdav = (0, react.useMemo)(savedWebdav, []);
			const localeSnap = (0, react.useSyncExternalStore)((cb) => props.locale.subscribe(cb), () => props.locale.getSnapshot());
			const lang = String(localeSnap.active).toLowerCase().startsWith("zh") ? "zh" : "en";
			const surface = props.surface ?? "settings";
			const sidebar = props.sidebar;
			const hostNavigation = props.hostNavigation;
			const openInHost = (0, react.useSyncExternalStore)((cb) => hostNavigation?.subscribe(cb) ?? (() => {}), () => hostNavigation?.get());
			const [sidebarSnap, setSidebarSnap] = (0, react.useState)(() => ({
				supported: sidebar?.supported() === true,
				enabled: sidebar?.enabled() === true,
				ready: sidebar?.ready() === true
			}));
			const [sidebarTipDismissed, setSidebarTipDismissed] = (0, react.useState)(readSidebarTipDismissed);
			const [sidebarTipSaving, setSidebarTipSaving] = (0, react.useState)(false);
			const [sidebarTipError, setSidebarTipError] = (0, react.useState)(null);
			(0, react.useEffect)(() => {
				if (sidebar === void 0) return void 0;
				const sync = () => {
					setSidebarSnap({
						supported: sidebar.supported(),
						enabled: sidebar.enabled(),
						ready: sidebar.ready()
					});
				};
				sync();
				return sidebar.subscribe(sync);
			}, [sidebar]);
			const showSidebarTip = surface === "settings" && sidebarSnap.ready && sidebarSnap.supported && !sidebarSnap.enabled && !sidebarTipDismissed;
			const enableSidebar = (0, react.useCallback)(() => {
				if (sidebar === void 0) return;
				setSidebarTipError(null);
				setSidebarTipSaving(true);
				sidebar.set(true).catch((cause) => {
					setSidebarTipError(cause instanceof Error ? cause.message : String(cause));
				}).finally(() => {
					setSidebarTipSaving(false);
				});
			}, [sidebar]);
			const themeSnap = (0, react.useSyncExternalStore)(props.themeStore.subscribe, props.themeStore.getSnapshot);
			const [data, setData] = (0, react.useState)(cachedRegistry);
			const [loadError, setLoadError] = (0, react.useState)(null);
			/**
			* The host answered 404 on one of the market's own routes (#962).
			*
			* That is not a failed request: it means DSH reloaded its plugins and did
			* not mount the market again, so nothing on this page can reach the host —
			* not the catalog, not the operation lock, not the restart route. The page
			* already on screen keeps rendering (it is a client-side app), which is
			* exactly why it owes the user this sentence instead of a spinner.
			*/
			const [marketGone, setMarketGone] = (0, react.useState)(false);
			const [reconnecting, setReconnecting] = (0, react.useState)(true);
			const [reconnectRound, setReconnectRound] = (0, react.useState)(0);
			const [installed, setInstalledState] = (0, react.useState)(cachedInstalled ?? {});
			const setInstalled = (0, react.useCallback)((value) => {
				cachedInstalled = value;
				setInstalledState(value);
			}, []);
			const [repoIdentities, setRepoIdentitiesState] = (0, react.useState)(cachedRepoIdentities ?? {});
			const setRepoIdentities = (0, react.useCallback)((value) => {
				cachedRepoIdentities = value;
				setRepoIdentitiesState(value);
			}, []);
			const [repoHints, setRepoHintsState] = (0, react.useState)(cachedRepoHints ?? {});
			const setRepoHints = (0, react.useCallback)((value) => {
				cachedRepoHints = value;
				setRepoHintsState(value);
			}, []);
			const [installedFiles, setInstalledFilesState] = (0, react.useState)(() => cachedInstalledFiles);
			const setInstalledFiles = (0, react.useCallback)(cacheState((value) => {
				cachedInstalledFiles = value;
			}, setInstalledFilesState), []);
			const [skins, setSkinsState] = (0, react.useState)(() => cachedSkins);
			const setSkins = (0, react.useCallback)(cacheState((value) => {
				cachedSkins = value;
			}, setSkinsState), []);
			const [tab, setTab] = (0, react.useState)(() => {
				const saved = sessionStorage.getItem("dshm-tab");
				if (saved !== null) sessionStorage.removeItem("dshm-tab");
				return saved || "discover";
			});
			const [q, setQ] = (0, react.useState)("");
			const [discoverSearchReset, resetDiscoverSearch] = (0, react.useState)(0);
			const [installedSearchReset, resetInstalledSearch] = (0, react.useState)(0);
			/** Per-tab searches stay independent: discover / themes / installed. */
			const [qThemes, setQThemes] = (0, react.useState)("");
			const [themeSearchReset, resetThemeSearch] = (0, react.useState)(0);
			const [qFavorites, setQFavorites] = (0, react.useState)("");
			const [qInstalled, setQInstalled] = (0, react.useState)("");
			const [cat, setCat] = (0, react.useState)("all");
			(0, react.useEffect)(() => {
				const target = props.preferredSubsectionId;
				if (target === void 0) return;
				const separator = target.indexOf(":");
				const kind = separator === -1 ? target : target.slice(0, separator);
				const value = separator === -1 ? "" : target.slice(separator + 1);
				if (kind === "installed") {
					setTab("installed");
					setQInstalled(value);
					resetInstalledSearch((n) => n + 1);
				} else if (kind === "discover") {
					setTab("discover");
					setCat("all");
					setQ(value);
					resetDiscoverSearch((n) => n + 1);
				}
			}, [props.preferredSubsectionId]);
			const [confirming, setConfirming] = (0, react.useState)(null);
			/** The plugin whose comment thread is open, or null. */
			const [commentsFor, setCommentsFor] = (0, react.useState)(null);
			/**
			* Every mutating operation the user started. Records outlive the card that
			* started them, so paginating or searching cannot take a pending decision
			* off screen — and finished records outlive the page load too (see the
			* settled restore below); one still moving or waiting on a decision does not.
			*/
			const [records, setRecords] = (0, react.useState)([]);
			const recordSeq = (0, react.useRef)(0);
			/** The synthetic install task rebuilt from dshm-pending after a remount. */
			const recoveredInstall = (0, react.useRef)(null);
			/** The synthetic task rebuilt from dshm-updating after this section remounts. */
			const recoveredUpdateRecordId = (0, react.useRef)(null);
			/**
			* The install queue: agents-busy 409s become `queued` records instead of
			* failures, and drain automatically when agents go idle (see drainQueue).
			* Persisted in localStorage so a refresh keeps the queue; only `queued`
			* records persist — `running` recovery stays on the dshm-pending paths.
			*/
			const [updates, setUpdatesState] = (0, react.useState)(() => cachedUpdates);
			const setUpdates = (0, react.useCallback)(cacheState((value) => {
				cachedUpdates = value;
			}, setUpdatesState), []);
			const queueRestoredRef = (0, react.useRef)(false);
			const [queueSnapshotReady, setQueueSnapshotReady] = (0, react.useState)({
				installed: cachedInstalledReady,
				updates: cachedUpdatesReady
			});
			(0, react.useEffect)(() => {
				if (queueRestoredRef.current) return;
				let saved = null;
				try {
					saved = JSON.parse(localStorage.getItem("dshm-queue-v1") ?? "null");
				} catch {
					saved = null;
				}
				if (!Array.isArray(saved) || saved.length === 0) {
					queueRestoredRef.current = true;
					return;
				}
				if (data === null) return;
				if (saved.some((row) => row?.kind === "update" || row?.kind === "uninstall") && !queueSnapshotReady.installed) return;
				if (saved.some((row) => row?.kind === "update") && !queueSnapshotReady.updates) return;
				queueRestoredRef.current = true;
				try {
					localStorage.removeItem("dshm-queue-v1");
				} catch {}
				/**
				* A queued row may only run while the world it was queued in still holds.
				*
				* It drains with no confirmation — that is what queueing is — so a row
				* that has gone stale is a destructive operation launched from an old
				* decision: queue an uninstall at 10:00, uninstall it by hand (or change
				* your mind), open the market at 15:00 and it runs. Each kind therefore
				* has to be true RIGHT NOW, and a row that no longer is gets REPORTED
				* rather than executed or silently dropped — the user queued it, so the
				* user is told what became of it.
				*/
				const judged = saved.flatMap((entry) => {
					if (entry === null || typeof entry !== "object") return [];
					const row = entry;
					const kindRaw = row.kind;
					if (kindRaw !== "install" && kindRaw !== "update" && kindRaw !== "uninstall") return [];
					if (typeof row.name !== "string" || row.name === "") return [];
					if (row.url !== void 0 && typeof row.url !== "string") return [];
					const kind = kindRaw;
					const name = row.name;
					const url = typeof row.url === "string" ? row.url : void 0;
					const stale = (reason) => [{
						ok: false,
						kind,
						name,
						url,
						reason
					}];
					const options = row.updateOptions !== null && typeof row.updateOptions === "object" ? row.updateOptions : {};
					const verdict = queuedRowApplies({
						kind,
						name,
						restore: options.restore === true,
						...typeof options.eligibleVersion === "string" ? { eligibleVersion: options.eligibleVersion } : {},
						...url === void 0 ? {} : { url }
					}, {
						installed,
						updates,
						plugins: data.plugins
					});
					if (verdict !== null) return stale(verdict === "target-changed" ? localizeBilingual("更新目标已变化，已跳过。请重新选择更新。 / The update target changed, so this task was skipped. Choose the update again.", lang) : verdict === "gone" ? t("agentQueueStaleGone") : t("agentQueueStaleNoUpdate"));
					if (kind === "install" && url === void 0) return [];
					const updateOptions = kind === "update" ? {
						force: options.force === true,
						restore: options.restore === true,
						...typeof options.compatVersion === "string" ? { compatVersion: options.compatVersion } : {},
						...typeof options.eligibleVersion === "string" ? { eligibleVersion: options.eligibleVersion } : {}
					} : void 0;
					return [{
						ok: true,
						row: {
							kind,
							name,
							...url === void 0 ? {} : { url },
							updateOptions
						}
					}];
				});
				const valid = judged.flatMap((verdict) => verdict.ok ? [verdict.row] : []);
				const stale = judged.flatMap((verdict) => verdict.ok ? [] : [verdict]);
				if (valid.length === 0 && stale.length === 0) return;
				setRecords((prev) => {
					const kept = [...prev];
					for (const entry of valid) {
						if (kept.some((record) => record.state === "queued" && record.kind === entry.kind && record.name === entry.name && (entry.kind !== "install" || record.url === entry.url))) continue;
						recordSeq.current += 1;
						kept.push({
							id: `op-${String(recordSeq.current)}`,
							kind: entry.kind,
							name: entry.name,
							...entry.url === void 0 ? {} : { url: entry.url },
							...entry.updateOptions === void 0 ? {} : { updateOptions: entry.updateOptions },
							state: "queued",
							reason: t("agentBusyQueued")
						});
					}
					for (const row of stale) {
						recordSeq.current += 1;
						kept.push({
							id: `op-${String(recordSeq.current)}`,
							kind: row.kind,
							name: row.name,
							...row.url === void 0 ? {} : { url: row.url },
							state: "failed",
							reason: row.reason
						});
					}
					return kept;
				});
				setOperationsOpen(true);
			}, [
				data,
				t,
				lang,
				queueSnapshotReady,
				installed,
				updates
			]);
			(0, react.useEffect)(() => {
				if (!queueRestoredRef.current) return;
				try {
					const queued = records.filter((record) => record.state === "queued" && record.hostOperationId === void 0).map((record) => ({
						kind: record.kind,
						name: record.name,
						...record.url === void 0 ? {} : { url: record.url },
						...record.updateOptions === void 0 ? {} : { updateOptions: record.updateOptions }
					}));
					if (queued.length === 0) localStorage.removeItem("dshm-queue-v1");
					else localStorage.setItem("dshm-queue-v1", JSON.stringify(queued));
				} catch {}
			}, [records]);
			/**
			* Finished rows survive a page load — and only finished rows.
			*
			* A failed operation is the one thing the panel cannot recover by itself:
			* after a reload the card is back to "Install", the plugin is not in
			* Installed (the host rolled the change back), and the sentence naming what
			* went wrong — plus the build-script approval that is the way out of it
			* (#314) — lived only in React state.
			*
			* The queue key owns `queued`, the dshm-pending markers own `running`, and
			* this key owns the rows that already ended. Unlike a queued row, a finished
			* one has nothing left to judge, so the restore waits for nothing — not even
			* the catalog.
			*/
			const settledRestoredRef = (0, react.useRef)(false);
			/** The restore's merge has not reached a render yet; see the write below. */
			const settledMergePendingRef = (0, react.useRef)(false);
			(0, react.useEffect)(() => {
				if (settledRestoredRef.current) return;
				settledRestoredRef.current = true;
				let saved = null;
				try {
					saved = localStorage.getItem(SETTLED_STORAGE_KEY);
				} catch {
					saved = null;
				}
				const restored = restoreSettled(saved);
				if (restored.length === 0) return;
				for (const record of restored) {
					const match = /^op-(\d+)$/.exec(record.id);
					if (match !== null) recordSeq.current = Math.max(recordSeq.current, Number(match[1]));
				}
				settledMergePendingRef.current = true;
				setRecords((prev) => {
					const known = new Set(prev.map((record) => record.id));
					const missing = restored.filter((record) => !known.has(record.id));
					return missing.length === 0 ? prev : [...prev, ...missing];
				});
			}, []);
			(0, react.useEffect)(() => {
				if (!settledRestoredRef.current) return;
				if (settledMergePendingRef.current) {
					settledMergePendingRef.current = false;
					return;
				}
				try {
					const settled = serializeSettled(records);
					if (settled.length === 0) localStorage.removeItem(SETTLED_STORAGE_KEY);
					else localStorage.setItem(SETTLED_STORAGE_KEY, JSON.stringify(settled));
				} catch {}
			}, [records]);
			/** Raised by the card marker, so "查看详情" lands on the record itself. */
			const [operationsOpen, setOperationsOpen] = (0, react.useState)(false);
			const openOperations = (0, react.useCallback)(() => setOperationsOpen(true), []);
			/**
			* Two plugins can ship under one name from different authors, so a roster
			* row that shows only the package name cannot tell the user which of their
			* plugins a swap would uninstall. Resolve through the catalog for the
			* author and avatar a card would show, and fall back to the bare name for
			* anything installed outside it.
			*/
			const describePlugin = (0, react.useCallback)((name) => {
				const entry = data?.plugins.find((plugin) => plugin.npm === name || plugin.name === name);
				if (entry === void 0) return { title: name };
				return {
					title: pluginName(entry.name, entry.npm),
					author: entry.owner === "" ? void 0 : entry.owner,
					avatar: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(OwnerAvatar, {
						name: entry.name,
						owner: entry.owner || "",
						icon: entry.icon ?? void 0
					})
				};
			}, [data]);
			/** Ids are sequential rather than random so a replayed session is stable. */
			const nextRecordId = (0, react.useCallback)(() => {
				recordSeq.current += 1;
				return `op-${String(recordSeq.current)}`;
			}, []);
			const [replacing, setReplacing] = (0, react.useState)(false);
			/** Shared by every screenshot source (card thumbnail, dialog strip). */
			const [lightbox, setLightbox] = (0, react.useState)(null);
			const openLightbox = (shots, index) => setLightbox({
				shots,
				index
			});
			const [themesFullscreen, setThemesFullscreen] = (0, react.useState)(false);
			const [busyUrl, setBusyUrl] = (0, react.useState)(null);
			/** Consecutive idle polls with a pending install that never landed (#32). */
			const idleStrikes = (0, react.useRef)(0);
			/** Same idle-strike bookkeeping for an update whose response was lost. */
			const updateIdleStrikes = (0, react.useRef)(0);
			const [doneUrls, setDoneUrls] = (0, react.useState)([]);
			const [installError, setInstallError] = (0, react.useState)(null);
			/**
			* The recovery surface, when a restart this page asked for did not come
			* back. Non-null means the origin answering /dsh-market/* is the recovery
			* server, not the host — see RecoveryPanel.tsx.
			*/
			const [recovery, setRecovery] = (0, react.useState)(null);
			const [recoveryOpen, setRecoveryOpen] = (0, react.useState)(false);
			const [recoveryKeep, setRecoveryKeep] = (0, react.useState)({});
			const [recoveryBusy, setRecoveryBusy] = (0, react.useState)(false);
			const [favoriteError, setFavoriteError] = (0, react.useState)(null);
			/** Ignores out-of-order /dsh-market/favorite responses after a newer toggle. */
			const favoriteOpGen = (0, react.useRef)(0);
			const [blockError, setBlockError] = (0, react.useState)(null);
			const [updateExemptError, setUpdateExemptError] = (0, react.useState)(null);
			const [updateExemptNotice, setUpdateExemptNotice] = (0, react.useState)(null);
			const updateExemptOpGen = (0, react.useRef)(0);
			/** Shown once a hide sticks, so the card vanishing has a place to look. */
			const [blockNotice, setBlockNotice] = (0, react.useState)(null);
			/** Ignores out-of-order /dsh-market/block responses after a newer toggle. */
			const blockOpGen = (0, react.useRef)(0);
			const [pluginMenuUrl, setPluginMenuUrl] = (0, react.useState)(null);
			const [installedMenuName, setInstalledMenuName] = (0, react.useState)(null);
			const [clearingStale, setClearingStale] = (0, react.useState)(false);
			const [compatibilityNotice, setCompatibilityNotice] = (0, react.useState)(null);
			const [rollingBack, setRollingBack] = (0, react.useState)(false);
			/** Log export lifecycle for visible feedback (#84): idle → busy → done/fail. */
			const [exportState, setExportState] = (0, react.useState)("idle");
			/**
			* Programmatic log download with explicit feedback (#84) — the plain
			* `<a download>` gave no sign anything happened, and the error banner's
			* "export the log" wording pointed at text that was not clickable at all.
			* Success/failure surface as a primitives Toast (body portal, no layout
			* impact) instead of inline text.
			*/
			const doExportLog = (0, react.useCallback)(() => {
				setExportState("busy");
				exportMarketLog().then(() => setExportState("done"), () => setExportState("fail"));
			}, []);
			/** Stable onDone for the export Toast — a fresh closure per render would
			* reset the Toast's auto-dismiss timer on every parent re-render. */
			const exportToastDone = (0, react.useCallback)(() => setExportState("idle"), []);
			const favoriteErrorDone = (0, react.useCallback)(() => setFavoriteError(null), []);
			const blockErrorDone = (0, react.useCallback)(() => setBlockError(null), []);
			const blockNoticeDone = (0, react.useCallback)(() => setBlockNotice(null), []);
			const updateExemptErrorDone = (0, react.useCallback)(() => setUpdateExemptError(null), []);
			const updateExemptNoticeDone = (0, react.useCallback)(() => setUpdateExemptNotice(null), []);
			/** Update reminders dismissed for this host boot. The Installed tab still
			* shows these plugins and their update actions; only proactive prompts use
			* this set. */
			const [ignoredUpdateNames, setIgnoredUpdateNames] = (0, react.useState)([]);
			const [updatingName, setUpdatingName] = (0, react.useState)(null);
			/** Update-notes dialog (#294): which row opened it, and what it resolved to. */
			const [notesFor, setNotesFor] = (0, react.useState)(null);
			const [updateNotes, setUpdateNotes] = (0, react.useState)(null);
			const [notesState, setNotesState] = (0, react.useState)("loading");
			const [staleName, setStaleName] = (0, react.useState)(null);
			const [restoreConfirm, setRestoreConfirm] = (0, react.useState)(null);
			/** A release whose declared host requirement this host does not meet (#404). kind distinguishes the update dialog from the fresh-install dialog. */
			const [hostIncompatible, setHostIncompatible] = (0, react.useState)(null);
			/**
			* The answer to "the newest release is too new for this host — what CAN I
			* install?" (#581). The dialog asks as soon as it opens, because that
			* question is the only way out it can offer: the alternative the route
			* gives (install anyway) is a decision about breaking the host, and most
			* users reaching this dialog have no way to weigh it.
			*/
			const [findingCompat, setFindingCompat] = (0, react.useState)({ status: "idle" });
			const [compatRetry, setCompatRetry] = (0, react.useState)(0);
			(0, react.useEffect)(() => {
				if (hostIncompatible === null || hostIncompatible.npmName === null) {
					setFindingCompat({ status: "idle" });
					return;
				}
				const controller = new AbortController();
				setFindingCompat({ status: "loading" });
				fetch(api("/dsh-market/find-compatible"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						npmName: hostIncompatible.npmName,
						upgradeOnly: hostIncompatible.kind === "update"
					}),
					signal: controller.signal
				}).then(async (response) => {
					if (!response.ok) throw new Error(`HTTP ${response.status}`);
					return await response.json();
				}).then((data) => {
					if (controller.signal.aborted) return;
					if (!(typeof data.compatibleVersion === "string" && data.compatibleVersion !== "")) {
						setFindingCompat({ status: "not-found" });
						return;
					}
					const maturity = data.maturity !== null && typeof data.maturity === "object" ? data.maturity : null;
					setFindingCompat({
						status: "found",
						version: data.compatibleVersion,
						installable: typeof maturity?.installable === "boolean" ? maturity.installable : null,
						releaseAgeMs: typeof maturity?.releaseAgeMs === "number" ? maturity.releaseAgeMs : null,
						nextMaturityAt: typeof maturity?.nextMaturityAt === "string" ? maturity.nextMaturityAt : null
					});
				}).catch(() => {
					if (!controller.signal.aborted) setFindingCompat({ status: "error" });
				});
				return () => controller.abort();
			}, [hostIncompatible, compatRetry]);
			const hostCompatHeldUpdate = hostIncompatible === null ? void 0 : updates[hostIncompatible.npmName ?? ""];
			const hostCompatHeld = findingCompat.status === "found" && (findingCompat.installable === false || findingCompat.installable === null && hostCompatHeldUpdate?.heldUpdate !== void 0 && hostCompatHeldUpdate.heldUpdate.latest === findingCompat.version && Date.parse(hostCompatHeldUpdate.heldUpdate.until) > Date.now());
			const hostCompatNextMaturityAt = findingCompat.status === "found" && findingCompat.installable === null ? hostCompatHeldUpdate?.heldUpdate?.until ?? null : findingCompat.status === "found" ? findingCompat.nextMaturityAt : null;
			const hostCompatHeldHours = hostCompatHeld && hostCompatNextMaturityAt !== null ? Math.max(1, Math.ceil((Date.parse(hostCompatNextMaturityAt) - Date.now()) / 36e5)) : null;
			const hostCompatWindowHours = findingCompat.status === "found" && findingCompat.releaseAgeMs !== null ? Math.max(1, Math.round(findingCompat.releaseAgeMs / 36e5)) : 24;
			const [restoreBlocked, setRestoreBlocked] = (0, react.useState)(null);
			const [migrationConfirm, setMigrationConfirm] = (0, react.useState)(null);
			/** Determinate percent parsed from pnpm's Progress line, when available. */
			const [progressPct, setProgressPct] = (0, react.useState)(null);
			/**
			* Blocked build scripts from the last install or update: enables
			* approve-and-retry (#6; updates in #69). Exactly one of `plugin`
			* (retry installs it) / `updateName` (retry re-runs the update) is set.
			*/
			const [buildsSkipped, setBuildsSkipped] = (0, react.useState)(null);
			const [updatingAll, setUpdatingAll] = (0, react.useState)(false);
			const [updatedNames, setUpdatedNames] = (0, react.useState)([]);
			const [restartNames, setRestartNames] = (0, react.useState)([]);
			const [hotUrls, setHotUrls] = (0, react.useState)([]);
			const [hotNames, setHotNames] = (0, react.useState)([]);
			const [progressLine, setProgressLine] = (0, react.useState)(null);
			/** Per-package activation states from /dsh-market/installed + operations. */
			const [activations, setActivationsState] = (0, react.useState)(() => cachedActivations);
			const setActivations = (0, react.useCallback)(cacheState((value) => {
				cachedActivations = value;
			}, setActivationsState), []);
			/** #60: persisted disable list + custom groups, straight from /installed. */
			const [disabledNames, setDisabledNamesState] = (0, react.useState)(() => cachedDisabledNames);
			const setDisabledNames = (0, react.useCallback)(cacheState((value) => {
				cachedDisabledNames = value;
			}, setDisabledNamesState), []);
			/** The user's own note per plugin (#347): package name → text. */
			const [notes, setNotes] = (0, react.useState)({});
			/** Catalog URLs bookmarked for later install (#414). */
			const [favoriteUrls, setFavoriteUrlsState] = (0, react.useState)(() => cachedFavoriteUrls);
			const setFavoriteUrls = (0, react.useCallback)(cacheState((value) => {
				cachedFavoriteUrls = value;
			}, setFavoriteUrlsState), []);
			/** Package names the user hid from Discover (#657). */
			const [blockedNames, setBlockedNamesState] = (0, react.useState)(() => cachedBlockedNames);
			const setBlockedNames = (0, react.useCallback)(cacheState((value) => {
				cachedBlockedNames = value;
			}, setBlockedNamesState), []);
			const [updateExemptNames, setUpdateExemptNames] = (0, react.useState)([]);
			/** Rows the user asked to show the AUTHOR's description on, despite a note. */
			const [showTheirs, setShowTheirs] = (0, react.useState)([]);
			/** The row whose note is being edited, and the text in the box. */
			const [notingName, setNotingName] = (0, react.useState)(null);
			const [noteDraft, setNoteDraft] = (0, react.useState)("");
			/** The disable set as of the first load; null until it arrives. */
			const loadedDisabled = (0, react.useRef)(null);
			/**
			* Patch-layer flags (port of dsh-plugin-hub): packages whose bundle rows
			* the user patch layer disables / force-enables. The UI treats them as the
			* real switch state so hand-edited cordis.patch.yml toggles are visible.
			*/
			const [patchDisabledNames, setPatchDisabledNames] = (0, react.useState)([]);
			/** Bundle packages DSH's own plugin page turned off by leaving them out of dsh.profile.bundles (#696). */
			const [unbundledNames, setUnbundledNames] = (0, react.useState)([]);
			const [groups, setGroups] = (0, react.useState)({});
			const [groupOrder, setGroupOrder] = (0, react.useState)([]);
			/** Installed-tab sub-view: flat list or groups (All-plugins was removed —
			* it duplicated the Discover tab). */
			const [installedView, setInstalledView] = (0, react.useState)("list");
			const [togglingName, setTogglingName] = (0, react.useState)(null);
			const [creatingGroup, setCreatingGroup] = (0, react.useState)(false);
			const [newGroupName, setNewGroupName] = (0, react.useState)("");
			const [renamingGroup, setRenamingGroup] = (0, react.useState)(null);
			const [renamingValue, setRenamingValue] = (0, react.useState)("");
			const [deletingGroup, setDeletingGroup] = (0, react.useState)(null);
			/** Open add-members picker for this group name. Plugins only. */
			const [addPanel, setAddPanel] = (0, react.useState)(null);
			const [addQuery, setAddQuery] = (0, react.useState)("");
			const [addSelected, setAddSelected] = (0, react.useState)([]);
			/** Group whose single theme slot is being chosen. */
			const [themePanel, setThemePanel] = (0, react.useState)(null);
			const [themePick, setThemePick] = (0, react.useState)(null);
			const [groupMenuFor, setGroupMenuFor] = (0, react.useState)(null);
			const [collapsedGroups, setCollapsedGroups] = (0, react.useState)(() => /* @__PURE__ */ new Set());
			const [assignFor, setAssignFor] = (0, react.useState)(null);
			/** Structured progress from pnpm ndjson (P1-6). */
			const [progressPhase, setProgressPhase] = (0, react.useState)(null);
			const [progressCurrent, setProgressCurrent] = (0, react.useState)(null);
			const [progressDone, setProgressDone] = (0, react.useState)(0);
			const [cancelling, setCancelling] = (0, react.useState)(false);
			/** Server-side operation lock from /dsh-market/status (#91). */
			const [hostBusy, setHostBusy] = (0, react.useState)(false);
			/**
			* The market's own version, shown beside the heading. Most bug reports
			* arrive as a photo of the screen, and without a version in frame the
			* first reply always has to ask which one it was.
			*/
			const [version, setVersionState] = (0, react.useState)(() => cachedMarketVersion);
			const setVersion = (0, react.useCallback)(cacheState((value) => {
				cachedMarketVersion = value;
			}, setVersionState), []);
			/**
			* Intranet mode, as reported by the status route.
			*
			* React state as well as the module bit in market-data: the module bit is
			* what the pure helpers read (avatar routing, screenshot mining), but the
			* heading needs a re-render to show the badge, and the status answer lands
			* after the first paint.
			*/
			const [offline, setOffline] = (0, react.useState)(() => marketOffline());
			/**
			* The catalog's own build date (#712). The version on a card is the
			* catalog's copy, not a live npm lookup, so a plugin published after the
			* last refresh shows the older number — the tooltip has to say so, or
			* "npm latest" beside a number that is not npm's latest is a bug report
			* waiting to be filed. Null until the catalog answers.
			*/
			const [catalogUpdated, setCatalogUpdated] = (0, react.useState)(null);
			const catalogVersionTip = (0, react.useMemo)(() => catalogUpdated === null ? t("catalogVersionUndated") : t("catalogVersionDated").replace("{0}", catalogUpdated), [catalogUpdated, t]);
			/** Non-live activation results from the last operation, shown as a banner. */
			const [activationWarnings, setActivationWarnings] = (0, react.useState)([]);
			/**
			* Installed plugins whose client asks for a config namespace nothing serves
			* (#810). Server-computed, because the answer needs one client bundle read
			* per plugin and the client cannot see a bundle's contents.
			*/
			const [configNamespaceIssues, setConfigNamespaceIssues] = (0, react.useState)([]);
			const [hostDependencyFindings, setHostDependencyFindings] = (0, react.useState)([]);
			/** Plugin name awaiting uninstall confirmation (Modal). */
			const [removeConfirm, setRemoveConfirm] = (0, react.useState)(null);
			const [agentsConfirm, setAgentsConfirm] = (0, react.useState)(null);
			const [removingName, setRemovingName] = (0, react.useState)(null);
			const [removedCount, setRemovedCount] = (0, react.useState)(0);
			/** Toggles whose live fiber did not follow the switch — restart to apply. */
			const [toggleRestart, setToggleRestart] = (0, react.useState)(0);
			/** Last completed toggle, shown as a toast (#299). The switch and the row
			* tag already say the new state, but both live in a row the user may have
			* scrolled past — a mis-click there goes unnoticed. The toast is fixed on
			* screen, so it is the part that actually catches an accident. */
			const [toggled, setToggled] = (0, react.useState)(null);
			const toggledDone = (0, react.useCallback)(() => setToggled(null), []);
			/**
			* Dismissal of the host-reported restart notice, keyed to the current boot
			* so it reappears after a restart that did not happen and after any new
			* change. sessionStorage, not local: closing the tab is a fresh start.
			*/
			const [restartNoticeDismissed, setRestartNoticeDismissed] = (0, react.useState)(false);
			/** Client-part plugins toggled this session — their UI needs a refresh. */
			const [refreshNames, setRefreshNames] = (0, react.useState)([]);
			const [envReady, setEnvReady] = (0, react.useState)(true);
			/**
			* Packages the market stopped declaring because their build could no longer
			* compose (#663). They are gone from the installed list — this is the only
			* thing that can say why, so it is read from `/status` on every poll rather
			* than folded into a one-shot reply.
			*/
			const [brokenPlugins, setBrokenPlugins] = (0, react.useState)({});
			const brokenPluginNames = (0, react.useMemo)(() => Object.keys(brokenPlugins), [brokenPlugins]);
			const [dismissBrokenError, setDismissBrokenError] = (0, react.useState)(null);
			/**
			* Per plugin, not one counter for the panel (#763 review).
			*
			* A shared generation made a second plugin's success swallow the first one's
			* FAILURE, so a notice the server still had stayed hidden on screen with no
			* error — the panel claimed a state the server did not have. Each name
			* carries its own counter, so only a LATER click on the SAME plugin can
			* supersede this one, and a different plugin's reply never can.
			*/
			const dismissBrokenGen = (0, react.useRef)(/* @__PURE__ */ new Map());
			/**
			* Bumped by every authoritative `/installed` read. A dismiss whose reply
			* arrives after one was overtaken by that read: the panel is already showing
			* the server's truth, and rolling this failure back would put back a record
			* the read has since settled.
			*/
			const installedReadGen = (0, react.useRef)(0);
			/** Rows with a dismiss in flight, so one row cannot queue two. */
			const [dismissingBroken, setDismissingBroken] = (0, react.useState)(() => /* @__PURE__ */ new Set());
			const [envFixing, setEnvFixing] = (0, react.useState)(false);
			const [envFailed, setEnvFailed] = (0, react.useState)(false);
			const [bootId, setBootId] = (0, react.useState)(null);
			/** One-click restart (#14 by @ysyyhhh): server capability + in-flight state. */
			const [restartEnabled, setRestartEnabled] = (0, react.useState)(false);
			/** Supervisor the host detected around itself, when it named one (#229). */
			const [supervisor, setSupervisor] = (0, react.useState)(null);
			/** Debugger latch when one-click restart must not kill the host (#447). */
			const [debuggerLatch, setDebuggerLatch] = (0, react.useState)(null);
			const [restartReachable, setRestartReachable] = (0, react.useState)(true);
			const [restarting, setRestarting] = (0, react.useState)(false);
			const [showTop, setShowTop] = (0, react.useState)(false);
			const [backupBusy, setBackupBusy] = (0, react.useState)(false);
			const webdavInFlight = (0, react.useRef)(false);
			const [backupMessage, setBackupMessage] = (0, react.useState)(null);
			const [backupRestored, setBackupRestored] = (0, react.useState)(false);
			const [pendingBackup, setPendingBackup] = (0, react.useState)(null);
			const [pendingDependencies, setPendingDependencies] = (0, react.useState)({});
			const [webdavUrl, setWebdavUrl] = (0, react.useState)(initialWebdav.url);
			const [webdavUser, setWebdavUser] = (0, react.useState)(initialWebdav.username);
			const [webdavPassword, setWebdavPassword] = (0, react.useState)(initialWebdav.password);
			/**
			* Auto-backup found a configured username but no password (#1058).
			*
			* The password is never written to browser storage (deliberate), so after a
			* reload it is gone — and the daily upload then ran with an empty password
			* and failed with a bare `HTTP 401` every time the market opened. A missing
			* password is not a failure to retry blindly; it is a state the card should
			* say out loud and the auto-run should not enter.
			*/
			const [webdavNeedsPassword, setWebdavNeedsPassword] = (0, react.useState)(false);
			const [autoBackup, setAutoBackup] = (0, react.useState)(initialWebdav.auto);
			/** GitHub token — session memory only, never written to any storage. */
			const [gistToken, setGistToken] = (0, react.useState)("");
			/** Gist id — persisted across reloads (non-sensitive: the Gist itself is private). */
			const [gistId, setGistId] = (0, react.useState)(() => {
				try {
					return localStorage.getItem("dshm-gist-id") ?? "";
				} catch {
					return "";
				}
			});
			/** Export mode: 'update' PATCHes the Gist in the field, 'create' makes a new one. */
			const [gistMode, setGistMode] = (0, react.useState)(() => {
				try {
					return localStorage.getItem("dshm-gist-id") ? "update" : "create";
				} catch {
					return "create";
				}
			});
			const [gistBusy, setGistBusy] = (0, react.useState)(false);
			const [gistMessage, setGistMessage] = (0, react.useState)(null);
			const [gistOk, setGistOk] = (0, react.useState)(false);
			const [gistResult, setGistResult] = (0, react.useState)(null);
			/** Export picker: open state, selected plugin names, include-config flag. */
			const [exportOpen, setExportOpen] = (0, react.useState)(false);
			const [exportSelection, setExportSelection] = (0, react.useState)(/* @__PURE__ */ new Set());
			const [exportIncludeConfig, setExportIncludeConfig] = (0, react.useState)(false);
			/** Export failure shown INSIDE the picker so it is never hidden behind it. */
			const [exportError, setExportError] = (0, react.useState)(null);
			/** Bundle-only plugin names from /dsh-market/installed (picker list). */
			const [installedBundles, setInstalledBundlesState] = (0, react.useState)(() => cachedInstalledBundles);
			const setInstalledBundles = (0, react.useCallback)(cacheState((value) => {
				cachedInstalledBundles = value;
			}, setInstalledBundlesState), []);
			const bodyRef = (0, react.useRef)(null);
			const rootRef = (0, react.useRef)(null);
			const headRef = (0, react.useRef)(null);
			const pluginsYRef = (0, react.useRef)(0);
			const headFloorRef = (0, react.useRef)(null);
			const catsFloorRef = (0, react.useRef)(null);
			const restoringStickRef = (0, react.useRef)(false);
			/** Hidden file input behind the Import button (a Button can't host an <input>). */
			const fileInputRef = (0, react.useRef)(null);
			const [sortField, setSortField] = (0, react.useState)("downloads");
			const [sortDir, setSortDir] = (0, react.useState)("desc");
			const [timeRange, setTimeRange] = (0, react.useState)("all");
			/** Undefined while the first catalog response is pending; null means the host cannot be located. */
			const [hostVersion, setHostVersionState] = (0, react.useState)(() => cachedHostVersion);
			const setHostVersion = (0, react.useCallback)((value) => {
				if (typeof cachedHostVersion === "string" && typeof value === "string" && value !== cachedHostVersion) clearHostCompatibilityCache();
				cachedHostVersion = value;
				setHostVersionState(value);
			}, []);
			/** v1 is deliberately opt-in: undeclared/unknown entries stay visible even when enabled. */
			const [compatibleWithHost, setCompatibleWithHostState] = (0, react.useState)(readHostFilterPreference);
			const setCompatibleWithHost = (0, react.useCallback)((next) => {
				setCompatibleWithHostState(next);
				try {
					localStorage.setItem(HOST_FILTER_KEY, next ? "compatible" : "all");
				} catch {}
			}, []);
			/** The profile this page is running in, for the manual command's own
			* `--profile` token (#872). The catalog's is always `web`. */
			const [profileName, setProfileName] = (0, react.useState)(null);
			const hostCompatibility = (0, react.useSyncExternalStore)(subscribeHostCompatibility, () => cachedHostCompatibility, () => cachedHostCompatibility);
			const [hostCompatibilityPending, setHostCompatibilityPending] = (0, react.useState)(0);
			const [catsOpen, setCatsOpen] = (0, react.useState)(false);
			/** Themes tab: independent from Discover's sort/time state above — a
			* search or sort choice in one tab has no business resetting the other. */
			const [themeSortField, setThemeSortField] = (0, react.useState)("downloads");
			const [themeSortDir, setThemeSortDir] = (0, react.useState)("desc");
			const [themeTimeRange, setThemeTimeRange] = (0, react.useState)("all");
			const [favSortField, setFavSortField] = (0, react.useState)("downloads");
			const [favSortDir, setFavSortDir] = (0, react.useState)("desc");
			const [favTimeRange, setFavTimeRange] = (0, react.useState)("all");
			/** WebDAV provider-preset dropdown (primitives Menu). */
			const [presetOpen, setPresetOpen] = (0, react.useState)(false);
			/** Install-command disclosure inside the confirm dialog. */
			const [cmdOpen, setCmdOpen] = (0, react.useState)(false);
			const [capsOpen, setCapsOpen] = (0, react.useState)(false);
			(0, react.useEffect)(() => {
				setCapsOpen(false);
				setCmdOpen(false);
			}, [confirming]);
			/** Per-row "why is it not live" disclosure (installed tab). */
			const [whyOpen, setWhyOpen] = (0, react.useState)(null);
			/** Restore-confirm dialog (replaces window.confirm). */
			const [restoreConfirmOpen, setRestoreConfirmOpen] = (0, react.useState)(false);
			/** Plugins that failed to install during a restore (replaces window.alert). */
			const [restoreErrors, setRestoreErrors] = (0, react.useState)([]);
			const [visibleCats, setVisibleCats] = (0, react.useState)(null);
			const catsWrapRef = (0, react.useRef)(null);
			const [catsStuck, setCatsStuck] = (0, react.useState)(false);
			/** While the sticky header is pinned, expansion is this flag — not
			* `catsOpen`. Becoming stuck collapses on the SAME render (stuckExpanded
			* starts false) instead of a follow-up `useLayoutEffect` that flipped
			* `catsOpen` and forced a second commit; that delayed height change is
			* what lined up with the host Settings dialog hitching after tab 收放.
			* An explicit chevron click while stuck sets this true and keeps
			* `catsOpen` in sync so unstuck restores the user's choice. */
			const [stuckExpanded, setStuckExpanded] = (0, react.useState)(false);
			const [catsSentinel, setCatsSentinel] = (0, react.useState)(null);
			/**
			* Latest /status sample for the queue drain: `busy` gates pnpm execution,
			* `runningAgents` gates the agent-file guard. A ref (not state) because the
			* drain interval is mount-once and must never read a stale closure.
			*/
			const statusRef = (0, react.useRef)({
				busy: false,
				runningAgents: [],
				agentDrain: false,
				boot: null
			});
			/** True while the drain is executing one queued request (no parallel starts). */
			const drainingRef = (0, react.useRef)(false);
			const refreshInstalled = (0, react.useCallback)((force) => {
				fetch(api("/dsh-market/installed"), { cache: "no-store" }).then((res) => res.json()).then((body) => {
					setInstalled(body.installed || {});
					setRepoIdentities(installedRepoIdentities(body.repoIdentities));
					setRepoHints(installedRepoHints(body.repoHints));
					setInstalledFiles(Array.isArray(body.present) ? body.present : Object.keys(body.installed || {}));
					setSkins(body.live || []);
					if (Array.isArray(body.disabled)) {
						setDisabledNames(body.disabled);
						if (loadedDisabled.current === null) loadedDisabled.current = new Set(body.disabled);
					}
					if (body.notes !== null && typeof body.notes === "object" && !Array.isArray(body.notes)) setNotes(body.notes);
					if (Array.isArray(body.patchDisabled)) setPatchDisabledNames(body.patchDisabled);
					if (typeof body.profile === "string") setProfileName(body.profile);
					if (Array.isArray(body.unbundled)) setUnbundledNames(body.unbundled);
					setConfigNamespaceIssues(Array.isArray(body.configNamespaces) ? body.configNamespaces.filter((item) => typeof item === "object" && item !== null && typeof item.name === "string" && Array.isArray(item.namespaces)) : []);
					if (body.groups && typeof body.groups === "object") setGroups(body.groups);
					if (Array.isArray(body.groupOrder)) setGroupOrder(body.groupOrder);
					if (Array.isArray(body.favorites)) setFavoriteUrls(body.favorites.filter((url) => typeof url === "string"));
					if (Array.isArray(body.blocked)) setBlockedNames(body.blocked.filter((name) => typeof name === "string"));
					if (Array.isArray(body.updateExempt)) setUpdateExemptNames(body.updateExempt.filter((name) => typeof name === "string"));
					setInstalledBundles(Array.isArray(body.bundles) ? body.bundles.filter((name) => typeof name === "string") : []);
					if (body.activation && typeof body.activation === "object") setActivations(body.activation);
					const findings = body.diagnostics?.schema === "dsh-market/diagnostics/v1" && Array.isArray(body.diagnostics.findings) ? body.diagnostics.findings.filter(isHostDependencyFinding) : [];
					setBrokenPlugins(isRecordOfRecords(body.brokenPlugins) ? body.brokenPlugins : {});
					installedReadGen.current += 1;
					setHostDependencyFindings(findings);
					cachedInstalledReady = true;
					setQueueSnapshotReady((ready) => ({
						...ready,
						installed: true
					}));
				}).catch(() => {});
				fetch(api("/dsh-market/updates") + (force === true ? "?force=1" : ""), { cache: "no-store" }).then((res) => res.json()).then((body) => {
					setUpdates(body.updates || {});
					cachedUpdatesReady = true;
					setQueueSnapshotReady((ready) => ({
						...ready,
						updates: true
					}));
				}).catch(() => {});
			}, [
				setActivations,
				setBlockedNames,
				setDisabledNames,
				setFavoriteUrls,
				setInstalledBundles,
				setInstalledFiles,
				setSkins,
				setUpdates
			]);
			/**
			* Host-owned deferred operations (#411).
			*
			* These rows are projections of `/status`, never entries in the client
			* queue: the Host owns the maintenance holds, and re-running a row here
			* would start a second mutation outside that barrier. `dshm-drain-v1`
			* remembers only which operations this page asked for, so a Host restart can
			* say "that one was cancelled" instead of leaving the user to guess.
			*/
			const settledHostRef = (0, react.useRef)(/* @__PURE__ */ new Set());
			const knownHostIdsRef = (0, react.useRef)(/* @__PURE__ */ new Set());
			/** Host operations the user cleared; a status poll must not add them back. */
			const dismissedHostRef = (0, react.useRef)(/* @__PURE__ */ new Set());
			const drainMarkerRestoredRef = (0, react.useRef)(false);
			const clearDrainMarker = (0, react.useCallback)((operationId) => {
				try {
					const raw = localStorage.getItem("dshm-drain-v1");
					if (raw === null) return;
					const parsed = JSON.parse(raw);
					if (!Array.isArray(parsed)) return;
					const kept = parsed.filter((entry) => entry?.id !== operationId);
					if (kept.length === 0) localStorage.removeItem("dshm-drain-v1");
					else localStorage.setItem("dshm-drain-v1", JSON.stringify(kept));
				} catch {}
			}, []);
			const rememberDrainMarker = (0, react.useCallback)((operation) => {
				try {
					const raw = localStorage.getItem("dshm-drain-v1");
					const parsed = raw === null ? [] : JSON.parse(raw);
					const list = Array.isArray(parsed) ? parsed : [];
					if (list.some((entry) => entry?.id === operation.operationId)) return;
					list.push({
						id: operation.operationId,
						kind: operation.kind,
						name: operation.name,
						...operation.url === void 0 ? {} : { url: operation.url }
					});
					localStorage.setItem("dshm-drain-v1", JSON.stringify(list));
				} catch {}
			}, []);
			/** Mark operations this page started in an earlier boot as cancelled by restart. */
			const restoreDrainMarkers = (0, react.useCallback)((status) => {
				if (drainMarkerRestoredRef.current) return;
				const boot = typeof status.boot === "string" ? status.boot : null;
				if (boot === null) return;
				drainMarkerRestoredRef.current = true;
				let saved = null;
				try {
					saved = JSON.parse(localStorage.getItem("dshm-drain-v1") ?? "null");
				} catch {
					saved = null;
				}
				if (!Array.isArray(saved) || saved.length === 0) return;
				const entries = saved.filter((entry) => {
					if (entry === null || typeof entry !== "object") return false;
					return typeof entry.id === "string";
				});
				const stale = entries.filter((entry) => !entry.id.startsWith(`${boot}-`));
				const current = entries.filter((entry) => entry.id.startsWith(`${boot}-`));
				if (stale.length > 0) {
					setRecords((previous) => {
						let next = previous;
						for (const entry of stale) {
							if (dismissedHostRef.current.has(entry.id)) continue;
							if (next.some((record) => record.hostOperationId === entry.id || record.id === `host-${entry.id}`)) continue;
							const kind = entry.kind === "install" || entry.kind === "update" || entry.kind === "uninstall" ? entry.kind : "update";
							next = enqueue(next, {
								id: `host-${entry.id}`,
								kind,
								name: typeof entry.name === "string" ? entry.name : "plugin",
								...typeof entry.url === "string" ? { url: entry.url } : {},
								hostOperationId: entry.id,
								state: "warned",
								reason: t("agentDrainRestarted")
							});
						}
						return next;
					});
					setOperationsOpen(true);
				}
				try {
					if (current.length > 0) localStorage.setItem("dshm-drain-v1", JSON.stringify(current));
					else localStorage.removeItem("dshm-drain-v1");
				} catch {}
			}, [t]);
			/** Project Host-owned operations into the Tasks panel. */
			const applyDrainStatus = (0, react.useCallback)((status) => {
				const operations = Array.isArray(status.drainOperations) ? status.drainOperations : [];
				const history = Array.isArray(status.drainHistory) ? status.drainHistory : [];
				if (operations.length === 0 && history.length === 0) return;
				let opened = false;
				for (const operation of operations) if (operation.state === "accepted" || operation.state === "draining" || operation.state === "queued-for-mutation" || operation.state === "running" || operation.state === "verifying") {
					if (!knownHostIdsRef.current.has(operation.operationId)) {
						knownHostIdsRef.current.add(operation.operationId);
						opened = true;
					}
				}
				for (const operation of operations) {
					if (dismissedHostRef.current.has(operation.operationId)) continue;
					if (operation.state !== "succeeded" && operation.state !== "failed" && operation.state !== "cancelled") continue;
					clearDrainMarker(operation.operationId);
					if (settledHostRef.current.has(operation.operationId)) continue;
					settledHostRef.current.add(operation.operationId);
					if (operation.state === "succeeded") {
						refreshInstalled();
						if (operation.outcome?.restartRequired === true) setRestartNames((names) => names.includes(operation.name) ? names : names.concat(operation.name));
						if (operation.kind === "update") setUpdatedNames((names) => names.includes(operation.name) ? names : names.concat(operation.name));
						if (operation.kind === "install" && operation.url !== void 0) setDoneUrls((urls) => urls.includes(operation.url) ? urls : urls.concat(operation.url));
					} else refreshInstalled();
				}
				const hostRecord = (operation) => {
					const base = {
						id: `host-${operation.operationId}`,
						kind: operation.kind,
						name: operation.name,
						...operation.url === void 0 ? {} : { url: operation.url },
						hostOperationId: operation.operationId
					};
					if (operation.state === "accepted" || operation.state === "draining" || operation.state === "queued-for-mutation") return {
						...base,
						state: "queued",
						...operation.wait === null ? {} : {
							blockedBy: operation.wait.activeAgentIds,
							waitSince: operation.wait.since
						},
						reason: operation.wait === null ? t("agentBusyQueued") : t("agentDrainWaiting").replace("{0}", String(operation.wait.activeCount))
					};
					if (operation.state === "running") return {
						...base,
						state: "running",
						blockedBy: void 0,
						waitSince: void 0,
						reason: void 0
					};
					if (operation.state === "verifying") return {
						...base,
						state: "running",
						detail: t("agentDrainVerifying"),
						blockedBy: void 0,
						waitSince: void 0,
						reason: void 0
					};
					if (operation.state === "succeeded") return {
						...base,
						state: "done",
						needsRefresh: operation.outcome?.needsRefresh === true,
						blockedBy: void 0,
						waitSince: void 0,
						reason: void 0
					};
					if (operation.state === "cancelled") return {
						...base,
						state: "warned",
						reason: t("agentDrainCancelled"),
						blockedBy: void 0,
						waitSince: void 0
					};
					return {
						...base,
						state: "failed",
						reason: operation.failure?.message ?? t("installFail"),
						blockedBy: void 0,
						waitSince: void 0
					};
				};
				setRecords((previous) => {
					let next = previous;
					for (const operation of operations) {
						if (dismissedHostRef.current.has(operation.operationId)) continue;
						const existing = next.find((record) => record.hostOperationId === operation.operationId);
						const desired = hostRecord(operation);
						if (existing === void 0) next = enqueue(next, desired);
						else {
							const { id: _id, kind: _kind, name: _name, hostOperationId: _host, ...changes } = desired;
							next = patch(next, existing.id, changes);
						}
					}
					for (const entry of history) {
						if (dismissedHostRef.current.has(entry.id)) continue;
						const id = `host-${entry.id}`;
						const existing = next.find((record) => record.id === id || record.hostOperationId === entry.id);
						const changes = entry.state === "succeeded" ? existing?.needsRefresh === true ? {
							state: "done",
							blockedBy: void 0,
							waitSince: void 0,
							reason: void 0
						} : {
							state: "done",
							needsRefresh: false,
							blockedBy: void 0,
							waitSince: void 0,
							reason: void 0
						} : {
							state: entry.state === "cancelled" ? "warned" : "failed",
							reason: entry.state === "cancelled" ? t("agentDrainHistoryCancelled") : t("agentDrainHistoryFailedShort"),
							blockedBy: void 0,
							waitSince: void 0
						};
						if (existing !== void 0) next = patch(next, existing.id, changes);
						else next = enqueue(next, {
							id,
							kind: entry.kind,
							name: entry.name,
							hostOperationId: entry.id,
							...changes
						});
					}
					return next;
				});
				if (opened) setOperationsOpen(true);
			}, [
				clearDrainMarker,
				refreshInstalled,
				t
			]);
			/** Active Bundles count as installed in Discover without becoming package-manager targets. */
			const catalogInstalled = (0, react.useMemo)(() => installedForCatalog(installed, installedBundles), [installed, installedBundles]);
			(0, react.useMemo)(() => new Set(disabledNames), [disabledNames]);
			const favoriteUrlSet = (0, react.useMemo)(() => new Set(favoriteUrls), [favoriteUrls]);
			const blockedNameSet = (0, react.useMemo)(() => new Set(blockedNames), [blockedNames]);
			const updateExemptSet = (0, react.useMemo)(() => new Set(updateExemptNames), [updateExemptNames]);
			/** Effective switch state: market disable list ∪ user-patch-layer disables. */
			const effectiveDisabledSet = (0, react.useMemo)(() => /* @__PURE__ */ new Set([
				...disabledNames,
				...patchDisabledNames,
				...unbundledNames
			]), [
				disabledNames,
				patchDisabledNames,
				unbundledNames
			]);
			(0, react.useEffect)(() => {
				if (tab !== "themes" && themesFullscreen) setThemesFullscreen(false);
			}, [tab, themesFullscreen]);
			(0, react.useEffect)(() => {
				if (!themesFullscreen || lightbox !== null) return;
				const onKey = (event) => {
					if (event.key !== "Escape") return;
					event.stopPropagation();
					setThemesFullscreen(false);
				};
				window.addEventListener("keydown", onKey, true);
				return () => window.removeEventListener("keydown", onKey, true);
			}, [lightbox, themesFullscreen]);
			/**
			* The host is no longer serving the market's routes (#962).
			*
			* Only a 404 says this: any other status means the route ran and answered.
			* When it happens mid-operation, the response that would have settled the
			* install was lost with the routes, so the spinner has to be released and
			* the row told what became of it — otherwise it turns until DSH restarts,
			* with the user left to guess whether the plugin landed.
			*/
			const noteMarketGone = (0, react.useCallback)(() => {
				setMarketGone(true);
				setBusyUrl(null);
				setUpdatingName(null);
				setRemovingName(null);
				setRecords((list) => list.map((record) => record.state === "running" || record.state === "queued" ? {
					...record,
					state: "failed",
					reason: t("marketGoneRecord")
				} : record));
				try {
					sessionStorage.removeItem("dshm-pending");
					sessionStorage.removeItem("dshm-updating");
				} catch {}
			}, [t]);
			/**
			* The status payload, or `null` when the route answered 404 (#962). Every
			* poll that reads this stops on the null: the market is no longer mounted,
			* so there is no status to read and nothing left to poll for.
			*/
			const readMarketStatus = (0, react.useCallback)(async (res) => {
				if (res.status === 404) {
					noteMarketGone();
					return null;
				}
				return await res.json();
			}, [noteMarketGone]);
			const loadCatalog = (0, react.useCallback)(() => {
				setLoadError(null);
				return fetch(api("/dsh-market/registry"), { cache: "no-store" }).then(async (res) => {
					const body = await res.json().catch(() => ({}));
					if (res.status === 404) {
						noteMarketGone();
						throw new Error(t("marketGoneTitle"));
					}
					if (!res.ok) throw new Error(typeof body.error === "string" ? body.error : `HTTP ${String(res.status)}`);
					return body;
				}).then((body) => {
					if (body.registry === void 0) throw new Error("the catalog response carried no data");
					if (body.registry.updated !== cachedRegistry?.updated) {
						resetScreenshotsCache();
						resetThemePreviewCache();
					}
					cachedRegistry = body.registry;
					setData(body.registry);
					const catalogDate = body.registry.updated;
					setCatalogUpdated(typeof catalogDate === "string" && catalogDate.trim() !== "" ? catalogDate : null);
					setHostVersion(typeof body.hostVersion === "string" ? body.hostVersion : null);
					setLoadError(null);
				}).catch((error) => {
					setLoadError(error instanceof Error ? error.message : String(error));
				});
			}, [noteMarketGone, t]);
			/**
			* Come back when the routes do (#1151).
			*
			* A 404 is how the page learns DSH unloaded the market, but DSH usually
			* mounts it again within seconds: it reloads plugins around an install or
			* an update, and the market is one of them. The page used to stay on "stopped"
			* for good, so the user restarted DSH — which also killed whatever the host
			* was still doing. Read-only on purpose: only `status` is asked, never a
			* request that changes anything, and nothing that was in flight is replayed.
			*/
			(0, react.useEffect)(() => {
				if (!marketGone) return;
				setReconnecting(true);
				const startedAt = Date.now();
				let wait = 1e3;
				let timer;
				let inFlight;
				let stopped = false;
				const attempt = async () => {
					inFlight = new AbortController();
					const cutoff = setTimeout(() => inFlight?.abort(), RECONNECT_REQUEST_MS);
					try {
						const res = await fetch(api("/dsh-market/status"), {
							cache: "no-store",
							signal: inFlight.signal
						});
						const status = res.ok ? await res.json() : null;
						if (!stopped && status !== null && typeof status === "object" && typeof status.boot === "string") {
							setMarketGone(false);
							loadCatalog();
							refreshInstalled();
							return;
						}
					} catch {} finally {
						clearTimeout(cutoff);
					}
					if (stopped) return;
					if (Date.now() - startedAt >= RECONNECT_BUDGET_MS) {
						setReconnecting(false);
						return;
					}
					timer = setTimeout(() => {
						attempt();
					}, wait);
					wait = Math.min(wait * 2, 5e3);
				};
				timer = setTimeout(() => {
					attempt();
				}, wait);
				return () => {
					stopped = true;
					clearTimeout(timer);
					inFlight?.abort();
				};
			}, [
				marketGone,
				reconnectRound,
				loadCatalog,
				refreshInstalled
			]);
			const loadHostCompatibility = (0, react.useCallback)(async (names) => {
				const unique = [...new Set(names)].filter((name) => {
					if (name === "" || hostCompatibilitySettled(name) || hostCompatibilityInFlight.has(name)) return false;
					hostCompatibilityInFlight.add(name);
					return true;
				});
				if (unique.length === 0) return;
				setHostCompatibilityPending((count) => count + unique.length);
				for (let offset = 0; offset < unique.length; offset += 64) {
					const chunk = unique.slice(offset, offset + 64);
					try {
						const response = await fetch(api("/dsh-market/discovery-compatibility"), {
							method: "POST",
							headers: { "content-type": "application/json" },
							body: JSON.stringify({
								packages: chunk.filter((key) => !key.startsWith("https://")),
								...chunk.some((key) => key.startsWith("https://")) ? { entries: chunk.filter((key) => key.startsWith("https://")) } : {}
							})
						});
						const body = await response.json();
						if (!response.ok || body.plugins === null || typeof body.plugins !== "object") throw new Error(`HTTP ${String(response.status)}`);
						if (typeof body.hostVersion === "string" || body.hostVersion === null) setHostVersion(body.hostVersion);
						const accepted = {};
						for (const name of chunk) {
							const item = body.plugins[name];
							if (item === null || item === void 0 || ![
								"compatible",
								"incompatible",
								"unknown"
							].includes(item.status) || ![
								"manifest",
								"undeclared",
								"unavailable"
							].includes(item.basis) || item.requirement !== null && typeof item.requirement !== "string" || !Array.isArray(item.declarations)) {
								accepted[name] = UNAVAILABLE_HOST_COMPATIBILITY;
								continue;
							}
							accepted[name] = item;
						}
						commitHostCompatibility(accepted);
					} catch {
						commitHostCompatibility(Object.fromEntries(chunk.map((name) => [name, UNAVAILABLE_HOST_COMPATIBILITY])));
					} finally {
						for (const name of chunk) hostCompatibilityInFlight.delete(name);
						setHostCompatibilityPending((count) => Math.max(0, count - chunk.length));
					}
				}
			}, [setHostVersion]);
			(0, react.useEffect)(() => {
				loadCatalog();
				fetch(api("/dsh-market/status"), { cache: "no-store" }).then(readMarketStatus).then((status) => {
					if (status === null) return;
					statusRef.current = {
						busy: status.busy === true,
						runningAgents: Array.isArray(status.runningAgents) ? status.runningAgents.map(String) : [],
						agentDrain: status.agentDrain === true,
						boot: typeof status.boot === "string" ? status.boot : null
					};
					applyDrainStatus(status);
					restoreDrainMarkers(status);
					setEnvReady(status.pnpm !== false);
					applyGithubRouting(status);
					setMarketOffline(status.offline === true);
					setOffline(status.offline === true);
					if (typeof status.boot === "string") {
						setBootId(status.boot);
						setIgnoredUpdateNames(ignoredUpdatesForBoot(status.boot));
						try {
							setRestartNoticeDismissed(sessionStorage.getItem("dshm-restart-dismissed") === status.boot);
						} catch {}
					}
					setRestartEnabled(status.restart === true);
					setSupervisor(typeof status.supervisor === "string" ? status.supervisor : null);
					setDebuggerLatch(typeof status.debugger === "string" ? status.debugger : null);
					setRestartReachable(status.restartReachable !== false);
					if (typeof status.version === "string" && status.version !== "") setVersion(status.version);
				}).catch(() => {});
				refreshInstalled();
			}, [
				applyDrainStatus,
				refreshInstalled,
				loadCatalog,
				readMarketStatus,
				restoreDrainMarkers
			]);
			(0, react.useEffect)(() => {
				if (bootId === null) return;
				const saved = readSession("dshm-restart");
				if (saved === null) return;
				if (saved.boot !== bootId) {
					sessionStorage.removeItem("dshm-restart");
					return;
				}
				if (Array.isArray(saved.doneUrls) && saved.doneUrls.length > 0) setDoneUrls(saved.doneUrls);
				if (Array.isArray(saved.updated) && saved.updated.length > 0) setUpdatedNames(saved.updated);
				if (Array.isArray(saved.restartNames) && saved.restartNames.length > 0) setRestartNames(saved.restartNames);
				if (typeof saved.removed === "number" && saved.removed > 0) setRemovedCount(saved.removed);
				if (typeof saved.toggled === "number" && saved.toggled > 0) setToggleRestart(saved.toggled);
			}, [bootId]);
			(0, react.useEffect)(() => {
				if (bootId === null) return;
				if (doneUrls.length === 0 && updatedNames.length === 0 && restartNames.length === 0 && removedCount === 0 && toggleRestart === 0) {
					sessionStorage.removeItem("dshm-restart");
					return;
				}
				sessionStorage.setItem("dshm-restart", JSON.stringify({
					boot: bootId,
					doneUrls,
					updated: updatedNames,
					restartNames,
					removed: removedCount,
					toggled: toggleRestart
				}));
			}, [
				bootId,
				doneUrls,
				updatedNames,
				restartNames,
				removedCount,
				toggleRestart
			]);
			const fixEnv = (0, react.useCallback)(() => {
				setEnvFixing(true);
				setEnvFailed(false);
				fetch(api("/dsh-market/setup-pnpm"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: "{}"
				}).then((res) => res.json()).then((body) => {
					if (body.ok) setEnvReady(true);
					else {
						setEnvFailed(true);
						if (typeof body.error === "string") setInstallError(body.error);
					}
				}).catch(() => setEnvFailed(true)).finally(() => setEnvFixing(false));
			}, []);
			(0, react.useEffect)(() => {
				const pending = readSession("dshm-pending");
				if (pending !== null && typeof pending.url === "string") {
					setBusyUrl(pending.url);
					recoveredInstall.current = {
						id: `recovered-install:${pending.url}`,
						url: pending.url,
						...typeof pending.name === "string" && pending.name !== "" ? { name: pending.name } : {}
					};
				}
				const updating = readSession("dshm-updating");
				if (updating !== null && typeof updating.name === "string" && updating.name !== "") {
					setUpdatingName(updating.name);
					const id = `recovered-update:${updating.name}`;
					recoveredUpdateRecordId.current = id;
					setRecords((list) => list.some((record) => record.kind === "update" && record.name === updating.name && record.state === "running") ? list : enqueue(list, {
						id,
						kind: "update",
						name: updating.name,
						state: "running"
					}));
				}
			}, []);
			(0, react.useEffect)(() => {
				const recovered = recoveredInstall.current;
				if (recovered === null) return;
				const name = recovered.name ?? data?.plugins.find((plugin) => plugin.url === recovered.url)?.name;
				if (name === void 0) return;
				recovered.name = name;
				setRecords((list) => list.some((record) => record.id === recovered.id) ? list : enqueue(list, {
					id: recovered.id,
					kind: "install",
					name,
					url: recovered.url,
					state: "running"
				}));
			}, [data]);
			(0, react.useEffect)(() => {
				if (busyUrl === null && updatingName === null) {
					setHostBusy(false);
					statusRef.current = {
						...statusRef.current,
						busy: false
					};
					setProgressLine(null);
					setProgressPhase(null);
					setProgressCurrent(null);
					setProgressDone(0);
					setCancelling(false);
					return;
				}
				const timer = setInterval(() => {
					fetch(api("/dsh-market/status"), { cache: "no-store" }).then(readMarketStatus).then((status) => {
						if (status === null) return;
						statusRef.current = {
							busy: status.busy === true,
							runningAgents: Array.isArray(status.runningAgents) ? status.runningAgents.map(String) : [],
							agentDrain: status.agentDrain === true,
							boot: typeof status.boot === "string" ? status.boot : null
						};
						applyDrainStatus(status);
						restoreDrainMarkers(status);
						setHostBusy(status.busy === true);
						setDebuggerLatch(typeof status.debugger === "string" ? status.debugger : null);
						if (status.active) {
							setCancelling(status.cancelling === true);
							if (status.phase !== null && status.phase !== void 0) {
								setProgressPhase(status.phase);
								setProgressCurrent(status.currentPackage ?? null);
								setProgressDone(status.done ?? 0);
								setProgressLine(null);
								if (typeof status.size === "number" && status.size > 0 && typeof status.downloaded === "number") setProgressPct(Math.max(4, Math.min(96, Math.round(status.downloaded / status.size * 100))));
							} else {
								const slow = (status.seconds ?? 0) >= SLOW_INSTALL_SECONDS ? " · " + t("progressSlow") : "";
								setProgressLine(localizeBilingual(status.lastLine || "…", lang) + "  (" + status.seconds + "s)" + slow);
								setProgressPhase(null);
								setProgressCurrent(null);
								setProgressDone(0);
								const m = /resolved (\d+), reused (\d+), downloaded (\d+), added (\d+)/.exec(status.lastLine || "");
								if (m !== null && Number(m[1]) > 0) {
									const done = Number(m[2]) + Number(m[3]) + Number(m[4]);
									setProgressPct(Math.max(4, Math.min(96, Math.round(done / Number(m[1]) * 100))));
								}
							}
						} else {
							setProgressLine(null);
							setProgressPct(null);
							setProgressPhase(null);
							setProgressCurrent(null);
							setProgressDone(0);
							setCancelling(false);
							const statusInstalled = installedMap(status.installed);
							if (!sameInstalledMap(installed, statusInstalled)) refreshInstalled();
							if (readSession("dshm-pending") !== null && busyUrl !== null && status.busy !== true) {
								const url = busyUrl;
								if (data !== null && data.plugins.some((p) => p.url === url && isInstalled(p, statusInstalled, repoIdentities, data.plugins, repoHints))) {
									idleStrikes.current = 0;
									sessionStorage.removeItem("dshm-pending");
									const recovered = recoveredInstall.current;
									if (recovered !== null) {
										setRecords((list) => drop(list, recovered.id));
										recoveredInstall.current = null;
									}
									setRecords((list) => list.map((record) => record.kind === "install" && record.url === url && record.state === "running" ? {
										...record,
										state: "done",
										needsRefresh: true
									} : record));
									setDoneUrls((urls) => urls.includes(url) ? urls : urls.concat(url));
									setBusyUrl(null);
								} else if (++idleStrikes.current >= 2) {
									idleStrikes.current = 0;
									sessionStorage.removeItem("dshm-pending");
									const recovered = recoveredInstall.current;
									if (recovered !== null) {
										setRecords((list) => drop(list, recovered.id));
										recoveredInstall.current = null;
									}
									setRecords((list) => list.map((record) => record.kind === "install" && record.url === url && record.state === "running" ? {
										...record,
										state: "failed",
										reason: t("installFail")
									} : record));
									setBusyUrl(null);
									setInstallError(t("installFail") + " — " + t("exportLog"));
								}
							}
							if (updatingName !== null && status.busy !== true) {
								if (++updateIdleStrikes.current >= 2) {
									updateIdleStrikes.current = 0;
									sessionStorage.removeItem("dshm-updating");
									const recoveredId = recoveredUpdateRecordId.current;
									if (recoveredId !== null) {
										setRecords((list) => drop(list, recoveredId));
										recoveredUpdateRecordId.current = null;
									}
									setUpdatingName(null);
									refreshInstalled();
								}
							} else updateIdleStrikes.current = 0;
						}
					}).catch(() => {});
				}, 2e3);
				return () => clearInterval(timer);
			}, [
				applyDrainStatus,
				busyUrl,
				updatingName,
				data,
				installed,
				repoIdentities,
				repoHints,
				refreshInstalled,
				lang,
				restoreDrainMarkers,
				t
			]);
			const scrollToTop = () => {
				const el = listScroller(surface, rootRef.current, bodyRef.current, themesFullscreen);
				const root = rootRef.current;
				const head = headRef.current;
				if (el === null) {
					setShowTop(false);
					return;
				}
				if (surface === "plugins" && !themesFullscreen && root !== null && head !== null) {
					const target = headPinScrollTop(el, root, head);
					if (typeof el.scrollTo === "function") el.scrollTo({
						top: target,
						behavior: "smooth"
					});
					else el.scrollTop = target;
					headFloorRef.current = target > 0 ? target : null;
					catsFloorRef.current = null;
					pluginsYRef.current = target;
				} else if (typeof el.scrollTo === "function") el.scrollTo({
					top: 0,
					behavior: "smooth"
				});
				else el.scrollTop = 0;
				setShowTop(false);
			};
			(0, react.useLayoutEffect)(() => {
				const el = listScroller(surface, rootRef.current, bodyRef.current, themesFullscreen);
				const root = rootRef.current;
				if (el !== null) {
					if (surface !== "plugins" || root === null || themesFullscreen) el.scrollTop = 0;
					else {
						const cats = root.querySelector(`.${Market_module_css_default.cats}`);
						const max = Math.max(0, el.scrollHeight - el.clientHeight);
						const preferred = cats !== null && catsFloorRef.current !== null ? catsFloorRef.current : headFloorRef.current !== null ? headFloorRef.current : pluginsYRef.current;
						const target = preferred <= max ? preferred : headFloorRef.current !== null && headFloorRef.current <= max ? headFloorRef.current : max;
						if (cats === null) catsFloorRef.current = null;
						restoringStickRef.current = true;
						if (target > 0) el.scrollTop = target;
						pluginsYRef.current = el.scrollTop;
						restoringStickRef.current = false;
					}
				}
				setShowTop(false);
			}, [
				surface,
				themesFullscreen,
				tab,
				q,
				cat,
				sortField,
				sortDir,
				timeRange,
				compatibleWithHost,
				qThemes,
				themeSortField,
				themeSortDir,
				themeTimeRange,
				qFavorites,
				favSortField,
				favSortDir,
				favTimeRange,
				qInstalled,
				installedView
			]);
			(0, react.useEffect)(() => {
				if (surface !== "plugins" || themesFullscreen) return void 0;
				const host = listScroller(surface, rootRef.current, null, false);
				if (host === null) return void 0;
				const onScroll = () => {
					setPluginMenuUrl(null);
					setInstalledMenuName(null);
					setGroupMenuFor(null);
					setAssignFor(null);
					const show = host.scrollTop > 400;
					setShowTop((prev) => prev === show ? prev : show);
				};
				onScroll();
				host.addEventListener("scroll", onScroll, { passive: true });
				return () => host.removeEventListener("scroll", onScroll);
			}, [surface, themesFullscreen]);
			(0, react.useLayoutEffect)(() => {
				const root = rootRef.current;
				if (surface !== "plugins" || root === null || themesFullscreen) {
					root?.style.removeProperty("--dshm-host-sticky-top");
					root?.style.removeProperty("--dshm-plugins-head-height");
					root?.style.removeProperty("--dshm-empty-view-height");
					return;
				}
				const host = listScroller(surface, root, null, false);
				if (host === null) {
					root.style.removeProperty("--dshm-host-sticky-top");
					root.style.removeProperty("--dshm-plugins-head-height");
					root.style.removeProperty("--dshm-empty-view-height");
					return;
				}
				let frame = 0;
				const apply = () => {
					frame = 0;
					const hostTop = hostStickyOffset(host, root);
					const head = headRef.current;
					const headHeight = head === null ? 0 : Math.round(head.getBoundingClientRect().height);
					root.style.setProperty("--dshm-host-sticky-top", `${String(hostTop)}px`);
					root.style.setProperty("--dshm-plugins-head-height", `${String(headHeight)}px`);
					const body = bodyRef.current;
					if (body !== null) {
						const hostRect = host.getBoundingClientRect();
						const empty = body.querySelector(`:scope > .${Market_module_css_default.empty}`);
						const topSrc = empty instanceof HTMLElement ? empty : body;
						const top = Math.max(hostRect.top, topSrc.getBoundingClientRect().top);
						const view = Math.max(0, Math.round(hostRect.bottom - top));
						root.style.setProperty("--dshm-empty-view-height", `${String(view)}px`);
					}
					if (restoringStickRef.current) return;
					const y = host.scrollTop;
					if (y > 0) pluginsYRef.current = y;
					if (head !== null && isPinned(host, head, hostTop)) headFloorRef.current = headFloorRef.current === null ? y : Math.min(headFloorRef.current, y);
					else if (headFloorRef.current !== null && y > 0 && y + 4 < headFloorRef.current) headFloorRef.current = null;
					const cats = root.querySelector(`.${Market_module_css_default.cats}`);
					if (cats instanceof HTMLElement && isPinned(host, cats, hostTop + headHeight)) catsFloorRef.current = catsFloorRef.current === null ? y : Math.min(catsFloorRef.current, y);
					else if (cats === null) catsFloorRef.current = null;
					else if (catsFloorRef.current !== null && y > 0 && y + 4 < catsFloorRef.current) catsFloorRef.current = null;
				};
				const schedule = () => {
					if (frame !== 0) return;
					frame = requestAnimationFrame(apply);
				};
				const clearPinVars = () => {
					host.removeEventListener("scroll", schedule);
					window.removeEventListener("resize", schedule);
					if (frame !== 0) cancelAnimationFrame(frame);
					frame = 0;
					root.style.removeProperty("--dshm-host-sticky-top");
					root.style.removeProperty("--dshm-plugins-head-height");
					root.style.removeProperty("--dshm-empty-view-height");
				};
				apply();
				host.addEventListener("scroll", schedule, { passive: true });
				window.addEventListener("resize", schedule);
				if (typeof ResizeObserver === "undefined") return clearPinVars;
				const observer = new ResizeObserver(schedule);
				observer.observe(host);
				observer.observe(root);
				const head = headRef.current;
				if (head !== null) observer.observe(head);
				return () => {
					observer.disconnect();
					clearPinVars();
				};
			}, [surface, themesFullscreen]);
			const pluginsAll = (0, react.useMemo)(() => {
				if (data === null) return [];
				const query = {
					category: cat,
					query: q,
					lang,
					categories: data.categories,
					sort: `${sortField}-${sortDir}`,
					sinceDays: timeRange === "all" ? void 0 : TIME_RANGE_DAYS[timeRange]
				};
				return visiblePlugins(data.plugins, {
					...query,
					compatibleWithHost: false
				});
			}, [
				data,
				q,
				cat,
				lang,
				sortField,
				sortDir,
				timeRange
			]);
			const pluginBlocked = (plugin) => blockAliases(plugin, matchInstalledName(plugin, installed, repoIdentities, data?.plugins, repoHints)).some((name) => blockedNameSet.has(name));
			const installedBlocked = (0, react.useMemo)(() => {
				const compute = (name) => {
					if (blockedNameSet.has(name)) return true;
					if (data === null) return false;
					const spec = installed[name];
					if (spec === void 0) return false;
					const entry = catalogEntryForInstalled(data.plugins, name, String(spec), repoIdentities[name], repoHints[name]);
					return entry !== void 0 && blockAliases(entry, name).some((alias) => blockedNameSet.has(alias));
				};
				const cache = /* @__PURE__ */ new Map();
				return (name) => {
					const hit = cache.get(name);
					if (hit !== void 0) return hit;
					const value = compute(name);
					cache.set(name, value);
					return value;
				};
			}, [
				data,
				blockedNameSet,
				installed,
				repoIdentities,
				repoHints
			]);
			const blockToggleName = (aliases) => aliases.find((name) => blockedNameSet.has(name)) ?? aliases[0];
			const pluginsUnblocked = (0, react.useMemo)(() => pluginsAll.filter((plugin) => !pluginBlocked(plugin)), [
				pluginsAll,
				blockedNameSet,
				installed,
				repoIdentities,
				data,
				repoHints
			]);
			const { plugins, hostHiddenCount } = (0, react.useMemo)(() => {
				if (!compatibleWithHost) return {
					plugins: pluginsUnblocked,
					hostHiddenCount: 0
				};
				const compatible = (plugin) => {
					const key = hostCompatibilityKey(plugin);
					return key === null || hostCompatibility[key]?.status !== "incompatible";
				};
				let hidden = 0;
				for (const plugin of pluginsAll) if (!compatible(plugin)) hidden += 1;
				return {
					plugins: pluginsUnblocked.filter(compatible),
					hostHiddenCount: hidden
				};
			}, [
				pluginsAll,
				pluginsUnblocked,
				compatibleWithHost,
				hostCompatibility
			]);
			const recentlyAdded = (0, react.useMemo)(() => data === null || tab !== "discover" || q.trim() !== "" || cat !== "all" || timeRange !== "all" || sortField !== "downloads" || sortDir !== "desc" ? [] : visiblePlugins(data.plugins, {
				category: "all",
				query: "",
				lang,
				sort: "downloads-desc",
				sinceDays: 7,
				hostCompatibility,
				compatibleWithHost
			}).filter((plugin) => !pluginBlocked(plugin)), [
				data,
				tab,
				q,
				cat,
				timeRange,
				sortField,
				sortDir,
				lang,
				hostCompatibility,
				compatibleWithHost,
				blockedNameSet,
				installed,
				repoIdentities,
				repoHints
			]);
			const hasRecent = recentlyAdded.length > 0;
			const [recentCollapsed, setRecentCollapsed] = (0, react.useState)(() => readRecentFlag(RECENT_COLLAPSED_KEY));
			const [recentHidden, setRecentHidden] = (0, react.useState)(() => readRecentFlag(RECENT_HIDDEN_KEY));
			const toggleRecentCollapsed = (0, react.useCallback)(() => {
				const next = !recentCollapsed;
				setRecentCollapsed(next);
				writeRecentFlag(RECENT_COLLAPSED_KEY, next);
			}, [recentCollapsed]);
			const hideRecent = (0, react.useCallback)(() => {
				setRecentHidden(true);
				writeRecentFlag(RECENT_HIDDEN_KEY, true);
			}, []);
			const showRecent = (0, react.useCallback)(() => {
				setRecentHidden(false);
				writeRecentFlag(RECENT_HIDDEN_KEY, false);
				setRecentCollapsed(false);
				writeRecentFlag(RECENT_COLLAPSED_KEY, false);
			}, []);
			const recentPlugins = recentlyAdded.slice(0, RECENT_STRIP_LIMIT);
			const { currentPage, totalPages, pageSize, goToPage, changePageSize } = usePagination(plugins.length, [
				q,
				cat,
				sortField,
				sortDir,
				timeRange,
				compatibleWithHost
			], scrollToTop);
			const discoverMore = useShownCount(plugins.length, [
				q,
				cat,
				sortField,
				sortDir,
				timeRange,
				compatibleWithHost
			], DEFAULT_PAGE_SIZE);
			const pagePlugins = surface === "plugins" ? plugins.slice(0, discoverMore.shown) : plugins.slice((currentPage - 1) * pageSize, currentPage * pageSize);
			const pageHostPackages = [...new Set([...pagePlugins, ...recentPlugins].flatMap((plugin) => hostCompatibilityKey(plugin) === null ? [] : [hostCompatibilityKey(plugin)]))];
			const allHostPackages = (0, react.useMemo)(() => [...new Set((data?.plugins ?? []).flatMap((plugin) => hostCompatibilityKey(plugin) === null ? [] : [hostCompatibilityKey(plugin)]))], [data]);
			const pageHostPackagesKey = pageHostPackages.join("\0");
			const allHostPackagesKey = allHostPackages.join("\0");
			(0, react.useEffect)(() => {
				if (tab === "discover") loadHostCompatibility(pageHostPackages);
			}, [
				tab,
				pageHostPackagesKey,
				loadHostCompatibility
			]);
			(0, react.useEffect)(() => {
				if (compatibleWithHost) loadHostCompatibility(allHostPackages);
			}, [
				compatibleWithHost,
				allHostPackagesKey,
				loadHostCompatibility
			]);
			const loadedHostPackages = allHostPackages.reduce((count, name) => count + (hostCompatibility[name] === void 0 ? 0 : 1), 0);
			const themePluginsAll = (0, react.useMemo)(() => data === null ? [] : visiblePlugins(data.plugins, {
				category: "theme",
				query: qThemes,
				lang,
				categories: data.categories,
				sort: `${themeSortField}-${themeSortDir}`,
				sinceDays: themeTimeRange === "all" ? void 0 : TIME_RANGE_DAYS[themeTimeRange]
			}), [
				data,
				qThemes,
				lang,
				themeSortField,
				themeSortDir,
				themeTimeRange
			]);
			const themePlugins$1 = (0, react.useMemo)(() => themePluginsAll.filter((plugin) => !pluginBlocked(plugin)), [
				themePluginsAll,
				blockedNameSet,
				installed,
				repoIdentities,
				data,
				repoHints
			]);
			const blockedPlugins = (0, react.useMemo)(() => data === null ? [] : data.plugins.filter((plugin) => pluginBlocked(plugin)), [
				data,
				blockedNameSet,
				installed,
				repoIdentities,
				repoHints
			]);
			const blockedMissing = (0, react.useMemo)(() => {
				const covered = new Set(blockedPlugins.flatMap((plugin) => blockAliases(plugin, matchInstalledName(plugin, installed, repoIdentities, data?.plugins, repoHints))));
				return blockedNames.filter((name) => !covered.has(name));
			}, [
				blockedNames,
				blockedPlugins,
				installed,
				repoIdentities,
				data,
				repoHints
			]);
			const themePagination = usePagination(themePlugins$1.length, [
				qThemes,
				themeSortField,
				themeSortDir,
				themeTimeRange
			], scrollToTop);
			const themeMore = useShownCount(themePlugins$1.length, [
				qThemes,
				themeSortField,
				themeSortDir,
				themeTimeRange
			], DEFAULT_PAGE_SIZE);
			const themePagePlugins = surface === "plugins" ? themePlugins$1.slice(0, themeMore.shown) : themePlugins$1.slice((themePagination.currentPage - 1) * themePagination.pageSize, themePagination.currentPage * themePagination.pageSize);
			const favoriteListed = (0, react.useMemo)(() => data === null ? [] : pluginsForFavorites(data.plugins, favoriteUrlSet, {
				query: qFavorites,
				lang,
				categories: data.categories,
				sort: `${favSortField}-${favSortDir}`,
				sinceDays: favTimeRange === "all" ? void 0 : TIME_RANGE_DAYS[favTimeRange]
			}), [
				data,
				qFavorites,
				lang,
				favoriteUrlSet,
				favSortField,
				favSortDir,
				favTimeRange
			]);
			const favoritePlugins = (0, react.useMemo)(() => favoriteListed.filter((p) => !pluginCategories(p).includes("theme")), [favoriteListed]);
			const favoriteThemes = (0, react.useMemo)(() => favoriteListed.filter((p) => pluginCategories(p).includes("theme")), [favoriteListed]);
			const favResetDeps = [
				qFavorites,
				favSortField,
				favSortDir,
				favTimeRange
			];
			const favoritePluginPagination = usePagination(favoritePlugins.length, favResetDeps, scrollToTop);
			const favoriteThemePagination = usePagination(favoriteThemes.length, favResetDeps, scrollToTop);
			const favoritePluginMore = useShownCount(favoritePlugins.length, favResetDeps, DEFAULT_PAGE_SIZE);
			const favoriteThemeMore = useShownCount(favoriteThemes.length, favResetDeps, DEFAULT_PAGE_SIZE);
			const favoritePagePlugins = surface === "plugins" ? favoritePlugins.slice(0, favoritePluginMore.shown) : favoritePlugins.slice((favoritePluginPagination.currentPage - 1) * favoritePluginPagination.pageSize, favoritePluginPagination.currentPage * favoritePluginPagination.pageSize);
			const favoritePageThemes = surface === "plugins" ? favoriteThemes.slice(0, favoriteThemeMore.shown) : favoriteThemes.slice((favoriteThemePagination.currentPage - 1) * favoriteThemePagination.pageSize, favoriteThemePagination.currentPage * favoriteThemePagination.pageSize);
			const favoritePageHostPackages = [...new Set(favoritePagePlugins.flatMap((plugin) => hostCompatibilityKey(plugin) === null ? [] : [hostCompatibilityKey(plugin)]))];
			const favoritePageHostPackagesKey = favoritePageHostPackages.join("\0");
			(0, react.useEffect)(() => {
				if (tab === "favorites") loadHostCompatibility(favoritePageHostPackages);
			}, [
				tab,
				favoritePageHostPackagesKey,
				loadHostCompatibility
			]);
			const favoriteStale = (0, react.useMemo)(() => data === null ? [] : staleFavoriteUrls(favoriteUrls, data.plugins), [data, favoriteUrls]);
			const favoritesAllStale = favoriteUrls.length > 0 && favoriteStale.length === favoriteUrls.length && qFavorites.trim() === "";
			/** Tab badge counts catalog-visible bookmarks once the registry is loaded. */
			const favoriteTabCount = data === null ? favoriteUrls.length : favoriteListed.length;
			/** Download a host endpoint as a file — primitives Button can't be an <a download>.
			* Prefers the server's Content-Disposition filename (e.g. the timestamped
			* backup export) and falls back to the caller's name. */
			const downloadFile = (0, react.useCallback)((url, filename, failureLabel) => {
				fetch(url).then(async (res) => {
					if (!res.ok) {
						const detail = await res.json().then((body) => typeof body.error === "string" && body.error !== "" ? body.error : null, () => null);
						throw new Error(`${failureLabel ?? ""}${detail ?? "HTTP " + res.status}`);
					}
					const disposition = res.headers.get("content-disposition");
					if (disposition !== null) {
						const match = /filename="?([^";]+)"?/.exec(disposition);
						if (match !== null && match[1] !== void 0 && match[1] !== "") filename = match[1];
					}
					return res.blob();
				}).then((blob) => {
					const a = document.createElement("a");
					a.href = URL.createObjectURL(blob);
					a.download = filename;
					a.click();
					setTimeout(() => URL.revokeObjectURL(a.href), 2e3);
				}).catch((error) => setInstallError(String(error)));
			}, []);
			const doRollback = (0, react.useCallback)((rollbackId) => {
				setRollingBack(true);
				setInstallError(null);
				fetch(api("/dsh-market/rollback"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({ rollbackId })
				}).then((res) => res.json().then((body) => ({
					status: res.status,
					body
				}))).then(({ status, body }) => {
					if (status === 200 && body.ok) {
						setCompatibilityNotice(null);
						refreshInstalled();
					} else setInstallError(String(body.error || body.detail || "rollback failed"));
				}).catch((error) => setInstallError(String(error))).finally(() => setRollingBack(false));
			}, [refreshInstalled]);
			const compatibilitySummary = (risks) => {
				if (risks.length === 0) return "";
				const first = risks[0];
				return `${first.plugin}: ${first.peer} ${first.range} vs ${first.resolved}`;
			};
			/** Which name now resolves from two layers, and which layers those are. */
			const shadowSummary = (entries) => {
				if (entries.length === 0) return "";
				const first = entries[0];
				const rest = entries.length > 1 ? ` (+${entries.length - 1})` : "";
				return `${first.name} — ${first.layers.join(" / ")}${rest}`;
			};
			const doInstall = (0, react.useCallback)((plugin, force = false, version, preferReject = false) => {
				setBuildsSkipped(null);
				setConfirming(null);
				setInstallError(null);
				setActivationWarnings([]);
				setBusyUrl(plugin.url);
				const recordId = nextRecordId();
				setRecords((list) => enqueue(list, {
					id: recordId,
					kind: "install",
					name: plugin.name,
					url: plugin.url,
					state: "running"
				}));
				sessionStorage.setItem("dshm-pending", JSON.stringify({
					url: plugin.url,
					name: plugin.name
				}));
				fetch(api("/dsh-market/install"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						url: plugin.url,
						...force ? { force: true } : {},
						...version !== void 0 ? { version } : {},
						...statusRef.current.agentDrain && !preferReject ? { busyPolicy: "drain" } : {}
					})
				}).then((res) => res.json().then((body) => ({
					status: res.status,
					body
				}))).then(({ status, body }) => {
					setBusyUrl(null);
					sessionStorage.removeItem("dshm-pending");
					if (status === 202 && typeof body.operationId === "string") {
						const operation = body.operation;
						setRecords((list) => patch(withoutHostProjection(list, body.operationId, recordId), recordId, {
							state: "queued",
							hostOperationId: body.operationId,
							...operation?.wait === null || operation?.wait === void 0 ? {} : {
								blockedBy: operation.wait.activeAgentIds,
								waitSince: operation.wait.since
							},
							reason: operation?.wait === null || operation?.wait === void 0 ? t("agentBusyQueued") : t("agentDrainWaiting").replace("{0}", String(operation.wait.activeCount))
						}));
						rememberDrainMarker({
							operationId: body.operationId,
							kind: "install",
							name: plugin.name,
							url: plugin.url
						});
						setOperationsOpen(true);
						return;
					}
					if (status === 200 && body.ok && body.hot && pluginCategories(plugin).includes("theme")) {
						sessionStorage.setItem("dshm-toast", JSON.stringify([plugin.name]));
						sessionStorage.setItem("dshm-tab", "themes");
						location.reload();
						return;
					}
					if (body.cancelled === true) {
						setRecords((list) => drop(list, recordId));
						refreshInstalled();
						if (body.partial === true) setInstallError(t("partialNote"));
						return;
					}
					if (status === 200 && body.ok) {
						if (body.activation && typeof body.activation === "object") {
							setActivations((prev) => ({
								...prev,
								...body.activation
							}));
							const warns = Object.entries(body.activation).filter(([, info]) => info.state !== "live" && info.state !== "missing" && info.loadedByProfile !== true && info.library !== true).map(([name, info]) => ({
								name,
								info
							}));
							setActivationWarnings(warns);
						}
						if (body.hot) {
							setDoneUrls((urls) => urls.filter((url) => url !== plugin.url));
							setHotUrls((urls) => urls.includes(plugin.url) ? urls : urls.concat(plugin.url));
							setHotNames((names) => names.includes(plugin.name) ? names : names.concat(plugin.name));
						} else if (body.activation?.[plugin.name]?.state !== "incompatible" && body.activation?.[plugin.name]?.library !== true) setDoneUrls((urls) => urls.includes(plugin.url) ? urls : urls.concat(plugin.url));
						if (body.compatibility?.code === "soft-incompatible") setCompatibilityNotice(body.compatibility);
						setRecords((list) => patch(list, recordId, body.heldRelease !== void 0 ? {
							state: "warned",
							reason: t("heldReleaseNotice").replace("{0}", String(body.heldRelease.latest)).replace("{1}", String(body.heldRelease.installed ?? "")),
							heldRelease: body.heldRelease
						} : body.compatibility?.code === "soft-incompatible" && (body.compatibility.risks.length > 0 || (body.compatibility.brokenBundles?.length ?? 0) > 0) ? {
							state: "warned",
							reason: t("compatRiskBanner")
						} : {
							state: "done",
							needsRefresh: body.hot !== true
						}));
						refreshInstalled();
					} else {
						if (body.unsupported === true) {
							setRecords((list) => drop(list, recordId));
							doInstall(plugin, force, version, true);
							return;
						}
						if (body.agentsBusy !== true && body.migration && typeof body.migration === "object") {
							const { from, target } = body.migration;
							if (typeof from === "string" && typeof target === "string") {
								setRecords((list) => drop(list, recordId));
								setMigrationConfirm({
									name: from,
									source: String(installed[from] ?? ""),
									target,
									kind: "npm-rename"
								});
								setOperationsOpen(true);
								return;
							}
						}
						if (status === 409) {
							if (body.failureCode === "AGENT_BARRIER_LOST") {
								setRecords((list) => patch(list, recordId, {
									state: "failed",
									reason: String(body.error ?? t("installFail"))
								}));
								setOperationsOpen(true);
								return;
							}
							if (body.targetChanged === true) {
								setRecords((list) => patch(list, recordId, {
									state: "failed",
									reason: String(body.error ?? t("installFail"))
								}));
								setOperationsOpen(true);
								return;
							}
							if (body.agentsBusy === true) {
								setRecords((list) => patch(list, recordId, {
									state: "queued",
									reason: t("agentBusyQueued"),
									blockedBy: blockedSessions(body)
								}));
								setOperationsOpen(true);
								return;
							}
							setRecords((list) => patch(list, recordId, { state: "queued" }));
							setOperationsOpen(true);
							return;
						}
						if (Array.isArray(body.conflictGroups) && body.conflictGroups.length > 0) {
							setRecords((list) => patch(list, recordId, {
								state: "input",
								conflicts: body.conflictGroups
							}));
							setOperationsOpen(true);
							return;
						}
						if (body.hostIncompatible && typeof body.hostIncompatible === "object") {
							const notice = body.hostIncompatible;
							setRecords((list) => drop(list, recordId));
							setHostIncompatible({
								kind: "install",
								name: String(notice.name ?? plugin.name),
								version: String(notice.version ?? ""),
								requirement: typeof notice.requirement === "string" ? notice.requirement : null,
								hostVersion: typeof notice.hostVersion === "string" ? notice.hostVersion : null,
								npmName: typeof notice.npmName === "string" ? notice.npmName : typeof plugin.npm === "string" ? plugin.npm : null,
								plugin
							});
							return;
						}
						const blocked = Array.isArray(body.ignoredBuilds) ? body.ignoredBuilds.map(String) : [];
						if (blocked.length > 0) setBuildsSkipped({
							plugin,
							names: blocked
						});
						const orphans = Array.isArray(body.orphanBundles) ? body.orphanBundles.map(String) : [];
						const failure = failureText(body);
						const staleEntry = typeof body.staleEntry === "string" ? body.staleEntry : null;
						const detail = [
							orphans.length > 0 ? `${t("orphanBundle")} ${orphans.join(", ")}` : null,
							staleEntry,
							failure
						].filter(Boolean).join("\n");
						setRecords((list) => patch(list, recordId, {
							state: "failed",
							reason: detail.trim().slice(0, 1200),
							...blocked.length > 0 ? { blockedBuilds: blocked } : {}
						}));
						setOperationsOpen(true);
					}
				}).catch(() => {});
			}, [
				nextRecordId,
				refreshInstalled,
				rememberDrainMarker,
				t,
				installed
			]);
			/**
			* Resolve a loader-id clash the only way one profile allows: uninstall the
			* plugins holding the ids, then retry the install. Sequential because each
			* route takes the host's mutation lock, so a parallel burst would 409.
			*
			* A failure part-way leaves plugins already gone. Nothing reinstalls them
			* automatically (a rollback would itself be an install that can fail), so
			* the message names them — reporting only "failed" would leave the user
			* guessing which of their plugins survived.
			*/
			const doReplace = (0, react.useCallback)(async (record, plugin) => {
				setInstallError(null);
				setReplacing(true);
				const removed = [];
				try {
					for (const group of record.conflicts ?? []) {
						const response = await fetch(api("/dsh-market/uninstall"), {
							method: "POST",
							headers: { "content-type": "application/json" },
							body: JSON.stringify({ name: group.owner })
						});
						const body = await response.json();
						if (response.status !== 200 || body.ok !== true) {
							const detail = failureText(body, {
								tail: 400,
								fallback: "error"
							}).trim();
							const reason = removed.length === 0 ? `${t("installFail")}: ${group.owner} — ${detail}` : `${t("conflictReplaceFailed")} ${removed.join(", ")} — ${detail}`;
							setRecords((list) => patch(list, record.id, {
								state: "failed",
								conflicts: void 0,
								reason
							}));
							setOperationsOpen(true);
							refreshInstalled();
							return;
						}
						removed.push(group.owner);
					}
				} finally {
					setReplacing(false);
				}
				setRecords((list) => drop(list, record.id));
				refreshInstalled();
				doInstall(plugin);
			}, [
				doInstall,
				refreshInstalled,
				t
			]);
			/**
			* Answer a clash. `keep` is not a no-op to skip: it is the user declining
			* the install, so the record retires rather than lingering as unanswered.
			*/
			const resolveConflict = (0, react.useCallback)((record, choice) => {
				if (choice === "keep") {
					setRecords((list) => patch(list, record.id, {
						state: "failed",
						conflicts: void 0,
						reason: t("conflictDeclined")
					}));
					return;
				}
				const plugin = data?.plugins.find((candidate) => candidate.url === record.url);
				if (plugin === void 0) return;
				doReplace(record, plugin);
			}, [
				data,
				doReplace,
				t
			]);
			/**
			* Turn the recovery surface into the failure prompt.
			*
			* The banner keeps the host's own words for what happened (the parsed boot
			* failure), and the new option sits beside the other actions — the point of
			* the exercise is that a dead end now has a way out, not that the failure
			* is explained differently.
			*/
			const enterRecovery = (0, react.useCallback)((view) => {
				setRecovery(view);
				setRecoveryKeep(initialKeep(view));
				setRecoveryBusy(false);
				setRestarting(false);
				setInstallError(t("recoveryBanner") + (view.failure.summary || t("recoveryNoSummary")));
			}, [t]);
			/**
			* Restart the host and reload once the boot id changes (#14 by @ysyyhhh).
			* The 202 races the process's SIGTERM, so network errors on the initial
			* request are expected and treated as "restart under way".
			*
			* A boot that never happens is now a first-class outcome rather than only a
			* timeout: the market's restart helper starts the recovery surface on this
			* same origin, so the poll below is how the tab that asked for the restart
			* finds out WHICH plugin stopped the boot and gets to switch it off.
			*/
			const doRestart = (0, react.useCallback)(() => {
				if (bootId === null || restarting || recovery !== null) return;
				const previousBoot = bootId;
				setRestarting(true);
				setInstallError(null);
				setRecovery(null);
				const shellRestart = typeof window === "undefined" ? void 0 : window.__dshHostShell?.restart;
				if (typeof shellRestart === "function") try {
					shellRestart();
					return;
				} catch {}
				const awaitNewBoot = () => {
					const deadline = Date.now() + 6e4;
					const poll = () => {
						fetch(api("/dsh-market/status"), { cache: "no-store" }).then((res) => res.json()).then((next) => {
							if (next.recovery === true) {
								fetchRecovery().then((view) => {
									if (view !== null) enterRecovery(view);
								});
								return;
							}
							if (typeof next.boot === "string" && next.boot !== previousBoot) {
								location.reload();
								return;
							}
							retry();
						}).catch(retry);
					};
					const retry = () => {
						if (Date.now() > deadline) {
							fetchRecovery().then((view) => {
								if (view !== null) {
									enterRecovery(view);
									return;
								}
								setRestarting(false);
								setInstallError(t("recoveryTimeout"));
							});
							return;
						}
						setTimeout(poll, 1500);
					};
					poll();
				};
				const requestRestart = (attemptsLeft) => {
					fetch(api("/dsh-market/restart"), {
						method: "POST",
						headers: { "content-type": "application/json" },
						body: "{}"
					}).then((res) => res.json().then((body) => ({
						status: res.status,
						body
					}))).then(({ status, body }) => {
						if (status === 202 && body.ok === true) {
							awaitNewBoot();
							return;
						}
						if (status === 409 && attemptsLeft > 0) {
							setTimeout(() => requestRestart(attemptsLeft - 1), 1500);
							return;
						}
						setRestarting(false);
						setInstallError(t("restartFail") + ": " + localizeBilingual(String(body.error || "HTTP " + String(status)), lang));
					}).catch(awaitNewBoot);
				};
				requestRestart(10);
			}, [
				bootId,
				restarting,
				recovery,
				t,
				lang,
				enterRecovery
			]);
			/**
			* Write the chosen enable set through the recovery surface and wait for the
			* next boot. The write goes to the profile's patch layer — the same durable
			* mechanism the live toggles use — so the choice is what the loader applies
			* on every later start, not just this one.
			*/
			const applyRecoveryChoice = (0, react.useCallback)(() => {
				if (recovery === null || recoveryBusy) return;
				setRecoveryBusy(true);
				setInstallError(null);
				applyRecovery(Object.entries(recoveryKeep).filter(([, on]) => on).map(([name]) => name)).then((result) => {
					if (!result.ok) {
						setRecoveryBusy(false);
						setInstallError(t("recoveryApplyFailed") + (result.error ?? ""));
						return;
					}
					setRecoveryOpen(false);
					setRestarting(true);
					watchRestart(recovery.bootId, {
						onBoot: () => {
							location.reload();
						},
						onRecovery: (view) => {
							enterRecovery(view);
							setRecoveryOpen(true);
						},
						onTimeout: () => {
							setRecoveryBusy(false);
							setRestarting(false);
							setInstallError(t("recoveryTimeout"));
						}
					});
				});
			}, [
				recovery,
				recoveryBusy,
				recoveryKeep,
				t,
				enterRecovery
			]);
			/** Cancel the running plugin command (#6 by @qichuang321). */
			const doCancel = (0, react.useCallback)((record) => {
				const body = record?.hostOperationId === void 0 ? {} : { operationId: record.hostOperationId };
				fetch(api("/dsh-market/cancel"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify(body)
				}).catch(() => {});
			}, []);
			const doUpdate = (0, react.useCallback)((name, force = false, restore = false, compatVersion, confirmAgentsRunning = false, eligibleVersion, preferReject = false) => {
				const expectedVersion = compatVersion === void 0 && !restore ? eligibleVersion ?? updates[name]?.eligibleVersion : void 0;
				const updateOptions = {
					force,
					restore,
					compatVersion,
					eligibleVersion: expectedVersion
				};
				setInstallError(null);
				setActivationWarnings([]);
				setStaleName((prev) => prev === name ? null : prev);
				setRestoreConfirm((prev) => prev?.name === name ? null : prev);
				setMigrationConfirm(null);
				setUpdatingName(name);
				updateIdleStrikes.current = 0;
				sessionStorage.setItem("dshm-updating", JSON.stringify({ name }));
				const updateRecordId = nextRecordId();
				setRecords((list) => enqueue(list, {
					id: updateRecordId,
					kind: "update",
					name,
					state: "running",
					updateOptions
				}));
				return fetch(api("/dsh-market/update"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						name,
						...force ? { force: true } : {},
						...restore ? { restore: true } : {},
						...compatVersion !== void 0 ? { compatVersion } : {},
						...expectedVersion !== void 0 ? { eligibleVersion: expectedVersion } : {},
						...confirmAgentsRunning ? { confirmAgentsRunning: true } : {},
						...!restore && statusRef.current.agentDrain && !preferReject ? { busyPolicy: "drain" } : {}
					})
				}).then((res) => res.json().then((body) => ({
					status: res.status,
					body
				}))).then(({ status, body }) => {
					sessionStorage.removeItem("dshm-updating");
					setUpdatingName(null);
					if (status === 202 && typeof body.operationId === "string") {
						const operation = body.operation;
						setRecords((list) => patch(withoutHostProjection(list, body.operationId, updateRecordId), updateRecordId, {
							state: "queued",
							hostOperationId: body.operationId,
							...operation?.wait === null || operation?.wait === void 0 ? {} : {
								blockedBy: operation.wait.activeAgentIds,
								waitSince: operation.wait.since
							},
							reason: operation?.wait === null || operation?.wait === void 0 ? t("agentBusyUpdateQueued") : t("agentDrainWaiting").replace("{0}", String(operation.wait.activeCount))
						}));
						rememberDrainMarker({
							operationId: body.operationId,
							kind: "update",
							name
						});
						setOperationsOpen(true);
						return;
					}
					if (body.cancelled === true) {
						setRecords((list) => drop(list, updateRecordId));
						refreshInstalled();
						if (body.partial === true) setInstallError(t("partialNote"));
						return;
					}
					if (status === 409 && body.staleTarget === true) {
						setRecords((list) => patch(list, updateRecordId, {
							state: "failed",
							reason: String(body.error ?? "Update target changed")
						}));
						setInstallError(localizeBilingual(String(body.error ?? "Update target changed"), lang));
						refreshInstalled(true);
						return;
					}
					if (status === 200 && body.ok && body.skipped === "current") {
						setRecords((list) => drop(list, updateRecordId));
						refreshInstalled(true);
						return;
					}
					if (status === 200 && body.ok) {
						const unverified = body.versionUnverified !== null && typeof body.versionUnverified === "object" ? body.versionUnverified : null;
						setRecords((list) => patch(list, updateRecordId, unverified === null ? { state: "done" } : {
							state: "warned",
							reason: typeof unverified.installed === "string" && unverified.installed !== "" ? t("versionUnverifiedNote").replace("{0}", unverified.installed) : t("versionUnverifiedNoteUnknown")
						}));
						setUpdatedNames((names) => names.concat(name));
						const activation = body.activation && typeof body.activation === "object" ? body.activation[name] : void 0;
						if (!activation || activation.state === "restart") setRestartNames((names) => names.includes(name) ? names : names.concat(name));
						if (body.activation && typeof body.activation === "object") setActivations((prev) => ({
							...prev,
							...body.activation
						}));
						if (body.compatibility?.code === "soft-incompatible") setCompatibilityNotice(body.compatibility);
						refreshInstalled();
					} else {
						if (body.unsupported === true) {
							setRecords((list) => drop(list, updateRecordId));
							doUpdate(name, force, restore, compatVersion, confirmAgentsRunning, eligibleVersion, true);
							return;
						}
						if (status === 409) {
							if (body.failureCode === "AGENT_BARRIER_LOST") {
								setRecords((list) => patch(list, updateRecordId, {
									state: "failed",
									reason: String(body.error ?? "An Agent became active before the update; nothing was changed.")
								}));
								setOperationsOpen(true);
								return;
							}
							if (body.targetChanged === true) {
								setRecords((list) => patch(list, updateRecordId, {
									state: "failed",
									reason: String(body.error ?? "Update target changed")
								}));
								setInstallError(localizeBilingual(String(body.error ?? "Update target changed"), lang));
								setOperationsOpen(true);
								return;
							}
							if (body.agentsBusy === true) {
								setRecords((list) => patch(list, updateRecordId, {
									state: "queued",
									reason: t("agentBusyUpdateQueued"),
									blockedBy: blockedSessions(body)
								}));
								setOperationsOpen(true);
								return;
							}
							setRecords((list) => patch(list, updateRecordId, { state: "queued" }));
							if (body.busy === true) return;
							setInstallError(t("queuedRunBusy"));
							setOperationsOpen(true);
							return;
						}
						if (body.hostIncompatible && typeof body.hostIncompatible === "object") {
							const notice = body.hostIncompatible;
							setRecords((list) => drop(list, updateRecordId));
							setHostIncompatible({
								kind: "update",
								name: String(notice.name ?? name),
								version: String(notice.version ?? ""),
								requirement: typeof notice.requirement === "string" ? notice.requirement : null,
								hostVersion: typeof notice.hostVersion === "string" ? notice.hostVersion : null,
								npmName: typeof notice.npmName === "string" ? notice.npmName : null,
								plugin: null
							});
							return;
						}
						if (body.stale === true) setStaleName(name);
						if (Array.isArray(body.ignoredBuilds) && body.ignoredBuilds.length > 0) setBuildsSkipped({
							updateName: name,
							names: body.ignoredBuilds.map(String),
							updateOptions
						});
						const orphans = Array.isArray(body.orphanBundles) ? body.orphanBundles.map(String) : [];
						const failure = failureText(body);
						const staleEntry = typeof body.staleEntry === "string" ? body.staleEntry : null;
						const clipped = [
							orphans.length > 0 ? `${t("orphanBundle")} ${orphans.join(", ")}` : null,
							staleEntry,
							failure
						].filter(Boolean).join("\n").trim().slice(0, 1200);
						setRecords((list) => patch(list, updateRecordId, {
							state: "failed",
							reason: clipped,
							...Array.isArray(body.ignoredBuilds) && body.ignoredBuilds.length > 0 ? { blockedBuilds: body.ignoredBuilds.map(String) } : {}
						}));
						setInstallError((restore ? t("restoreFail") : t("updateFail")) + ": " + name + " — " + localizeBilingual(clipped, lang));
					}
				}).catch(() => {});
			}, [
				refreshInstalled,
				installed,
				rememberDrainMarker,
				t,
				lang,
				updates
			]);
			const doSourceMigration = (0, react.useCallback)((name, confirmAgentsRunning = false, renameTo) => {
				setInstallError(null);
				setActivationWarnings([]);
				setMigrationConfirm(null);
				setUpdatingName(name);
				return fetch(api("/dsh-market/migrate-source"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						name,
						...renameTo === void 0 ? {} : {
							kind: "npm-rename",
							to: renameTo
						},
						...confirmAgentsRunning ? { confirmAgentsRunning: true } : {}
					})
				}).then((res) => res.json().then((body) => ({
					status: res.status,
					body
				}))).then(({ status, body }) => {
					setUpdatingName(null);
					if (status === 200 && body.ok === true) {
						const targetName = typeof body.to?.name === "string" ? body.to.name : name;
						setUpdatedNames((names) => names.includes(targetName) ? names : names.concat(targetName));
						if (body.activation && typeof body.activation === "object") setActivations((prev) => ({
							...prev,
							...body.activation
						}));
						refreshInstalled(true);
						const warnings = Array.isArray(body.warnings) ? body.warnings.map(String).filter(Boolean) : [];
						if (warnings.length > 0) setInstallError(warnings.join("\n"));
						return;
					}
					if (status === 409 && body.agentsBusy === true) {
						setAgentsConfirm({
							name,
							kind: "update",
							run: () => {
								doSourceMigration(name, true, renameTo);
							}
						});
						return;
					}
					setInstallError(t("migrateFail") + ": " + localizeBilingual(String(body.error || "HTTP " + String(status)), lang));
				}).catch((error) => {
					setUpdatingName(null);
					setInstallError(t("migrateFail") + ": " + String(error));
				});
			}, [
				refreshInstalled,
				t,
				lang
			]);
			const askSourceMigration = (0, react.useCallback)((name) => {
				const migration = updates[name]?.sourceMigration;
				const source = installed[name];
				setStaleName(null);
				setRestoreConfirm(null);
				setRestoreBlocked(null);
				setInstallError(null);
				if (migration === void 0 || source === void 0) {
					setMigrationConfirm(null);
					return;
				}
				setMigrationConfirm({
					name,
					source: String(source),
					target: migration.target,
					kind: migration.kind
				});
			}, [installed, updates]);
			const askRestore = (0, react.useCallback)((name) => {
				if (data === null) return;
				const spec = installed[name];
				if (spec === void 0) return;
				const specText = String(spec);
				setStaleName(null);
				setMigrationConfirm(null);
				setRestoreBlocked(null);
				if (/^(?:link|file):/i.test(specText)) {
					const resolved = resolveCatalogRestore(data.plugins, name, repoIdentities[name] ?? [], repoHints[name] ?? []);
					if (!resolved.ok) {
						setRestoreConfirm(null);
						setRestoreBlocked({
							name,
							reason: resolved.reason
						});
						return;
					}
					setRestoreConfirm({
						name,
						entry: resolved.entry,
						verified: resolved.verified
					});
					return;
				}
				const entry = entryForDep(data.plugins, name, specText, repoIdentities[name], repoHints[name]);
				if (entry === void 0) {
					setRestoreConfirm(null);
					setRestoreBlocked({
						name,
						reason: "no-catalog"
					});
					return;
				}
				setRestoreConfirm({
					name,
					entry,
					verified: true
				});
			}, [
				data,
				installed,
				repoHints,
				repoIdentities
			]);
			/** Open the update-notes dialog and start its fetch. Lazy: the request only
			exists while a user is actually looking at one plugin's notes, and
			closing the dialog abandons the render — the server side caches the
			payload, so reopening is cheap. */
			const openNotes = (0, react.useCallback)((name, current, latest, repoUrl) => {
				setNotesFor({
					name,
					current,
					latest,
					repoUrl
				});
				setUpdateNotes(null);
				setNotesState("loading");
				fetch(`${api("/dsh-market/changelog")}?name=${encodeURIComponent(name)}`).then((res) => res.json()).then((body) => {
					setUpdateNotes(body);
					setNotesState("ready");
				}).catch(() => setNotesState("fail"));
			}, []);
			const doUseSkin = (0, react.useCallback)((name) => {
				setInstallError(null);
				fetch(api("/dsh-market/use-skin"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({ name })
				}).then((res) => res.json().then((body) => ({
					status: res.status,
					body
				}))).then(({ status, body }) => {
					if (status === 200 && body.ok) {
						sessionStorage.setItem("dshm-toast", JSON.stringify([name]));
						sessionStorage.setItem("dshm-toast-mode", "theme");
						sessionStorage.setItem("dshm-tab", "themes");
						location.reload();
					} else setInstallError(String(body.error || "failed"));
				}).catch((error) => setInstallError(String(error)));
			}, []);
			/**
			* Forget a pending page-refresh for a plugin that is no longer here.
			*
			* The banner counts what the page has not caught up with. Install then
			* uninstall and the page is level again — there is nothing left to load —
			* but both sets were append-only, so it kept asking for a refresh that
			* would show nothing (#340). It conflated "something needs doing" with
			* "something happened in this session".
			*/
			/** Write (or clear, when empty) this plugin's note. */
			const saveNote = (0, react.useCallback)((name, text) => {
				setNotingName(null);
				fetch(api("/dsh-market/note"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						name,
						text
					})
				}).then((res) => res.json()).then((body) => {
					if (body.ok && body.notes !== null && typeof body.notes === "object") setNotes(body.notes);
					else setInstallError(String(body.error || "note failed"));
				}).catch((error) => setInstallError(String(error)));
			}, []);
			const toggleFavorite = (0, react.useCallback)((url) => {
				const gen = ++favoriteOpGen.current;
				const favorited = !favoriteUrlSet.has(url);
				const previous = favoriteUrls;
				setFavoriteError(null);
				setFavoriteUrls((list) => {
					if (favorited) return list.includes(url) ? list : [...list, url];
					return list.filter((entry) => entry !== url);
				});
				fetch(api("/dsh-market/favorite"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						url,
						favorited
					})
				}).then(async (res) => {
					const text = await res.text();
					let body = null;
					if (text !== "") try {
						body = JSON.parse(text);
					} catch {}
					return {
						status: res.status,
						body
					};
				}).then(({ status, body }) => {
					if (gen !== favoriteOpGen.current) return;
					if (status === 200 && body?.ok === true && Array.isArray(body.favorites)) {
						setFavoriteUrls(body.favorites.filter((entry) => typeof entry === "string"));
						return;
					}
					setFavoriteUrls(previous);
					if (body === null && (status === 404 || status === 405)) {
						setFavoriteError(t("favoriteUnavailable"));
						return;
					}
					if (status === 409) {
						setFavoriteError(t("favoriteBusy"));
						return;
					}
					setFavoriteError(typeof body?.error === "string" ? body.error : t("favoriteFailed"));
				}).catch((error) => {
					if (gen !== favoriteOpGen.current) return;
					setFavoriteUrls(previous);
					setFavoriteError(String(error));
				});
			}, [
				favoriteUrlSet,
				favoriteUrls,
				t
			]);
			const toggleBlock = (0, react.useCallback)((name) => {
				const gen = ++blockOpGen.current;
				const nextBlocked = !blockedNameSet.has(name);
				const previous = blockedNames;
				setBlockError(null);
				setBlockedNames((list) => {
					if (nextBlocked) return list.includes(name) ? list : [...list, name];
					return list.filter((entry) => entry !== name);
				});
				fetch(api("/dsh-market/block"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						name,
						blocked: nextBlocked
					})
				}).then(async (res) => {
					const text = await res.text();
					let body = null;
					if (text !== "") try {
						body = JSON.parse(text);
					} catch {}
					return {
						status: res.status,
						body
					};
				}).then(({ status, body }) => {
					if (gen !== blockOpGen.current) return;
					if (status === 200 && body?.ok === true && Array.isArray(body.blocked)) {
						setBlockedNames(body.blocked.filter((entry) => typeof entry === "string"));
						if (nextBlocked) setBlockNotice(t("blockMoved"));
						return;
					}
					setBlockedNames(previous);
					setBlockError(typeof body?.error === "string" ? body.error : t("blockFailed"));
				}).catch((error) => {
					if (gen !== blockOpGen.current) return;
					setBlockedNames(previous);
					setBlockError(String(error));
				});
			}, [
				blockedNameSet,
				blockedNames,
				t
			]);
			const toggleUpdateExempt = (0, react.useCallback)((name) => {
				const gen = ++updateExemptOpGen.current;
				const nextExempt = !updateExemptSet.has(name);
				const previous = updateExemptNames;
				setUpdateExemptError(null);
				setUpdateExemptNames((list) => {
					if (nextExempt) return list.includes(name) ? list : [...list, name];
					return list.filter((entry) => entry !== name);
				});
				fetch(api("/dsh-market/update-exempt"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						name,
						exempt: nextExempt
					})
				}).then(async (res) => {
					const text = await res.text();
					let body = null;
					if (text !== "") try {
						body = JSON.parse(text);
					} catch {}
					return {
						status: res.status,
						body
					};
				}).then(({ status, body }) => {
					if (gen !== updateExemptOpGen.current) return;
					if (status === 200 && body?.ok === true && Array.isArray(body.updateExempt)) {
						setUpdateExemptNames(body.updateExempt.filter((entry) => typeof entry === "string"));
						setUpdateExemptNotice(t(nextExempt ? "updateExemptOn" : "updateExemptOff"));
						return;
					}
					setUpdateExemptNames(previous);
					setUpdateExemptError(typeof body?.error === "string" ? body.error : t("updateExemptFailed"));
				}).catch((error) => {
					if (gen !== updateExemptOpGen.current) return;
					setUpdateExemptNames(previous);
					setUpdateExemptError(String(error));
				});
			}, [
				updateExemptSet,
				updateExemptNames,
				t
			]);
			/**
			* Stop showing one removed-declaration notice (#763).
			*
			* The notice is durable on purpose — it is the only thing left that says why
			* a plugin vanished — but the reporter's plugin was no longer in the catalog,
			* so the search it offered found nothing and the banner outlived every other
			* action. Hiding it says nothing about the plugin: the declaration stays
			* dropped and the directory stays where it is.
			*
			* Every step touches THIS name and nothing else, in both directions:
			*
			* - success removes this key and ignores the reply's map. That map is a
			*   snapshot from when the request ran, so adopting it wholesale would
			*   resurrect a notice another click had already dismissed, and would drop a
			*   record an `/installed` read reported while this was in flight — including
			*   one written by a failed update (#663), which is the one thing the notice
			*   exists for.
			* - failure puts THIS key back, and only if no `/installed` read has landed
			*   since: that read is the server's current truth and outranks a rollback
			*   built from what the panel happened to be showing.
			*
			* A dismiss that silently did nothing is worse than having no button: the
			* user would go on believing they had been told the truth about their profile.
			*/
			const dismissBrokenPlugin = (0, react.useCallback)((name) => {
				const record = brokenPlugins[name];
				if (record === void 0) return;
				const gens = dismissBrokenGen.current;
				const gen = (gens.get(name) ?? 0) + 1;
				gens.set(name, gen);
				const readAtRequest = installedReadGen.current;
				setDismissBrokenError(null);
				setDismissingBroken((current) => new Set(current).add(name));
				setBrokenPlugins((current) => {
					if (current[name] === void 0) return current;
					const next = { ...current };
					delete next[name];
					return next;
				});
				/** This request's own failure, applied to this one name only. */
				const restore = (reason) => {
					if (dismissBrokenGen.current.get(name) !== gen) return;
					if (installedReadGen.current === readAtRequest) setBrokenPlugins((current) => current[name] === void 0 ? {
						...current,
						[name]: record
					} : current);
					setDismissBrokenError(reason);
				};
				fetch(api("/dsh-market/dismiss-broken"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({ name })
				}).then(async (res) => {
					const text = await res.text();
					let body = null;
					if (text !== "") try {
						body = JSON.parse(text);
					} catch {}
					return {
						status: res.status,
						body
					};
				}).then(({ status, body }) => {
					if (status === 200 && body?.ok === true) {
						if (dismissBrokenGen.current.get(name) !== gen) return;
						setBrokenPlugins((current) => {
							if (current[name] === void 0) return current;
							const next = { ...current };
							delete next[name];
							return next;
						});
						return;
					}
					restore(typeof body?.error === "string" ? body.error : t("toggleFail"));
				}).catch((error) => {
					restore(String(error));
				}).finally(() => {
					setDismissingBroken((current) => {
						const next = new Set(current);
						next.delete(name);
						return next;
					});
				});
			}, [brokenPlugins, t]);
			const clearStaleFavorites = (0, react.useCallback)(() => {
				if (favoriteStale.length === 0) return;
				const gen = ++favoriteOpGen.current;
				const stale = favoriteStale;
				const previous = favoriteUrls;
				setFavoriteError(null);
				setClearingStale(true);
				setFavoriteUrls((list) => list.filter((url) => !stale.includes(url)));
				(async () => {
					try {
						let latest = null;
						for (const url of stale) {
							const res = await fetch(api("/dsh-market/favorite"), {
								method: "POST",
								headers: { "content-type": "application/json" },
								body: JSON.stringify({
									url,
									favorited: false
								})
							});
							const text = await res.text();
							let body = null;
							if (text !== "") try {
								body = JSON.parse(text);
							} catch {}
							if (res.status === 200 && body?.ok === true && Array.isArray(body.favorites)) {
								latest = body.favorites.filter((entry) => typeof entry === "string");
								continue;
							}
							if (gen !== favoriteOpGen.current) return;
							setFavoriteUrls(previous);
							if (res.status === 409) setFavoriteError(t("favoriteBusy"));
							else setFavoriteError(typeof body?.error === "string" ? body.error : t("favoriteFailed"));
							return;
						}
						if (gen !== favoriteOpGen.current) return;
						if (latest !== null) setFavoriteUrls(latest);
					} catch (error) {
						if (gen !== favoriteOpGen.current) return;
						setFavoriteUrls(previous);
						setFavoriteError(String(error));
					} finally {
						if (gen === favoriteOpGen.current) setClearingStale(false);
					}
				})();
			}, [
				favoriteStale,
				favoriteUrls,
				t
			]);
			const clearPendingRefresh = (0, react.useCallback)((name) => {
				setHotNames((names) => names.filter((entry) => entry !== name));
				setRefreshNames((names) => names.filter((entry) => entry !== name));
			}, []);
			const doUninstall = (0, react.useCallback)((name, confirmAgentsRunning = false, preferReject = false) => {
				setRemoveConfirm(null);
				setInstallError(null);
				setActivationWarnings([]);
				setRemovingName(name);
				const uninstallRecordId = nextRecordId();
				setRecords((list) => enqueue(list, {
					id: uninstallRecordId,
					kind: "uninstall",
					name,
					state: "running"
				}));
				return fetch(api("/dsh-market/uninstall"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						name,
						...confirmAgentsRunning ? { confirmAgentsRunning: true } : {},
						...statusRef.current.agentDrain && !preferReject ? { busyPolicy: "drain" } : {}
					})
				}).then((res) => res.json().then((body) => ({
					status: res.status,
					body
				}))).then(({ status, body }) => {
					if (status === 202 && typeof body.operationId === "string") {
						const operation = body.operation;
						setRecords((list) => patch(withoutHostProjection(list, body.operationId, uninstallRecordId), uninstallRecordId, {
							state: "queued",
							hostOperationId: body.operationId,
							...operation?.wait === null || operation?.wait === void 0 ? {} : {
								blockedBy: operation.wait.activeAgentIds,
								waitSince: operation.wait.since
							},
							reason: operation?.wait === null || operation?.wait === void 0 ? t("agentBusyUninstallQueued") : t("agentDrainWaiting").replace("{0}", String(operation.wait.activeCount))
						}));
						rememberDrainMarker({
							operationId: body.operationId,
							kind: "uninstall",
							name
						});
						setOperationsOpen(true);
						return;
					}
					if (body.unsupported === true) {
						setRecords((list) => drop(list, uninstallRecordId));
						doUninstall(name, confirmAgentsRunning, true);
						return;
					}
					if (status === 409 && body.failureCode === "AGENT_BARRIER_LOST") {
						setRecords((list) => patch(list, uninstallRecordId, {
							state: "failed",
							reason: String(body.error ?? "An Agent became active before the uninstall; nothing was changed.")
						}));
						setOperationsOpen(true);
						return;
					}
					if (status === 409 && body.targetChanged === true) {
						setRecords((list) => patch(list, uninstallRecordId, {
							state: "failed",
							reason: String(body.error ?? t("installFail"))
						}));
						setOperationsOpen(true);
						return;
					}
					if (status === 409 && body.agentsBusy === true) {
						setRecords((list) => patch(list, uninstallRecordId, {
							state: "queued",
							reason: t("agentBusyUninstallQueued"),
							blockedBy: blockedSessions(body)
						}));
						setOperationsOpen(true);
						return;
					}
					setRecords((list) => drop(list, uninstallRecordId));
					if (status === 200 && body.ok) {
						if (!body.hot) setRemovedCount((n) => n + 1);
						const neverLoadedHere = hotNames.includes(name) || refreshNames.includes(name);
						if (body.refresh === true && !neverLoadedHere) setRefreshNames((names) => names.includes(name) ? names : names.concat(name));
						else clearPendingRefresh(name);
						refreshInstalled();
					} else {
						if (body.cancelled === true) {
							refreshInstalled();
							if (body.partial === true) setInstallError(t("partialNote"));
							return;
						}
						if (body.reconciled === true) {
							if (!body.hot) setRemovedCount((n) => n + 1);
							clearPendingRefresh(name);
							refreshInstalled();
							setInstallError(t("reconciledNote"));
							return;
						}
						setInstallError(failureText(body, { fallback: "error" }).trim());
					}
				}).catch((error) => setInstallError(String(error))).finally(() => setRemovingName(null));
			}, [
				refreshInstalled,
				hotNames,
				refreshNames,
				nextRecordId,
				rememberDrainMarker,
				t
			]);
			const busyUrlRef = (0, react.useRef)(null);
			busyUrlRef.current = busyUrl;
			const updatingNameRef = (0, react.useRef)(null);
			updatingNameRef.current = updatingName;
			const removingNameRef = (0, react.useRef)(null);
			removingNameRef.current = removingName;
			/**
			* The records as of the last commit, for the drain's tick.
			*
			* The tick must not read the list out of its own `setRecords` updater.
			* React only runs that updater synchronously when the fiber has no pending
			* work (its eager-state optimization, react-dom dispatchSetState); an
			* interval tick regularly races the status poll's state writes, and when
			* the updater is deferred the read returns null BEFORE it runs — while the
			* updater still removes the row it finds when render finally calls it. The
			* drain then deleted a queued operation instead of starting it, and the
			* persistence effect rewrote the durable queue without it.
			*/
			const recordsRef = (0, react.useRef)(records);
			recordsRef.current = records;
			const dataRef = (0, react.useRef)(null);
			dataRef.current = data;
			const doInstallRef = (0, react.useRef)(null);
			doInstallRef.current = doInstall;
			const doUpdateRef = (0, react.useRef)(null);
			doUpdateRef.current = doUpdate;
			const doUninstallRef = (0, react.useRef)(null);
			doUninstallRef.current = doUninstall;
			/**
			* Whether a plugin operation started from THIS page is still in flight.
			*
			* The host runs one mutation at a time and answers a second one with 409
			* (routes.ts withMutationLock) rather than queueing it, so every start path
			* has to look before it fires. The catalog and installed cards do it by
			* disabling their button on `busyUrl`/`updatingName`/`removingName`; the
			* drain does it on these refs. The Tasks panel's "run now" asked only about
			* the agent guard, so a batch of clicks sent one request that ran and N-1
			* the host refused — and a refusal used to be recorded as a failure, which
			* is not part of the durable queue.
			*
			* Refs, not `statusRef.current.busy`: that sample is up to a whole poll
			* interval old, and the batch lands inside exactly that window. Asking the
			* host "are you busy" cannot answer a question about a request this page
			* has just sent.
			*/
			const operationInFlight = (0, react.useCallback)(() => busyUrlRef.current !== null || updatingNameRef.current !== null || removingNameRef.current !== null, []);
			/**
			* Installs wait only for the mutation lock; replacements also wait for
			* running sessions unless the user confirms a single request. Legacy hosts
			* can still refuse installs, so retain their queue fallback. When every
			* operation is queued, nothing else polls /status, so this loop fetches it
			* itself — but only while a queued record exists, so an idle page makes no
			* requests.
			* One mutation at a time — the host still serializes via its lock, and a
			* re-refused drain simply re-queues instead of failing.
			*/
			(0, react.useEffect)(() => {
				let disposed = false;
				const timer = setInterval(() => {
					if (drainingRef.current) return;
					if (operationInFlight()) return;
					if (!recordsRef.current.some((record) => record.hostOperationId === void 0 ? record.state === "queued" : record.state === "queued" || record.state === "running")) return;
					fetch(api("/dsh-market/status"), { cache: "no-store" }).then(readMarketStatus).then((status) => {
						if (disposed || status === null) return;
						const runningAgents = Array.isArray(status.runningAgents) ? status.runningAgents.map(String) : [];
						const busy = status.busy === true;
						statusRef.current = {
							busy,
							runningAgents,
							agentDrain: status.agentDrain === true,
							boot: typeof status.boot === "string" ? status.boot : null
						};
						applyDrainStatus(status);
						restoreDrainMarkers(status);
						if (busy) return;
						if (status.drainActive === true) return;
						if (operationInFlight()) return;
						const task = recordsRef.current.find((record) => record.state === "queued" && record.hostOperationId === void 0 && (record.kind === "install" || runningAgents.length === 0));
						if (task === void 0 || recordsRef.current.some((record) => record.state === "running" && record.hostOperationId === void 0)) return;
						setRecords((list) => list.filter((record) => record.id !== task.id));
						drainingRef.current = true;
						try {
							if (task.kind === "install") {
								const plugin = dataRef.current?.plugins.find((candidate) => candidate.url === task.url);
								if (plugin !== void 0) doInstallRef.current?.(plugin);
							} else if (task.kind === "update") doUpdateRef.current?.(task.name, task.updateOptions?.force, task.updateOptions?.restore, task.updateOptions?.compatVersion, false, task.updateOptions?.eligibleVersion);
							else doUninstallRef.current?.(task.name);
						} finally {
							drainingRef.current = false;
						}
					}).catch(() => {});
				}, 2e3);
				return () => {
					disposed = true;
					clearInterval(timer);
				};
			}, [
				applyDrainStatus,
				readMarketStatus,
				restoreDrainMarkers
			]);
			/** A queued record's "run now": retry immediately instead of waiting for idle. */
			const runQueuedNow = (0, react.useCallback)((record, confirmAgentsRunning = false) => {
				if (record.hostOperationId !== void 0) return;
				if (!recordsRef.current.some((item) => item.id === record.id && item.state === "queued")) return;
				if (record.kind !== "install" && !confirmAgentsRunning && (statusRef.current.runningAgents.length > 0 || (record.blockedBy?.length ?? 0) > 0)) {
					setAgentsConfirm({
						name: record.name,
						kind: record.kind,
						run: () => runQueuedNow(record, true)
					});
					return;
				}
				if (operationInFlight() || statusRef.current.busy) {
					setInstallError(t("queuedRunBusy"));
					setOperationsOpen(true);
					return;
				}
				if (record.kind === "install") {
					const plugin = data?.plugins.find((candidate) => candidate.url === record.url);
					if (plugin === void 0) {
						setRecords((prev) => drop(prev, record.id));
						setInstallError(t("queuedInstallGone"));
						setOperationsOpen(true);
						return;
					}
					setRecords((prev) => drop(prev, record.id));
					doInstall(plugin);
				} else if (record.kind === "update") {
					setRecords((prev) => drop(prev, record.id));
					doUpdate(record.name, record.updateOptions?.force, record.updateOptions?.restore, record.updateOptions?.compatVersion, confirmAgentsRunning, record.updateOptions?.eligibleVersion);
				} else {
					setRecords((prev) => drop(prev, record.id));
					doUninstall(record.name, confirmAgentsRunning);
				}
			}, [
				data,
				doInstall,
				doUpdate,
				doUninstall,
				operationInFlight,
				t
			]);
			/** Live enable/disable of one installed plugin (#60). `reload` opts the
			* card-level theme flow into a page refresh so the visual result lands
			* immediately (mirrors the use-skin reload on activate). */
			const doToggle = (0, react.useCallback)((name, enabled, reload = false) => {
				setTogglingName(name);
				setInstallError(null);
				return fetch(api("/dsh-market/toggle"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						name,
						enabled
					})
				}).then((res) => res.json().then((body) => ({
					status: res.status,
					body
				}))).then(({ status, body }) => {
					if (status === 200 && body.ok) {
						if (Array.isArray(body.disabled)) setDisabledNames(body.disabled);
						if (Array.isArray(body.live)) setSkins(body.live);
						if (body.activation && typeof body.activation === "object") setActivations((prev) => ({
							...prev,
							...body.activation
						}));
						if (body.restart === true) setToggleRestart((n) => n + 1);
						if (body.refresh === true) {
							if ((loadedDisabled.current?.has(name) ?? false) === !enabled) clearPendingRefresh(name);
							else setRefreshNames((names) => names.includes(name) ? names : names.concat(name));
						}
						if (!reload) setToggled({
							name,
							enabled
						});
						refreshInstalled();
						if (reload) {
							sessionStorage.removeItem("dshm-toast");
							sessionStorage.removeItem("dshm-toast-mode");
							sessionStorage.setItem("dshm-tab", "themes");
							location.reload();
						}
					} else {
						const text = (v) => typeof v === "string" ? v : v == null ? "" : JSON.stringify(v);
						setInstallError(text(body.reason) || text(body.error) || t("toggleFail"));
						if (body.restart === true) setToggleRestart((n) => n + 1);
						if (body.refresh === true) setRefreshNames((names) => names.includes(name) ? names : names.concat(name));
					}
				}).catch((error) => setInstallError(String(error))).finally(() => setTogglingName(null));
			}, [
				clearPendingRefresh,
				refreshInstalled,
				t
			]);
			/** Adopt the groups payload returned by POST /dsh-market/groups. */
			const setGroupPayload = (0, react.useCallback)((body) => {
				if (body.groups && typeof body.groups === "object") setGroups(body.groups);
				if (Array.isArray(body.groupOrder)) setGroupOrder(body.groupOrder);
				if (Array.isArray(body.disabled)) setDisabledNames(body.disabled);
			}, []);
			/** One POST /dsh-market/groups round trip (create/rename/delete/members/toggle). */
			const doGroupAction = (0, react.useCallback)((payload) => {
				setInstallError(null);
				return fetch(api("/dsh-market/groups"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify(payload)
				}).then((res) => res.json().then((body) => ({
					status: res.status,
					body
				}))).then(({ status, body }) => {
					if (status === 200 && body.ok) {
						setGroupPayload(body);
						if (Array.isArray(body.restartMembers) && body.restartMembers.length > 0) setToggleRestart((n) => n + body.restartMembers.length);
						if (Array.isArray(body.refreshMembers) && body.refreshMembers.length > 0) setRefreshNames((names) => [.../* @__PURE__ */ new Set([...names, ...body.refreshMembers])]);
						refreshInstalled();
						return true;
					}
					const text = (v) => typeof v === "string" ? v : v == null ? "" : JSON.stringify(v);
					setInstallError(text(body.error) || t("toggleFail"));
					if (Array.isArray(body.restartMembers) && body.restartMembers.length > 0) setToggleRestart((n) => n + body.restartMembers.length);
					if (Array.isArray(body.refreshMembers) && body.refreshMembers.length > 0) setRefreshNames((names) => [.../* @__PURE__ */ new Set([...names, ...body.refreshMembers])]);
					return false;
				}).catch((error) => {
					setInstallError(String(error));
					return false;
				});
			}, [
				refreshInstalled,
				setGroupPayload,
				t
			]);
			/** Approve the build scripts pnpm refused, then rerun what was blocked. */
			const approveAndRetry = (0, react.useCallback)((names, resume) => {
				fetch(api("/dsh-market/approve-builds"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({ packages: names })
				}).then((res) => res.json()).then((body) => {
					if (!body.ok) setInstallError(String(body.error || "approve failed"));
					else resume();
				}).catch((error) => setInstallError(String(error)));
			}, []);
			const doGroupToggle = (0, react.useCallback)((name, enabled) => {
				return doGroupAction({
					action: "toggle",
					name,
					enabled
				});
			}, [doGroupAction]);
			const cancelCreateGroup = (0, react.useCallback)(() => {
				setCreatingGroup(false);
				setNewGroupName("");
			}, []);
			const doCreateGroup = (0, react.useCallback)(() => {
				const name = newGroupName.trim();
				if (name === "") return;
				doGroupAction({
					action: "create",
					name
				}).then((ok) => {
					if (ok) cancelCreateGroup();
				});
			}, [
				cancelCreateGroup,
				doGroupAction,
				newGroupName
			]);
			const doRenameGroup = (0, react.useCallback)((name) => {
				const newName = renamingValue.trim();
				if (newName === "" || newName === name) {
					setRenamingGroup(null);
					return;
				}
				doGroupAction({
					action: "rename",
					name,
					newName
				}).then((ok) => {
					if (ok) {
						setRenamingGroup(null);
						setRenamingValue("");
					}
				});
			}, [doGroupAction, renamingValue]);
			const doDeleteGroup = (0, react.useCallback)((name) => {
				doGroupAction({
					action: "delete",
					name
				}).then((ok) => {
					if (ok) setDeletingGroup(null);
				});
			}, [doGroupAction]);
			const doAssign = (0, react.useCallback)((name, group) => {
				if (group === "") return;
				const members = groups[group] ?? [];
				doGroupAction({
					action: "set-members",
					name: group,
					members: [...members, name]
				}).then((ok) => {
					if (ok) setAssignFor(null);
				});
			}, [doGroupAction, groups]);
			const doRemoveMember = (0, react.useCallback)((group, name) => {
				const members = (groups[group] ?? []).filter((member) => member !== name);
				doGroupAction({
					action: "set-members",
					name: group,
					members
				});
			}, [doGroupAction, groups]);
			/** Open the multi-select add-members dialog for a group. Plugins only. */
			const openAddPanel = (0, react.useCallback)((group) => {
				setRenamingGroup(null);
				setDeletingGroup(null);
				setGroupMenuFor(null);
				setThemePanel(null);
				setAddQuery("");
				setAddSelected([]);
				setAddPanel(group);
			}, []);
			/** Commit the current multi-select into the open group. */
			const doAddSelectedMembers = (0, react.useCallback)(() => {
				if (addPanel === null || addSelected.length === 0) return;
				const next = [...groups[addPanel] ?? []];
				for (const name of addSelected) if (!next.includes(name)) next.push(name);
				doGroupAction({
					action: "set-members",
					name: addPanel,
					members: next
				}).then((ok) => {
					if (ok) setAddPanel(null);
				});
			}, [
				addPanel,
				addSelected,
				doGroupAction,
				groups
			]);
			const toggleCollapsedGroup = (0, react.useCallback)((gid) => {
				setCollapsedGroups((prev) => {
					const next = new Set(prev);
					if (next.has(gid)) next.delete(gid);
					else next.add(gid);
					return next;
				});
			}, []);
			const selfName = installed["dshmarket"] !== void 0 ? "dshmarket" : "dsh-market";
			const updatableNames = Object.keys(installed).filter((name) => name !== selfName && !effectiveDisabledSet.has(name) && isPluginUpdatable(name, String(installed[name]), updates[name], updatedNames));
			const batchUpdatableNames = updatableNames.filter((name) => updates[name]?.restoreRequired !== true);
			const ignoredUpdateSet = (0, react.useMemo)(() => new Set(ignoredUpdateNames), [ignoredUpdateNames]);
			const quietUpdateSet = (0, react.useMemo)(() => /* @__PURE__ */ new Set([...ignoredUpdateNames, ...updateExemptNames]), [ignoredUpdateNames, updateExemptNames]);
			const reminderUpdatableNames = updatableNames.filter((name) => !quietUpdateSet.has(name) && !installedBlocked(name));
			const reminderBatchUpdatableNames = batchUpdatableNames.filter((name) => !quietUpdateSet.has(name) && !installedBlocked(name));
			const reminderUpdateNames = [...updates[selfName]?.updateAvailable === true && !updatedNames.includes(selfName) ? [selfName] : [], ...updatableNames].filter((name) => !quietUpdateSet.has(name) && !installedBlocked(name));
			/**
			* Installed packages that are not plugins at all: a plain library some
			* other plugin pulled in — zustand, bufferutil, a peer of ws (#634's
			* `dependencyOf`, #857). They were rendered as plugin cards with a
			* working uninstall, which is a real remove path for something a plugin
			* needs. Out of the list; the count stays visible in one quiet line, so the
			* list is not silently shorter than package.json.
			*/
			const dependencyOnlyNames = (0, react.useMemo)(() => new Set(Object.keys(installed).filter((name) => {
				const act = activations[name];
				return act?.state === "inert" && act.dependencyOf !== void 0;
			})), [installed, activations]);
			const installedOtherCount = Object.keys(installed).filter((name) => name !== selfName && !dependencyOnlyNames.has(name)).length;
			const ignoreUpdateNotices = (0, react.useCallback)((names) => {
				if (bootId === null || names.length === 0) return;
				setIgnoredUpdateNames((current) => {
					const next = [.../* @__PURE__ */ new Set([...current, ...names])];
					try {
						sessionStorage.setItem(IGNORED_UPDATES_SESSION_KEY, JSON.stringify({
							boot: bootId,
							names: next
						}));
					} catch {}
					return next;
				});
			}, [bootId]);
			const unignoreUpdateNotice = (0, react.useCallback)((name) => {
				if (bootId === null) return;
				setIgnoredUpdateNames((current) => {
					const next = current.filter((n) => n !== name);
					try {
						sessionStorage.setItem(IGNORED_UPDATES_SESSION_KEY, JSON.stringify({
							boot: bootId,
							names: next
						}));
					} catch {}
					return next;
				});
			}, [bootId]);
			const doUpdateAll = (0, react.useCallback)(() => {
				const names = reminderBatchUpdatableNames.map((name) => ({
					name,
					eligibleVersion: updates[name]?.eligibleVersion
				}));
				setUpdatingAll(true);
				const next = () => {
					const item = names.shift();
					if (item === void 0) {
						setUpdatingAll(false);
						refreshInstalled(true);
						return;
					}
					doUpdate(item.name, false, false, void 0, false, item.eligibleVersion).then(next, next);
				};
				next();
			}, [
				reminderBatchUpdatableNames,
				doUpdate,
				refreshInstalled,
				updates
			]);
			const finishRestore = (0, react.useCallback)((body) => {
				const errors = Array.isArray(body.errors) ? body.errors : [];
				const unportable = Array.isArray(body.unportable) ? body.unportable : [];
				const pinned = Array.isArray(body.pinned) ? body.pinned : [];
				const bootErrors = Array.isArray(body.bootErrors) ? body.bootErrors.map(String) : [];
				setRestoreErrors([
					...errors.map((item) => `${String(item.name)}: ${String(item.error)}`),
					...unportable.map((item) => `${String(item.name)}: ${t("restoreUnportable")} (${String(item.spec)})`),
					...pinned.map((item) => `${String(item.name)}: ${t("restoreSelfPinned")} (${String(item.from)} → ${String(item.to)})`),
					...bootErrors.map((line) => `${t("restoreBootError")} ${line}`)
				]);
				setBackupRestored(true);
				setBackupMessage(t("restoreDone"));
				if (errors.length === 0) {
					setPendingBackup(null);
					setPendingDependencies({});
				}
				refreshInstalled(true);
			}, [refreshInstalled, t]);
			const previewBackup = (0, react.useCallback)((backup) => {
				const dependencies = backupDependencies(backup);
				setPendingBackup(backup);
				setPendingDependencies(dependencies);
				setBackupMessage(t("restorePreviewDone"));
				setRestoreErrors([]);
				setTab("installed");
			}, [t]);
			/** Actually run the restore; the confirm dialog gates this (previously window.confirm). */
			const doRestore = (0, react.useCallback)(() => {
				if (pendingBackup === null) return Promise.resolve();
				setRestoreConfirmOpen(false);
				setBackupBusy(true);
				setBackupMessage(null);
				setRestoreErrors([]);
				return fetch(api("/dsh-market/restore"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({ backup: pendingBackup })
				}).then(async (response) => {
					const body = await response.json();
					if (!response.ok) throw new Error(String(body.error || "restore failed"));
					finishRestore(body);
				}).catch((error) => setBackupMessage(String(error))).finally(() => setBackupBusy(false));
			}, [finishRestore, pendingBackup]);
			const runWebdav = (0, react.useCallback)((action) => {
				if (webdavUrl.trim() === "" || webdavInFlight.current) return;
				webdavInFlight.current = true;
				setBackupBusy(true);
				setBackupMessage(null);
				setRestoreErrors([]);
				fetch(api("/dsh-market/webdav"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						action,
						url: webdavUrl.trim(),
						username: webdavUser,
						password: webdavPassword
					})
				}).then(async (response) => {
					const body = await response.json();
					if (!response.ok) throw new Error(String(body.error || "WebDAV failed"));
					if (action === "restore") previewBackup(body.backup);
					if (action === "backup") {
						try {
							localStorage.setItem("dshm-webdav-last", String(Date.now()));
						} catch {}
						setBackupMessage(t("backupDone"));
					}
				}).catch((error) => {
					const message = String(error);
					if (action === "backup" && webdavPassword === "" && /HTTP 401|401/u.test(message)) {
						setWebdavNeedsPassword(true);
						setBackupMessage(null);
						return;
					}
					setBackupMessage(message);
				}).finally(() => {
					webdavInFlight.current = false;
					setBackupBusy(false);
				});
			}, [
				previewBackup,
				t,
				webdavPassword,
				webdavUrl,
				webdavUser
			]);
			/** Map the server's token-source string to a localized label. */
			const gistSourceLabel = (source) => {
				if (source === "token") return t("gistSrcToken");
				if (source === "env") return t("gistSrcEnv");
				if (source === "gh") return t("gistSrcGh");
				return source;
			};
			/** Turn any failure (server error, network error, timeout) into a friendly message. */
			const gistErrorMessage = (error) => {
				const err = error;
				const name = typeof err?.name === "string" ? err.name : "";
				const code = typeof err?.code === "string" ? err.code : "";
				if (code === "timeout" || name === "TimeoutError" || name === "AbortError") return t("gistErrTimeout");
				if (code === "network") return t("gistErrNetwork");
				if (code === "auth") return t("gistErrAuth");
				if (code === "notfound") return t("gistErrNotFound");
				if (code === "rate-limit") return t("gistErrRateLimit");
				if (code === "invalid") return t("gistErrInvalid");
				if (error instanceof TypeError) return t("gistErrNetwork");
				return String(error);
			};
			const runGist = (0, react.useCallback)((action) => {
				setGistBusy(true);
				setGistMessage(null);
				setGistOk(false);
				setGistResult(null);
				setRestoreErrors([]);
				setExportError(null);
				const body = {
					action,
					token: gistToken.trim()
				};
				if (action === "import") body.gistId = gistId.trim();
				if (action === "export" && gistMode === "update") {
					if (gistId.trim() === "") {
						setGistBusy(false);
						setGistMessage(t("gistErrNoId"));
						setGistOk(false);
						return;
					}
					body.gistId = gistId.trim();
				}
				if (action === "export") {
					const allNames = /* @__PURE__ */ new Set([...Object.keys(installed), ...installedBundles]);
					if (!(exportSelection.size === allNames.size && exportSelection.size > 0)) {
						body.includeDeps = [...exportSelection];
						if (exportIncludeConfig) body.includeConfig = true;
					}
				}
				fetch(api("/dsh-market/gist"), {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify(body),
					signal: AbortSignal.timeout(3e4)
				}).then(async (response) => {
					let body = {};
					try {
						body = await response.json();
					} catch {}
					if (!response.ok) {
						const error = new Error(String(body.error || "Gist failed"));
						if (typeof body.code === "string") error.code = body.code;
						throw error;
					}
					if (action === "export") {
						setGistResult(body);
						const ref = body;
						if (typeof ref.gistId === "string" && ref.gistId !== "") {
							setGistId(ref.gistId);
							setGistMode("update");
							try {
								localStorage.setItem("dshm-gist-id", ref.gistId);
							} catch {}
						}
						setGistMessage(t("gistExportDone"));
						setGistOk(true);
						setExportOpen(false);
					} else if (action === "import") previewBackup(body.backup);
					else {
						const source = typeof body.source === "string" ? body.source : "";
						setGistMessage(t("gistVerifySource").replace("{0}", gistSourceLabel(source)));
						setGistOk(true);
					}
				}).catch((error) => {
					const message = gistErrorMessage(error);
					setGistMessage(message);
					setGistOk(false);
					if (action === "export") setExportError(message);
				}).finally(() => setGistBusy(false));
			}, [
				exportIncludeConfig,
				exportSelection,
				gistId,
				gistToken,
				installed,
				installedBundles,
				previewBackup,
				t
			]);
			/** The picker list: dependency plugins + bundle-only plugins, deduplicated. */
			const exportOptions = (0, react.useMemo)(() => {
				return [.../* @__PURE__ */ new Set([...Object.keys(installed), ...installedBundles])].sort();
			}, [installed, installedBundles]);
			/** Classify an install spec for the export picker badge. */
			const specKind = (spec) => {
				if (spec === void 0) return "bundle";
				if (/^file:/i.test(spec)) return "file";
				if (/^(github:|git\+|git:)/i.test(spec)) return "git";
				return "npm";
			};
			const openExportPicker = (0, react.useCallback)(() => {
				const names = /* @__PURE__ */ new Set([...Object.keys(installed), ...installedBundles]);
				setExportSelection(new Set(names));
				setExportIncludeConfig(false);
				setExportOpen(true);
			}, [installed, installedBundles]);
			const runWebdavRef = (0, react.useRef)(runWebdav);
			(0, react.useEffect)(() => {
				runWebdavRef.current = runWebdav;
			}, [runWebdav]);
			(0, react.useEffect)(() => {
				try {
					localStorage.setItem(WEBDAV_STORAGE_KEY, JSON.stringify({
						url: webdavUrl,
						username: webdavUser,
						auto: autoBackup
					}));
				} catch {}
			}, [
				autoBackup,
				webdavUrl,
				webdavUser
			]);
			(0, react.useEffect)(() => {
				if (!autoBackup) return;
				let last = 0;
				try {
					last = Number(localStorage.getItem("dshm-webdav-last")) || 0;
				} catch {}
				if (Date.now() - last >= 864e5) runWebdavRef.current("backup");
			}, [autoBackup]);
			const sessionPendingRestart = doneUrls.length + restartNames.length + removedCount + toggleRestart + (backupRestored ? 1 : 0);
			/**
			* Plugins the HOST reports as restart-pending, independent of what this
			* browser session happens to remember. Installing and then reloading the
			* page used to leave no restart affordance at all: the banner is built
			* from session state, while the Installed tab only says "activates on
			* restart" in passing — so the user was told a restart was needed and
			* given nothing to press. Dismissible, because a standing banner nobody
			* wants to act on right now is just noise (it returns next session, or
			* as soon as another change lands).
			*/
			const hostPendingNames = Object.keys(activations).filter((name) => activations[name]?.state === "restart");
			const showHostPending = hostPendingNames.length > 0 && !restartNoticeDismissed && sessionPendingRestart === 0;
			const pendingRestart = sessionPendingRestart > 0 ? sessionPendingRestart : showHostPending ? hostPendingNames.length : 0;
			const displayedInstalled = pendingBackup === null ? installed : {
				...pendingDependencies,
				...installed
			};
			/**
			* Installed entries ordered for the list view: enabled plugins first
			* (#745), then rows with a pending update, then manifest order — a stable
			* sort, so each of those groups keeps its own order.
			*
			* The order settles once and then holds, so rows never reshuffle under a
			* pointer that is already aiming at one (#631). Two moments are allowed to
			* move it. One is when the update check lands: `/installed` is a local read
			* and `/updates` is a network probe over every package, so the list is
			* always rendered BEFORE the answer exists — freezing on the view alone
			* would leave it in manifest order forever. `updatesLoaded` is therefore
			* the one part of `updates` allowed in, as a boolean: it flips once when
			* the result arrives, and every later change (a newer check, a row the user
			* just updated) leaves the boolean and the order alone. The other is the
			* disable set changing: when the snapshot first arrives, or when a switch
			* the user flipped settles — and in the switch case the toggled row is the
			* only one that crosses the enabled/disabled line, so every other row
			* stays where it was.
			*/
			const isInstalledListActive = tab === "installed" && installedView === "list";
			const updatesLoaded = Object.keys(updates).length > 0;
			const orderedInstalledEntries = (0, react.useMemo)(() => {
				return Object.entries(displayedInstalled).filter(([name]) => name !== selfName).filter(([name]) => !dependencyOnlyNames.has(name)).sort(([nameA, specA], [nameB, specB]) => {
					const aOn = effectiveDisabledSet.has(nameA) ? 0 : 1;
					const bOn = effectiveDisabledSet.has(nameB) ? 0 : 1;
					if (aOn !== bOn) return bOn - aOn;
					const aUp = isPluginUpdatable(nameA, String(specA), updates[nameA], updatedNames, quietUpdateSet) ? 1 : 0;
					return (isPluginUpdatable(nameB, String(specB), updates[nameB], updatedNames, quietUpdateSet) ? 1 : 0) - aUp;
				});
			}, [
				isInstalledListActive,
				displayedInstalled,
				selfName,
				updatesLoaded,
				effectiveDisabledSet,
				dependencyOnlyNames
			]);
			const missingRestoreCount = Object.keys(pendingDependencies).filter((name) => !installedFiles.includes(name)).length;
			const hasUpdates = reminderUpdatableNames.length > 0;
			/** Live status line: structured phase, or the human-line fallback. */
			const phasePart = progressPhase != null ? phaseLabel(progressPhase, t) + (progressCurrent !== null ? " · " + progressCurrent : "") + (progressDone > 0 ? " · " + t("packagesDone").replace("{0}", String(progressDone)) : "") : progressLine || t("progressHint");
			const progressText = cancelling ? t("cancelling") + " · " + phasePart : phasePart;
			/** Whether the catalog carries ANY theme-category entry at all — distinct
			* from `themePlugins.length === 0` above (which also fires the instant a
			* search/sort/time filter matches nothing) so the two empty states read
			* differently: "there's nothing here yet" vs "nothing matches your filter". */
			const anyThemePlugins = data === null ? [] : themePlugins(data.plugins);
			/** The catalog entry a deprecated plugin's `replacement` names, if any. */
			const replacementOf = (p) => p.deprecated === true && p.replacement !== void 0 ? data?.plugins.find((r) => r.name === p.replacement) : void 0;
			const renderFavoriteControl = (url) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)(FavoriteButton, {
				filled: favoriteUrlSet.has(url),
				label: favoriteUrlSet.has(url) ? t("favoriteRemove") : t("favoriteAdd"),
				onToggle: () => toggleFavorite(url)
			});
			const renderPluginMenu = (plugin, key = plugin.url) => {
				const aliases = blockAliases(plugin, matchInstalledName(plugin, installed, repoIdentities, data?.plugins, repoHints));
				const hidden = aliases.some((name) => blockedNameSet.has(name));
				return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
					open: pluginMenuUrl === key,
					onClose: () => setPluginMenuUrl(null),
					onSelect: (id) => {
						setPluginMenuUrl(null);
						if (id === "block") toggleBlock(blockToggleName(aliases));
					},
					align: "end",
					portal: true,
					anchor: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						className: Market_module_css_default.cardMore,
						"aria-label": t("groupMore"),
						"aria-expanded": pluginMenuUrl === key,
						onClick: () => setPluginMenuUrl((open) => open === key ? null : key),
						children: "···"
					}),
					items: [{
						id: "block",
						label: hidden ? t("blockRemove") : t("blockAdd")
					}]
				});
			};
			/**
			* What the group view says about an installed plugin beyond its name: the
			* user's own note, else the catalog's description (#1006). One place, so a
			* plugin reads the same whether it sits in a group or in "Ungrouped".
			*/
			const installedBlurb = (name) => {
				const entry = data === null ? void 0 : catalogEntryForInstalled(data.plugins, name, String(installed[name]), repoIdentities[name], repoHints[name]);
				const note = notes[name];
				const authored = entry?.description && (entry.description[lang] || entry.description.en) || "";
				return {
					entry,
					note,
					shown: note ?? authored
				};
			};
			const renderInstalledBlockMenu = (name) => {
				const hostPage = openInHost === void 0 ? null : () => {
					openInHost.openBundle(name);
				};
				const entry = data === null ? void 0 : catalogEntryForInstalled(data.plugins, name, String(installed[name] ?? ""), repoIdentities[name], repoHints[name]);
				const aliases = entry === void 0 ? [name] : blockAliases(entry, name);
				const hidden = aliases.some((alias) => blockedNameSet.has(alias));
				const favoriteUrl = entry?.url;
				const favorited = favoriteUrl !== void 0 && favoriteUrlSet.has(favoriteUrl);
				const removing = removingName === name;
				const uninstallBusy = removingName !== null || busyUrl !== null || updatingName !== null;
				const spec = String(installed[name] ?? "");
				const status = updates[name];
				const localDev = isLocalDev(spec, status);
				const exempt = updateExemptSet.has(name);
				const updatable = isPluginUpdatable(name, spec, status, updatedNames);
				const showExempt = !localDev || exempt || updatable;
				const showBootIgnore = bootId !== null && !exempt && !ignoredUpdateSet.has(name) && updatable;
				const showRestore = localDev && !(status?.updateAvailable === true && status.restoreRequired === true);
				return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
					open: installedMenuName === name,
					onClose: () => setInstalledMenuName(null),
					onSelect: (id) => {
						setInstalledMenuName(null);
						if (id === "restore-online" && data !== null && !uninstallBusy) askRestore(name);
						if (id === "favorite" && favoriteUrl !== void 0) toggleFavorite(favoriteUrl);
						if (id === "block") toggleBlock(blockToggleName(aliases));
						if (id === "update-exempt") toggleUpdateExempt(name);
						if (id === "ignore-boot") ignoreUpdateNotices([name]);
						if (id === "host-page") hostPage?.();
						if (id === "uninstall" && !uninstallBusy) setRemoveConfirm(name);
					},
					align: "end",
					portal: true,
					anchor: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						variant: "ghost",
						size: "sm",
						"aria-label": t("groupMore"),
						onClick: () => setInstalledMenuName((open) => open === name ? null : name),
						children: "···"
					}),
					items: [
						...showRestore ? [{
							id: "restore-online",
							label: t("restoreOnline"),
							disabled: data === null || uninstallBusy
						}] : [],
						...favoriteUrl === void 0 ? [] : [{
							id: "favorite",
							label: favorited ? t("favoriteRemove") : t("favoriteAdd")
						}],
						{
							id: "block",
							label: hidden ? t("blockRemove") : t("blockAdd")
						},
						...showBootIgnore ? [{
							id: "ignore-boot",
							label: t("ignoreUpdateNotice")
						}] : [],
						...hostPage === null ? [] : [{
							id: "host-page",
							label: t("openInHostPage")
						}],
						...showExempt ? [{
							id: "update-exempt",
							label: exempt ? t("updateExemptRemove") : t("updateExemptAdd")
						}] : [],
						{
							type: "separator",
							id: "uninstall-sep"
						},
						{
							id: "uninstall",
							label: removing ? t("uninstalling") : t("uninstall"),
							danger: true,
							disabled: uninstallBusy
						}
					]
				});
			};
			/**
			* Chip label for one capability name, or the scanner's own name.
			*
			* `network` has a label; a name this build has never seen (`dynamic-code`
			* arrived after the first integration) shows as itself rather than
			* disappearing — an unlabelled fact is still a fact, and a missing chip
			* would read as "does not do that".
			*/
			const capabilityLabel = (name) => {
				const key = "cap" + name.split("-").map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join("");
				const label = t(key);
				return label === key ? name : label;
			};
			/**
			* The scanner's red-line sentences, in the reader's language.
			*
			* The scanner emits a fixed set of shapes — one per rule family — and every
			* one of them is translated here. A sentence from a family this build does
			* not know stays in the scanner's own words on purpose: a mistranslation of
			* a security fact is worse than a foreign word, and this is the one line on
			* the card a reader must not misread. The shapes are matched by their stable
			* prefix rather than in full, so the parenthesised detail the scanner
			* attaches can change without falling back to English.
			*/
			const redLineLabel = (line) => {
				if (line === "reads credentials/secrets AND has network access") return t("capRedCredentialsNetwork");
				const plaintext = /^uses plaintext http:\/\/ to (.+)$/.exec(line);
				if (plaintext !== null) return t("capRedPlaintextHttp").replace("{0}", plaintext[1]);
				const literalIp = /^uses literal IP (.+) for network access$/.exec(line);
				if (literalIp !== null) return t("capRedLiteralIp").replace("{0}", literalIp[1]);
				const installScript = /^runs code at install time(?: \((.+)\))?$/.exec(line);
				if (installScript !== null) return installScript[1] === void 0 ? t("capRedInstallScript") : t("capRedInstallScriptScripts").replace("{0}", installScript[1]);
				const coreVerb = /^tampers with a core bundle \((overrides|disables) bundle (.+)\)$/.exec(line);
				if (coreVerb !== null) {
					const key = coreVerb[1] === "overrides" ? "capRedCoreOverride" : "capRedCoreDisable";
					return t(key).replace("{0}", coreVerb[2]);
				}
				const coreTamper = /^tampers with a core bundle(?: \((.+)\))?$/.exec(line);
				if (coreTamper !== null) return coreTamper[1] === void 0 ? t("capRedCoreTamper") : t("capRedCoreTamperDetail").replace("{0}", coreTamper[1]);
				return line;
			};
			/**
			* What the static scan found (#401), in the detail dialog and nowhere else.
			*
			* It used to sit on both cards. It does not any more, for three reasons that
			* all pointed the same way: a capability list does not help anyone choose a
			* plugin, most of it cannot be acted on, and — the one that decided it — a
			* line every card carries is a line nobody reads, including the install-time
			* script that IS worth stopping for. So the card says nothing about this, the
			* dialog leads with the one thing that needs a decision before you press
			* install, and the rest of the facts are one click away.
			*
			* Which lines count as that one thing is `redLineIsUrgent`: a rare rule that
			* fires at install time, drawn above everything else. `aheadFacts` follow
			* as plain sentences in body ink. The closed fold holds every capability,
			* grouped by what it touches, with the uncommon ones filled and counted in
			* the fold's title as a frequency, plus the address red lines. The
			* blind-spot sentence sits under the fold whenever a scan ran, so a dialog
			* with nothing in front is not read as a clean scan. A plugin never scanned
			* gets the fold's frame with nothing to open and no blind-spot sentence:
			* the state is seen without a click, and there is no scan to qualify.
			* Nothing here scores, bands, or colours a plugin safe.
			*/
			const capabilityDetail = (p) => {
				const redLines = p.capabilityRedLines ?? [];
				const ahead = aheadFacts(p);
				const addresses = redLines.filter(redLineNamesAddress);
				const names = p.capabilities ?? [];
				const uncommon = names.filter((name) => UNCOMMON_CAPABILITIES.has(name)).length;
				const meta = names.length === 0 ? void 0 : uncommon === 0 ? t("capabilityCount").replace("{0}", String(names.length)) : t("capabilityCountUncommon").replace("{0}", String(names.length)).replace("{1}", String(uncommon));
				const chip = (name) => {
					const className = UNCOMMON_CAPABILITIES.has(name) ? `${Market_module_css_default.capChip} ${Market_module_css_default.capChipUncommon}` : Market_module_css_default.capChip;
					return HostTag !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(HostTag, {
						tone: "outline",
						className,
						children: capabilityLabel(name)
					}, name) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className,
						children: capabilityLabel(name)
					}, name);
				};
				const checkedAt = typeof p.capabilityCheckedAt === "string" && p.capabilityCheckedAt.length > 0 ? p.capabilityCheckedAt.slice(0, 10) : null;
				if (p.capabilities === void 0 && redLines.length === 0) return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
					className: Market_module_css_default.confirmPanel,
					"data-state": "unchecked",
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: `${Market_module_css_default.confirmPanelRow} ${Market_module_css_default.confirmPanelRowStatic}`,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.confirmPanelIcon,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ConfirmCapabilityIcon, {})
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.confirmPanelTitle,
								children: t("capabilityTitle")
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.confirmPanelMeta,
								children: t("capabilityUnchecked")
							})
						]
					})
				});
				return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
					redLines.filter(redLineIsUrgent).map((line) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
						className: Market_module_css_default.warnLine,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
							size: 14,
							className: Market_module_css_default.bannerIcon
						}), " " + redLineLabel(line)]
					}, line)),
					ahead.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.capAhead,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							className: Market_module_css_default.capAheadLabel,
							children: t("capabilityAhead")
						}), ahead.map((fact) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
							className: Market_module_css_default.capAheadRow,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(AheadMark, { fact }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: fact === "dynamic-code" ? capabilityLabel(fact) : redLineLabel(fact) })]
						}, fact))]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)(ConfirmFold, {
						icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ConfirmCapabilityIcon, {}),
						title: t("capabilityTitle"),
						meta,
						open: capsOpen,
						onToggle: () => setCapsOpen((o) => !o),
						children: [
							addresses.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.caps,
								children: addresses.map((line) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.capAddress,
									children: redLineLabel(line)
								}, line))
							}),
							p.capabilities === void 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.caps,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.capMuted,
									"data-state": "unchecked",
									children: t("capabilityUnchecked")
								})
							}) : p.capabilities.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.caps,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.capMuted,
									"data-state": "none",
									children: t("capabilityNone")
								})
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.capGroups,
								children: groupCapabilities(p.capabilities).map(([key, members]) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.capGroupLabel,
									children: t(key)
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.caps,
									children: members.map((name) => chip(name))
								})] }, key))
							}),
							(uncommon > 0 || checkedAt !== null) && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
								className: Market_module_css_default.capCaveat,
								children: [uncommon > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.capCaveatNote,
									children: t("capabilityUncommonLegend")
								}), checkedAt !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.capCaveatAt,
									children: t("capabilityScannedAt").replace("{0}", checkedAt)
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: Market_module_css_default.capNote,
						children: t("capabilityNote")
					})
				] });
			};
			/**
			* The enable/disable control, wherever it appears — the installed row, a
			* group member row, the plugin detail view. One helper because they were
			* three copies of the same markup, and because the host has this component:
			* its own plugin list uses `Switch`, so the market's rows should look like
			* the list they sit in. Before 0.1.7-rc.2 the market's own switch renders,
			* with the same `role="switch"` contract either way.
			*/
			const onOffSwitch = (opts) => HostSwitch !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(HostSwitch, {
				checked: opts.on,
				onChange: () => opts.toggle(),
				label: opts.label,
				disabled: opts.disabled
			}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
				type: "button",
				role: "switch",
				"aria-checked": opts.on,
				"aria-label": opts.label,
				className: opts.on ? `${Market_module_css_default.switch} ${Market_module_css_default.switchOn}` : Market_module_css_default.switch,
				disabled: opts.disabled,
				onClick: opts.toggle,
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.switchKnob })
			});
			/**
			* A labelled checkbox: the host's when it has one, the market's label+input
			* otherwise. Only the simple ones go through here — see `HostCheckbox` for
			* why the export rows and the recovery panel keep their own markup.
			*/
			const labelledCheckbox = (opts) => HostCheckbox !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(HostCheckbox, {
				checked: opts.checked,
				onChange: opts.onChange,
				label: opts.label,
				disabled: opts.disabled,
				className: opts.className
			}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
				className: opts.className,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: opts.checked,
					disabled: opts.disabled,
					onChange: (event) => opts.onChange(event.target.checked)
				}), opts.label]
			});
			const pluginTitleNode = (p, children = pluginName(p.name, p.npm), nativeTitle = false) => offline || marketOffline() ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: Market_module_css_default.nm,
				title: p.name,
				children
			}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
				className: `${Market_module_css_default.nm} ${Market_module_css_default.nmLink}`,
				href: p.url,
				target: "_blank",
				rel: "noreferrer",
				...nativeTitle ? { title: p.name } : {},
				"aria-label": `${p.name} — ${t("repoLink")}`,
				children
			});
			const installAction = (p) => {
				const done = doneUrls.includes(p.url) || hotUrls.includes(p.url);
				const already = isInstalled(p, catalogInstalled, repoIdentities, data?.plugins, repoHints);
				const busy = busyUrl === p.url;
				const record = recordForUrl(records, p.url);
				const blocked = record !== null && (record.state === "input" || record.state === "failed");
				const queued = record !== null && record.state === "queued";
				return done ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: Market_module_css_default.okState,
					children: t("installedBadge")
				}) : already ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
					className: Market_module_css_default.okState,
					children: t("alreadyInstalled")
				}) : busy ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "outline",
					size: "sm",
					className: Market_module_css_default.installBtn,
					disabled: true,
					children: t("installing")
				}) : queued ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
					type: "button",
					className: Market_module_css_default.cardBlockedMark,
					onClick: openOperations,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 13 }), t(record?.hostOperationId !== void 0 && (record.blockedBy?.length ?? 0) > 0 ? "agentDrainBadge" : "queuedBadge")]
				}) : blocked ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
					type: "button",
					className: Market_module_css_default.cardBlockedMark,
					onClick: openOperations,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 13 }), t("opBlockedCard")]
				}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "outline",
					size: "sm",
					className: Market_module_css_default.installBtn,
					disabled: busyUrl !== null || !envReady,
					onClick: () => setConfirming(p),
					children: t("install")
				});
			};
			const recentTile = (p) => {
				const desc = p.description && (p.description[lang] || p.description.en) || "";
				const record = recordForUrl(records, p.url);
				const blocked = record !== null && (record.state === "input" || record.state === "failed");
				return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: blocked ? `${Market_module_css_default.recentTile} ${Market_module_css_default.cardBlocked}` : Market_module_css_default.recentTile,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.recentTitle,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(OwnerAvatar, {
								name: p.name,
								owner: p.owner || "",
								icon: p.icon ?? void 0,
								className: Market_module_css_default.recentAv
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.recentName,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
									label: p.name,
									side: "bottom",
									maxWidth: 320,
									delayMs: HOVER_TIP_DELAY_MS,
									children: pluginTitleNode(p)
								})
							}),
							installAction(p)
						]
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.recentBottom,
						children: [desc !== "" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
							label: desc,
							side: "bottom",
							maxWidth: 320,
							delayMs: HOVER_TIP_DELAY_MS,
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: Market_module_css_default.recentDesc,
								tabIndex: 0,
								children: desc
							})
						}), renderPluginMenu(p, `recent:${p.url}`)]
					})]
				}, p.url);
			};
			const pluginCard = (p, menuKey = p.url) => {
				const desc = p.description && (p.description[lang] || p.description.en) || "";
				const busy = busyUrl === p.url;
				const replacement = replacementOf(p);
				const record = recordForUrl(records, p.url);
				const blocked = record !== null && (record.state === "input" || record.state === "failed");
				const compatibilityKey = hostCompatibilityKey(p);
				const compatibility = compatibilityKey === null ? void 0 : hostCompatibility[compatibilityKey];
				const hostRequirementLabel = compatibility?.requirement !== null && compatibility?.requirement !== void 0 ? t("hostRequirement").replace("{0}", compatibility.requirement) : compatibilityKey === null ? t("hostRequirementUnavailable") : compatibility === void 0 ? t("hostRequirementLoading") : compatibility.basis === "undeclared" ? t("hostRequirementUndeclared") : t("hostRequirementUnavailable");
				const hostRequirementTitle = compatibility?.declarations.map((declaration) => declaration.kind === "engine" ? `engines.dsh: ${declaration.range}` : `${declaration.package ?? "peer"}: ${declaration.range}`).join("\n") || hostRequirementLabel;
				return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: blocked ? `${Market_module_css_default.card} ${Market_module_css_default.cardBlocked}` : Market_module_css_default.card,
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.row1,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									style: { minWidth: 0 },
									children: [pluginTitleNode(p, /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
										pluginName(p.name, p.npm),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(GithubRepoMark, { className: Market_module_css_default.repoMark }),
										p.deprecated === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.depBadge,
											children: t("deprecatedBadge")
										})
									] }), true), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: Market_module_css_default.byline,
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)(OwnerAvatar, {
												name: p.name,
												owner: p.owner || "",
												icon: p.icon ?? void 0
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
												className: Market_module_css_default.owner,
												title: p.owner,
												children: p.owner
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)(CatalogVersionMark, {
												version: p.version,
												tip: catalogVersionTip
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)(DownloadCount, {
												plugin: p,
												t
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)(StarCount, {
												plugin: p,
												t
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.cardAction,
									children: installAction(p)
								})
							]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(CardDesc, {
							text: desc,
							t
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(CardShot, {
							plugin: p,
							onOpen: openLightbox
						}),
						p.deprecated === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.deprecate,
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.depLine,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: ["⚠️ ", t("deprecatedWarn")] }), replacement !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
									className: Market_module_css_default.src,
									href: replacement.url,
									target: "_blank",
									rel: "noreferrer",
									children: t("replacementHint") + " " + replacement.name
								})]
							})
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.foot,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.footTags,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: compatibility?.status === "incompatible" ? `${Market_module_css_default.hostRequirement} ${Market_module_css_default.hostRequirementBad}` : Market_module_css_default.hostRequirement,
									"data-status": compatibility?.status ?? "unknown",
									title: (compatibility?.status === "compatible" || compatibility?.status === "incompatible" ? t(compatibility.status === "compatible" ? "hostStatusCompatible" : "hostStatusIncompatible") + "\n" : "") + hostRequirementTitle,
									children: hostRequirementLabel
								}), pluginCategories(p).map((category) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.tag,
									children: data.categories[category] && (data.categories[category][lang] || data.categories[category].en) || category
								}, category))]
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.footActions,
								children: [
									renderFavoriteControl(p.url),
									!marketOffline() && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										type: "button",
										className: Market_module_css_default.commentsLink,
										onClick: () => setCommentsFor(p),
										children: t("comments")
									}),
									renderPluginMenu(p, menuKey)
								]
							})]
						}),
						busy && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.progress,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.spin,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLoadingOutline16, { size: 14 })
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
									className: Market_module_css_default.grow,
									children: progressText
								}),
								progressPct !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
									className: Market_module_css_default.pct,
									children: [progressPct, "%"]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									disabled: cancelling,
									onClick: () => doCancel(),
									children: cancelling ? t("cancelling") : t("cancelOp")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.bar,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: progressPct !== null ? Market_module_css_default.barFill : `${Market_module_css_default.barFill} ${Market_module_css_default.barWave}`,
										style: progressPct !== null ? { width: `${progressPct}%` } : void 0
									})
								})
							]
						})
					]
				}, p.url);
			};
			const installedNameOf = (p) => matchInstalledName(p, installed, repoIdentities, data?.plugins, repoHints);
			const bootEntries = typeof window !== "undefined" && window.__DSH_BOOT__ && Array.isArray(window.__DSH_BOOT__.entries) ? window.__DSH_BOOT__.entries : [];
			const themePluginCard = (p) => {
				const instName = installedNameOf(p);
				const desc = p.description && (p.description[lang] || p.description.en) || "";
				const replacement = replacementOf(p);
				const done = doneUrls.includes(p.url) || hotUrls.includes(p.url);
				const busy = busyUrl === p.url;
				const record = recordForUrl(records, p.url);
				const blocked = record !== null && (record.state === "input" || record.state === "failed");
				const themeQueued = record !== null && record.state === "queued";
				const mounted = instName !== null && (skins.includes(instName) || bootEntries.some((e) => e.id === instName)) && !effectiveDisabledSet.has(instName);
				return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
					className: blocked ? `${Market_module_css_default.themeCard} ${Market_module_css_default.cardBlocked}` : Market_module_css_default.themeCard,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(ThemeCover, {
						plugin: p,
						onOpen: openLightbox,
						t
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.themeCardBody,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.themeCardHead,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: Market_module_css_default.themeIdentity,
										children: [pluginTitleNode(p, /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [pluginName(p.name, p.npm), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(GithubRepoMark, { className: Market_module_css_default.repoMark })] }), true), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.byline,
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(OwnerAvatar, {
													name: p.name,
													owner: p.owner || "",
													icon: p.icon ?? void 0
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: Market_module_css_default.owner,
													title: p.owner,
													children: p.owner
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(CatalogVersionMark, {
													version: p.version,
													tip: catalogVersionTip
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(DownloadCount, {
													plugin: p,
													t
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(StarCount, {
													plugin: p,
													t
												})
											]
										})]
									}),
									p.deprecated === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.depBadge,
										children: t("deprecatedBadge")
									}),
									mounted && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.themeStatus,
										children: t("themeActive")
									}),
									instName !== null && !mounted && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.themeStatusMuted,
										children: effectiveDisabledSet.has(instName) ? t("disabledState") : t("alreadyInstalled")
									})
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: Market_module_css_default.themeDescription,
								title: desc,
								children: desc
							}),
							p.deprecated === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.deprecate,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.depLine,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: ["⚠️ ", t("deprecatedWarn")] }), replacement !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
										className: Market_module_css_default.src,
										href: replacement.url,
										target: "_blank",
										rel: "noreferrer",
										children: t("replacementHint") + " " + replacement.name
									})]
								})
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.themeCardFooter,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.footActions,
										children: [renderFavoriteControl(p.url), renderPluginMenu(p)]
									}),
									instName === null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.themeLifecycle,
										children: done ? t("installedBadge") : t("notInstalled")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.themeActions,
										children: instName === null ? done ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.okState,
											children: t("installedBadge")
										}) : busy ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "outline",
											size: "sm",
											className: Market_module_css_default.installBtn,
											disabled: true,
											children: t("installing")
										}) : themeQueued ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
											type: "button",
											className: Market_module_css_default.cardBlockedMark,
											onClick: openOperations,
											children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 13 }), t(record?.hostOperationId !== void 0 && (record.blockedBy?.length ?? 0) > 0 ? "agentDrainBadge" : "queuedBadge")]
										}) : blocked ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
											type: "button",
											className: Market_module_css_default.cardBlockedMark,
											onClick: openOperations,
											children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 13 }), t("opBlockedCard")]
										}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "outline",
											size: "sm",
											className: Market_module_css_default.installBtn,
											disabled: busyUrl !== null || !envReady,
											onClick: () => setConfirming(p),
											children: t("install")
										}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [removingName === instName ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "outline",
											size: "sm",
											disabled: true,
											children: t("uninstalling")
										}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "ghost",
											size: "sm",
											onClick: () => setRemoveConfirm(instName),
											children: t("uninstall")
										}), mounted ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "outline",
											size: "sm",
											disabled: togglingName !== null,
											onClick: () => doToggle(instName, false, true),
											children: t("themeDeactivate")
										}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "primary",
											size: "sm",
											onClick: () => doUseSkin(instName),
											children: t("themeApply")
										})] })
									})
								]
							}),
							busy && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.progress,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spin,
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLoadingOutline16, { size: 14 })
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
										className: Market_module_css_default.grow,
										children: progressText
									}),
									progressPct !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.pct,
										children: [progressPct, "%"]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "outline",
										size: "sm",
										disabled: cancelling,
										onClick: () => doCancel(),
										children: cancelling ? t("cancelling") : t("cancelOp")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.bar,
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
											className: progressPct !== null ? Market_module_css_default.barFill : `${Market_module_css_default.barFill} ${Market_module_css_default.barWave}`,
											style: progressPct !== null ? { width: `${progressPct}%` } : void 0
										})
									})
								]
							})
						]
					})]
				}, p.url);
			};
			const themeCard = (id, label, swatch) => {
				const active = themeSnap !== null && themeSnap.preference === id;
				return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: Market_module_css_default.card,
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.swatches,
						children: swatch.map((c, i) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("i", { style: { background: c } }, i))
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.foot,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.nm,
								children: label
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow }),
							active ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.okState,
								children: t("themeActive")
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "outline",
								size: "sm",
								onClick: () => {
									try {
										props.theme.setTheme(id);
									} catch (error) {
										setInstallError(String(error));
									}
								},
								children: t("themeApply")
							})
						]
					})]
				}, "th-" + id);
			};
			const categories = data === null ? [] : Object.keys(data.categories);
			(0, react.useLayoutEffect)(() => {
				setVisibleCats(null);
			}, [lang, categories.length]);
			(0, react.useLayoutEffect)(() => {
				const el = catsWrapRef.current;
				if (el === null || typeof ResizeObserver === "undefined") return;
				let width = el.clientWidth;
				const observer = new ResizeObserver((entries) => {
					const next = entries[0]?.contentRect.width ?? el.clientWidth;
					if (next < 80 || Math.abs(next - width) < 8) return;
					width = next;
					setVisibleCats(null);
				});
				observer.observe(el);
				return () => observer.disconnect();
			}, [data]);
			(0, react.useLayoutEffect)(() => {
				if (visibleCats !== null) return;
				const el = catsWrapRef.current;
				if (el === null) return;
				const chips = [...el.children].filter((c) => c.dataset?.chip === "1");
				if (chips.length === 0) return;
				const first = chips[0];
				const rowTwoTop = first.offsetTop + first.offsetHeight + 6 - 3;
				let fits = 0;
				for (const chip of chips) if (chip.offsetTop < rowTwoTop) fits += 1;
				setVisibleCats(Math.max(1, fits));
			}, [visibleCats, data]);
			(0, react.useEffect)(() => {
				if (surface === "plugins" || catsSentinel === null || typeof IntersectionObserver === "undefined") return;
				const observer = new IntersectionObserver(([entry]) => {
					const leftView = entry !== void 0 && !entry.isIntersecting;
					const root = bodyRef.current;
					const wrap = catsWrapRef.current;
					if (leftView && root !== null && wrap !== null) {
						if (root.scrollHeight - root.clientHeight <= wrap.offsetHeight) return;
					}
					setCatsStuck((prev) => prev === leftView ? prev : leftView);
				}, {
					root: bodyRef.current,
					threshold: 0
				});
				observer.observe(catsSentinel);
				return () => observer.disconnect();
			}, [catsSentinel, surface]);
			(0, react.useEffect)(() => {
				if (!catsStuck) setStuckExpanded(false);
			}, [catsStuck]);
			/** Expanded chips + chevron share one value. Stuck uses `stuckExpanded`
			* so pinning collapses without rewriting `catsOpen` in a layout effect
			* (see stuckExpanded state). Leaving stuck falls back to `catsOpen`,
			* which still holds the pre-pin / in-pin user choice. */
			const catsExpanded = catsStuck ? stuckExpanded : catsOpen;
			/**
			* The collapsed row must be exactly one row.
			*
			* Whatever the measuring pass predicts, the answer is only right once the
			* chips are painted with the host's real font — an early pass measures
			* narrower pills and lands one too many, which wraps the last one onto a
			* second row. So: after a collapsed render, look at what actually happened
			* and step the budget down until the row holds. A layout effect, so the
			* correction lands before paint and the user never sees the two-row state.
			*/
			(0, react.useLayoutEffect)(() => {
				const el = catsWrapRef.current;
				if (el === null || visibleCats === null || catsExpanded) return;
				const chips = [...el.children].filter((c) => c.dataset?.chip === "1");
				if (chips.length < 2) return;
				const top = Math.round(chips[0].getBoundingClientRect().top);
				if (chips.every((chip) => Math.round(chip.getBoundingClientRect().top) === top)) return;
				setVisibleCats(Math.max(1, chips.length - 1));
			}, [
				visibleCats,
				catsExpanded,
				catsStuck
			]);
			/**
			* A fresh install (hotUrls/hotNames) and a toggle/group action
			* (refreshNames) both end in the same place — "reload the page" — and
			* used to render as two near-identical banners stacked on top of each
			* other when both happened in one session (reported as "为啥有三个状态横幅
			* 啊，太奇怪了"). They're merged into one count and one banner; only the
			* restart banner (a full host restart, a different action entirely) stays
			* separate.
			*/
			const pendingRefreshNames = (0, react.useMemo)(() => [.../* @__PURE__ */ new Set([...hotNames, ...refreshNames])], [hotNames, refreshNames]);
			/** Installed plugins the market itself cannot group (#60). */
			const groupableNames = Object.keys(installed).filter((name) => name !== "dsh-market" && name !== "dshmarket" && !dependencyOnlyNames.has(name));
			/** Names already inside some group; everything else shows under "ungrouped". */
			const groupedNames = (0, react.useMemo)(() => new Set(Object.values(groups).flat()), [groups]);
			const ungroupedNames = groupableNames.filter((name) => !groupedNames.has(name));
			const groupQuery = qInstalled.trim().toLowerCase();
			const matchesInstalledQuery = (0, react.useCallback)((name) => {
				if (groupQuery === "") return true;
				if (name.toLowerCase().includes(groupQuery)) return true;
				const note = notes[name];
				if (note !== void 0 && note.toLowerCase().includes(groupQuery)) return true;
				const spec = installed[name];
				if (spec !== void 0 && String(spec).toLowerCase().includes(groupQuery)) return true;
				if (data !== null && spec !== void 0) {
					const entry = catalogEntryForInstalled(data.plugins, name, String(spec), repoIdentities[name], repoHints[name]);
					if ((entry?.description && (entry.description[lang] || entry.description.en) || "").toLowerCase().includes(groupQuery)) return true;
				}
				return false;
			}, [
				data,
				groupQuery,
				installed,
				lang,
				notes,
				repoHints,
				repoIdentities
			]);
			const visibleUngrouped = ungroupedNames.filter(matchesInstalledQuery);
			const visibleGroupIds = groupOrder.filter((gid) => {
				if (groupQuery === "") return true;
				if (gid.toLowerCase().includes(groupQuery)) return true;
				return (groups[gid] ?? []).some(matchesInstalledQuery);
			});
			/** Installed package names the catalog classifies as themes (client-side
			* mirror of the server's classification; themes are exclusive per group). */
			const installedThemeNames = (0, react.useMemo)(() => {
				const names = /* @__PURE__ */ new Set();
				if (data === null) return names;
				for (const [name, spec] of Object.entries(installed)) {
					const entry = catalogEntryForInstalled(data.plugins, name, String(spec), repoIdentities[name], repoHints[name]);
					if (entry !== void 0 && pluginCategories(entry).includes("theme")) names.add(name);
				}
				return names;
			}, [
				data,
				installed,
				repoIdentities,
				repoHints
			]);
			const openThemePanel = (0, react.useCallback)((group) => {
				const current = (groups[group] ?? []).find((name) => installedThemeNames.has(name)) ?? null;
				setAddPanel(null);
				setRenamingGroup(null);
				setDeletingGroup(null);
				setGroupMenuFor(null);
				setThemePick(current);
				setThemePanel(group);
			}, [groups, installedThemeNames]);
			/** Set or clear the single theme slot. The previous theme leaves this group. */
			const applyGroupTheme = (0, react.useCallback)((group, themeName) => {
				const without = (groups[group] ?? []).filter((name) => !installedThemeNames.has(name));
				const next = themeName === null ? without : [...without, themeName];
				doGroupAction({
					action: "set-members",
					name: group,
					members: next
				}).then((ok) => {
					if (ok) setThemePanel(null);
				});
			}, [
				doGroupAction,
				groups,
				installedThemeNames
			]);
			const batchActions = /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
				(() => {
					const self = installed["dshmarket"] !== void 0 ? "dshmarket" : "dsh-market";
					const status = updates[self];
					return status && status.updateAvailable && !updatedNames.includes(self) && !quietUpdateSet.has(self) && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						variant: "primary",
						size: "sm",
						disabled: updatingName !== null || busyUrl !== null,
						onClick: () => {
							setTab("installed");
							if (status.restoreRequired === true) askRestore(self);
							else doUpdate(self);
						},
						children: updatingName === self ? t("updating") : status.restoreRequired === true ? t("restoreOnline") : t("marketUpdate")
					});
				})(),
				reminderBatchUpdatableNames.length >= 1 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "primary",
					size: "sm",
					disabled: updatingAll || updatingName !== null || busyUrl !== null || removingName !== null,
					onClick: () => {
						setTab("installed");
						doUpdateAll();
					},
					children: updatingAll ? t("updating") : t("updateAll") + " (" + reminderBatchUpdatableNames.length + ")"
				}),
				bootId !== null && reminderUpdateNames.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => ignoreUpdateNotices(reminderUpdateNames),
					children: t("ignoreAllUpdateNotices")
				})
			] });
			const exportLogButton = /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "ghost",
				size: "sm",
				className: Market_module_css_default.exportLogBtn,
				icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconDownloadOutline16, { size: 14 }),
				disabled: exportState === "busy",
				onClick: doExportLog,
				children: exportState === "busy" ? t("exportingLog") : t("exportLog")
			});
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				ref: rootRef,
				className: `${Market_module_css_default.root} notranslate`,
				"data-dsh-market-root": true,
				"data-dsh-market-plugins-tab": surface === "plugins" ? "true" : void 0,
				translate: "no",
				"data-dsh-market-tab": tab,
				"data-dsh-market-fullscreen": tab === "themes" && themesFullscreen ? "true" : void 0,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						ref: headRef,
						className: Market_module_css_default.head,
						children: [
							surface !== "plugins" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.headTop,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.titleRow,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(MarketLogo, {
											size: 18,
											ambient: true,
											style: { flexShrink: 0 }
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h2", {
											className: Market_module_css_default.title,
											children: t("nav")
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
											className: Market_module_css_default.sub,
											children: t("subtitle")
										})
									]
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.titleActions,
									children: [
										offline ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.version,
											title: t("offlineHint"),
											children: t("offlineBadge")
										}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
												className: Market_module_css_default.repoLink,
												href: "https://github.com/dsh-market/dsh-market",
												target: "_blank",
												rel: "noreferrer",
												title: "dsh-market · GitHub",
												children: "dsh-market"
											}),
											version !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
												className: Market_module_css_default.version,
												title: t("versionHint"),
												children: ["v", version]
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
												className: Market_module_css_default.submitLink,
												href: "https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/blob/main/contributing.md",
												target: "_blank",
												rel: "noreferrer",
												children: t("submitPlugin")
											})
										] }),
										exportLogButton,
										batchActions
									]
								})]
							}),
							showSidebarTip && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.sidebarTip,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("sidebarTip") }),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										size: "sm",
										variant: "outline",
										disabled: sidebarTipSaving,
										onClick: enableSidebar,
										children: t("setSidebarOn")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										size: "sm",
										variant: "ghost",
										disabled: sidebarTipSaving,
										onClick: () => {
											writeSidebarTipDismissed();
											setSidebarTipDismissed(true);
										},
										children: t("sidebarTipDismiss")
									}),
									sidebarTipError !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: sidebarTipError })
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.tabs,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										className: tab === "discover" ? `${Market_module_css_default.tab} ${Market_module_css_default.on}` : Market_module_css_default.tab,
										onClick: () => setTab("discover"),
										children: t("tabDiscover")
									}),
									themeSnap !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										className: tab === "themes" ? `${Market_module_css_default.tab} ${Market_module_css_default.on}` : Market_module_css_default.tab,
										onClick: () => setTab("themes"),
										children: t("tabThemes")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										className: tab === "favorites" ? `${Market_module_css_default.tab} ${Market_module_css_default.on}` : Market_module_css_default.tab,
										onClick: () => setTab("favorites"),
										children: t("tabFavorites") + (favoriteTabCount > 0 ? " (" + favoriteTabCount + ")" : "")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
										className: tab === "installed" ? `${Market_module_css_default.tab} ${Market_module_css_default.on}` : Market_module_css_default.tab,
										onClick: () => {
											setTab("installed");
											refreshInstalled(true);
										},
										children: [t("tabInstalled") + (installedOtherCount > 0 ? " (" + installedOtherCount + ")" : ""), hasUpdates && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
											state: "error",
											size: 7,
											className: Market_module_css_default.dot
										})]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										className: tab === "blocked" ? `${Market_module_css_default.tab} ${Market_module_css_default.on}` : Market_module_css_default.tab,
										onClick: () => setTab("blocked"),
										children: t("tabBlocked") + (blockedNames.length > 0 ? " (" + blockedNames.length + ")" : "")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										className: tab === "backup" || tab === "diagnostics" ? `${Market_module_css_default.tab} ${Market_module_css_default.on}` : Market_module_css_default.tab,
										onClick: () => {
											if (tab !== "backup" && tab !== "diagnostics") setTab("backup");
										},
										children: t("tabAdvanced")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow }),
									surface === "plugins" && batchActions,
									surface === "plugins" && exportLogButton,
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(OperationsPanel, {
										t,
										lang,
										describe: describePlugin,
										records,
										open: operationsOpen,
										onOpenChange: setOperationsOpen,
										replacing,
										envReady,
										onClearSettled: () => {
											for (const record of recordsRef.current) if (record.hostOperationId !== void 0 && (record.state === "done" || record.state === "warned" || record.state === "failed")) dismissedHostRef.current.add(record.hostOperationId);
											setRecords((list) => clearSettled(list));
										},
										onCancel: (record) => doCancel(record),
										onDismiss: (record) => {
											if (record.hostOperationId !== void 0) dismissedHostRef.current.add(record.hostOperationId);
											setRecords((list) => drop(list, record.id));
										},
										onRefresh: () => location.reload(),
										onResolveConflict: resolveConflict,
										onForceInstall: (record) => {
											const plugin = record.url === void 0 ? void 0 : data?.plugins.find((p) => p.url === record.url);
											if (plugin === void 0) return;
											setRecords((list) => drop(list, record.id));
											doInstall(plugin, true);
										},
										onRunNow: runQueuedNow,
										onApproveBuilds: (record) => {
											const names = record.blockedBuilds ?? [];
											if (names.length === 0) return;
											setRecords((list) => drop(list, record.id));
											const plugin = record.url === void 0 ? void 0 : data?.plugins.find((p) => p.url === record.url);
											approveAndRetry(names, () => {
												if (plugin !== void 0) doInstall(plugin);
												else doUpdate(record.name, record.updateOptions?.force, record.updateOptions?.restore, record.updateOptions?.compatVersion, false, record.updateOptions?.eligibleVersion);
											});
										}
									})
								]
							}),
							(tab === "backup" || tab === "diagnostics") && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.subTabs,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										className: tab === "backup" ? `${Market_module_css_default.tab} ${Market_module_css_default.on}` : Market_module_css_default.tab,
										onClick: () => setTab("backup"),
										children: t("tabBackup")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										className: tab === "diagnostics" ? `${Market_module_css_default.tab} ${Market_module_css_default.on}` : Market_module_css_default.tab,
										onClick: () => setTab("diagnostics"),
										children: t("tabDiagnostics")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow })
								]
							}),
							!envReady && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.banner,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconCordisPluginOutline14, {
										size: 14,
										className: Market_module_css_default.bannerIcon
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.grow,
										children: envFailed ? t("envFixFail") : t("envMissing")
									}),
									!envFailed && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "primary",
										size: "sm",
										disabled: envFixing,
										onClick: fixEnv,
										children: envFixing ? t("envFixing") : t("envFix")
									})
								]
							}),
							backupMessage !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.backupMessage,
								children: backupMessage
							}),
							restoreErrors.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.banner,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
									size: 14,
									className: Market_module_css_default.bannerIcon
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
									className: Market_module_css_default.grow,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: t("restorePartial") }) }), restoreErrors.map((error) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.spec,
										children: error
									}, error))]
								})]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(HostRecoveryBanner, {
								t,
								bootId
							}),
							tab === "installed" && pendingBackup !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.banner,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconRefreshOutline14, {
										size: 14,
										className: Market_module_css_default.bannerIcon
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.grow,
										children: t("restoreMissing").replace("{0}", String(missingRestoreCount))
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "primary",
										size: "sm",
										disabled: backupBusy,
										onClick: () => setRestoreConfirmOpen(true),
										children: backupBusy ? t("backupWorking") : t("restoreStart")
									})
								]
							}),
							pendingRefreshNames.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.banner,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconSparkle16, {
										size: 14,
										className: Market_module_css_default.bannerIcon
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.grow,
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: pendingRefreshNames.length }),
											" ",
											t("refreshBanner")
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "primary",
										size: "sm",
										onClick: () => {
											if (hotNames.length > 0) sessionStorage.setItem("dshm-toast", JSON.stringify(hotNames));
											sessionStorage.setItem("dshm-tab", "installed");
											location.reload();
										},
										children: t("refresh")
									})
								]
							}),
							pendingRestart > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.banner,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconRefreshOutline14, {
										size: 14,
										className: Market_module_css_default.bannerIcon
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
										className: Market_module_css_default.grow,
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: pendingRestart }),
											" ",
											t("restartBanner")
										]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
										label: t(restartHintKey({
											debuggerLatch,
											restartReachable,
											supervisor
										})).replace("{0}", supervisor ?? ""),
										side: "bottom",
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.bannerHint,
											children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconQuestionOutline14, { size: 14 })
										})
									}),
									restartEnabled && restartReachable && debuggerLatch === null && recovery === null && !marketGone && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "primary",
										size: "sm",
										disabled: restarting || hostBusy || busyUrl !== null || updatingName !== null || removingName !== null,
										onClick: doRestart,
										children: restarting ? t("restarting") : t("restartNow")
									}),
									showHostPending && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "ghost",
										size: "sm",
										"aria-label": t("dismissNotice"),
										onClick: () => {
											setRestartNoticeDismissed(true);
											try {
												sessionStorage.setItem("dshm-restart-dismissed", String(bootId ?? ""));
											} catch {}
										},
										children: t("dismiss")
									})
								]
							}),
							activationWarnings.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.banner,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
									size: 14,
									className: Market_module_css_default.bannerIcon
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.grow,
									children: activationWarnings.map(({ name, info }) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: name }),
										" — ",
										activationMeta(info.state, t, info.dependencyOf, info.loadedByProfile, info.library).label,
										info.reasons.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
											className: Market_module_css_default.spec,
											children: [
												"（",
												localizeBilingualList(info.reasons, lang),
												"）"
											]
										})
									] }, name))
								})]
							}),
							tab === "installed" && configNamespaceIssues.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.banner,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
									size: 14,
									className: Market_module_css_default.bannerIcon
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.grow,
									children: configNamespaceIssues.map((finding) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { children: t("configNamespaceNotice").replace("{0}", finding.name).replace("{1}", finding.namespaces.join("、")).replace("{2}", finding.ownEntryIds.join("、") || "—") }, finding.name))
								})]
							}),
							tab === "installed" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(HostDependencyDiagnostics, {
								findings: hostDependencyFindings,
								t
							}),
							tab === "installed" && brokenPluginNames.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.brokenPluginNotice,
								children: [brokenPluginNames.map((name) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.brokenPluginItem,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.brokenPluginText,
											children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: t(brokenPlugins[name]?.reason === "incomplete-build-cancelled" ? "brokenPluginTitleCancelled" : "brokenPluginTitle").replace("{0}", name) }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t(brokenPlugins[name]?.reason === "incomplete-build-cancelled" ? "brokenPluginBodyCancelled" : "brokenPluginBody") })]
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "outline",
											size: "sm",
											onClick: () => {
												setCat("all");
												setQ(name);
												setTab("discover");
											},
											children: t("brokenPluginAction")
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "ghost",
											size: "sm",
											disabled: dismissingBroken.has(name),
											onClick: () => dismissBrokenPlugin(name),
											children: t("brokenPluginDismiss")
										})
									]
								}, name)), dismissBrokenError !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.brokenPluginItem,
									role: "alert",
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.brokenPluginText,
										children: dismissBrokenError
									})
								})]
							})
						]
					}),
					buildsSkipped !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.banner,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, {
								size: 14,
								className: Market_module_css_default.bannerIcon
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.grow,
								children: [
									t("buildsSkipped"),
									" ",
									buildsSkipped.names.join(", ")
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								size: "sm",
								disabled: busyUrl !== null,
								onClick: () => {
									const { plugin, updateName, names, updateOptions } = buildsSkipped;
									setBuildsSkipped(null);
									approveAndRetry(names, () => {
										if (plugin !== void 0) doInstall(plugin);
										else if (updateName !== void 0) doUpdate(updateName, updateOptions?.force, updateOptions?.restore, updateOptions?.compatVersion, false, updateOptions?.eligibleVersion);
									});
								},
								children: t("approveBuilds")
							})
						]
					}),
					compatibilityNotice !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.banner,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: Market_module_css_default.grow,
								children: [
									compatibilityNotice.risks.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: t(compatibilityNotice.rollbackId === void 0 ? "compatRiskBannerNoRollback" : "compatRiskBanner") }),
										" ",
										compatibilitySummary(compatibilityNotice.risks)
									] }),
									compatibilityNotice.shadowedNames !== void 0 && compatibilityNotice.shadowedNames.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
										compatibilityNotice.risks.length > 0 && " · ",
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: t("shadowNameBanner") }),
										" ",
										shadowSummary(compatibilityNotice.shadowedNames)
									] }),
									compatibilityNotice.brokenBundles !== void 0 && compatibilityNotice.brokenBundles.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
										(compatibilityNotice.risks.length > 0 || (compatibilityNotice.shadowedNames?.length ?? 0) > 0) && " · ",
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: t("brokenBundleBanner") }),
										" ",
										compatibilityNotice.brokenBundles.map((entry) => entry.name).join(", ")
									] })
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setTab("diagnostics"),
								children: t("goDiagnose")
							}),
							compatibilityNotice.risks.length === 0 && (compatibilityNotice.brokenBundles?.length ?? 0) === 0 ? null : compatibilityNotice.rollbackId === void 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: compatibilityNotice.rollbackUnavailable ? localizeBilingual(compatibilityNotice.rollbackUnavailable, lang) : t("rollbackUnavailable") }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "primary",
								size: "sm",
								disabled: rollingBack,
								onClick: () => void doRollback(compatibilityNotice.rollbackId),
								children: rollingBack ? t("rollingBack") : t("rollbackNow")
							})
						]
					}),
					installError !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: Market_module_css_default.err,
						children: [localizeBilingual(installError, lang), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.staleAction,
							children: [
								recovery !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "primary",
									size: "sm",
									onClick: () => setRecoveryOpen(true),
									children: t("recoveryOption")
								}),
								staleName !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "primary",
									size: "sm",
									onClick: () => doUpdate(staleName, true),
									children: t("updateNow")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									size: "sm",
									variant: "outline",
									icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconDownloadOutline16, { size: 14 }),
									disabled: exportState === "busy",
									onClick: doExportLog,
									children: exportState === "busy" ? t("exportingLog") : t("exportLog")
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: Market_module_css_default.body,
						ref: bodyRef,
						onScroll: surface === "plugins" && !themesFullscreen ? void 0 : (e) => {
							const show = e.currentTarget.scrollTop > 400;
							setShowTop((prev) => prev === show ? prev : show);
							setPluginMenuUrl(null);
							setInstalledMenuName(null);
							setGroupMenuFor(null);
							setAssignFor(null);
						},
						children: marketGone ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.empty,
							role: "alert",
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("b", { children: t("marketGoneTitle") }) }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.spec,
									children: t("marketGoneBody")
								}),
								reconnecting ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.spec,
									children: t("marketGoneReconnecting")
								}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setReconnectRound((round) => round + 1),
									children: t("marketGoneReconnect")
								}) })
							]
						}) : tab === "backup" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.backupGrid,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
									className: Market_module_css_default.backupCard,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", { children: t("backupLocal") }),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("backupHint") }),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
											className: Market_module_css_default.backupWarn,
											children: t("credsWarning")
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.backupActions,
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
													variant: "primary",
													size: "sm",
													icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconDownloadOutline16, { size: 14 }),
													disabled: backupBusy,
													onClick: () => downloadFile(api("/dsh-market/backup"), "dsh-profile-backup.json", t("backupExportFailed") + "："),
													children: backupBusy ? t("backupWorking") : t("backupDownload")
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
													variant: "outline",
													size: "sm",
													icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconFolderOpen16, { size: 14 }),
													disabled: backupBusy,
													onClick: () => fileInputRef.current?.click(),
													children: backupBusy ? t("backupWorking") : t("backupImport")
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
													ref: fileInputRef,
													type: "file",
													accept: "application/json,.json",
													className: Market_module_css_default.hiddenFile,
													tabIndex: -1,
													"aria-hidden": "true",
													disabled: backupBusy,
													onChange: (event) => {
														const file = event.currentTarget.files?.[0];
														event.currentTarget.value = "";
														if (file !== void 0) file.text().then((text) => previewBackup(JSON.parse(text))).catch((error) => setBackupMessage(String(error)));
													}
												})
											]
										})
									]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
									className: Market_module_css_default.backupCard,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", { children: t("webdav") }),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
											open: presetOpen,
											onClose: () => setPresetOpen(false),
											onSelect: (id) => {
												const urls = {
													jianguoyun: "https://dav.jianguoyun.com/dav/dsh-profile-backup.json",
													koofr: "https://app.koofr.net/dav/Koofr/dsh-profile-backup.json",
													nextcloud: "https://nextcloud.example/remote.php/dav/files/USERNAME/dsh-profile-backup.json"
												};
												if (urls[id] !== void 0) setWebdavUrl(urls[id]);
											},
											align: "start",
											anchor: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 }),
												onClick: () => setPresetOpen((o) => !o),
												children: t("webdavPreset")
											}),
											items: [
												{
													id: "custom",
													label: t("webdavPreset")
												},
												{
													id: "jianguoyun",
													label: "坚果云 / Nutstore"
												},
												{
													id: "koofr",
													label: "Koofr"
												},
												{
													id: "nextcloud",
													label: "Nextcloud"
												}
											]
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
											className: Market_module_css_default.backupInput,
											icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLinkOutline14, { size: 14 }),
											type: "url",
											value: webdavUrl,
											placeholder: t("webdavUrl"),
											onChange: (e) => setWebdavUrl(e.target.value)
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("webdavPathHint") }),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
											className: Market_module_css_default.backupInput,
											autoComplete: "username",
											value: webdavUser,
											placeholder: t("webdavUser"),
											onChange: (e) => setWebdavUser(e.target.value)
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
											className: Market_module_css_default.backupInput,
											type: "password",
											autoComplete: "current-password",
											value: webdavPassword,
											placeholder: t("webdavPassword"),
											onChange: (e) => {
												setWebdavPassword(e.target.value);
												if (e.target.value !== "") setWebdavNeedsPassword(false);
											}
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.backupActions,
											children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "primary",
												size: "sm",
												disabled: backupBusy || webdavUrl.trim() === "",
												onClick: () => runWebdav("backup"),
												children: backupBusy ? t("backupWorking") : t("webdavUpload")
											}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
												variant: "outline",
												size: "sm",
												disabled: backupBusy || webdavUrl.trim() === "",
												onClick: () => runWebdav("restore"),
												children: t("webdavRestore")
											})]
										}),
										labelledCheckbox({
											label: t("autoBackup"),
											checked: autoBackup,
											className: Market_module_css_default.backupCheck,
											onChange: setAutoBackup
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("webdavNote") }),
										webdavNeedsPassword && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
											className: Market_module_css_default.backupWarn,
											children: t("webdavAutoBackupPaused")
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
											className: Market_module_css_default.backupWarn,
											children: t("credsWarning")
										})
									]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
									className: Market_module_css_default.backupCard,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", { children: t("gist") }),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
											className: Market_module_css_default.backupInput,
											type: "password",
											autoComplete: "off",
											value: gistToken,
											placeholder: t("gistToken"),
											onChange: (e) => setGistToken(e.target.value)
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
											className: Market_module_css_default.backupInput,
											icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLinkOutline14, { size: 14 }),
											value: gistId,
											placeholder: t("gistId"),
											onChange: (e) => setGistId(e.target.value)
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.backupActions,
											children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
												className: Market_module_css_default.backupCheck,
												children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
													type: "radio",
													name: "gist-mode",
													checked: gistMode === "update",
													onChange: () => setGistMode("update")
												}), t("gistModeUpdate")]
											}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
												className: Market_module_css_default.backupCheck,
												children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
													type: "radio",
													name: "gist-mode",
													checked: gistMode === "create",
													onChange: () => setGistMode("create")
												}), t("gistModeCreate")]
											})]
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.backupActions,
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
													variant: "outline",
													size: "sm",
													disabled: gistBusy,
													onClick: () => runGist("verify"),
													children: gistBusy ? t("backupWorking") : t("gistVerify")
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
													variant: "primary",
													size: "sm",
													disabled: gistBusy || gistMode === "update" && gistId.trim() === "",
													onClick: openExportPicker,
													children: gistBusy ? t("backupWorking") : t("gistExport")
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
													variant: "outline",
													size: "sm",
													disabled: gistBusy || gistId.trim() === "",
													onClick: () => runGist("import"),
													children: t("gistImport")
												})
											]
										}),
										gistResult !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
											className: Market_module_css_default.backupCheck,
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("gistCreated") }),
												" ",
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
													className: Market_module_css_default.src,
													href: gistResult.gistUrl,
													target: "_blank",
													rel: "noreferrer",
													children: gistResult.gistUrl
												})
											]
										}),
										gistMessage !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
											className: gistOk ? Market_module_css_default.backupMessage : Market_module_css_default.backupWarn,
											children: gistMessage
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("gistNote") })
									]
								})
							]
						}) : tab === "discover" ? loadError !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.empty,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { children: t("loadFail") }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.err,
									children: loadError
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									className: Market_module_css_default.retryBtn,
									onClick: () => {
										loadCatalog();
									},
									children: t("loadRetry")
								})
							]
						}) : data === null ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.loading,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.logoMark,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(MarketLogo, {
									size: 26,
									animated: true
								})
							}), t("loading")]
						}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", { ref: setCatsSentinel }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.stickyHead,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.tabSearchRow,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(SearchInput, {
										resetToken: discoverSearchReset,
										className: Market_module_css_default.tabSearch,
										placeholder: t("searchPh"),
										value: q,
										onCommit: setQ,
										t
									}, "discover"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(FilterMenu, {
										sortField,
										sortDir,
										timeRange,
										hostVersion,
										compatibleWithHost,
										onSortField: setSortField,
										onSortDir: setSortDir,
										onTimeRange: setTimeRange,
										onCompatibleWithHost: setCompatibleWithHost,
										t
									})]
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.cats,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: Market_module_css_default.catsRow,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
											ref: catsWrapRef,
											className: visibleCats === null && !catsExpanded ? `${Market_module_css_default.catsWrap} ${Market_module_css_default.catsCollapsed}` : Market_module_css_default.catsWrap,
											children: (() => {
												const budget = visibleCats;
												const ordered = orderedCategories(categories, cat, catsExpanded, budget);
												const shown = catsExpanded ? ordered : budget === null ? ordered : ordered.slice(0, Math.max(0, budget - 1));
												return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Pill, {
													"data-chip": "1",
													active: cat === "all",
													onClick: () => setCat("all"),
													children: t("all") + " (" + formatCount(data.count) + ")"
												}), shown.map((id) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Pill, {
													"data-chip": "1",
													active: cat === id,
													onClick: () => setCat(id),
													children: data.categories[id] && (data.categories[id][lang] || data.categories[id].en) || id
												}, id))] });
											})()
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "ghost",
											size: "sm",
											className: Market_module_css_default.catsToggle,
											icon: catsExpanded ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 }),
											"aria-label": catsExpanded ? t("catsLess") : t("catsMore"),
											onClick: () => {
												const next = !catsExpanded;
												if (catsStuck) setStuckExpanded(next);
												setCatsOpen(next);
											}
										})]
									}), compatibleWithHost && typeof hostVersion === "string" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.hostFilterNote,
										children: hostCompatibilityPending > 0 || loadedHostPackages < allHostPackages.length ? t("hostFilterLoading").replace("{0}", String(loadedHostPackages)).replace("{1}", String(allHostPackages.length)) : t("hostFilterActive").replace("{0}", hostVersion).replace("{1}", String(hostHiddenCount))
									})]
								})]
							}),
							hasRecent && (recentHidden ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
								type: "button",
								className: Market_module_css_default.recentShow,
								onClick: showRecent,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronRightOutline14, { size: 14 }), t("recentShow")]
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
								className: Market_module_css_default.recentBlock,
								"aria-labelledby": "dshm-recently-added",
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.recentHead,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", {
										id: "dshm-recently-added",
										className: Market_module_css_default.favoritesSectionHead,
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
											type: "button",
											className: Market_module_css_default.recentToggle,
											"aria-expanded": !recentCollapsed,
											"aria-controls": "dshm-recent-grid",
											onClick: toggleRecentCollapsed,
											children: [recentCollapsed ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronRightOutline14, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 }), t("recentlyAdded")]
										})
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "ghost",
										size: "sm",
										className: Market_module_css_default.recentHide,
										onClick: hideRecent,
										children: t("recentHide")
									})]
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									id: "dshm-recent-grid",
									className: recentCollapsed ? `${Market_module_css_default.recentRow} ${Market_module_css_default.recentCollapsed}` : Market_module_css_default.recentRow,
									children: recentPlugins.map((plugin) => recentTile(plugin))
								})]
							})),
							plugins.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(EmptyResults, {
								blocked: pluginsAll.length > hostHiddenCount,
								t,
								onClear: data.plugins.length > 0 && (q !== "" || cat !== "all" || timeRange !== "all" || compatibleWithHost) ? () => {
									setQ("");
									resetDiscoverSearch((value) => value + 1);
									setCat("all");
									setTimeRange("all");
									setCompatibleWithHost(false);
									bodyRef.current?.querySelector("input")?.focus();
								} : void 0
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Masonry, {
								items: pagePlugins,
								render: (plugin) => pluginCard(plugin)
							}), surface === "plugins" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(LoadMore, {
								more: discoverMore.more,
								onLoad: discoverMore.loadMore,
								t
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(Pager, {
								currentPage,
								totalPages,
								pageSize,
								onGoToPage: goToPage,
								onChangePageSize: changePageSize,
								t
							})] })
						] }) : tab === "favorites" ? data === null ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.loading,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.logoMark,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(MarketLogo, {
									size: 26,
									animated: true
								})
							}), t("loading")]
						}) : favoriteUrls.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.empty,
							children: t("favoritesEmpty")
						}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.themeToolbar,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(SearchInput, {
								className: Market_module_css_default.themeSearch,
								placeholder: t("searchFavoritesPh"),
								value: qFavorites,
								onCommit: setQFavorites,
								t
							}, "favorites"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.themeToolbarActions,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(FilterMenu, {
									sortField: favSortField,
									sortDir: favSortDir,
									timeRange: favTimeRange,
									onSortField: setFavSortField,
									onSortDir: setFavSortDir,
									onTimeRange: setFavTimeRange,
									t
								})
							})]
						}), favoriteListed.length === 0 ? favoritesAllStale ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.favoritesStaleOnly,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.empty,
								children: t("favoritesStaleEmpty")
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "outline",
								size: "sm",
								disabled: clearingStale,
								onClick: () => clearStaleFavorites(),
								children: clearingStale ? t("favoritesClearingStale") : t("favoritesClearStale")
							})]
						}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.empty,
							children: t("empty")
						}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
							favoriteStale.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.favoritesStaleBar,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("favoritesStaleNote").replace("{0}", String(favoriteStale.length)) }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									disabled: clearingStale,
									onClick: () => clearStaleFavorites(),
									children: clearingStale ? t("favoritesClearingStale") : t("favoritesClearStale")
								})]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.themeResultBar,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("favoritesResultCount").replace("{0}", String(favoriteListed.length)) })
							}),
							favoritePlugins.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", {
									className: Market_module_css_default.favoritesSectionHead,
									children: t("favoritesPluginsSection").replace("{0}", String(favoritePlugins.length))
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Masonry, {
									items: favoritePagePlugins,
									render: (plugin) => pluginCard(plugin)
								}),
								surface === "plugins" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(LoadMore, {
									more: favoritePluginMore.more,
									onLoad: favoritePluginMore.loadMore,
									t
								}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(Pager, {
									currentPage: favoritePluginPagination.currentPage,
									totalPages: favoritePluginPagination.totalPages,
									pageSize: favoritePluginPagination.pageSize,
									onGoToPage: favoritePluginPagination.goToPage,
									onChangePageSize: favoritePluginPagination.changePageSize,
									t
								})
							] }),
							favoriteThemes.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", {
									className: Market_module_css_default.favoritesSectionHead,
									children: t("favoritesThemesSection").replace("{0}", String(favoriteThemes.length))
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.themeGallery,
									children: favoritePageThemes.map(themePluginCard)
								}),
								surface === "plugins" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(LoadMore, {
									more: favoriteThemeMore.more,
									onLoad: favoriteThemeMore.loadMore,
									t
								}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(Pager, {
									currentPage: favoriteThemePagination.currentPage,
									totalPages: favoriteThemePagination.totalPages,
									pageSize: favoriteThemePagination.pageSize,
									onGoToPage: favoriteThemePagination.goToPage,
									onChangePageSize: favoriteThemePagination.changePageSize,
									t
								})
							] })
						] })] }) : tab === "themes" && themeSnap !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.themeToolbar,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(SearchInput, {
									resetToken: themeSearchReset,
									className: Market_module_css_default.themeSearch,
									placeholder: t("searchPh"),
									value: qThemes,
									onCommit: setQThemes,
									t
								}, "themes"), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.themeToolbarActions,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(FilterMenu, {
										sortField: themeSortField,
										sortDir: themeSortDir,
										timeRange: themeTimeRange,
										onSortField: setThemeSortField,
										onSortDir: setThemeSortDir,
										onTimeRange: setThemeTimeRange,
										t
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
										label: themesFullscreen ? t("themeExitFullscreen") : t("themeFullscreen"),
										side: "top",
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "outline",
											size: "sm",
											className: Market_module_css_default.themeFullscreenBtn,
											icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconFullscreenOutline16, { size: 16 }),
											"aria-label": themesFullscreen ? t("themeExitFullscreen") : t("themeFullscreen"),
											"aria-pressed": themesFullscreen,
											onClick: () => setThemesFullscreen((value) => !value)
										})
									})]
								})]
							}),
							(() => {
								const extra = themeSnap.themes.filter((def) => def.id !== "light" && def.id !== "dark");
								return extra.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: `${Market_module_css_default.grid} ${Market_module_css_default.themesGrid}`,
									children: extra.map((def) => themeCard(def.id, def.id, themeSwatch(def)))
								});
							})(),
							data === null ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.loading,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.logoMark,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(MarketLogo, {
										size: 26,
										animated: true
									})
								}), t("loading")]
							}) : anyThemePlugins.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.empty,
								children: t("themeEmpty")
							}) : themePlugins$1.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(EmptyResults, {
								blocked: themePluginsAll.length > 0,
								t,
								onClear: qThemes !== "" || themeTimeRange !== "all" ? () => {
									setQThemes("");
									resetThemeSearch((value) => value + 1);
									setThemeTimeRange("all");
									bodyRef.current?.querySelector("input")?.focus();
								} : void 0
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.themeResultBar,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("themeResultCount").replace("{0}", String(themePlugins$1.length)) })
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.themeGallery,
									children: themePagePlugins.map(themePluginCard)
								}),
								surface === "plugins" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(LoadMore, {
									more: themeMore.more,
									onLoad: themeMore.loadMore,
									t
								}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(Pager, {
									currentPage: themePagination.currentPage,
									totalPages: themePagination.totalPages,
									pageSize: themePagination.pageSize,
									onGoToPage: themePagination.goToPage,
									onChangePageSize: themePagination.changePageSize,
									t
								})
							] })
						] }) : tab === "diagnostics" ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(Diagnostics, { t }) : tab === "blocked" ? data === null ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.loading,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: Market_module_css_default.logoMark,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(MarketLogo, {
									size: 26,
									animated: true
								})
							}), t("loading")]
						}) : blockedNames.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
							className: Market_module_css_default.empty,
							children: t("blockedEmpty")
						}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.blockedTabHint,
								children: t("blockedTabHint")
							}),
							blockedPlugins.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(Masonry, {
								items: blockedPlugins,
								render: (plugin) => pluginCard(plugin)
							}),
							blockedMissing.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.blockedMissing,
								children: blockedMissing.map((name) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.blockedBarRow,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.blockedBarName,
										title: name,
										children: name
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										type: "button",
										className: Market_module_css_default.blockedBarUndo,
										onClick: () => toggleBlock(name),
										children: t("blockRemove")
									})]
								}, name))
							})
						] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.viewBar,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									type: "button",
									className: installedView === "list" ? `${Market_module_css_default.viewBtn} ${Market_module_css_default.viewOn}` : Market_module_css_default.viewBtn,
									onClick: () => setInstalledView("list"),
									children: t("tabList")
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									type: "button",
									className: installedView === "groups" ? `${Market_module_css_default.viewBtn} ${Market_module_css_default.viewOn}` : Market_module_css_default.viewBtn,
									onClick: () => setInstalledView("groups"),
									children: t("tabGroups")
								})]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.tabSearchRow,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(SearchInput, {
									resetToken: installedSearchReset,
									className: Market_module_css_default.tabSearch,
									placeholder: t("searchPh"),
									value: qInstalled,
									onCommit: setQInstalled,
									t
								}, "installed"), installedView === "groups" && (creatingGroup ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.groupCreateInline,
									onBlur: (event) => {
										const next = event.relatedTarget;
										if (next instanceof Node && event.currentTarget.contains(next)) return;
										cancelCreateGroup();
									},
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
											className: Market_module_css_default.inlineInput,
											placeholder: t("groupNamePh"),
											value: newGroupName,
											onChange: (e) => setNewGroupName(e.target.value),
											onKeyDown: (e) => {
												if (e.key === "Enter") doCreateGroup();
												if (e.key === "Escape") cancelCreateGroup();
											},
											autoFocus: true
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "primary",
											size: "sm",
											onClick: doCreateGroup,
											children: t("groupCreate")
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "ghost",
											size: "sm",
											onClick: cancelCreateGroup,
											children: t("cancel")
										})
									]
								}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setCreatingGroup(true),
									children: t("groupNew")
								}))]
							}),
							installedView === "groups" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
								groupQuery === "" && groupOrder.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.empty,
									children: t("noGroups")
								}) : visibleGroupIds.map((gid) => {
									const members = groups[gid] ?? [];
									const nameHit = groupQuery !== "" && gid.toLowerCase().includes(groupQuery);
									const visibleMembers = (groupQuery === "" || nameHit ? members : members.filter(matchesInstalledQuery)).slice().sort((a, b) => Number(installedThemeNames.has(b)) - Number(installedThemeNames.has(a)));
									const themeSlot = visibleMembers.some((name) => installedThemeNames.has(name)) && visibleMembers.some((name) => !installedThemeNames.has(name));
									if (groupQuery !== "" && !nameHit && visibleMembers.length === 0) return null;
									const switchableMembers = members.filter((member) => activations[member]?.library !== true);
									const sw = groupSwitchState(switchableMembers, effectiveDisabledSet);
									const enabledCount = switchableMembers.filter((member) => !effectiveDisabledSet.has(member)).length;
									const collapsed = groupQuery === "" && collapsedGroups.has(gid);
									const meta = t("groupMembersMeta").replace("{0}", String(members.length)).replace("{1}", String(enabledCount));
									return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: Market_module_css_default.groupRow,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.groupHead,
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
													type: "button",
													className: Market_module_css_default.groupCollapse,
													"aria-expanded": !collapsed,
													"aria-label": (collapsed ? t("groupExpand") : t("groupFold")).replace("{0}", gid),
													onClick: () => toggleCollapsedGroup(gid),
													children: collapsed ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronRightOutline14, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 })
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
													type: "button",
													role: "switch",
													"aria-checked": sw === "on" ? true : sw === "off" ? false : "mixed",
													"aria-label": (sw !== "on" ? t("enable") : t("disable")) + " " + gid,
													className: sw === "on" ? `${Market_module_css_default.switch} ${Market_module_css_default.switchOn}` : sw === "mixed" ? `${Market_module_css_default.switch} ${Market_module_css_default.switchMixed}` : Market_module_css_default.switch,
													disabled: togglingName !== null || sw === "empty",
													onClick: () => doGroupToggle(gid, sw !== "on"),
													children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.switchKnob })
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: Market_module_css_default.groupTitle,
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.groupName,
															children: gid
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.groupMeta,
															children: meta
														}),
														sw === "mixed" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.groupHint,
															children: t("groupMixed")
														})
													]
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: Market_module_css_default.groupActions,
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "outline",
															size: "sm",
															onClick: () => openThemePanel(gid),
															children: members.some((member) => installedThemeNames.has(member)) ? t("groupChangeTheme") : t("groupPickTheme")
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "outline",
															size: "sm",
															onClick: () => openAddPanel(gid),
															children: t("groupAdd")
														}),
														deletingGroup === gid ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "primary",
															size: "sm",
															className: Market_module_css_default.dangerArmed,
															onClick: () => doDeleteGroup(gid),
															children: t("groupConfirmDelete")
														}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "ghost",
															size: "sm",
															onClick: () => setDeletingGroup(null),
															children: t("cancel")
														})] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
															open: groupMenuFor === gid,
															onClose: () => setGroupMenuFor(null),
															onSelect: (id) => {
																setGroupMenuFor(null);
																if (id === "rename") {
																	setAddPanel(null);
																	setDeletingGroup(null);
																	setRenamingGroup(gid);
																	setRenamingValue(gid);
																} else if (id === "delete") {
																	setAddPanel(null);
																	setRenamingGroup(null);
																	setDeletingGroup(gid);
																}
															},
															align: "end",
															portal: true,
															anchor: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
																variant: "ghost",
																size: "sm",
																"aria-label": t("groupMore"),
																onClick: () => setGroupMenuFor((open) => open === gid ? null : gid),
																children: "···"
															}),
															items: [{
																id: "rename",
																label: t("groupRename")
															}, {
																id: "delete",
																label: t("groupDelete")
															}]
														})
													]
												})
											]
										}), !collapsed && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.groupMembers,
											children: [members.length === 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
												className: Market_module_css_default.groupHint,
												children: t("groupEmpty")
											}), visibleMembers.map((member) => {
												const { note, shown } = installedBlurb(member);
												return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: installedThemeNames.has(member) && themeSlot ? `${Market_module_css_default.groupMember} ${Market_module_css_default.themeSlot}` : Market_module_css_default.groupMember,
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
															className: shown !== "" ? `${Market_module_css_default.memberName} ${Market_module_css_default.memberNameWithDesc}` : Market_module_css_default.memberName,
															children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																className: Market_module_css_default.nm,
																children: member
															}), installedThemeNames.has(member) && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
																className: Market_module_css_default.memberKind,
																children: ["· ", t("groupThemeBadge")]
															})]
														}),
														shown !== "" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
															label: shown,
															side: "top",
															maxWidth: 320,
															children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																className: note !== void 0 ? `${Market_module_css_default.ungroupedDesc} ${Market_module_css_default.noteMine}` : Market_module_css_default.ungroupedDesc,
																children: shown
															})
														}),
														activations[member]?.library === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.spec,
															children: t("stateLibrary")
														}),
														activations[member]?.library !== true && effectiveDisabledSet.has(member) && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.spec,
															children: t("disabledState")
														}),
														activations[member]?.library !== true && onOffSwitch({
															label: (effectiveDisabledSet.has(member) ? t("enable") : t("disable")) + " " + member,
															on: !effectiveDisabledSet.has(member),
															disabled: togglingName !== null,
															toggle: () => doToggle(member, effectiveDisabledSet.has(member))
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "ghost",
															size: "sm",
															onClick: () => doRemoveMember(gid, member),
															children: t("groupRemove")
														})
													]
												}, member);
											})]
										})]
									}, gid);
								}),
								(groupQuery === "" || visibleUngrouped.length > 0) && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.groupRow,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.groupHead,
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.groupTitle,
											children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
												className: Market_module_css_default.groupName,
												children: t("ungrouped")
											}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
												className: Market_module_css_default.groupMeta,
												children: t("groupMembersMeta").replace("{0}", String((groupQuery === "" ? ungroupedNames : visibleUngrouped).length)).replace("{1}", String((groupQuery === "" ? ungroupedNames : visibleUngrouped).filter((name) => activations[name]?.library !== true && !effectiveDisabledSet.has(name)).length))
											})]
										})
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.groupMembers,
										children: (groupQuery === "" ? ungroupedNames : visibleUngrouped).length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
											className: Market_module_css_default.empty,
											children: t("installedEmpty")
										}) : visibleUngrouped.map((name) => {
											const { entry, note, shown } = installedBlurb(name);
											const act = activations[name];
											const off = act?.library !== true && effectiveDisabledSet.has(name);
											const meta = !off && act !== void 0 ? activationMeta(act.state, t, act.dependencyOf, act.loadedByProfile, act.library) : null;
											const stateLabel = act?.library === true ? meta?.label : off ? t("disabledState") : act?.state === "inert" && act.dependencyOf === void 0 && act.loadedByProfile !== true ? t("groupStateInert") : act?.state === "restart" ? t("groupStateRestart") : act?.state === "broken" ? t("groupStateBroken") : meta?.label;
											const stateDot = off ? "warning" : meta?.dot === "error" ? "error" : meta?.dot === "warning" ? "warning" : "done";
											const stateClass = stateDot === "error" ? Market_module_css_default.actBroken : stateDot === "warning" ? Market_module_css_default.actWarn : Market_module_css_default.actLive;
											return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
												className: `${Market_module_css_default.groupMember} ${Market_module_css_default.ungroupedRow}`,
												children: [
													/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
														className: Market_module_css_default.nm,
														title: name,
														children: [name, entry?.deprecated === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.depBadge,
															children: t("deprecatedBadge")
														})]
													}),
													installedThemeNames.has(name) && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
														className: Market_module_css_default.memberKind,
														children: ["· ", t("groupThemeBadge")]
													}),
													stateLabel !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
														className: Market_module_css_default.ungroupedState,
														children: act?.library === true ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.spec,
															children: stateLabel
														}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
															className: stateClass,
															title: stateLabel,
															children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
																state: stateDot,
																size: 7
															}), stateLabel]
														})
													}),
													shown !== "" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
														label: shown,
														side: "top",
														maxWidth: 320,
														children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: note !== void 0 ? `${Market_module_css_default.ungroupedDesc} ${Market_module_css_default.noteMine}` : Market_module_css_default.ungroupedDesc,
															children: shown
														})
													}),
													/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
														className: Market_module_css_default.groupMemberAction,
														children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
															open: assignFor === name,
															onClose: () => setAssignFor(null),
															onSelect: (id) => {
																if (installedThemeNames.has(name) && (groups[id] ?? []).some((member) => installedThemeNames.has(member))) return;
																setAssignFor(null);
																doAssign(name, id);
															},
															align: "end",
															portal: true,
															anchor: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
																variant: "outline",
																size: "sm",
																disabled: groupOrder.length === 0,
																icon: assignFor === name ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronDownOutline14, { size: 14 }),
																onClick: () => setAssignFor((open) => open === name ? null : name),
																children: t("groupAssign")
															}),
															items: groupOrder.map((gid) => {
																const blocked = installedThemeNames.has(name) && (groups[gid] ?? []).some((member) => installedThemeNames.has(member));
																return {
																	id: gid,
																	disabled: blocked,
																	label: blocked ? gid + " · " + t("groupThemeTaken") : gid
																};
															})
														})
													})
												]
											}, "ug-" + name);
										})
									})]
								}),
								groupQuery !== "" && visibleGroupIds.length === 0 && visibleUngrouped.length === 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.empty,
									children: t("groupSearchEmpty")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									className: Market_module_css_default.groupOrgHint,
									children: t("groupOrgHint")
								})
							] }) : orderedInstalledEntries.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.empty,
								children: t("installedEmpty")
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(Masonry, {
								items: orderedInstalledEntries.filter(([name, spec]) => {
									const needle = qInstalled.trim().toLowerCase();
									if (needle === "") return true;
									if (name.toLowerCase().includes(needle)) return true;
									if (String(spec).toLowerCase().includes(needle)) return true;
									const entry = data === null ? void 0 : catalogEntryForInstalled(data.plugins, name, String(spec), repoIdentities[name], repoHints[name]);
									if (entry !== void 0) {
										if ((entry.description && (entry.description[lang] || entry.description.en) || "").toLowerCase().includes(needle)) return true;
										if ((entry.owner || "").toLowerCase().includes(needle)) return true;
									}
									return false;
								}),
								render: ([name, spec]) => {
									const missing = pendingBackup !== null && !installedFiles.includes(name);
									const entry = data === null ? void 0 : catalogEntryForInstalled(data.plugins, name, String(spec), repoIdentities[name], repoHints[name]);
									const status = updates[name];
									const generation = status?.kind === "generation" || isGenerationSpec(String(spec));
									const localDev = isLocalDev(String(spec), status);
									const act = activations[name];
									const meta = act !== void 0 ? activationMeta(act.state, t, act.dependencyOf, act.loadedByProfile, act.library) : null;
									const version = status && status.version ? "v" + status.version : "";
									const specText = String(spec);
									const specRedundant = version !== "" && /^[\^~]?\d/.test(specText);
									const localPath = localPathOf(specText);
									const ghSpec = /^github:([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+?)(?:#|$)/.exec(specText);
									const repoUrl = entry !== void 0 ? entry.url : ghSpec !== null ? "https://github.com/" + ghSpec[1] : null;
									const off = act?.library !== true && effectiveDisabledSet.has(name);
									const toggleable = act?.library !== true && (off || act !== void 0 && (act.state === "live" || act.state === "restart"));
									return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: missing ? `${Market_module_css_default.irow} ${Market_module_css_default.irowMissing}` : Market_module_css_default.irow,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											style: { minWidth: 0 },
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: Market_module_css_default.irowHead,
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
														className: `${Market_module_css_default.nm} ${Market_module_css_default.irowName}`,
														children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.irowNameText,
															children: repoUrl !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
																className: Market_module_css_default.nameLink,
																href: repoUrl + "#readme",
																target: "_blank",
																rel: "noreferrer",
																title: name,
																"aria-label": `${name} — ${t("readme")}`,
																children: name
															}) : name
														}), entry?.deprecated === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.depBadge,
															children: t("deprecatedBadge")
														})]
													}), !missing && name !== "dsh-market" && name !== "dshmarket" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
														className: Market_module_css_default.irowMenu,
														children: renderInstalledBlockMenu(name)
													})]
												}),
												(version !== "" || localDev) && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
													className: Market_module_css_default.irowMeta,
													children: [version, localDev ? t("linkedDev") : ""].filter(Boolean).join(" · ")
												}),
												specRedundant ? null : localPath !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: Market_module_css_default.irowPath,
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.irowPathIcon,
															children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconFolderOpen16, { size: 14 })
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.spec,
															title: localPath,
															children: shortLocalPath(localPath)
														}),
														isAbsoluteLocalPath(localPath) && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.irowPathCopy,
															children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ConfirmCopyButton, {
																text: localPath,
																label: t("copyPath"),
																copiedLabel: t("pathCopied")
															})
														})
													]
												}) : repoUrl !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: Market_module_css_default.irowPath,
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
														className: Market_module_css_default.irowPathIcon,
														children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLinkOutline14, { size: 14 })
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
														className: `${Market_module_css_default.spec} ${Market_module_css_default.src}`,
														href: repoUrl,
														target: "_blank",
														rel: "noreferrer",
														children: specText
													})]
												}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
													className: Market_module_css_default.spec,
													children: specText
												}),
												notingName === name ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: Market_module_css_default.noteEdit,
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
														className: Market_module_css_default.noteInput,
														value: noteDraft,
														maxLength: NOTE_MAX,
														autoFocus: true,
														placeholder: t("notePlaceholder"),
														onChange: (e) => setNoteDraft(e.target.value),
														onKeyDown: (e) => {
															if (e.nativeEvent.isComposing || e.keyCode === 229) return;
															if (e.key === "Enter") saveNote(name, noteDraft);
															if (e.key === "Escape") setNotingName(null);
														}
													}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
														className: Market_module_css_default.noteEditBar,
														children: [
															/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																className: Market_module_css_default.noteCount,
																"aria-hidden": "true",
																children: `${noteDraft.length}/${NOTE_MAX}`
															}),
															/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
																variant: "ghost",
																size: "sm",
																onClick: () => setNotingName(null),
																children: t("cancel")
															}),
															/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
																variant: "primary",
																size: "sm",
																onClick: () => saveNote(name, noteDraft),
																children: t("noteSave")
															})
														]
													})]
												}) : (() => {
													const note = notes[name];
													const authored = entry?.description && (entry.description[lang] || entry.description.en) || "";
													const theirs = showTheirs.includes(name);
													const shown = note !== void 0 && !theirs ? note : authored;
													return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
														className: `${Market_module_css_default.desc} ${Market_module_css_default.descTight} ${Market_module_css_default.noteRow}`,
														children: [
															shown !== "" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(CardDesc, {
																text: shown,
																t,
																lines: 3,
																className: Market_module_css_default.irowDesc,
																textClassName: note !== void 0 && !theirs ? Market_module_css_default.noteMine : void 0
															}, shown),
															note !== void 0 && authored !== "" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
																type: "button",
																className: Market_module_css_default.noteToggle,
																title: theirs ? t("noteSeeMine") : t("noteSeeTheirs"),
																"aria-label": theirs ? t("noteSeeMine") : t("noteSeeTheirs"),
																onClick: () => setShowTheirs((list) => theirs ? list.filter((n) => n !== name) : list.concat(name)),
																children: theirs ? t("noteMine") : t("noteTheirs")
															}),
															/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
																type: "button",
																className: Market_module_css_default.noteAdd,
																onClick: () => {
																	setNoteDraft(note ?? "");
																	setNotingName(name);
																},
																children: [note === void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconPlus, { size: 14 }), note === void 0 ? t("noteAdd") : t("noteEdit")]
															})
														]
													});
												})(),
												(() => {
													const updatable = isPluginUpdatable(name, String(spec), status, updatedNames);
													const exempt = updateExemptSet.has(name);
													if (!updatable && !exempt) return null;
													const ignored = !exempt && bootId !== null && ignoredUpdateSet.has(name);
													const sep = /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
														className: Market_module_css_default.irowStatusSep,
														"aria-hidden": "true",
														children: "·"
													});
													return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
														updatable && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
															className: Market_module_css_default.irowStatus,
															children: [!generation && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
																className: Market_module_css_default.irowStatusPart,
																children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																	className: Market_module_css_default.irowStatusFact,
																	children: status?.eligibleVersion != null ? t("hostUpdateReady").replace("{0}", displayLatest(status.eligibleVersion)) : status?.latest != null ? t("hostUpdateReady").replace("{0}", displayLatest(status.latest)) : t("updateAvailableShort")
																}), sep]
															}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
																type: "button",
																className: Market_module_css_default.notesLink,
																onClick: () => openNotes(name, status?.current ?? null, status?.latest ?? null, repoUrl),
																children: `${t("notesLink")} ›`
															})]
														}),
														updatable && status?.eligibleVersion !== void 0 && status.restoreRequired !== true && status.heldUpdate !== void 0 && status.heldUpdate.latest !== status.eligibleVersion && (() => {
															const left = Date.parse(status.heldUpdate.until) - Date.now();
															const known = status.heldUpdate.estimated !== true && Number.isFinite(left) && left > 0;
															return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
																className: Market_module_css_default.irowStatus,
																children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																	className: Market_module_css_default.metaInline,
																	children: t(known ? "updateHeldTarget" : "updateHeldTargetUnknown").replace("{0}", displayLatest(status.heldUpdate.latest)).replace("{1}", String(Math.max(1, Math.ceil(left / 36e5)))).replace("{2}", displayLatest(status.eligibleVersion))
																})
															});
														})(),
														(exempt || ignored) && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
															className: Market_module_css_default.irowStatus,
															children: [
																/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																	className: Market_module_css_default.irowStatusIcon,
																	children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconBellOff, { size: 16 })
																}),
																exempt ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																	className: Market_module_css_default.metaInline,
																	title: t("updateExemptHint"),
																	role: "status",
																	children: t("updateExemptMark")
																}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																	className: Market_module_css_default.metaInline,
																	role: "status",
																	children: t("updateNoticeIgnored")
																}),
																/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																	className: Market_module_css_default.irowStatusAction,
																	children: exempt ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
																		type: "button",
																		className: Market_module_css_default.noteToggle,
																		title: t("updateExemptHint"),
																		"aria-label": `${t("updateExemptRestore")} ${name}`,
																		onClick: () => toggleUpdateExempt(name),
																		children: t("updateExemptRestore")
																	}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
																		type: "button",
																		className: Market_module_css_default.noteToggle,
																		"aria-label": `${t("updateExemptRestore")} ${name}`,
																		onClick: () => unignoreUpdateNotice(name),
																		children: t("updateExemptRestore")
																	})
																})
															]
														})
													] });
												})(),
												!off && act !== void 0 && meta !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: Market_module_css_default.act,
													children: [
														act.library === true ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.metaTag,
															children: meta.label
														}) : meta.dot !== "done" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
															className: meta.dot === "error" ? Market_module_css_default.actBroken : Market_module_css_default.actWarn,
															children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, {
																state: meta.dot,
																size: 7
															}), meta.label]
														}),
														act.library === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
															className: Market_module_css_default.spec,
															children: t("libraryUseHint")
														}),
														act.library !== true && act.state !== "live" && act.reasons.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.DisclosureRow, {
															icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconQuestionOutline14, { size: 14 }),
															title: t("actWhy"),
															open: whyOpen === name,
															expandable: true,
															expandOnRowClick: true,
															onToggle: () => setWhyOpen(whyOpen === name ? null : name),
															className: Market_module_css_default.actWhy,
															children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
																className: Market_module_css_default.spec,
																children: localizeBilingualList(act.reasons, lang)
															})
														})
													]
												}),
												entry !== void 0 && entry.deprecated === true && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
													className: Market_module_css_default.deprecate,
													style: { marginTop: 8 },
													children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
														className: Market_module_css_default.depLine,
														children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: ["⚠️ ", t("deprecatedWarn")] }), entry.replacement !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.src,
															children: t("replacementHint") + " " + entry.replacement
														})]
													})
												}),
												updatingName === name && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
													className: Market_module_css_default.progress,
													children: [
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.spin,
															children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconLoadingOutline16, { size: 14 })
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", {
															className: Market_module_css_default.grow,
															children: progressText
														}),
														progressPct !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
															className: Market_module_css_default.pct,
															children: [progressPct, "%"]
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "outline",
															size: "sm",
															disabled: cancelling,
															onClick: () => doCancel(),
															children: cancelling ? t("cancelling") : t("cancelOp")
														}),
														/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
															className: Market_module_css_default.bar,
															children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
																className: progressPct !== null ? Market_module_css_default.barFill : `${Market_module_css_default.barFill} ${Market_module_css_default.barWave}`,
																style: progressPct !== null ? { width: `${progressPct}%` } : void 0
															})
														})
													]
												})
											]
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
											className: Market_module_css_default.irowActions,
											children: [
												!missing && act?.library !== true && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
													className: Market_module_css_default.stateTag,
													"data-on": off ? "false" : "true",
													children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
														className: Market_module_css_default.stateDot,
														"data-on": off ? "false" : "true"
													}), off ? t("disabledState") : t("switchOnLabel")]
												}),
												toggleable && onOffSwitch({
													label: (off ? t("enable") : t("disable")) + " " + name,
													on: !off,
													disabled: togglingName !== null || busyUrl !== null || updatingName !== null || removingName !== null,
													toggle: () => doToggle(name, off)
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.grow }),
												entry !== void 0 && entry.deprecated === true && entry.replacement !== void 0 && (() => {
													const replacement = data?.plugins.find((r) => r.name === entry.replacement);
													if (replacement === void 0) return null;
													return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
														variant: "outline",
														size: "sm",
														onClick: () => {
															setCat("all");
															setQ(entry.replacement);
															setTab("discover");
														},
														children: t("viewReplacement")
													}), !isInstalled(replacement, catalogInstalled, repoIdentities, data?.plugins, repoHints) && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
														variant: "outline",
														size: "sm",
														onClick: () => setConfirming(replacement),
														children: t("installReplacement")
													})] });
												})(),
												/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
													className: Market_module_css_default.irowTrailing,
													children: [
														!missing && status?.sourceMigration !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "outline",
															size: "sm",
															disabled: updatingName !== null || removingName !== null || busyUrl !== null,
															onClick: () => askSourceMigration(name),
															children: status.sourceMigration.kind === "npm-rename" ? t("renameRowAction") : t("migrateNpm")
														}),
														missing ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.metaTag,
															children: t("notInstalled")
														}) : updatedNames.includes(name) ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: `${Market_module_css_default.metaTag} ${Market_module_css_default.metaTagOk}`,
															children: act?.library === true ? t("updatedLibrary") : act?.state === "live" ? t("updatedLive") : t("updated")
														}) : updatingName === name ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "outline",
															size: "sm",
															className: Market_module_css_default.warnBtn,
															disabled: true,
															children: t("updating")
														}) : status !== void 0 && generation && status.latest != null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.metaTag,
															title: t("hostUpdateHint"),
															children: t("hostUpdateReady").replace("{0}", status.latest)
														}) : status && status.updateAvailable ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "outline",
															size: "sm",
															className: Market_module_css_default.warnBtn,
															disabled: updatingName !== null,
															onClick: () => {
																if (status.restoreRequired === true) askRestore(name);
																else doUpdate(name);
															},
															children: status.restoreRequired === true ? t("restoreOnline") : status.eligibleVersion !== void 0 ? `${t("update")} ${displayLatest(status.eligibleVersion)}` : t("update")
														}), status.heldUpdate !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.metaTag,
															children: t("updateHeldTag").replace("{0}", displayLatest(status.heldUpdate.latest))
														})] }) : status?.heldUpdate !== void 0 ? (() => {
															const left = Date.parse(status.heldUpdate.until) - Date.now();
															const estimated = status.heldUpdate.estimated === true;
															const amount = String(Math.max(1, Math.ceil(left / (estimated ? 6e4 : 36e5))));
															const hint = t(estimated ? "updateHeldEstimatedHint" : "updateHeldHint").replace("{1}", amount);
															return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
																className: Market_module_css_default.metaTag,
																title: hint,
																children: t("updateHeldTag").replace("{0}", displayLatest(status.heldUpdate.latest))
															});
														})() : localDev ? null : status?.unreleasedCommit != null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.metaTag,
															title: t("unreleasedCommitsHint"),
															children: t("unreleasedCommits").replace("{0}", displayLatest(status.unreleasedCommit))
														}) : status?.newerPrerelease !== void 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.metaTag,
															title: t("newerPrereleaseHint"),
															children: t("newerPrereleaseAvailable").replace("{0}", status.newerPrerelease)
														}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
															variant: "outline",
															size: "sm",
															disabled: updatingName !== null || removingName !== null || busyUrl !== null,
															onClick: () => doUpdate(name, false, false, status.newerPrerelease),
															children: t("install")
														})] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.metaTag,
															title: t("upToDate"),
															children: t("upToDate")
														}),
														removingName === name && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
															className: Market_module_css_default.metaTag,
															children: t("uninstalling")
														})
													]
												})
											]
										})]
									}, name);
								}
							}),
							dependencyOnlyNames.size > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: Market_module_css_default.groupOrgHint,
								children: t("installedDependencyNote").replace("{0}", String(dependencyOnlyNames.size))
							})
						] })
					}),
					showTop && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Tooltip, {
						label: t("backTop"),
						side: "top",
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							className: Market_module_css_default.top,
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "outline",
								className: Market_module_css_default.topBtn,
								"aria-label": t("backTop"),
								onClick: scrollToTop,
								children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconChevronUpOutline14, { size: 16 })
							})
						})
					}),
					renamingGroup !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						onClose: () => {
							setRenamingGroup(null);
							setRenamingValue("");
						},
						title: t("groupRenameTitle"),
						description: t("groupRenameHint"),
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "ghost",
							onClick: () => {
								setRenamingGroup(null);
								setRenamingValue("");
							},
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "primary",
							disabled: renamingValue.trim() === "" || renamingValue.trim() === renamingGroup,
							onClick: () => doRenameGroup(renamingGroup),
							children: t("groupRenameSave")
						})] }),
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.groupRenameField,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("label", {
								htmlFor: "dsh-market-group-rename",
								children: t("groupNamePh")
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
								id: "dsh-market-group-rename",
								className: Market_module_css_default.inlineInput,
								placeholder: t("groupNamePh"),
								value: renamingValue,
								onChange: (e) => setRenamingValue(e.target.value),
								onFocus: (e) => e.currentTarget.select(),
								onKeyDown: (e) => {
									if (e.key === "Enter") doRenameGroup(renamingGroup);
								},
								autoFocus: true
							})]
						})
					}),
					addPanel !== null && (() => {
						const members = groups[addPanel] ?? [];
						const pluginCandidates = ungroupedNames.filter((name) => !installedThemeNames.has(name) && !members.includes(name));
						const needle = addQuery.trim().toLowerCase();
						const candidates = needle === "" ? pluginCandidates : pluginCandidates.filter((name) => name.toLowerCase().includes(needle));
						return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
							open: true,
							onClose: () => setAddPanel(null),
							title: t("groupAddTitle").replace("{0}", addPanel),
							footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: Market_module_css_default.groupAddFooterMeta,
									children: t("groupAddSelected").replace("{0}", String(addSelected.length))
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									onClick: () => setAddPanel(null),
									children: t("cancel")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "primary",
									disabled: addSelected.length === 0,
									onClick: doAddSelectedMembers,
									children: t("groupAddConfirm").replace("{0}", String(addSelected.length))
								})
							] }),
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.groupAddModalBody,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(SearchInput, {
										value: addQuery,
										onCommit: setAddQuery,
										placeholder: t("groupAddSearchPh"),
										t
									}),
									candidates.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
										className: Market_module_css_default.groupAddModalHint,
										children: t("groupAddEmpty")
									}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.groupAddModalList,
										children: candidates.map((name) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
											className: Market_module_css_default.groupAddPick,
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
													type: "checkbox",
													checked: addSelected.includes(name),
													onChange: () => setAddSelected((prev) => prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name])
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: Market_module_css_default.nm,
													children: name
												}),
												effectiveDisabledSet.has(name) && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: Market_module_css_default.spec,
													children: t("disabledState")
												})
											]
										}, name))
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
										className: Market_module_css_default.groupAddModalHint,
										children: t("groupAddHint")
									})
								]
							})
						});
					})(),
					themePanel !== null && (() => {
						const current = (groups[themePanel] ?? []).find((name) => installedThemeNames.has(name)) ?? null;
						const choices = [...current !== null ? [current] : [], ...ungroupedNames.filter((name) => installedThemeNames.has(name))];
						return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
							open: true,
							onClose: () => setThemePanel(null),
							title: t("groupThemeTitle").replace("{0}", themePanel),
							footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
								current !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									onClick: () => applyGroupTheme(themePanel, null),
									children: t("groupThemeRemove")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { className: Market_module_css_default.groupAddFooterMeta }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "ghost",
									onClick: () => setThemePanel(null),
									children: t("cancel")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "primary",
									disabled: themePick === null || themePick === current,
									onClick: () => {
										if (themePick !== null) applyGroupTheme(themePanel, themePick);
									},
									children: t("groupThemeUse")
								})
							] }),
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.groupAddModalBody,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									className: Market_module_css_default.groupAddModalHint,
									children: t("groupThemeHint")
								}), choices.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									className: Market_module_css_default.groupAddModalHint,
									children: t("groupThemeEmpty")
								}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.groupAddModalList,
									role: "radiogroup",
									"aria-label": t("groupPickTheme"),
									children: choices.map((name) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
										className: Market_module_css_default.groupAddPick,
										children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
												type: "radio",
												name: "dsh-market-group-theme",
												checked: themePick === name,
												onChange: () => setThemePick(name)
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
												className: Market_module_css_default.nm,
												children: name
											}),
											name === current && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
												className: Market_module_css_default.spec,
												children: t("groupThemeCurrent")
											})
										]
									}, name))
								})]
							})
						});
					})(),
					confirming !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						className: Market_module_css_default.confirmModal,
						contentClassName: Market_module_css_default.confirmContent,
						onClose: () => setConfirming(null),
						title: t("confirmTitle") + " " + pluginName(confirming.name, confirming.npm) + "?",
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "ghost",
							onClick: () => setConfirming(null),
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "primary",
							onClick: () => doInstall(confirming),
							children: t("confirmInstall")
						})] }),
						children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: Market_module_css_default.confirmBody,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.byline,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(OwnerAvatar, {
											name: confirming.name,
											owner: confirming.owner || "",
											icon: confirming.icon ?? void 0
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.owner,
											title: confirming.owner,
											children: confirming.owner
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(CatalogVersionMark, {
											version: confirming.version,
											tip: catalogVersionTip
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(DownloadCount, {
											plugin: confirming,
											t
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)(StarCount, {
											plugin: confirming,
											t
										}),
										confirming.added && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.star,
											title: t("published"),
											children: `· ${confirming.added}`
										})
									]
								}),
								pluginCategories(confirming).length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.confirmTags,
									children: pluginCategories(confirming).map((category) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.tag,
										children: data.categories[category] && (data.categories[category][lang] || data.categories[category].en) || category
									}, category))
								}),
								(() => {
									const text = confirming.description && (confirming.description[lang] || confirming.description.en) || "";
									return text === "" ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
										className: Market_module_css_default.confirmDesc,
										children: text
									});
								})(),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(ScreenshotStrip, {
									plugin: confirming,
									onOpen: openLightbox
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.confirmFold,
									children: [capabilityDetail(confirming), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ConfirmFold, {
										icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ConfirmTerminalIcon, {}),
										title: t("cmdDetails"),
										open: cmdOpen,
										onToggle: () => setCmdOpen((o) => !o),
										children: (() => {
											const shown = installCommandFor(confirming.install, profileName);
											if (shown.unusable) return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
												className: Market_module_css_default.confirmCmd,
												children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
													className: Market_module_css_default.cmd,
													children: t("cmdDesktopUnavailable")
												})
											});
											if (shown.command === null) return null;
											return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
												className: Market_module_css_default.confirmCmd,
												children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
													className: Market_module_css_default.cmd,
													children: shown.command
												}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ConfirmCopyButton, {
													text: shown.command,
													label: t("cmdCopy"),
													copiedLabel: t("cmdCopied")
												})]
											});
										})()
									})]
								}),
								(looksTerminal(confirming, lang) || confirming.deprecated === true) && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.installCaution,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
											className: Market_module_css_default.installCautionLabel,
											children: t("installCaution")
										}),
										looksTerminal(confirming, lang) && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
												className: Market_module_css_default.installCautionHead,
												children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(ConfirmWarnIcon, {}), t("terminalCautionTitle")]
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
												className: Market_module_css_default.installCautionBody,
												children: t("terminalCautionBody")
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
												className: Market_module_css_default.installCautionFoot,
												children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("terminalCautionStartup") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
													className: Market_module_css_default.installCautionLink,
													href: confirming.url + "#readme",
													target: "_blank",
													rel: "noreferrer",
													children: t("terminalCautionLink")
												})]
											})
										] }),
										confirming.deprecated === true && (() => {
											const replacement = replacementOf(confirming);
											return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
												className: Market_module_css_default.installCautionBody,
												children: [t("deprecatedWarn"), replacement !== void 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [" ", /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
													className: Market_module_css_default.src,
													href: replacement.url,
													target: "_blank",
													rel: "noreferrer",
													children: t("replacementHint") + " " + replacement.name
												})] })]
											});
										})()
									]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									className: Market_module_css_default.confirmFineprint,
									children: t("confirmWarn")
								})
							]
						})
					}),
					recovery !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(RecoveryPanel, {
						open: recoveryOpen,
						view: recovery,
						keep: recoveryKeep,
						busy: recoveryBusy,
						onToggle: (name, on) => setRecoveryKeep((current) => ({
							...current,
							[name]: on
						})),
						onApply: applyRecoveryChoice,
						onClose: () => setRecoveryOpen(false),
						t
					}),
					commentsFor !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(CommentsModal, {
						name: pluginName(commentsFor.name, commentsFor.npm),
						url: commentsFor.url,
						lang,
						onClose: () => setCommentsFor(null),
						t
					}, commentsFor.url),
					lightbox !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ScreenshotLightbox, {
						shots: lightbox.shots,
						startIndex: lightbox.index,
						onClose: () => setLightbox(null),
						t
					}),
					migrationConfirm !== null && (() => {
						const copy = sourceMigrationCopy(migrationConfirm, t);
						return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
							open: true,
							onClose: () => setMigrationConfirm(null),
							title: copy.title,
							description: copy.description,
							footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "ghost",
								onClick: () => setMigrationConfirm(null),
								children: t("cancel")
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "primary",
								disabled: updatingName !== null,
								onClick: () => doSourceMigration(migrationConfirm.name, false, migrationConfirm.kind === "npm-rename" ? migrationConfirm.target : void 0),
								children: copy.confirmLabel
							})] }),
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.migrationSources,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: Market_module_css_default.migrationSource,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.migrationLabel,
											children: copy.currentLabel
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("code", { children: [
											migrationConfirm.name,
											": ",
											migrationConfirm.source
										] })]
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.migrationArrow,
										children: "↓"
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: Market_module_css_default.migrationSource,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.migrationLabel,
											children: copy.targetLabel
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", { children: migrationConfirm.target })]
									})
								]
							}), copy.noteTone === "warning" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
								className: Market_module_css_default.migrationWarning,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 14 }), copy.note]
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: Market_module_css_default.migrationNote,
								children: copy.note
							})]
						});
					})(),
					agentsConfirm !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						onClose: () => setAgentsConfirm(null),
						title: t("agentsRunningConfirm") + " " + agentsConfirm.name,
						description: t("agentsRunningRisk"),
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "ghost",
							onClick: () => setAgentsConfirm(null),
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "primary",
							disabled: busyUrl !== null || updatingName !== null || removingName !== null,
							onClick: () => {
								setAgentsConfirm(null);
								agentsConfirm.run();
							},
							children: t(agentsConfirm.kind === "uninstall" ? "opUninstallNow" : "opUpdateNow")
						})] })
					}),
					removeConfirm !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						onClose: () => setRemoveConfirm(null),
						title: t("uninstall") + " " + removeConfirm + "?",
						description: t(activations[removeConfirm]?.library === true ? "uninstallLibraryConfirmDesc" : "uninstallConfirmDesc"),
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "ghost",
							onClick: () => setRemoveConfirm(null),
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "primary",
							disabled: removingName !== null,
							onClick: () => doUninstall(removeConfirm),
							children: t("uninstall")
						})] })
					}),
					restoreConfirm !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						onClose: () => setRestoreConfirm(null),
						title: `${t("restoreOnline")} ${restoreConfirm.name}?`,
						description: `${restoreConfirm.verified ? t("restoreHint") : t("restoreNameOnlyHint")}\n\n${restoreConfirm.entry.owner} · ${restoreConfirm.entry.url}`,
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "ghost",
							onClick: () => setRestoreConfirm(null),
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "primary",
							disabled: updatingName !== null,
							onClick: () => doUpdate(restoreConfirm.name, false, true),
							children: t("restoreProceed")
						})] })
					}),
					hostIncompatible !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						onClose: () => setHostIncompatible(null),
						title: t("hostIncompatibleTitle"),
						description: [t(hostIncompatible.kind === "install" ? "hostIncompatibleBodyInstall" : "hostIncompatibleBody").replace("{plugin}", `${hostIncompatible.name} ${hostIncompatible.version}`.trim()).replace("{requirement}", hostIncompatible.requirement ?? t("hostIncompatibleUnknown")).replace("{host}", hostIncompatible.hostVersion ?? t("hostIncompatibleUnknown")), hostIncompatible.npmName === null ? null : findingCompat.status === "loading" ? t("hostIncompatibleSearching") : findingCompat.status === "found" ? hostCompatHeld ? hostCompatHeldHours === null ? t("hostIncompatibleHeldTargetUnknown").replace("{version}", findingCompat.version) : t("hostIncompatibleHeldTarget").replace("{version}", findingCompat.version).replace("{window}", String(hostCompatWindowHours)).replace("{hours}", String(hostCompatHeldHours)) : t(hostIncompatible.kind === "install" ? "hostIncompatibleFoundInstall" : "hostIncompatibleFoundUpdate").replace("{version}", findingCompat.version) : findingCompat.status === "not-found" ? t("hostIncompatibleNoCompat") : findingCompat.status === "error" ? t("hostIncompatibleSearchFailed") : null].filter((line) => line !== null).join("\n"),
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: findingCompat.status === "found" && !hostCompatHeld ? "outline" : "primary",
								onClick: () => setHostIncompatible(null),
								children: t(hostIncompatible.kind === "install" ? "hostIncompatibleCancel" : "hostIncompatibleKeep")
							}),
							findingCompat.status === "found" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "primary",
								disabled: hostCompatHeld || (hostIncompatible.kind === "install" ? busyUrl !== null : updatingName !== null),
								onClick: () => {
									const kind = hostIncompatible.kind;
									const target = hostIncompatible.name;
									const plugin = hostIncompatible.plugin;
									const version = findingCompat.version;
									setHostIncompatible(null);
									if (kind === "install") {
										if (plugin !== null) doInstall(plugin, false, version);
									} else doUpdate(target, false, false, version);
								},
								children: hostCompatHeld ? hostCompatHeldHours === null ? t("hostIncompatibleHeldButtonUnknown") : t("hostIncompatibleHeldButton").replace("{hours}", String(hostCompatHeldHours)) : t(hostIncompatible.kind === "install" ? "hostIncompatibleInstallCompat" : "hostIncompatibleUpdateCompat").replace("{version}", findingCompat.version)
							}),
							findingCompat.status === "error" && hostIncompatible.npmName !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "outline",
								onClick: () => setCompatRetry((n) => n + 1),
								children: t("hostIncompatibleRetry")
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "ghost",
								disabled: hostIncompatible.kind === "install" ? busyUrl !== null : updatingName !== null,
								onClick: () => {
									const kind = hostIncompatible.kind;
									const target = hostIncompatible.name;
									const forcePlugin = hostIncompatible.plugin;
									setHostIncompatible(null);
									if (kind === "install" && forcePlugin !== null) doInstall(forcePlugin, true);
									else doUpdate(target, true);
								},
								children: t(hostIncompatible.kind === "install" ? "hostIncompatibleInstallAnyway" : "hostIncompatibleAnyway")
							})
						] })
					}),
					restoreBlocked !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						onClose: () => setRestoreBlocked(null),
						title: `${t("restoreNoCatalogTitle")} — ${restoreBlocked.name}`,
						description: t(restoreBlocked.reason === "repo-mismatch" ? "restoreNoMatch" : "restoreNoCatalog"),
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "ghost",
							onClick: () => setRestoreBlocked(null),
							children: t("gotIt")
						})
					}),
					notesFor !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						onClose: () => setNotesFor(null),
						className: notesState === "ready" && updateNotes?.kind === "release" ? Market_module_css_default.notesModalWide : void 0,
						title: notesFor.repoUrl !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
							className: Market_module_css_default.nameLink,
							href: notesFor.repoUrl + "#readme",
							target: "_blank",
							rel: "noreferrer",
							children: notesFor.name
						}) : notesFor.name,
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "ghost",
							onClick: () => setNotesFor(null),
							children: t("gotIt")
						}),
						children: [
							(notesFor.current !== null || notesFor.latest !== null) && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.notesRange,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spec,
										children: notesFor.current !== null && notesFor.current.length === 40 ? notesFor.current.slice(0, 7) : notesFor.current
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.notesArrow,
										children: "→"
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: Market_module_css_default.spec,
										children: notesFor.latest !== null && notesFor.latest.length === 40 ? notesFor.latest.slice(0, 7) : notesFor.latest
									})
								]
							}),
							notesState === "loading" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.spec,
								children: t("loading")
							}),
							notesState === "fail" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.spec,
								children: t("notesLoadFail")
							}),
							notesState === "ready" && updateNotes !== null && (updateNotes.kind === "release" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.notesBody,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: Market_module_css_default.notesMeta,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: t("notesRelease") }),
										updateNotes.release.tag !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: " " + updateNotes.release.tag }),
										updateNotes.release.publishedAt !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: " · " + updateNotes.release.publishedAt.slice(0, 10) })
									]
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.notesRendered,
									children: renderMarkdown(updateNotes.release.body || t("notesNone"))
								})]
							}) : updateNotes.kind === "commits" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.notesBody,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.notesMeta,
										children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: t("notesCommits") })
									}),
									!updateNotes.commits.found && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
										className: Market_module_css_default.notesMeta,
										children: t("notesCommitsRecent")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("ul", {
										className: Market_module_css_default.notesList,
										children: updateNotes.commits.items.map((c) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("li", {
											className: Market_module_css_default.notesRow,
											children: [
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: Market_module_css_default.notesDate,
													children: c.date !== null ? c.date.slice(0, 10) : ""
												}),
												/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
													className: Market_module_css_default.notesMsg,
													children: mdInline(c.message)
												}),
												notesFor.repoUrl !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
													className: Market_module_css_default.notesSha,
													href: notesFor.repoUrl + "/commit/" + c.sha,
													target: "_blank",
													rel: "noreferrer",
													title: c.message,
													children: c.sha.slice(0, 7)
												})
											]
										}, c.sha))
									})
								]
							}) : updateNotes.kind === "npm" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.notesBody,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: Market_module_css_default.notesMeta,
									children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: t("notesNpm") })
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("ul", {
									className: Market_module_css_default.notesList,
									children: updateNotes.npmTimes.map((v) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("li", {
										className: Market_module_css_default.notesRow,
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.notesDate,
											children: v.date.slice(0, 10)
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
											className: Market_module_css_default.notesVer,
											href: `https://www.npmjs.com/package/${encodeURIComponent(notesFor.name)}/v/${encodeURIComponent(v.version)}`,
											target: "_blank",
											rel: "noreferrer",
											children: v.version
										})]
									}, v.version))
								})]
							}) : updateNotes.kind === "source" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.spec,
								children: [t(updateNotes.reason === "unavailable" ? "notesLoadFail" : updateNotes.reason === "unreadable" ? "notesSourceUnreadable" : "notesSource"), typeof updateNotes.sourceUrl === "string" && /^https?:\/\//i.test(updateNotes.sourceUrl) ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [lang === "zh" ? "" : " ", /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
									className: Market_module_css_default.notesSourceLink,
									href: updateNotes.sourceUrl,
									target: "_blank",
									rel: "noreferrer",
									children: t("notesSourceLink")
								})] }) : updateNotes.reason !== "unavailable" && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [lang === "zh" ? "" : " ", t("notesSourceNoLink")] })]
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.spec,
								children: t("notesNone")
							}))
						]
					}),
					restoreConfirmOpen && pendingBackup !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						onClose: () => setRestoreConfirmOpen(false),
						title: t("restoreConfirm"),
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "ghost",
							onClick: () => setRestoreConfirmOpen(false),
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "primary",
							disabled: backupBusy,
							onClick: doRestore,
							children: t("confirm")
						})] })
					}),
					exportOpen && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(_deepseek_ai_dsh_client_ui_primitives.Modal, {
						open: true,
						onClose: () => setExportOpen(false),
						title: t("gistExportSelect"),
						description: t("gistExportHint"),
						footer: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "ghost",
							onClick: () => setExportOpen(false),
							children: t("cancel")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							variant: "primary",
							disabled: gistBusy || exportSelection.size === 0,
							onClick: () => runGist("export"),
							children: gistBusy ? t("backupWorking") : t("gistExportGo")
						})] }),
						children: [exportOptions.length === 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("gistNoPlugins") }), exportOptions.length > 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: Market_module_css_default.backupActions,
								children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									size: "sm",
									variant: "outline",
									onClick: () => setExportSelection(new Set(exportOptions)),
									children: t("gistSelectAll")
								}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									size: "sm",
									variant: "outline",
									onClick: () => setExportSelection(/* @__PURE__ */ new Set()),
									children: t("gistSelectNone")
								})]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: Market_module_css_default.backupCheckList,
								children: exportOptions.map((name) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
									className: Market_module_css_default.backupCheck,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: exportSelection.has(name),
											onChange: (e) => {
												const next = new Set(exportSelection);
												if (e.currentTarget.checked) next.add(name);
												else next.delete(name);
												setExportSelection(next);
											}
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.grow,
											children: name
										}),
										specKind(installed[name]) === "git" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: `${Market_module_css_default.specTag} ${Market_module_css_default.specTagGit}`,
											children: "git"
										}),
										specKind(installed[name]) === "file" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: `${Market_module_css_default.specTag} ${Market_module_css_default.specTagFile}`,
											children: t("gistSpecLocal")
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											className: Market_module_css_default.spec,
											title: installed[name],
											children: installed[name] ?? t("bundleTag")
										})
									]
								}, name))
							}),
							labelledCheckbox({
								label: t("gistIncludeConfig"),
								checked: exportIncludeConfig,
								className: Market_module_css_default.backupCheck,
								onChange: setExportIncludeConfig
							}),
							exportIncludeConfig && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: Market_module_css_default.backupWarn,
								children: t("credsWarning")
							}),
							exportError !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: Market_module_css_default.backupWarn,
								children: exportError
							})
						] })]
					}),
					exportState === "done" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
						text: t("exportedLog"),
						icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconCheckOutline16, { size: 14 }),
						onDone: exportToastDone
					}),
					exportState === "fail" && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
						text: t("exportLogFail"),
						icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 14 }),
						onDone: exportToastDone
					}),
					favoriteError !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
						text: localizeBilingual(favoriteError, lang),
						icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 14 }),
						onDone: favoriteErrorDone
					}),
					blockError !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
						text: localizeBilingual(blockError, lang),
						icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 14 }),
						onDone: blockErrorDone
					}),
					blockNotice !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
						text: blockNotice,
						onDone: blockNoticeDone
					}),
					updateExemptError !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
						text: localizeBilingual(updateExemptError, lang),
						icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 14 }),
						onDone: updateExemptErrorDone
					}),
					updateExemptNotice !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
						text: updateExemptNotice,
						onDone: updateExemptNoticeDone
					}),
					toggled !== null && /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
						text: toggled.name + " " + t(toggled.enabled ? "toastToggledOn" : "toastToggledOff"),
						icon: toggled.enabled ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconCheckOutline16, { size: 14 }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(IconWarningOutline16, { size: 14 }),
						onDone: toggledDone
					})
				]
			});
		}
		//#endregion
		//#region src/client/market-element.ts
		/**
		* The market's panel, as an element, built from explicit dependencies.
		*
		* Two callers want the same thing and must not drift apart:
		*
		* - the `settings.section` this package registers, whose slot passes down a
		*   host-chosen `preferredSubsectionId`;
		* - `market.render()`, for a host shell that renders the market inside its
		*   own container (#602, from the Tauri desktop).
		*
		* A module function taking its dependencies rather than a closure over the
		* cordis context, so the wiring — which locale, which theme, which log
		* exporter reaches the panel — is something a test can assert instead of
		* something only a running host can reveal.
		*/
		/**
		* @param props - see {@link MarketElementProps}.
		* @returns the panel wrapped in its error boundary.
		*/
		function marketElement(props) {
			return (0, react.createElement)(MarketErrorBoundary, {
				text: props.crashText,
				actions: (0, react.createElement)("button", {
					type: "button",
					onClick: () => {
						props.exportLog();
					}
				}, props.t("exportLog"))
			}, (0, react.createElement)(MarketSection, {
				t: props.t,
				locale: props.locale,
				theme: props.theme,
				themeStore: props.themeStore,
				preferredSubsectionId: props.preferredSubsectionId,
				sidebar: props.sidebar,
				hostNavigation: props.hostNavigation,
				surface: props.surface
			}));
		}
		//#endregion
		//#region src/client/section-gate.ts
		/**
		* @param register - registers the entry and returns its disposer. Called
		*   only when the entry should be visible; may be called again after a
		*   retraction, which is why the disposer is required rather than optional.
		* @param initiallyVisible - the answer before anyone has given one. The
		*   settings entry defaults to shown: hiding it is an opt-in (the host, or
		*   the user's card switch, #1015), so no opinion means "as it always was".
		*   The sidebar entry (#846) defaults to hidden: showing it is an opt-in the
		*   user makes.
		* @returns the gate.
		*/
		function createSectionGate(register, initiallyVisible = true) {
			let ready = false;
			let wanted = initiallyVisible;
			let removed = false;
			let dispose = null;
			const apply = () => {
				if (!ready) return;
				const shouldShow = wanted && !removed;
				if (shouldShow && dispose === null) {
					dispose = register();
					return;
				}
				if (!shouldShow && dispose !== null) {
					const stop = dispose;
					dispose = null;
					stop();
				}
			};
			return {
				available: () => {
					ready = true;
					apply();
				},
				setVisible: (visible) => {
					wanted = visible;
					apply();
				},
				visible: () => dispose !== null,
				retire: () => {
					removed = true;
					apply();
				}
			};
		}
		//#endregion
		//#region src/client/entry-visibility.ts
		/**
		* The market's page-level entrances and whether the user keeps them (#1015).
		*
		* Three doors lead into the market: the page in Settings, the tab on the
		* host's Plugins page, and the opt-in sidebar row (#846, sidebar-entry.ts).
		* This module owns the first two and ASKS the sidebar controller whether a
		* third door remains — it does not own that choice.
		*
		* Absent means shown for both of these, unlike the sidebar row: they are the
		* entries every host has always had, and a host before 0.2.1 offers the
		* settings page as its only one. The host decides which slots exist at all
		* (an older dsh never declares `plugins.tab`, and the desktop shell may hide
		* the settings section through #602), so availability is answered live from
		* the slots and the host's service, never inferred from the stored value.
		*
		* ## The last-door rule
		*
		* Any switch that could turn a door off asks {@link EntryVisibility.otherDoorOpen}
		* first. The server enforces the same rule on the three stored answers, but
		* it cannot see which slots THIS host declares — on a host with no Plugins
		* tab, hiding the settings page while the row is off would leave no entry at
		* all, and the server would happily store it. So the browser answers for the
		* host's half, and the server answers for the saved half.
		*/
		function createEntryVisibility({ settingsGate, pluginsTabGate, fetch, sidebarSupported, sidebarShown }) {
			let settingsSeat = false;
			let pluginsTabSeat = false;
			let hostSettings = true;
			let settingsSection = true;
			let pluginsTab = true;
			/** Bumped by every `set` so a slow initial `load` cannot overwrite it. */
			let epoch = 0;
			const listeners = /* @__PURE__ */ new Set();
			const notify = () => {
				for (const listener of listeners) listener();
			};
			const apply = () => {
				settingsGate.setVisible(hostSettings && settingsSection);
				pluginsTabGate.setVisible(pluginsTab);
			};
			/**
			* "Is this door open?" is a question about what the UI shows, so it
			* combines the host's declaration, the host's own preference, and the
			* user's answer. The sidebar's two facts arrive through callbacks because
			* that controller keeps its own state.
			*/
			const settingsOpen = () => settingsSeat && hostSettings && settingsSection;
			const pluginsOpen = () => pluginsTabSeat && pluginsTab;
			const sidebarOpen = () => sidebarSupported() && sidebarShown();
			const otherDoorOpen = (key) => key !== "settingsSection" && settingsOpen() || key !== "pluginsTab" && pluginsOpen() || key !== "sidebar" && sidebarOpen();
			const loadState = async () => {
				const at = epoch;
				try {
					const response = await fetch(api("/dsh-market/entry-visibility"), { cache: "no-store" });
					if (response.ok) {
						const body = await response.json();
						if (at === epoch) {
							if (typeof body.settingsSection === "boolean") settingsSection = body.settingsSection;
							if (typeof body.pluginsTab === "boolean") pluginsTab = body.pluginsTab;
							apply();
						}
					}
				} catch {} finally {
					notify();
				}
			};
			/**
			* `set` is serialized because two saves in flight at once each answer the
			* last-door rule from the state before the other one landed. The second
			* save would then be judged against a world that no longer exists — or be
			* discarded by the epoch guard after the server accepted it.
			*/
			let queue = Promise.resolve();
			const serialize = (task) => {
				const run = queue.then(task, task);
				queue = run.then(() => void 0, () => void 0);
				return run;
			};
			const save = async (key, visible) => {
				const at = ++epoch;
				if (!visible) {
					await loadState();
					if (!otherDoorOpen(key)) throw new Error("at least one market entry must stay visible");
				}
				try {
					const response = await fetch(api("/dsh-market/entry-visibility"), {
						method: "POST",
						headers: { "content-type": "application/json" },
						body: JSON.stringify({ [key]: visible })
					});
					let body;
					try {
						body = await response.json();
					} catch {
						throw new Error(`entry visibility: HTTP ${response.status}`);
					}
					if (body.ok !== true || typeof body.settingsSection !== "boolean" || typeof body.pluginsTab !== "boolean") throw new Error(body.error ?? `entry visibility: HTTP ${response.status}`);
					if (at === epoch) {
						settingsSection = body.settingsSection;
						pluginsTab = body.pluginsTab;
						apply();
						notify();
					}
					return key === "settingsSection" ? body.settingsSection : body.pluginsTab;
				} catch (error) {
					await loadState();
					throw error;
				}
			};
			return {
				settingsSection: () => settingsSection,
				pluginsTab: () => pluginsTab,
				settingsSupported: () => settingsSeat,
				settingsAvailable: () => settingsSeat && hostSettings,
				pluginsTabSupported: () => pluginsTabSeat,
				settingsVisible: () => settingsGate.visible(),
				setHostSettingsVisible: (visible) => {
					hostSettings = visible;
					apply();
					notify();
				},
				markSettingsSection: () => {
					settingsSeat = true;
					apply();
					settingsGate.available();
					notify();
				},
				markPluginsTab: () => {
					pluginsTabSeat = true;
					apply();
					pluginsTabGate.available();
					notify();
				},
				otherDoorOpen,
				subscribe: (listener) => {
					listeners.add(listener);
					return () => {
						listeners.delete(listener);
					};
				},
				load: loadState,
				set: (key, visible) => serialize(() => save(key, visible)),
				retire: () => {
					settingsGate.retire();
					pluginsTabGate.retire();
					notify();
				}
			};
		}
		//#endregion
		//#region src/client/SettingsCard.tsx
		/**
		* The market's card on the plugin configuration page (dsh >= 0.1.0-rc.7).
		*
		* It manages the market ITSELF — version, update, remove — when the current
		* profile owns the dependency. A host-provided market keeps only its version
		* display and download-region controls. This page is where a user goes to deal
		* with a plugin,
		* and "which version am I on / update it / get rid of it" is the part of
		* that anybody can act on without knowing how DSH is put together.
		*
		* `allowRestart` deliberately does NOT appear here. It exists for hosts
		* where a supervisor (systemd, launchd, pm2, Docker `restart: always`, a
		* desktop wrapper) owns the process, and its audience is whoever wrote that
		* deployment — a person already editing config, not someone browsing
		* settings. As a switch it read as jargon to everyone else, which is worse
		* than absent: a control you cannot evaluate is a control you cannot safely
		* touch. It remains a config option.
		*
		* ## Why the chrome is hand-built (again), and why it now matches
		*
		* The host's own contract is that "a plugin that ships a browser half owns
		* its own card" — the plugins tab only lays out a flex column and dispatches
		* `settings.plugin.item`. So the container IS ours to draw, and a value
		* import from `dsh-client-ui-settings-plugins` would fail the client
		* bundle-purity gate anyway.
		*
		* What the first version got wrong was drawing something of its own
		* invention: a flat, always-expanded box next to rows that collapse and
		* carry a chevron. The fix is not a different component — `DisclosureRow` is
		* 24px chrome for compact flow rows, a different thing — but the same design
		* tokens, laid out the way the host lays out `PluginCard`. Classes below
		* mirror it one for one, so the market stops looking like it wandered in
		* from another product.
		*/
		/** Keys the market leaves in the browser; cleared when the user purges. */
		const BROWSER_KEYS = ["dshm-webdav", "dshm-gist-id"];
		const CHANNELS = [
			"stable",
			"beta",
			"dev"
		];
		const asChannel = (value) => CHANNELS.includes(value) ? value : null;
		const CHANNEL_LABEL = {
			stable: "setChannelStable",
			beta: "setChannelBeta",
			dev: "setChannelDev"
		};
		const CHANNEL_HINT = {
			stable: "setChannelStableHint",
			beta: "setChannelBetaHint",
			dev: "setChannelDevHint"
		};
		const REGIONS = ["global", "china"];
		const asRegion = (value) => REGIONS.includes(value) ? value : null;
		const REGION_LABEL = {
			global: "setRegionGlobal",
			china: "setRegionChina"
		};
		const REGION_HINT = {
			global: "setRegionGlobalHint",
			china: "setRegionChinaHint"
		};
		/**
		* Read the server's answer, taking the list of channels FROM it.
		*
		* The card does not decide which channels exist: the server is what accepts
		* or refuses a selection, so a card drawing its own list could only ever
		* disagree with it.
		*/
		function readStatus(body) {
			const offered = (body.channels ?? []).map(asChannel).filter((c) => c !== null);
			const regions = (body.regions ?? []).map(asRegion).filter((r) => r !== null);
			return {
				version: body.version ?? null,
				restart: body.restart === true,
				channel: asChannel(body.channel) ?? "stable",
				channels: offered.length > 0 ? offered : ["stable", "beta"],
				region: asRegion(body.region) ?? "global",
				regions: regions.length > 0 ? regions : REGIONS,
				regionAuto: body.regionAuto === true,
				githubProxyCustom: typeof body.githubProxyCustom === "string" ? body.githubProxyCustom : null,
				githubProxyManaged: body.githubProxyManaged === true,
				selfManaged: body.selfManaged !== false,
				offline: body.offline === true,
				selfUninstallReachable: body.selfUninstallReachable !== false,
				buildEnv: body.buildEnv ?? {}
			};
		}
		/** Render the effective build environment as one `KEY=value` line each. */
		function buildEnvToText(env) {
			return Object.entries(env).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, value]) => `${key}=${value}`).join("\n");
		}
		/** Parse a `KEY=value` block back into a map; blank lines are dropped. */
		function buildEnvFromText(text) {
			const out = {};
			for (const line of text.split("\n")) {
				const entry = line.trim();
				if (entry === "") continue;
				const at = entry.indexOf("=");
				if (at <= 0) continue;
				const key = entry.slice(0, at).trim();
				const value = entry.slice(at + 1).trim();
				if (key === "") continue;
				out[key] = value;
			}
			return out;
		}
		function readUpdate(own) {
			return {
				updateAvailable: own.updateAvailable === true,
				latest: own.latest ?? null,
				channelSwitch: own.channelSwitch ?? null,
				restoreRequired: own.restoreRequired === true,
				hostManaged: own.kind === "generation"
			};
		}
		/**
		* Clear the market's browser-side leftovers.
		*
		* These are the only two things the market keeps in the browser, and the
		* server cannot reach either. Neither holds a credential — the WebDAV
		* password is never persisted and a Gist token is read from the environment,
		* never from disk — so this is tidiness, not a security step, and the copy
		* must not imply otherwise.
		*/
		function clearBrowserState(storage) {
			for (const key of BROWSER_KEYS) try {
				storage.removeItem(key);
			} catch {}
		}
		function SettingsCard({ t, onRemoved, sidebar, entries }) {
			const [open, setOpen] = (0, react.useState)(false);
			const [advancedOpen, setAdvancedOpen] = (0, react.useState)(false);
			const advancedId = (0, react.useId)();
			const [, bumpEntries] = (0, react.useState)(0);
			const [entrySaving, setEntrySaving] = (0, react.useState)(0);
			const [sidebarState, setSidebarState] = (0, react.useState)(() => ({
				supported: sidebar?.supported() === true,
				enabled: sidebar?.enabled() === true,
				shown: sidebar?.shown() === true,
				onlyDoor: sidebar?.onlyDoor() === true
			}));
			const [sidebarSaving, setSidebarSaving] = (0, react.useState)(false);
			(0, react.useEffect)(() => {
				if (sidebar === void 0) return void 0;
				const sync = () => {
					setSidebarState({
						supported: sidebar.supported(),
						enabled: sidebar.enabled(),
						shown: sidebar.shown(),
						onlyDoor: sidebar.onlyDoor()
					});
				};
				sync();
				return sidebar.subscribe(sync);
			}, [sidebar]);
			(0, react.useEffect)(() => {
				if (entries === void 0) return void 0;
				return entries.subscribe(() => {
					bumpEntries((v) => v + 1);
				});
			}, [entries]);
			const [status, setStatus] = (0, react.useState)(null);
			const [update, setUpdate] = (0, react.useState)(null);
			const [phase, setPhase] = (0, react.useState)("idle");
			const [restoreConfirming, setRestoreConfirming] = (0, react.useState)(false);
			const [purge, setPurge] = (0, react.useState)(false);
			const [error, setError] = (0, react.useState)(null);
			const [proxyEditing, setProxyEditing] = (0, react.useState)(false);
			const [proxyDraft, setProxyDraft] = (0, react.useState)("");
			const [proxySaving, setProxySaving] = (0, react.useState)(false);
			/** Draft of the build-environment editor (#336), seeded once from status. */
			const [envText, setEnvText] = (0, react.useState)("");
			const envSeeded = (0, react.useRef)(false);
			/**
			* The last self-update was refused by pnpm's fresh-release safety wait
			* (#39). Only the market's own card can update the market, so without a
			* retry here there is NO way to take a just-published version — the
			* discover list's retry button covers every plugin except this one (#255).
			*/
			const [stale, setStale] = (0, react.useState)(false);
			const probed = (0, react.useRef)(false);
			(0, react.useEffect)(() => {
				if (!open || probed.current) return;
				probed.current = true;
				let live = true;
				(async () => {
					try {
						const body = await (await fetch(api("/dsh-market/status"), { cache: "no-store" })).json();
						if (live) setStatus(readStatus(body));
						applyGithubRouting(body);
					} catch {
						if (live) setStatus({
							version: null,
							restart: false,
							channel: "stable",
							channels: ["stable", "beta"],
							region: "global",
							regions: REGIONS,
							regionAuto: false,
							githubProxyCustom: null,
							githubProxyManaged: false,
							selfManaged: true,
							offline: false,
							selfUninstallReachable: true,
							buildEnv: {}
						});
					}
					try {
						const body = await (await fetch(api("/dsh-market/updates"), { cache: "no-store" })).json();
						const own = body.updates?.["dshmarket"] ?? body.updates?.["dsh-market"];
						if (live && own !== void 0) setUpdate(readUpdate(own));
					} catch {}
				})();
				return () => {
					live = false;
				};
			}, [open]);
			const post = (0, react.useCallback)(async (path, payload) => {
				return await (await fetch(path, {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify(payload)
				})).json();
			}, []);
			const onUpdate = (0, react.useCallback)((force = false) => {
				setRestoreConfirming(false);
				setPhase("working");
				setError(null);
				setStale(false);
				(async () => {
					try {
						const body = await post(api("/dsh-market/update"), {
							name: "dshmarket",
							...update?.restoreRequired === true ? { restore: true } : {},
							...force ? { force: true } : {}
						});
						if (body.ok === true) setPhase("updated");
						else {
							setStale(body.stale === true);
							setError(body.error ?? t("setSelfFailed"));
							setPhase("failed");
						}
					} catch (cause) {
						setError(cause instanceof Error ? cause.message : String(cause));
						setPhase("failed");
					}
				})();
			}, [
				post,
				t,
				update?.restoreRequired
			]);
			const onRemove = (0, react.useCallback)(() => {
				setPhase("working");
				setError(null);
				(async () => {
					try {
						const body = await post(api("/dsh-market/self-uninstall"), {
							confirm: true,
							purge
						});
						if (body.ok === true) {
							if (purge) clearBrowserState(localStorage);
							setPhase("removed");
							onRemoved?.();
						} else {
							setError(body.error ?? t("setSelfFailed"));
							setPhase("failed");
						}
					} catch (cause) {
						setError(cause instanceof Error ? cause.message : String(cause));
						setPhase("failed");
					}
				})();
			}, [
				onRemoved,
				post,
				purge,
				t
			]);
			const busy = phase === "working";
			const version = status?.version ?? null;
			const prerelease = version !== null && version.includes("-");
			/** Re-ask what this channel offers; the previous answer was for another one. */
			const refreshUpdate = (0, react.useCallback)(async () => {
				const body = await (await fetch(api("/dsh-market/updates") + "?force=1", { cache: "no-store" })).json();
				const own = body.updates?.["dshmarket"] ?? body.updates?.["dsh-market"];
				setUpdate(own === void 0 ? null : readUpdate(own));
			}, []);
			/**
			* Select a channel — and show the one the SERVER accepted.
			*
			* This used to move the control first and ignore the answer, which was
			* harmless while every channel was permitted. It stopped being harmless
			* the moment one of them can be refused: a 403 would have left "dev"
			* highlighted on a profile that is not on it.
			*/
			const onChannel = (0, react.useCallback)((next) => {
				setError(null);
				(async () => {
					try {
						const body = await post(api("/dsh-market/channel"), { channel: next });
						if (body.ok !== true) {
							setError(body.error ?? t("setSelfFailed"));
							return;
						}
						setStatus((current) => current === null ? current : {
							...current,
							channel: asChannel(body.channel) ?? next
						});
						await refreshUpdate();
					} catch (cause) {
						setError(cause instanceof Error ? cause.message : String(cause));
					}
				})();
			}, [
				post,
				refreshUpdate,
				t
			]);
			/**
			* Select a download region — and show the one the SERVER accepted, on the
			* same reasoning as the channel above.
			*
			* A hand-made choice retires the one-time notice: the market no longer has
			* anything to explain once the user has answered for themselves.
			*/
			const onRegion = (0, react.useCallback)((next) => {
				setError(null);
				(async () => {
					try {
						const body = await post(api("/dsh-market/region"), { region: next });
						if (body.ok !== true) {
							setError(body.error ?? t("setSelfFailed"));
							return;
						}
						const accepted = asRegion(body.region) ?? next;
						setStatus((current) => current === null ? current : {
							...current,
							region: accepted,
							regionAuto: false
						});
						try {
							applyGithubRouting(await (await fetch(api("/dsh-market/status"), { cache: "no-store" })).json());
						} catch {}
					} catch (cause) {
						setError(cause instanceof Error ? cause.message : String(cause));
					}
				})();
			}, [post, t]);
			/** Save or clear the single user-facing GitHub escape route. */
			const onGithubProxy = (0, react.useCallback)((proxy) => {
				setError(null);
				setProxySaving(true);
				(async () => {
					try {
						const body = await post(api("/dsh-market/github-proxy"), { proxy });
						if (body.ok !== true) {
							setError(body.error ?? t("setSelfFailed"));
							return;
						}
						const statusBody = await (await fetch(api("/dsh-market/status"), { cache: "no-store" })).json();
						setStatus(readStatus(statusBody));
						applyGithubRouting(statusBody);
						setProxyEditing(false);
					} catch (cause) {
						setError(cause instanceof Error ? cause.message : String(cause));
					} finally {
						setProxySaving(false);
					}
				})();
			}, [post, t]);
			/**
			* Seed the build-environment editor from the server's effective value —
			* ONCE. The draft is the user's to edit from then on; the status refetch
			* after a save updates it explicitly instead.
			*/
			(0, react.useEffect)(() => {
				if (status === null || envSeeded.current) return;
				envSeeded.current = true;
				setEnvText(buildEnvToText(status.buildEnv));
			}, [status]);
			/** Save the draft build environment; an empty list clears it (#336). */
			const onSaveEnv = (0, react.useCallback)(async () => {
				setError(null);
				try {
					const body = await post(api("/dsh-market/build-env"), { buildEnv: buildEnvFromText(envText) });
					if (body.ok !== true) {
						setError(body.error ?? t("setSelfFailed"));
						return;
					}
					setEnvText(buildEnvToText(body.buildEnv ?? {}));
				} catch (cause) {
					setError(cause instanceof Error ? cause.message : String(cause));
				}
			}, [
				envText,
				post,
				t
			]);
			const onSidebar = (0, react.useCallback)((next) => {
				if (sidebar === void 0) return;
				setError(null);
				setSidebarSaving(true);
				(async () => {
					try {
						if (!next && entries !== void 0) {
							await entries.load();
							if (!entries.otherDoorOpen("sidebar")) {
								setError(t("setEntryLastDoorHint"));
								return;
							}
						}
						await sidebar.set(next);
					} catch (cause) {
						setError(cause instanceof Error ? cause.message : String(cause));
					} finally {
						setSidebarSaving(false);
					}
				})();
			}, [
				entries,
				sidebar,
				t
			]);
			const onEntry = (0, react.useCallback)((key, next) => {
				if (entries === void 0) return;
				setError(null);
				setEntrySaving((count) => count + 1);
				(async () => {
					try {
						await entries.set(key, next);
					} catch (cause) {
						setError(cause instanceof Error ? cause.message : String(cause));
					} finally {
						setEntrySaving((count) => count - 1);
					}
				})();
			}, [entries]);
			/** One label + hint block with an optional action, the host's row shape. */
			const row = (label, hint, action) => (0, react.createElement)("div", { className: Market_module_css_default.setRow }, (0, react.createElement)("div", { className: Market_module_css_default.setLabelBox }, (0, react.createElement)("div", { className: Market_module_css_default.setLabel }, label), (0, react.createElement)("div", { className: Market_module_css_default.setHint }, hint)), action);
			/**
			* A Show/Hide pair. `canHide` disables only the OFF half: the entry that
			* is currently on stays clickable, and the rule "at least one door stays
			* open" is what the OFF button reflects.
			*/
			const toggle = (on, saving, canHide, labels, pick) => (0, react.createElement)("div", { className: Market_module_css_default.setSeg }, [false, true].map((value) => (0, react.createElement)("button", {
				key: String(value),
				type: "button",
				className: on === value ? `${Market_module_css_default.setSegBtn} ${Market_module_css_default.setSegOn}` : Market_module_css_default.setSegBtn,
				disabled: busy || saving || value === false && !canHide,
				"aria-pressed": on === value,
				onClick: () => {
					if (on !== value) pick(value);
				}
			}, value ? labels.show : labels.hide)));
			/** One of the two page entries (#1015), with the last-door rule applied. */
			const entryRow = (key, label, hint, on) => {
				const canHide = entries?.otherDoorOpen(key) === true;
				return row(label, canHide ? hint : `${hint} ${t("setEntryLastDoorHint")}`, toggle(on, entriesBusy, canHide, {
					show: t("setEntryShow"),
					hide: t("setEntryHide")
				}, (next) => onEntry(key, next)));
			};
			const entriesBusy = entrySaving > 0 || sidebarSaving;
			const entryRows = [];
			if (entries !== void 0) {
				if (entries.settingsAvailable()) entryRows.push(entryRow("settingsSection", t("setEntrySection"), t("setEntrySectionHint"), entries.settingsSection()));
				if (entries.pluginsTabSupported()) entryRows.push(entryRow("pluginsTab", t("setEntryPluginsTab"), t("setEntryPluginsTabHint"), entries.pluginsTab()));
			}
			if (sidebarState.supported) {
				const canHide = entries === void 0 || entries.otherDoorOpen("sidebar");
				entryRows.push(row(t("setSidebar"), sidebarState.onlyDoor ? t("setSidebarOnlyDoorHint") : canHide ? t("setSidebarHint") : `${t("setSidebarHint")} ${t("setEntryLastDoorHint")}`, toggle(sidebarState.shown, entriesBusy, canHide, {
					show: t("setSidebarOn"),
					hide: t("setSidebarOff")
				}, onSidebar)));
			}
			const advanced = entryRows.length > 0 ? (0, react.createElement)("div", { className: Market_module_css_default.setAdvanced }, (0, react.createElement)("button", {
				type: "button",
				className: Market_module_css_default.setAdvancedHead,
				"aria-expanded": advancedOpen,
				"aria-controls": advancedId,
				"aria-label": t("setAdvanced"),
				onClick: () => {
					setAdvancedOpen((value) => !value);
				}
			}, (0, react.createElement)("div", { className: Market_module_css_default.setLabelBox }, (0, react.createElement)("div", { className: Market_module_css_default.setLabel }, t("setAdvanced")), (0, react.createElement)("div", { className: Market_module_css_default.setHint }, t("setAdvancedHint"))), (0, react.createElement)("span", { className: advancedOpen ? `${Market_module_css_default.setChevron} ${Market_module_css_default.setChevronOpen}` : Market_module_css_default.setChevron }, (0, react.createElement)(IconChevronDownOutline14, { size: 14 }))), advancedOpen ? (0, react.createElement)("div", {
				id: advancedId,
				className: Market_module_css_default.setAdvancedBody
			}, entryRows.map((node, index) => (0, react.createElement)(react.Fragment, { key: index }, node))) : null) : null;
			const body = phase === "removed" ? row(t("setSelfRemoved"), t("setSelfRemovedHint"), null) : (0, react.createElement)(react.Fragment, null, advanced, status?.offline === true ? null : row(t("setIndexSource"), t("setIndexSourceHint"), null), status?.selfManaged === true ? row((update?.updateAvailable === true || update?.hostManaged === true) && update.latest !== null ? `${t("setSelfUpdateReady")} ${update.latest}` : update?.channelSwitch != null ? `${t("setChannelSwitch")} ${update.channelSwitch}` : t("setSelfUpToDate"), phase === "updated" ? t("setSelfUpdatedHint") : update?.channelSwitch != null ? t("setChannelSwitchHint") : update?.updateAvailable === true ? t("setSelfUpdateHint") : update?.hostManaged === true && update.latest !== null ? t("setSelfHostManagedHint") : t("setSelfUpToDateHint"), phase === "updated" ? null : update?.updateAvailable === true ? (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "primary",
				size: "sm",
				disabled: busy,
				onClick: () => {
					if (update.restoreRequired) setRestoreConfirming(true);
					else onUpdate();
				}
			}, update.restoreRequired ? t("restoreOnline") : t("setSelfUpdate")) : update?.channelSwitch != null ? (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "outline",
				size: "sm",
				disabled: busy,
				onClick: () => onUpdate()
			}, t("setChannelSwitch")) : null) : null, status?.selfManaged === true && restoreConfirming ? (0, react.createElement)("div", { className: Market_module_css_default.setConfirm }, (0, react.createElement)("div", { className: Market_module_css_default.setHint }, t("restoreHint")), (0, react.createElement)("div", { className: Market_module_css_default.setActions }, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "ghost",
				size: "sm",
				onClick: () => {
					setRestoreConfirming(false);
				}
			}, t("setSelfCancel")), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "primary",
				size: "sm",
				onClick: () => onUpdate()
			}, t("restoreContinue")))) : null, status?.selfManaged === true ? row(t("setChannel"), t(CHANNEL_HINT[status.channel]), (0, react.createElement)("div", { className: Market_module_css_default.setSeg }, (status?.channels ?? ["stable", "beta"]).map((id) => (0, react.createElement)("button", {
				key: id,
				type: "button",
				className: status?.channel === id ? `${Market_module_css_default.setSegBtn} ${Market_module_css_default.setSegOn}` : Market_module_css_default.setSegBtn,
				disabled: busy || status === null,
				title: id === "dev" ? t("setChannelDevHint") : void 0,
				onClick: () => {
					onChannel(id);
				}
			}, t(CHANNEL_LABEL[id]))))) : null, status?.offline === true ? null : row(t("setRegion"), status?.regionAuto === true ? `${t(REGION_HINT[status.region])} ${t("setRegionAuto")}` : t(REGION_HINT[status?.region ?? "global"]), (0, react.createElement)("div", { className: Market_module_css_default.setSeg }, (status?.regions ?? REGIONS).map((id) => (0, react.createElement)("button", {
				key: id,
				type: "button",
				className: status?.region === id ? `${Market_module_css_default.setSegBtn} ${Market_module_css_default.setSegOn}` : Market_module_css_default.setSegBtn,
				disabled: busy || status === null,
				onClick: () => {
					onRegion(id);
				}
			}, t(REGION_LABEL[id]))))), status?.offline === true ? null : row(t("setGithubProxy"), status?.githubProxyManaged === true ? t("setGithubProxyManagedHint") : status?.githubProxyCustom !== null && status?.githubProxyCustom !== void 0 ? t("setGithubProxyCustomHint") : t("setGithubProxyAutoHint"), status?.githubProxyManaged === true ? null : status?.githubProxyCustom !== null && status?.githubProxyCustom !== void 0 ? (0, react.createElement)("div", { className: Market_module_css_default.setInlineActions }, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "outline",
				size: "sm",
				disabled: proxySaving,
				onClick: () => {
					setProxyDraft(status.githubProxyCustom ?? "");
					setProxyEditing(true);
				}
			}, t("setGithubProxyEdit")), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "ghost",
				size: "sm",
				disabled: proxySaving,
				onClick: () => {
					onGithubProxy(null);
				}
			}, t("setGithubProxyAuto"))) : (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "outline",
				size: "sm",
				disabled: status === null || proxySaving,
				onClick: () => {
					setProxyDraft("");
					setProxyEditing(true);
				}
			}, t("setGithubProxyCustom"))), proxyEditing && status?.githubProxyManaged !== true ? (0, react.createElement)("div", { className: Market_module_css_default.setProxyEditor }, (0, react.createElement)("label", { className: Market_module_css_default.setProxyLabel }, t("setGithubProxyInput"), (0, react.createElement)("input", {
				className: Market_module_css_default.setProxyInput,
				type: "url",
				value: proxyDraft,
				placeholder: "https://mirror.example",
				"aria-label": t("setGithubProxyInput"),
				disabled: proxySaving,
				onChange: (event) => {
					setProxyDraft(event.currentTarget.value);
				}
			})), (0, react.createElement)("div", { className: Market_module_css_default.setInlineActions }, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "ghost",
				size: "sm",
				disabled: proxySaving,
				onClick: () => {
					setProxyEditing(false);
				}
			}, t("setSelfCancel")), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "primary",
				size: "sm",
				disabled: proxySaving || proxyDraft.trim() === "",
				onClick: () => {
					onGithubProxy(proxyDraft);
				}
			}, t("setGithubProxySave")))) : null, (0, react.createElement)("div", { className: Market_module_css_default.setConfirm }, (0, react.createElement)("div", { className: Market_module_css_default.setLabel }, t("setBuildEnv")), (0, react.createElement)("div", { className: Market_module_css_default.setHint }, t("setBuildEnvHint")), (0, react.createElement)("textarea", {
				className: Market_module_css_default.envEditor,
				rows: 3,
				spellCheck: false,
				"aria-label": t("setBuildEnv"),
				value: envText,
				disabled: busy || status === null,
				placeholder: "CC=/usr/bin/gcc-11\nCXX=/usr/bin/g++-11",
				onChange: (event) => {
					setEnvText(event.target.value);
				}
			}), (0, react.createElement)("div", { className: Market_module_css_default.setActions }, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "primary",
				size: "sm",
				disabled: busy || status === null,
				onClick: () => {
					onSaveEnv();
				}
			}, t("setBuildEnvSave")))), status?.selfManaged === true ? row(t("setSelfRemove"), status.selfUninstallReachable ? t("setSelfRemoveHint") : t("setSelfRemoveRemote"), status.selfUninstallReachable && phase !== "confirming" && !busy ? (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "outline",
				size: "sm",
				className: Market_module_css_default.setDanger,
				disabled: busy,
				onClick: () => {
					setPhase("confirming");
				}
			}, t("setSelfRemove")) : null) : null, status?.selfManaged === true && status.selfUninstallReachable && (phase === "confirming" || busy) ? (0, react.createElement)("div", { className: Market_module_css_default.setConfirm }, (0, react.createElement)("div", { className: Market_module_css_default.setHint }, t("setSelfConfirm")), (0, react.createElement)("label", { className: Market_module_css_default.setCheck }, (0, react.createElement)("input", {
				type: "checkbox",
				checked: purge,
				onChange: () => {
					setPurge(!purge);
				}
			}), (0, react.createElement)("span", null, t("setSelfPurge"))), (0, react.createElement)("div", { className: Market_module_css_default.setHint }, purge ? t("setSelfPurgeOn") : t("setSelfPurgeOff")), (0, react.createElement)("div", { className: Market_module_css_default.setActions }, busy ? null : (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "ghost",
				size: "sm",
				onClick: () => {
					setPhase("idle");
					setPurge(false);
				}
			}, t("setSelfCancel")), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "primary",
				size: "sm",
				className: Market_module_css_default.setDanger,
				disabled: busy,
				icon: busy ? (0, react.createElement)("span", { className: Market_module_css_default.spin }, (0, react.createElement)(IconLoadingOutline16, { size: 16 })) : void 0,
				onClick: onRemove
			}, busy ? t("setSelfWorking") : t("setSelfRemoveConfirm")))) : null, error !== null ? (0, react.createElement)("div", { className: Market_module_css_default.err }, error) : null, stale ? (0, react.createElement)("div", { className: Market_module_css_default.setActions }, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "primary",
				size: "sm",
				onClick: () => onUpdate(true)
			}, t("updateNow"))) : null);
			return (0, react.createElement)("div", { className: open ? `${Market_module_css_default.setCard} ${Market_module_css_default.setCardOpen}` : Market_module_css_default.setCard }, (0, react.createElement)("button", {
				type: "button",
				className: Market_module_css_default.setHeader,
				"aria-expanded": open,
				onClick: () => {
					setOpen(!open);
				}
			}, (0, react.createElement)("div", { className: Market_module_css_default.setHeadText }, (0, react.createElement)("div", { className: Market_module_css_default.setName }, t("nav"), version !== null ? (0, react.createElement)("span", { className: Market_module_css_default.version }, ` v${version}`) : null, prerelease ? (0, react.createElement)("span", { className: Market_module_css_default.setBetaTag }, t("setChannelBeta")) : null), (0, react.createElement)("div", { className: Market_module_css_default.setDesc }, t("setCardDesc"))), (0, react.createElement)("span", { className: open ? `${Market_module_css_default.setChevron} ${Market_module_css_default.setChevronOpen}` : Market_module_css_default.setChevron }, (0, react.createElement)(IconChevronDownOutline14, { size: 14 }))), open ? (0, react.createElement)("div", { className: Market_module_css_default.setBody }, body) : null);
		}
		//#endregion
		//#region src/client/SourceRepoLink.tsx
		/**
		* "View source" on the host's plugin detail page: its own source fact is an
		* install spec, a version range nobody can open. Resolved per installed
		* package; absent when nothing declares a repository.
		*/
		/** Answers already read, by package name. Only definite ones are cached, so a failed request retries. */
		const resolved = /* @__PURE__ */ new Map();
		function SourceRepoLink(props) {
			const { name, t } = props;
			const [url, setUrl] = (0, react.useState)(() => resolved.get(name) ?? null);
			(0, react.useEffect)(() => {
				const known = resolved.get(name);
				if (known !== void 0) {
					setUrl(known);
					return;
				}
				let live = true;
				fetch(`${api("/dsh-market/source-repo")}?name=${encodeURIComponent(name)}`).then(async (res) => res.ok ? await res.json() : null).then((body) => {
					const next = typeof body?.url === "string" && body.url.startsWith("https://") ? body.url : null;
					resolved.set(name, next);
					if (live) setUrl(next);
				}).catch(() => {});
				return () => {
					live = false;
				};
			}, [name]);
			if (url === null) return null;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
				className: Market_module_css_default.sourceRepo,
				href: url,
				target: "_blank",
				rel: "noreferrer",
				children: t("viewSourceRepo")
			});
		}
		//#endregion
		//#region src/client/settings-nav-icon.ts
		/**
		* The market's block mark in the settings navigation.
		*
		* Hosts before dsh 0.2.2 pick nav glyphs from a closed list of section ids
		* (`models`, `agent-presets`, `plugins`) and fall back to the gear for every
		* other id. `settings.section` on those hosts projects only `id` / `order` /
		* `label`, so a registrant has no icon to pass. Every third-party section
		* therefore wears the gear, the market included.
		*
		* So the market claims its own row once the dialog is mounted and swaps the
		* fallback gear for the block mark — the same mark `MarketLogo` draws inside
		* the section (see market-mark.ts), which is what makes the nav entry read as
		* the same thing as the page it opens. `dsh-better-sidebar` and
		* `dsh-skill-mcp-panel` solve it the same way.
		*
		* Scope, deliberately narrow:
		*
		* - only the row whose visible text equals this plugin's own localized
		*   section label is marked; no shell structure is touched;
		* - the marker and the injected stylesheet belong to a `ctx.effect`, so they
		*   are removed with the fiber;
		* - a locale switch re-claims the row through the MutationObserver, so the
		*   label and the glyph never disagree.
		*
		* dsh 0.2.2 grew a real icon seat (`settings.section.icon`) and wrapped the
		* fallback gear, so this stand-in no longer lines up with that shell — the
		* caller keeps it only for hosts that never declare the seat. Delete this
		* module once those hosts are gone.
		*/
		/** Marks the one nav row this plugin owns. */
		const NAV_ICON_MARKER = "data-dsh-market-nav-icon";
		/**
		* The nav rows of the settings dialog. The shell renders each
		* `settings.section` entry as a `<button>` inside the panel's `<nav>`
		* (SettingsPanel in dsh-client-ui-settings-general).
		*/
		const NAV_ROW_SELECTOR = "[role=\"dialog\"] nav button";
		/**
		* The mark as standalone SVG for a CSS `mask-image`.
		*
		* Painted pure black on purpose: a mask reads alpha only, and the visible
		* colour comes from the element's `background-color: currentColor`. The
		* plug block carries its tilt without the animated variant's transform
		* classes — a mask cannot animate through CSS-module classes.
		*/
		function marketMaskSvg() {
			const blocks = MARK_GRID_BLOCKS.map((block) => `<rect x="${block.x}" y="${block.y}" width="${MARK_BLOCK_SIZE}" height="${MARK_BLOCK_SIZE}" rx="${MARK_BLOCK_RADIUS}"/>`).join("");
			const plug = MARK_PLUG_BLOCK;
			return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="#000"><g>${blocks}</g><rect x="${plug.x}" y="${plug.y}" width="${MARK_BLOCK_SIZE}" height="${MARK_BLOCK_SIZE}" rx="${MARK_BLOCK_RADIUS}" transform="rotate(${plug.degrees} ${plug.originX} ${plug.originY})"/></svg>`;
		}
		/** The mask URL for the mark (encoded at runtime, never hand-escaped). */
		function marketMaskUrl(svg = marketMaskSvg()) {
			return `data:image/svg+xml,${encodeURIComponent(svg)}`;
		}
		/**
		* Whether a nav row is this plugin's own.
		*
		* Pure, and the only decision this feature makes: the row whose visible text
		* is the section label the shell is currently projecting. An empty label
		* matches nothing — a locale that has not resolved yet must not mark the
		* whole nav.
		*/
		function isOwnNavRow(rowText, wantedLabel) {
			const wanted = String(wantedLabel ?? "").trim();
			if (wanted.length === 0) return false;
			return String(rowText ?? "").trim() === wanted;
		}
		/** Stylesheet for the marked row: hide the shell's gear, draw the mark. */
		function navIconCss(maskUrl) {
			return [
				`[${NAV_ICON_MARKER}] > svg { display: none; }`,
				`[${NAV_ICON_MARKER}]::before {`,
				`  content: '';`,
				`  flex: none;`,
				`  width: 16px;`,
				`  height: 16px;`,
				`  background-color: currentColor;`,
				`  -webkit-mask-image: url("${maskUrl}");`,
				`  mask-image: url("${maskUrl}");`,
				`  -webkit-mask-repeat: no-repeat;`,
				`  mask-repeat: no-repeat;`,
				`  -webkit-mask-position: center;`,
				`  mask-position: center;`,
				`  -webkit-mask-size: 16px 16px;`,
				`  mask-size: 16px 16px;`,
				`}`
			].join("\n");
		}
		/**
		* Install the nav glyph.
		*
		* @param ctx - client context, for effect ownership.
		* @param resolveLabel - this plugin's current section label (the same thunk
		*   the `settings.section` registration passes), re-read on every sync so a
		*   locale switch is picked up without re-registering.
		* @returns a stopper. Calling it removes the marker and the stylesheet; the
		*   fiber's own disposal does the same, and either one is safe to repeat.
		*   The caller uses it when a host that looked old turns out to paint icons
		*   itself.
		*/
		function installSettingsNavIcon(ctx, resolveLabel) {
			if (typeof document === "undefined") return () => {};
			let dispose = () => {};
			ctx.effect(() => {
				const tag = document.createElement("style");
				tag.dataset.plugin = "dshmarket";
				tag.dataset.pluginCss = "dshmarket/settings-nav-icon";
				tag.textContent = navIconCss(marketMaskUrl());
				document.head.appendChild(tag);
				let disposed = false;
				let scheduled = false;
				const sync = () => {
					scheduled = false;
					if (disposed) return;
					const wanted = resolveLabel();
					for (const row of document.querySelectorAll(NAV_ROW_SELECTOR)) if (isOwnNavRow(row.textContent, wanted)) row.setAttribute(NAV_ICON_MARKER, "");
					else row.removeAttribute(NAV_ICON_MARKER);
				};
				const schedule = () => {
					if (scheduled || disposed) return;
					scheduled = true;
					queueMicrotask(sync);
				};
				sync();
				const observer = new MutationObserver(schedule);
				observer.observe(document.body, {
					childList: true,
					subtree: true,
					characterData: true
				});
				const cleanup = () => {
					if (disposed) return;
					disposed = true;
					observer.disconnect();
					for (const row of document.querySelectorAll(`[${NAV_ICON_MARKER}]`)) row.removeAttribute(NAV_ICON_MARKER);
					tag.remove();
				};
				dispose = cleanup;
				return cleanup;
			}, "dsh-market: settings nav icon");
			return () => {
				dispose();
			};
		}
		//#endregion
		//#region src/client/host-navigation.ts
		function createHostNavigation() {
			let navigation;
			const listeners = /* @__PURE__ */ new Set();
			return {
				get: () => navigation,
				subscribe: (listener) => {
					listeners.add(listener);
					return () => {
						listeners.delete(listener);
					};
				},
				attach: (next) => {
					navigation = next;
					for (const listener of [...listeners]) listener();
				}
			};
		}
		//#endregion
		//#region src/client/sidebar-entry.ts
		/**
		* The market's own row in the sidebar (#846), beside the host's Plugins page.
		*
		* Off by default: the sidebar's global rows are the host's own pages, and
		* installing plugins is occasional, so the row is something a user turns on
		* in the market's settings card. The page entries (Settings, and the host's
		* Plugins tab where it exists) are the defaults; the card refuses to let
		* the last open door close, this row included (#1015).
		*
		* Two facts decide whether the row exists, and they arrive independently:
		* whether the host declares `sidebar.panellist` at all (hosts before the
		* Plugins page moved to the sidebar do not), and what the user chose, which
		* is read from the server. The section gate already owns that ordering
		* problem for the settings entry; this reuses it with the opposite default.
		*
		* Opening the row selects a `main` panel, so the market renders as a page —
		* the only one-click destination the host's public contracts allow. A
		* settings-dialog shortcut is not possible: the dialog's state is private
		* to the host's settings shell.
		*/
		/** The `main` key and `sidebar.panellist` id this package registers. */
		const SIDEBAR_PANEL_ID = "dsh-market";
		function createSidebarEntry({ gate, fetch, hasOtherSeat }) {
			const otherSeat = hasOtherSeat ?? (() => true);
			let supported = false;
			let enabled = false;
			let ready = false;
			/** The user has ever answered; an absent choice is not an "off". */
			let chosen = false;
			/** Bumped by every `set` so a slow initial `load` cannot overwrite it. */
			let epoch = 0;
			const listeners = /* @__PURE__ */ new Set();
			const notify = () => {
				for (const listener of listeners) listener();
			};
			/**
			* One place that answers "is the row shown": the user's own choice wins;
			* with no choice on record, the row is shown exactly when it is the only
			* way into the market.
			*/
			const decide = () => {
				if (!supported) return;
				gate.setVisible(enabled || !chosen && !otherSeat());
				notify();
			};
			const settle = () => {
				if (ready) return;
				ready = true;
				notify();
			};
			return {
				supported: () => supported,
				enabled: () => enabled,
				shown: () => gate.visible(),
				ready: () => ready,
				onlyDoor: () => !otherSeat(),
				subscribe: (listener) => {
					listeners.add(listener);
					return () => {
						listeners.delete(listener);
					};
				},
				markSupported: () => {
					supported = true;
					gate.available();
					decide();
				},
				refresh: () => {
					decide();
				},
				load: async () => {
					const at = epoch;
					try {
						const response = await fetch(api("/dsh-market/sidebar-entry"), { cache: "no-store" });
						if (response.ok) {
							const body = await response.json();
							if (at === epoch) {
								enabled = body.enabled === true;
								chosen = body.chosen === true;
								decide();
							}
						}
					} catch {} finally {
						settle();
					}
				},
				set: async (next) => {
					const at = ++epoch;
					const response = await fetch(api("/dsh-market/sidebar-entry"), {
						method: "POST",
						headers: { "content-type": "application/json" },
						body: JSON.stringify({ enabled: next })
					});
					let body;
					try {
						body = await response.json();
					} catch {
						throw new Error(`sidebar entry: HTTP ${response.status}`);
					}
					if (body.ok !== true || typeof body.enabled !== "boolean") throw new Error(body.error ?? `sidebar entry: HTTP ${response.status}`);
					if (at === epoch) {
						enabled = body.enabled;
						chosen = true;
						decide();
					}
					settle();
					return body.enabled;
				}
			};
		}
		//#endregion
		//#region src/client/index.ts
		/**
		* dsh-market client: registers a "Market" settings section rendering the
		* plugin market UI, plus the post-install toast in the shell overlay layer.
		* Built by tsdown into the __ModuleLoader__ factory bundle at
		* client/client.js; the only externals are the loader module table's react
		* entries.
		*/
		const NS = "dsh-market";
		/**
		* Primitives this bundle relies on that did not exist before rc.6. The
		* primitives module is host-injected (external at build time), so on an
		* older host the module resolves but these named exports are undefined —
		* rendering would throw and blank the whole settings dialog. Returning the
		* gaps lets apply() skip registration for a clean downgrade instead.
		*/
		const REQUIRED_PRIMITIVES = [
			"Menu",
			"DisclosureRow",
			"Tooltip",
			"Toast"
		];
		function missingPrimitives(mod, required = REQUIRED_PRIMITIVES) {
			return required.filter((name) => mod[name] === void 0);
		}
		/**
		* The package name the host keys a bundle's own configuration by.
		*
		* `plugins.bundle.config` on dsh 0.1.7+ is keyed by the BUNDLE's package
		* name. The market's is `dshmarket` — the name `dsh plugin add dshmarket`
		* installs and the one its own `package.json` declares — which is not the
		* same string as the locale namespace (`dsh-market`) this file uses for copy.
		*/
		const MARKET_PACKAGE_NAME = "dshmarket";
		const name = "dsh-market";
		const inject = [
			"slots",
			"locale",
			"theme"
		];
		function apply(ctx) {
			const mod = _deepseek_ai_dsh_client_ui_primitives;
			const gaps = missingPrimitives(mod);
			if (gaps.length > 0) {
				console.warn("[dsh-market] host ui-primitives missing " + gaps.join(", ") + " — market section disabled (dsh web >= 0.1.0-rc.6 required)");
				return;
			}
			const iconGaps = missingIcons(mod);
			if (iconGaps.length > 0) console.warn("[dsh-market] host ui-primitives missing icons " + iconGaps.join(", ") + " — rendering without them");
			try {
				mountMarket(ctx);
			} catch (error) {
				console.error("[dsh-market] mounting failed, so the market is missing for this session. The rest of the app is unaffected. Report at https://github.com/dsh-market/dsh-market/issues with this line and the stack below:", error);
			}
		}
		/**
		* The market's mounts, split out only so apply() can contain a throw from any
		* of them. Not exported: the split is a guard, not a surface.
		*/
		function mountMarket(ctx) {
			ctx.effect(() => ctx.locale.register(NS, {
				zh,
				en,
				ja
			}), "dsh-market: dictionaries");
			const t = ctx.locale.bind(NS);
			let stopNavStandIn;
			let hostPaintsNavIcon = false;
			ctx.slots.inject("settings.section.icon", () => {
				hostPaintsNavIcon = true;
				stopNavStandIn?.();
				stopNavStandIn = void 0;
				const off = ctx.slots.register({
					name: "settings.section.icon",
					id: "market"
				}, (owner = {}) => (0, react.createElement)(MarketLogo, { size: owner.size ?? 16 }));
				return typeof off === "function" ? off : () => {};
			});
			if (!hostPaintsNavIcon) stopNavStandIn = installSettingsNavIcon(ctx, () => t("nav"));
			let sidebar;
			/**
			* The host's `pluginNavigation` (dsh 0.2.1+), published as a store so the
			* panel's menus can offer "在插件页查看" whether the service is there before
			* or after this package mounts. See host-navigation.ts.
			*/
			const hostNavigation = createHostNavigation();
			/**
			* The market's own panel, as an element — one builder for the settings
			* section this package registers and for `market.render()` (#602). Built
			* per call: the props are live (locale, theme, the host's preferred
			* subsection), and a cached element would freeze the first caller's.
			*/
			const buildMarketElement = (ownerProps = {}) => marketElement({
				t,
				locale: ctx.locale,
				theme: ctx.theme,
				themeStore: {
					subscribe: (cb) => ctx.on("theme/change", cb),
					getSnapshot: () => ctx.theme.getTheme()
				},
				crashText: {
					title: t("crashTitle"),
					hint: t("crashHint"),
					reload: t("crashReload"),
					details: t("crashDetails")
				},
				exportLog: () => {
					exportMarketLog().catch(() => {});
				},
				preferredSubsectionId: ownerProps.preferredSubsectionId,
				sidebar,
				hostNavigation,
				surface: ownerProps.surface ?? "settings"
			});
			const entries = createEntryVisibility({
				settingsGate: createSectionGate(() => {
					const off = ctx.slots.register({
						name: "settings.section",
						id: "market",
						order: 40,
						label: () => t("nav"),
						locale: NS,
						inject: () => ({ t })
					}, (ownerProps = {}) => buildMarketElement({
						...ownerProps,
						surface: "settings"
					}));
					return typeof off === "function" ? off : () => {};
				}),
				pluginsTabGate: createSectionGate(() => {
					const off = ctx.slots.register({
						name: "plugins.tab",
						id: NS,
						order: -1,
						label: () => t("nav"),
						locale: NS,
						inject: () => ({ t })
					}, () => buildMarketElement({ surface: "plugins" }));
					return typeof off === "function" ? off : () => {};
				}),
				fetch: (...args) => fetch(...args),
				sidebarSupported: () => sidebar?.supported() === true,
				sidebarShown: () => sidebar?.shown() === true
			});
			entries.load();
			ctx.slots.inject("settings.section", () => {
				entries.markSettingsSection();
				sidebar?.refresh();
			});
			let layout;
			const sidebarGate = createSectionGate(() => {
				const offPanel = ctx.slots.register({
					name: "main",
					key: SIDEBAR_PANEL_ID,
					locale: NS,
					inject: () => ({ t })
				}, () => (0, react.createElement)("div", { className: Market_module_css_default.panelHost }, buildMarketElement({ surface: "sidebar" })));
				const offRow = ctx.slots.register({
					name: "sidebar.panellist",
					id: SIDEBAR_PANEL_ID,
					order: 1,
					label: () => t("nav"),
					locale: NS
				}, ((owner = {}) => (0, react.createElement)(MarketLogo, { size: owner.size ?? 16 })));
				return () => {
					if (layout?.panelInfo.getSnapshot().activePanelId === "dsh-market") layout.selectPanel(null);
					if (typeof offRow === "function") offRow();
					if (typeof offPanel === "function") offPanel();
				};
			}, false);
			sidebar = createSidebarEntry({
				gate: sidebarGate,
				fetch: (...args) => fetch(...args),
				hasOtherSeat: () => entries.settingsSupported() || entries.pluginsTabSupported()
			});
			sidebar.load();
			ctx.slots.inject("sidebar.panellist", () => {
				sidebar?.markSupported();
			});
			setTimeout(() => {
				sidebar?.refresh();
			}, 0);
			ctx.inject(["layout"], (scoped) => {
				layout = scoped.layout;
			});
			ctx.inject(["pluginNavigation"], (scoped) => {
				hostNavigation.attach({ openBundle: (name) => {
					scoped.pluginNavigation.openBundle(name);
				} });
			});
			const retire = () => {
				entries.retire();
				sidebarGate.retire();
			};
			const marketControl = {
				version: 1,
				setSettingsVisible: (visible) => {
					entries.setHostSettingsVisible(visible);
				},
				settingsVisible: () => entries.settingsVisible(),
				/**
				* The market's panel as an element, for a host that renders it inside
				* its own container. Same page, same React instance — this package's
				* bundle resolves react through the host's module table, so an element
				* returned here mounts anywhere in that tree.
				*
				* What it is NOT: a way to rearrange the market. It hands over the whole
				* panel, chrome included. Cutting the market into host-fillable regions
				* is a different design and has not been asked for by a second host yet.
				*/
				render: (props = {}) => buildMarketElement(props)
			};
			if (typeof ctx.provide === "function") ctx.provide("market", marketControl);
			ctx.inject(["settingsScope"], (scoped) => {
				scoped.slots.inject("settings.plugin.item", () => scoped.slots.register({
					name: "settings.plugin.item",
					key: NS,
					locale: NS,
					inject: () => ({ t })
				}, () => (0, react.createElement)(SettingsCard, {
					t,
					sidebar,
					entries,
					onRemoved: retire
				})));
			});
			const bundleConfigCtx = ctx;
			bundleConfigCtx.slots.inject("plugins.bundle.config", () => bundleConfigCtx.slots.register({
				name: "plugins.bundle.config",
				key: MARKET_PACKAGE_NAME,
				locale: NS,
				inject: () => ({ t })
			}, (ownerProps = {}) => ownerProps.view === "summary" ? null : (0, react.createElement)(SettingsCard, {
				t,
				sidebar,
				entries,
				onRemoved: retire
			})));
			const pluginsTabCtx = ctx;
			pluginsTabCtx.slots.inject("settings.plugins.tab", () => pluginsTabCtx.slots.register({
				name: "settings.plugins.tab",
				id: NS,
				order: 60,
				label: () => t("nav"),
				locale: NS,
				inject: () => ({ t })
			}, () => (0, react.createElement)(SettingsCard, {
				t,
				sidebar,
				entries,
				onRemoved: retire
			})));
			ctx.slots.inject("plugins.tab", () => {
				entries.markPluginsTab();
				sidebar?.refresh();
			});
			const detailSectionCtx = ctx;
			detailSectionCtx.slots.inject("plugins.detail.section", () => detailSectionCtx.slots.register({
				name: "plugins.detail.section",
				id: "dsh-market-source",
				order: 90,
				locale: NS,
				inject: () => ({ t })
			}, (ownerProps = {}) => {
				const name = ownerProps.subject?.pkg?.name;
				return name === void 0 ? null : (0, react.createElement)(SourceRepoLink, {
					name,
					t
				});
			}));
			const Toast = () => (0, react.createElement)(InstallToast, { t });
			ctx.slots.inject("shell.overlay", () => ctx.slots.register({
				name: "shell.overlay",
				id: "dsh-market-toast",
				label: () => "dsh-market"
			}, Toast));
		}
		//#endregion
		exports.REQUIRED_PRIMITIVES = REQUIRED_PRIMITIVES;
		exports.apply = apply;
		exports.inject = inject;
		exports.missingPrimitives = missingPrimitives;
		exports.name = name;
		return module.exports;
	}
});
